// SPDX-FileCopyrightText: 2010-2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com>
// SPDX-License-Identifier: BSD-2-Clause

#include <gpaste-gtk4/gpaste-gtk-preferences-dialog.h>
#include <gpaste-gtk4/gpaste-gtk-util.h>

/* Answered exactly once, as the text dialog is (GPasteGtkTextDialogData says
 * why each route is needed): from the response, or as a refusal when the
 * dialog or its window goes first. adw_alert_dialog_choose () answers nothing
 * then, which would leave the caller's @user_data for good. */
typedef struct
{
    GPasteGtkConfirmDialogCallback callback;
    gpointer                       user_data;
    gboolean                       answered;
} GPasteGtkConfirmDialogCallbackData;

static void
g_paste_gtk_confirm_dialog_answer (AdwDialog *dialog,
                                   gboolean   confirmed)
{
    GPasteGtkConfirmDialogCallbackData *data = g_object_get_data (G_OBJECT (dialog), "confirm-dialog-data");

    if (!data || data->answered)
        return;

    data->answered = TRUE;
    data->callback (confirmed, data->user_data);
}

static void
on_confirm_response (AdwAlertDialog *dialog,
                     const gchar    *response,
                     gpointer        user_data G_GNUC_UNUSED)
{
    g_paste_gtk_confirm_dialog_answer (ADW_DIALOG (dialog), g_paste_str_equal (response, "confirm"));
}

/* Connected as g_paste_gtk_text_dialog_cancel () is. */
static void
g_paste_gtk_confirm_dialog_refuse (AdwDialog *dialog)
{
    g_paste_gtk_confirm_dialog_answer (dialog, FALSE);
}

/**
 * g_paste_gtk_util_confirm_dialog:
 * @parent: (nullable): the parent #GtkWindow
 * @heading: the question being asked
 * @body: what confirming it does
 * @action: the label for the confirm button
 * @appearance: how the confirm button should look -- destructive only when
 *              something is actually lost
 * @on_confirmation: (closure user_data) (scope async): handed whether the user
 *                   confirmed -- called exactly once, a dialog whose window is
 *                   destroyed under it and a call that is refused both
 *                   answering %FALSE
 *
 * Ask the user for confirmation.
 *
 * The heading is the question, not the application's name and version: what an
 * alert is asking has to be readable from its title alone, and "GPaste 51.0"
 * asks nothing.
 */
G_PASTE_VISIBLE void
g_paste_gtk_util_confirm_dialog (GtkWindow                     *parent,
                                 const gchar                   *heading,
                                 const gchar                   *body,
                                 const gchar                   *action,
                                 AdwResponseAppearance          appearance,
                                 GPasteGtkConfirmDialogCallback on_confirmation,
                                 gpointer                       user_data)
{
    g_return_if_fail (on_confirmation);

    /* Hand-rolled, as in g_paste_gtk_util_text_dialog (): a refused call still
     * gives its answer. */
    if ((parent && !GTK_IS_WINDOW (parent)) || !action || !heading || !g_utf8_validate (heading, -1, NULL) ||
        (body && !g_utf8_validate (body, -1, NULL)))
    {
        g_critical ("%s: assertion failed: a #GtkWindow or no @parent, an @action, and a @heading and @body in UTF-8", G_STRFUNC);

        on_confirmation (FALSE, user_data);

        return;
    }

    GPasteGtkConfirmDialogCallbackData *data = g_new0 (GPasteGtkConfirmDialogCallbackData, 1);
    AdwAlertDialog *dialog = ADW_ALERT_DIALOG (adw_alert_dialog_new (heading, body));

    data->callback = on_confirmation;
    data->user_data = user_data;

    adw_alert_dialog_add_responses (dialog,
                                    "cancel",  _("Cancel"),
                                    "confirm", action,
                                    NULL);
    adw_alert_dialog_set_response_appearance (dialog, "confirm", appearance);
    /* Escape and Enter both land somewhere deliberate rather than on whatever
     * the default response happens to be. */
    adw_alert_dialog_set_default_response (dialog, "cancel");
    adw_alert_dialog_set_close_response (dialog, "cancel");

    g_object_set_data_full (G_OBJECT (dialog), "confirm-dialog-data", data, g_free);
    g_signal_connect (dialog, "response", G_CALLBACK (on_confirm_response), NULL);
    g_signal_connect (dialog, "destroy", G_CALLBACK (g_paste_gtk_confirm_dialog_refuse), NULL);
    if (parent)
        g_signal_connect_object (parent, "destroy", G_CALLBACK (g_paste_gtk_confirm_dialog_refuse), dialog, G_CONNECT_SWAPPED);

    adw_dialog_present (ADW_DIALOG (dialog), GTK_WIDGET (parent));
}

/**
 * g_paste_gtk_util_get_image_finish:
 * @client: the #GPasteClient the g_paste_client_get_image() call was made on
 * @result: the #GAsyncResult handed to the callback
 * @error: return location for a #GError, or %NULL
 *
 * Finish a g_paste_client_get_image() call as a ready-to-display texture. The
 * core client stays toolkit-free and hands image items over as bytes; this is
 * the GTK-side conversion for its consumers.
 *
 * It can fail on either half: fetching the item carries the #GPasteClient
 * domains (%G_PASTE_ERROR, %G_DBUS_ERROR, %G_IO_ERROR), while decoding bytes
 * GDK cannot make a texture out of yields %GDK_TEXTURE_ERROR.
 *
 * Returns: (transfer full) (nullable): the image as a newly allocated #GdkTexture
 */
G_PASTE_VISIBLE GdkTexture *
g_paste_gtk_util_get_image_finish (GPasteClient *client,
                                   GAsyncResult *result,
                                   GError      **error)
{
    g_autoptr (GBytes) bytes = g_paste_client_get_image_finish (client, result, error);

    if (!bytes)
        return NULL;

    return gdk_texture_new_from_bytes (bytes, error);
}

/**
 * g_paste_gtk_util_toast:
 * @origin: the #GtkWidget the message is about
 * @message: what to say
 *
 * Say something to the user, in the window @origin is in.
 *
 * Quiet when there is nowhere to say it: our application windows wrap their
 * content in an #AdwToastOverlay, the daemon's prompt windows do not, and a
 * widget torn down while a reply was in flight is in no window at all. Failing
 * quietly is right in each case — a prompt has no history list for an empty to
 * have failed on.
 */
G_PASTE_VISIBLE void
g_paste_gtk_util_toast (GtkWidget   *origin,
                        const gchar *message)
{
    g_return_if_fail (GTK_IS_WIDGET (origin));

    GtkRoot *root = gtk_widget_get_root (origin);

    if (!ADW_IS_APPLICATION_WINDOW (root))
        return;

    GtkWidget *content = adw_application_window_get_content (ADW_APPLICATION_WINDOW (root));

    if (!ADW_IS_TOAST_OVERLAY (content))
        return;

    AdwToast *toast = adw_toast_new (message);

    /* Plain: @message is a translation, and an & or a < a translator wrote
     * would have Pango refuse it as markup, the toast saying nothing at the
     * very moment it is the only report of a failure. No test reads a toast
     * back, AdwToastOverlay handing none out; the window's own is held to it
     * (/ui/daemon-presence/version-toast). */
    adw_toast_set_use_markup (toast, FALSE);
    adw_toast_overlay_add_toast (ADW_TOAST_OVERLAY (content), toast);
}

typedef struct
{
    GPasteClient *client;
    gchar        *history;
    GtkWindow    *parent; /* borrowed: it outlives the dialog it put up */
} EmptyHistoryCallbackData;

static void
on_history_emptied (GObject      *source_object,
                    GAsyncResult *result,
                    gpointer      user_data)
{
    g_autoptr (GtkWindow) parent = user_data;
    g_autoptr (GError) error = NULL;

    g_paste_client_empty_history_finish (G_PASTE_CLIENT (source_object), result, &error);

    if (!error)
        return;

    g_warning ("Could not empty the history: %s", error->message);

    /* empty_history() takes a parent it is allowed not to have -- a menu item is
     * a GObject, not a widget in a window -- and the toast helper asks for a
     * widget. Nowhere to say it is the quiet case it already documents. */
    if (parent)
        g_paste_gtk_util_toast (GTK_WIDGET (parent), _("Could not empty the history"));
}

static void
empty_history (GPasteClient *client,
               const gchar  *history,
               GtkWindow    *parent)
{
    g_paste_client_empty_history (client, history, NULL /* cancellable */, on_history_emptied,
                                  (parent) ? g_object_ref (parent) : NULL);
}

static void
empty_history_callback (gboolean confirmed,
                        gpointer user_data)
{
    g_autofree EmptyHistoryCallbackData *data = user_data;
    g_autoptr (GPasteClient) client = data->client;
    g_autofree gchar *history = data->history;

    /* Not once the daemon has left with the question up: the call would be what
     * the bus starts one on, only to empty its history, or reach one standing
     * down. */
    if (confirmed && g_paste_client_get_daemon_presence (client) == G_PASTE_DAEMON_PRESENCE_READY)
        empty_history (client, history, data->parent);
}

/**
 * g_paste_gtk_util_empty_history:
 * @parent_window: (nullable): the parent #GtkWindow
 * @client: a #GPasteClient instance
 * @settings: a #GPasteSettings instance
 * @history: the name of the history to empty
 *
 * Empty history after prompting user for confirmation
 */
G_PASTE_VISIBLE void
g_paste_gtk_util_empty_history (GtkWindow      *parent_window,
                                GPasteClient   *client,
                                GPasteSettings *settings,
                                const gchar    *history)
{
    g_return_if_fail (!parent_window || GTK_IS_WINDOW (parent_window));
    g_return_if_fail (G_PASTE_IS_CLIENT (client));
    g_return_if_fail (G_PASTE_IS_SETTINGS (settings));
    g_return_if_fail (history);

    if (g_paste_settings_get_empty_history_confirmation (settings))
    {
        EmptyHistoryCallbackData *data = g_new (EmptyHistoryCallbackData, 1);

        data->client = g_object_ref (client);
        data->history = g_strdup (history);
        data->parent = parent_window;

        /* Translators: %s is the name of the history being emptied. */
        g_autofree gchar *heading = g_strdup_printf (_("Empty \u201c%s\u201d?"), history);
        g_paste_gtk_util_confirm_dialog (parent_window,
                                         heading,
                                         _("Every item it holds is deleted for good."),
                                         C_("verb", "Empty"),
                                         ADW_RESPONSE_DESTRUCTIVE,
                                         empty_history_callback,
                                         data);
    }
    else
        empty_history (client, history, parent_window);
}

/**
 * g_paste_gtk_util_show_window:
 * @application: a #GtkApplication
 *
 * Present the application's window to user
 */
G_PASTE_VISIBLE void
g_paste_gtk_util_show_window (GApplication *application)
{
    g_return_if_fail (GTK_IS_APPLICATION (application));

    for (GList *wins = gtk_application_get_windows (GTK_APPLICATION (application)); wins; wins = g_list_next (wins))
    {
        if (GTK_IS_WIDGET (wins->data) && gtk_widget_get_realized (wins->data))
            gtk_window_present (wins->data);
    }
}

static void
on_form_dialog_cancel (GtkButton *button,
                       gpointer   user_data G_GNUC_UNUSED)
{
    adw_dialog_close (ADW_DIALOG (gtk_widget_get_ancestor (GTK_WIDGET (button), ADW_TYPE_DIALOG)));
}

/**
 * g_paste_gtk_util_form_dialog:
 * @heading: what the dialog is for
 * @confirm_label: the label of the confirm button
 * @content: (transfer none): what fills the dialog under its header bar
 * @width: the content width to give the dialog
 * @height: the content height to give it, or 0 to let @content ask for its own
 * @confirm: (out) (transfer none): the confirm button, which the caller connects
 *           to and is free to follow -- desensitizing it while the form is
 *           incomplete, and again once it has been pressed, since closing is
 *           asynchronous and the button stays live until it happens
 *
 * The shell every composer puts up: @content under a header bar offering to
 * cancel or to confirm, cancelling being all it handles by itself.
 *
 * A dialog rather than an alert: an alert is a short message with a question
 * attached, and a composer is neither -- a text editor six hundred pixels wide,
 * or a small form in a boxed list.
 *
 * Returns: (transfer none): the dialog, not presented yet: the caller still has
 *          its own data to hang off it
 */
G_PASTE_VISIBLE AdwDialog *
g_paste_gtk_util_form_dialog (const gchar  *heading,
                              const gchar  *confirm_label,
                              GtkWidget    *content,
                              gint          width,
                              gint          height,
                              GtkWidget   **confirm)
{
    g_return_val_if_fail (heading, NULL);
    g_return_val_if_fail (confirm_label, NULL);
    g_return_val_if_fail (GTK_IS_WIDGET (content), NULL);
    g_return_val_if_fail (confirm, NULL);

    GtkWidget *cancel = gtk_button_new_with_label (_("Cancel"));

    *confirm = gtk_button_new_with_label (confirm_label);

    gtk_widget_add_css_class (*confirm, "suggested-action");
    g_signal_connect (cancel, "clicked", G_CALLBACK (on_form_dialog_cancel), NULL);

    GtkWidget *header = adw_header_bar_new ();

    adw_header_bar_set_show_start_title_buttons (ADW_HEADER_BAR (header), FALSE);
    adw_header_bar_set_show_end_title_buttons (ADW_HEADER_BAR (header), FALSE);
    adw_header_bar_pack_start (ADW_HEADER_BAR (header), cancel);
    adw_header_bar_pack_end (ADW_HEADER_BAR (header), *confirm);

    GtkWidget *toolbar = adw_toolbar_view_new ();

    adw_toolbar_view_add_top_bar (ADW_TOOLBAR_VIEW (toolbar), header);
    adw_toolbar_view_set_content (ADW_TOOLBAR_VIEW (toolbar), content);

    AdwDialog *dialog = adw_dialog_new ();

    adw_dialog_set_title (dialog, heading);
    adw_dialog_set_content_width (dialog, width);
    if (height)
        adw_dialog_set_content_height (dialog, height);
    adw_dialog_set_child (dialog, toolbar);

    return dialog;
}

/* The longest line the composer will put in a #GtkTextView, in characters.
 *
 * A #GtkTextView lays a line out again whenever that line changes, so what an
 * edit costs is the length of the line it lands in and not the size of the
 * text: a megabyte spread over ordinary lines answers a keystroke in about
 * twenty milliseconds, a single line of that size in more than a second.
 *
 * The cost is linear in the length of the line, at roughly a microsecond per
 * character in a 600x400 view -- 10k characters to a keystroke of 10ms, 20k to
 * 20ms, 40k to 42ms, 80k to 93ms, 300k to 578ms. The wrap mode only scales it:
 * GTK_WRAP_NONE is the cheapest at a third of the cost and still 172ms at 300k,
 * and GTK_WRAP_CHAR is four times dearer than the GTK_WRAP_WORD used below, so
 * there is no way to lay such a line out and keep up with typing.
 *
 * 50000 is the last round number whose keystroke still fits in a few frames,
 * and the curve above it has no second knee to aim at: what is workable and
 * what is not are the same thing at different speeds, so the number is a
 * judgement about the slowest edit worth offering rather than a preference
 * anyone can hold, and it stays a constant for that reason. Moving it is one
 * line, and the measurements that say where to move it are made by typing into
 * a view, not by the person doing the typing.
 */
#define MAX_COMPOSABLE_LINE 50000

/* Whether inserting @text between the @before characters a line already has
 * ahead of the caret and the @after ones behind it would put any line past the
 * limit.
 *
 * Every line the insertion makes is measured: the first segment of @text
 * continues the line it lands in, the last is continued by the caret's own tail,
 * and each segment between them is a whole line of its own. A paste is the case
 * this exists for, and a paste of several lines is one whose long line is as
 * likely to be its third as its first.
 *
 * Lines are split where GtkTextBuffer splits them, which is at every paragraph
 * delimiter pango knows -- "\n", "\r", "\r\n" and U+2029 alike -- and not at
 * "\n" alone: the cost MAX_COMPOSABLE_LINE bounds is the view's, per line it
 * lays out, so text broken by carriage returns is as many short lines to the
 * view as text broken by newlines, and splitting on "\n" only would refuse it as
 * one long line (/ui/text_dialog/cr_lines_opened). */
static gboolean
insertion_has_uncomposable_line (const gchar *text,
                                 gsize        size,
                                 glong        before,
                                 glong        after)
{
    const gchar *end = text + size;

    for (const gchar *line = text; ; )
    {
        gint delimiter;
        gint next;

        pango_find_paragraph_boundary (line, end - line, &delimiter, &next);

        /* No delimiter left: the boundary is the end of @text itself. */
        gboolean last = (delimiter == next);
        glong length = g_utf8_strlen (line, delimiter);

        if (line == text)
            length += before;
        if (last)
            length += after;

        if (length > MAX_COMPOSABLE_LINE)
            return TRUE;

        if (last)
            return FALSE;

        line += next;
    }
}

/* Whether any line of @text is longer than MAX_COMPOSABLE_LINE: an insertion
 * into an empty view. Answered rather than measured -- stopping at the first
 * line over the limit is what keeps this off the length of the text. */
static gboolean
text_has_uncomposable_line (const gchar *text)
{
    return insertion_has_uncomposable_line (text, strlen (text), 0, 0);
}

/* The characters behind @iter up to its line's delimiter -- the half of the line
 * an edit at @iter is continued by; the half ahead of it is
 * gtk_text_iter_get_line_offset (). Shared by the insertion and the deletion
 * check below, so the two cannot come to disagree on where a line ends -- which
 * is GtkTextBuffer's own answer, at every delimiter it breaks on. */
static glong
chars_after_on_line (const GtkTextIter *iter)
{
    GtkTextIter end = *iter;

    if (!gtk_text_iter_ends_line (&end))
        gtk_text_iter_forward_to_line_end (&end);

    return gtk_text_iter_get_offset (&end) - gtk_text_iter_get_offset (iter);
}

/* Refuse an insertion that would take a line past the limit -- a paste, above
 * all, which is how a line that long gets into a view that refused to open with
 * one. The bell is what says so: a toast would come up behind the dialog it is
 * about. */
static void
on_text_dialog_insert_text (GtkTextBuffer *buffer,
                            GtkTextIter   *location,
                            gchar         *text,
                            gint           len,
                            gpointer       user_data)
{
    GtkWidget *view = user_data;
    gsize size = (len < 0) ? strlen (text) : (gsize) len;
    glong before = gtk_text_iter_get_line_offset (location);
    glong after = chars_after_on_line (location);

    if (!insertion_has_uncomposable_line (text, size, before, after))
        return;

    gtk_widget_error_bell (view);
    g_signal_stop_emission_by_name (buffer, "insert-text");
}

/* Refuse a deletion that would join two lines into one past the limit.
 *
 * Deleting across a line break makes one line out of the text ahead of @start on
 * its line and the text behind @end on its own, and two lines each under the
 * limit can add up to one well past it: the insertion check above never sees
 * that, nothing being inserted, and without this the limit is one Delete key
 * away from the freeze it exists to prevent. Refused the way an insertion is
 * (/ui/text_dialog/joined_line_refused). */
static void
on_text_dialog_delete_range (GtkTextBuffer *buffer,
                             GtkTextIter   *start,
                             GtkTextIter   *end,
                             gpointer       user_data)
{
    GtkWidget *view = user_data;

    /* Within one line, a deletion only ever shortens it. */
    if (gtk_text_iter_get_line (start) == gtk_text_iter_get_line (end))
        return;

    if (gtk_text_iter_get_line_offset (start) + chars_after_on_line (end) <= MAX_COMPOSABLE_LINE)
        return;

    gtk_widget_error_bell (view);
    g_signal_stop_emission_by_name (buffer, "delete-range");
}

/* Kept on the dialog, so it lives exactly as long as the dialog does. @answer
 * is what the user wrote, set only when they confirmed: the result is delivered
 * from "closed", which is the way out of the dialog every choice of the user's
 * goes through.
 *
 * Not the only way out, though: a dialog whose window is destroyed under it goes
 * without emitting "closed". The callback is then answered as a cancellation, so
 * it is answered exactly once whatever happens -- which is what lets a caller
 * hand its state over to @user_data and free it there, holding nothing else, its
 * window above all (/ui/edit_item/closed_with_dialog_up).
 *
 * Answered from the window's "destroy", and from the dialog's own for a dialog
 * that goes any other way; never from this being freed with the dialog's data,
 * which happens at finalize. Nor is the dialog's "destroy" alone enough: a
 * dialog something else still holds -- an accessible, a pending animation, the
 * inspector -- is only unparented when its window goes, not disposed, and emits
 * nothing until that reference is dropped, the caller's state waiting on it. The
 * first answer sets @answered, whichever route gives it, and every later one is
 * a no-op. A callback answered from either must not reach back for the dialog. */
typedef struct
{
    GPasteGtkTextDialogCallback callback;
    gpointer                    user_data;
    GtkTextBuffer              *buffer;
    gchar                      *answer;
    gboolean                    answered;
} GPasteGtkTextDialogData;

static void
g_paste_gtk_text_dialog_data_free (gpointer user_data)
{
    GPasteGtkTextDialogData *data = user_data;

    g_free (data->answer);
    g_free (data);
}

/* Exactly once: see the struct. */
static void
g_paste_gtk_text_dialog_answer (AdwDialog *dialog,
                                gboolean   cancelled)
{
    GPasteGtkTextDialogData *data = g_object_get_data (G_OBJECT (dialog), "text-dialog-data");

    if (!data || data->answered)
        return;

    data->answered = TRUE;
    data->callback ((cancelled) ? NULL : data->answer, data->user_data);
}

/* Connected straight to the dialog's "destroy" and, swapped, to its parent's:
 * both hand it the dialog first and something it ignores after. */
static void
g_paste_gtk_text_dialog_cancel (AdwDialog *dialog)
{
    g_paste_gtk_text_dialog_answer (dialog, TRUE);
}

static void
on_text_dialog_closed (AdwDialog *dialog,
                       gpointer   user_data G_GNUC_UNUSED)
{
    g_paste_gtk_text_dialog_answer (dialog, FALSE);
}

/* An empty text is no item: nothing to add, and an edit emptying one would be a
 * deletion, which is not what confirming asks for. */
static void
on_text_dialog_changed (GtkTextBuffer *buffer,
                        gpointer       user_data)
{
    gtk_widget_set_sensitive (user_data, gtk_text_buffer_get_char_count (buffer) > 0);
}

static void
on_text_dialog_confirm (GtkButton *button,
                        gpointer   user_data G_GNUC_UNUSED)
{
    AdwDialog *dialog = ADW_DIALOG (gtk_widget_get_ancestor (GTK_WIDGET (button), ADW_TYPE_DIALOG));
    GPasteGtkTextDialogData *data = g_object_get_data (G_OBJECT (dialog), "text-dialog-data");
    GtkTextIter start, end;

    gtk_text_buffer_get_bounds (data->buffer, &start, &end);
    /* Closing is what delivers the answer, and the close below is asynchronous:
     * the button is still live until it happens, so a second press would drop
     * the first answer on the floor. */
    g_free (data->answer);
    data->answer = gtk_text_buffer_get_text (data->buffer, &start, &end, FALSE);

    adw_dialog_close (dialog);
}

/**
 * g_paste_gtk_util_can_host_dialog:
 * @window: (nullable): a #GtkWindow
 *
 * Whether libadwaita puts a dialog presented over @window inside it: an
 * #AdwWindow or #AdwApplicationWindow that can be resized. Over anything else,
 * %NULL included, it gives the dialog a window of its own instead.
 *
 * Returns: whether @window can be the parent of g_paste_gtk_util_text_dialog ()
 */
G_PASTE_VISIBLE gboolean
g_paste_gtk_util_can_host_dialog (GtkWindow *window)
{
    return (ADW_IS_WINDOW (window) || ADW_IS_APPLICATION_WINDOW (window)) && gtk_window_get_resizable (window);
}

/**
 * g_paste_gtk_util_text_dialog:
 * @parent: the parent window, one g_paste_gtk_util_can_host_dialog () accepts
 * @heading: what the dialog is for
 * @confirm_label: the label of the confirm button
 * @text: (nullable): what the text view starts with
 * @callback: (closure user_data) (scope async): handed what the user wrote,
 *            never empty, or %NULL if they cancelled -- called exactly once, a
 *            dialog whose window is destroyed under it and a call that is
 *            refused both answering %NULL
 *
 * The dialog for composing an item: a wrapping, scrollable text view in the shell
 * g_paste_gtk_util_form_dialog () puts up. Both adding a new item and editing an
 * existing one put up the same one.
 */
G_PASTE_VISIBLE void
g_paste_gtk_util_text_dialog (GtkWindow                  *parent,
                              const gchar                *heading,
                              const gchar                *confirm_label,
                              const gchar                *text,
                              GPasteGtkTextDialogCallback callback,
                              gpointer                    user_data)
{
    g_return_if_fail (callback);

    /* A parent the dialog can live in, and nothing else. A window of its own
     * would have a life of its own: it outlives its parent, goes before it, and
     * is freed under libadwaita's own close when an answer takes the parent
     * down -- each a way to answer twice, not at all, or to use freed memory.
     *
     * Hand-rolled where the check above uses g_return_if_fail (), as in
     * g_paste_clipboard_provider_sync_text (): the answer is what frees the
     * caller's state, so a refused call still gives it
     * (/ui/text_dialog_answer/foreign_parent_refused,
     * /ui/text_dialog_answer/fixed_size_parent_refused). */
    if (!g_paste_gtk_util_can_host_dialog (parent) || !heading || !confirm_label)
    {
        g_critical ("%s: assertion failed: a @parent g_paste_gtk_util_can_host_dialog () accepts, a @heading and a @confirm_label", G_STRFUNC);

        callback (NULL, user_data);

        return;
    }

    /* Never opened over a line the view cannot lay out at typing speed (see
     * MAX_COMPOSABLE_LINE): showing it is already seconds of frozen window, and
     * every edit after that is another one. Answered like a cancellation, which
     * is what the caller is built for. */
    if (text && text_has_uncomposable_line (text))
    {
        g_paste_gtk_util_toast (GTK_WIDGET (parent), _("This item has a line too long to edit"));

        callback (NULL, user_data);

        return;
    }

    GtkWidget *view = gtk_text_view_new ();
    GtkTextView *tv = GTK_TEXT_VIEW (view);
    GtkWidget *scroll = gtk_scrolled_window_new ();
    GtkScrolledWindow *sw = GTK_SCROLLED_WINDOW (scroll);
    GtkTextBuffer *buffer = gtk_text_view_get_buffer (tv);

    gtk_text_view_set_wrap_mode (tv, GTK_WRAP_WORD);
    gtk_text_view_set_top_margin (tv, 6);
    gtk_text_view_set_bottom_margin (tv, 6);
    gtk_text_view_set_left_margin (tv, 6);
    gtk_text_view_set_right_margin (tv, 6);

    if (text)
        gtk_text_buffer_set_text (buffer, text, -1);

    g_signal_connect (buffer, "insert-text", G_CALLBACK (on_text_dialog_insert_text), view);
    g_signal_connect (buffer, "delete-range", G_CALLBACK (on_text_dialog_delete_range), view);

    gtk_scrolled_window_set_child (sw, view);
    gtk_widget_set_vexpand (scroll, TRUE);

    GtkWidget *confirm;
    AdwDialog *dialog = g_paste_gtk_util_form_dialog (heading, confirm_label, scroll, 600, 400, &confirm);

    g_signal_connect (confirm, "clicked", G_CALLBACK (on_text_dialog_confirm), NULL);
    g_signal_connect_object (buffer, "changed", G_CALLBACK (on_text_dialog_changed), confirm, 0);
    on_text_dialog_changed (buffer, confirm);

    GPasteGtkTextDialogData *data = g_new0 (GPasteGtkTextDialogData, 1);

    data->callback = callback;
    data->user_data = user_data;
    data->buffer = buffer;

    g_object_set_data_full (G_OBJECT (dialog), "text-dialog-data", data, g_paste_gtk_text_dialog_data_free);
    g_signal_connect (dialog, "closed", G_CALLBACK (on_text_dialog_closed), NULL);
    g_signal_connect (dialog, "destroy", G_CALLBACK (g_paste_gtk_text_dialog_cancel), NULL);
    /* Gone with the dialog, g_signal_connect_object () disconnecting it then. */
    g_signal_connect_object (parent, "destroy", G_CALLBACK (g_paste_gtk_text_dialog_cancel), dialog, G_CONNECT_SWAPPED);

    adw_dialog_present (dialog, GTK_WIDGET (parent));
    gtk_widget_grab_focus (view);
}

/* The meter, kept on the row rather than handed back beside it: AdwActionRow is
 * a final type, so there is nowhere else to put it, and a caller that only ever
 * rates what was typed has no use for the widget itself. */
#define STRENGTH_BAR_KEY "password-strength-bar"
/* What is waiting to be rated, kept on the row for the same reason. */
#define STRENGTH_RATING_KEY "password-strength-rating"

/* @source rather than the password itself: a copy here would be a second one of
 * the cleartext, in ordinary pageable heap, kept for as long as the row lives
 * and released without being wiped -- where the entry's own buffer is a copy
 * that exists either way. The waiting rating reads it when it comes to run,
 * which is also what makes the rate limit right: what is rated is whatever the
 * entry holds then, not whatever it held when the timer was armed. */
typedef struct
{
    GtkWidget   *row;
    GtkEditable *source;
    guint        id;
} GPasteGtkStrengthRating;

static void
g_paste_gtk_strength_rating_free (gpointer user_data)
{
    GPasteGtkStrengthRating *rating = user_data;

    g_clear_handle_id (&rating->id, g_source_remove);
    g_clear_weak_pointer (&rating->source);
    g_free (rating);
}

static void
g_paste_gtk_strength_rating_apply (gpointer user_data)
{
    GPasteGtkStrengthRating *rating = user_data;
    GtkWidget *bar = g_object_get_data (G_OBJECT (rating->row), STRENGTH_BAR_KEY);

    rating->id = 0;

    /* The entry went before the rating waiting on it did: what it held is gone
     * with it, and so is the form it was being typed into. */
    if (!rating->source)
        return;

    g_autofree gchar *hint = NULL;
    guint strength = g_paste_util_password_strength (gtk_editable_get_text (rating->source), &hint);

    gtk_level_bar_set_value (GTK_LEVEL_BAR (bar), strength);
    adw_action_row_set_subtitle (ADW_ACTION_ROW (rating->row), (hint) ? hint : "");
}

/* The row is going, and the rating waiting on it would land on a meter its
 * children no longer include. Dropping the data is what stops it: ::destroy runs
 * at the top of the row's dispose, before anything it holds is unparented. The
 * meter goes with it, which is what makes every later rate () a no-op: dropping
 * the rating alone would leave one arriving during that same dispose arming a
 * fresh rating on a row about to be finalized. */
static void
on_strength_row_destroy (GtkWidget *row,
                         gpointer   user_data G_GNUC_UNUSED)
{
    g_object_set_data (G_OBJECT (row), STRENGTH_RATING_KEY, NULL);
    g_object_set_data (G_OBJECT (row), STRENGTH_BAR_KEY, NULL);
}

/**
 * g_paste_gtk_util_password_strength_row_new:
 * @title: what the row is called
 * @unavailable: (nullable): what to say when this build cannot rate anything,
 *               or %NULL for the standard wording
 *
 * The row rating a password as it is typed: a colour-graded meter, and the
 * rating word or libpwquality's own advice as the subtitle.
 *
 * Built without libpwquality there is nothing to rate with, and the row says so
 * and goes insensitive rather than being left out — someone choosing a password
 * should know it is not being judged, instead of reading a silent absence as
 * approval. What it says is this function's to decide, since the condition is:
 * a caller passes @unavailable only when it wants different words for the same
 * thing, as the passphrase prompt does, and one that has nothing of its own to
 * say passes %NULL rather than repeating the sentence.
 *
 * Returns: (transfer none): a newly created #AdwActionRow, to be rated with
 *          g_paste_gtk_util_password_strength_row_rate ()
 */
G_PASTE_VISIBLE GtkWidget *
g_paste_gtk_util_password_strength_row_new (const gchar *title,
                                            const gchar *unavailable)
{
    g_return_val_if_fail (title, NULL);

    GtkWidget *row = adw_action_row_new ();

    /* Plain text, both of it: a translation and libpwquality's advice, neither
     * of them markup, where one "&" would blank the label. */
    adw_preferences_row_set_use_markup (ADW_PREFERENCES_ROW (row), FALSE);
    adw_preferences_row_set_title (ADW_PREFERENCES_ROW (row), title);

    if (!g_paste_util_pwquality_available ())
    {
        adw_action_row_set_subtitle (ADW_ACTION_ROW (row),
                                     unavailable ? unavailable
                                                 : _("Password strength rating is not available in this build"));
        gtk_widget_set_sensitive (row, FALSE);

        return row;
    }

    GtkWidget *bar = gtk_level_bar_new ();
    GtkLevelBar *level = GTK_LEVEL_BAR (bar);

    gtk_level_bar_set_min_value (level, 0);
    gtk_level_bar_set_max_value (level, G_PASTE_UTIL_STRENGTH_MAX);
    /* Colour the meter red → orange → green as the rating climbs. */
    gtk_level_bar_add_offset_value (level, GTK_LEVEL_BAR_OFFSET_LOW, 1);
    gtk_level_bar_add_offset_value (level, GTK_LEVEL_BAR_OFFSET_HIGH, 3);
    gtk_level_bar_add_offset_value (level, GTK_LEVEL_BAR_OFFSET_FULL, G_PASTE_UTIL_STRENGTH_MAX);
    gtk_widget_set_valign (bar, GTK_ALIGN_CENTER);
    gtk_widget_set_size_request (bar, 120, -1);

    g_object_set_data (G_OBJECT (row), STRENGTH_BAR_KEY, bar);
    adw_action_row_add_suffix (ADW_ACTION_ROW (row), bar);

    return row;
}

/**
 * g_paste_gtk_util_password_strength_row_rate:
 * @row: (transfer none): a row from g_paste_gtk_util_password_strength_row_new ()
 * @source: (transfer none): the editable the password is being typed into
 *
 * Show how what @source holds rates, in the meter and in the subtitle. What is
 * shown is always what it holds latest, but shortly after the call rather than
 * within it: see %G_PASTE_UTIL_STRENGTH_RATING_DELAY.
 *
 * The editable rather than its text: rating a password means holding it until
 * the rating runs, and the entry is already holding it -- where a string handed
 * here would have to be copied into a second buffer, one this library would keep
 * for the row's lifetime and free without wiping.
 *
 * A no-op on a row with no meter. A build without libpwquality has none: the
 * row already says so, and overwriting that with an empty rating would take the
 * explanation away. Neither has a row that has been destroyed, which is what
 * keeps a rating from being armed on one.
 */
G_PASTE_VISIBLE void
g_paste_gtk_util_password_strength_row_rate (GtkWidget   *row,
                                             GtkEditable *source)
{
    g_return_if_fail (ADW_IS_ACTION_ROW (row));
    g_return_if_fail (GTK_IS_EDITABLE (source));

    GtkWidget *bar = g_object_get_data (G_OBJECT (row), STRENGTH_BAR_KEY);

    if (!bar)
        return;

    GPasteGtkStrengthRating *rating = g_object_get_data (G_OBJECT (row), STRENGTH_RATING_KEY);

    if (!rating)
    {
        rating = g_new0 (GPasteGtkStrengthRating, 1);
        rating->row = row;

        g_object_set_data_full (G_OBJECT (row), STRENGTH_RATING_KEY, rating, g_paste_gtk_strength_rating_free);
        g_signal_connect (row, "destroy", G_CALLBACK (on_strength_row_destroy), NULL);
    }

    /* Weakly, so an entry that goes before its row leaves the waiting rating with
     * nothing to read rather than a dangling pointer to read it from. */
    g_set_weak_pointer (&rating->source, source);

    if (rating->id)
        return;

    rating->id = g_timeout_add_once (G_PASTE_UTIL_STRENGTH_RATING_DELAY, g_paste_gtk_strength_rating_apply, rating);
    g_source_set_name_by_id (rating->id, "[GPaste] password strength rating");
}

/* Nothing to read a number from is no number: left alone, a cleared field
 * would commit 0 as it loses the focus. */
static gint
refuse_blank_input (AdwSpinRow *row,
                    gdouble    *new_value G_GNUC_UNUSED,
                    gpointer    user_data G_GNUC_UNUSED)
{
    g_autofree gchar *text = g_strdup (gtk_editable_get_text (GTK_EDITABLE (row)));

    return (*g_strstrip (text)) ? FALSE : GTK_INPUT_ERROR;
}

/**
 * g_paste_gtk_util_spin_row_new:
 * @min: the smallest value the row takes
 * @max: the largest value the row takes
 * @step: the step between proposed values
 *
 * A row for a number in that range which commits only a value the range takes:
 * anything else puts the row's own value back. Committing whatever is there --
 * a field cleared to type another number into, or holding no number at all --
 * would set the range's minimum as it loses the focus: a maximum history size
 * trimming the history to five items there and then, a password's timeout going
 * to 0, which never takes it off the clipboard.
 *
 * Returns: (transfer floating): a newly created #AdwSpinRow
 */
G_PASTE_VISIBLE GtkWidget *
g_paste_gtk_util_spin_row_new (gdouble min,
                               gdouble max,
                               gdouble step)
{
    AdwSpinRow *row = ADW_SPIN_ROW (adw_spin_row_new_with_range (min, max, step));

    adw_spin_row_set_update_policy (row, GTK_UPDATE_IF_VALID);
    g_signal_connect (row, "input", G_CALLBACK (refuse_blank_input), NULL);

    return GTK_WIDGET (row);
}
