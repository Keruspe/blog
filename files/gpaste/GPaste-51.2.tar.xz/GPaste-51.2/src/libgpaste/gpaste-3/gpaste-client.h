// SPDX-FileCopyrightText: 2010-2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com>
// SPDX-License-Identifier: BSD-2-Clause

#if !defined (__G_PASTE_H_INSIDE__) && !defined (G_PASTE_COMPILATION)
#error "Only <gpaste.h> can be included directly."
#endif

#pragma once

#include <gpaste-3/gpaste-client-history.h>
#include <gpaste-3/gpaste-client-item.h>
#include <gpaste-3/gpaste-item-enums.h>

G_BEGIN_DECLS

/**
 * GPasteDaemonPresence:
 * @G_PASTE_DAEMON_PRESENCE_ABSENT: there is no daemon to talk to, nor one on
 *   its way: nobody owns the bus name, or -- for a client following the daemon
 *   -- its owner has not served a history in two minutes. Any client turns
 *   ready by itself should one come back
 * @G_PASTE_DAEMON_PRESENCE_STARTING: there is no daemon to talk to yet, but one
 *   is on its way
 * @G_PASTE_DAEMON_PRESENCE_READY: a daemon is there and serving a history
 *
 * Whether a #GPasteClient has a daemon to talk to: see
 * #GPasteClient:daemon-presence.
 */
typedef enum {
    G_PASTE_DAEMON_PRESENCE_ABSENT,
    G_PASTE_DAEMON_PRESENCE_STARTING,
    G_PASTE_DAEMON_PRESENCE_READY
} GPasteDaemonPresence;

#define G_PASTE_TYPE_DAEMON_PRESENCE (g_paste_daemon_presence_get_type ())
GType g_paste_daemon_presence_get_type (void);

#define G_PASTE_TYPE_CLIENT (g_paste_client_get_type ())

G_PASTE_FINAL_TYPE (Client, client, CLIENT, GDBusProxy)

/*******************/
/* Methods /  Sync */
/*******************/

gchar   *g_paste_client_add_text_sync                   (GPasteClient  *self,
                                                         const gchar   *text,
                                                         GError       **error);
gchar   *g_paste_client_add_file_sync                   (GPasteClient  *self,
                                                         const gchar   *file,
                                                         GError       **error);
gchar   *g_paste_client_add_password_sync               (GPasteClient  *self,
                                                         const gchar   *name,
                                                         const gchar   *password,
                                                         guint          timeout,
                                                         GError       **error);
void     g_paste_client_backup_history_sync             (GPasteClient  *self,
                                                         const gchar   *history,
                                                         const gchar   *backup,
                                                         GError       **error);
void     g_paste_client_change_passphrase_sync          (GPasteClient  *self,
                                                         GError       **error);
void     g_paste_client_delete_item_sync                (GPasteClient  *self,
                                                         const gchar   *uuid,
                                                         GError       **error);
void     g_paste_client_delete_history_sync             (GPasteClient  *self,
                                                         const gchar   *name,
                                                         GError       **error);
void     g_paste_client_delete_password_sync            (GPasteClient  *self,
                                                         const gchar   *name,
                                                         GError       **error);
GStrv    g_paste_client_doctor_sync                     (GPasteClient  *self,
                                                         gboolean      *healthy,
                                                         GError       **error);
void     g_paste_client_empty_history_sync              (GPasteClient  *self,
                                                         const gchar   *name,
                                                         GError       **error);
GPasteClientItem *g_paste_client_get_item_sync          (GPasteClient  *self,
                                                         const gchar   *uuid,
                                                         GError       **error);
GList   *g_paste_client_get_items_sync                  (GPasteClient  *self,
                                                         const gchar * const *uuids,
                                                         GError       **error);
GList   *g_paste_client_get_favourites_sync             (GPasteClient  *self,
                                                         GError       **error);
GList   *g_paste_client_get_history_sync                (GPasteClient  *self,
                                                         GError       **error);
guint64  g_paste_client_get_history_size_sync           (GPasteClient  *self,
                                                         GError       **error);
GBytes  *g_paste_client_get_image_sync                  (GPasteClient  *self,
                                                         const gchar   *uuid,
                                                         GError       **error);
guint    g_paste_client_get_password_timeout_sync       (GPasteClient  *self,
                                                         const gchar   *uuid,
                                                         GError       **error);
GStrv    g_paste_client_get_uris_sync                   (GPasteClient  *self,
                                                         const gchar   *uuid,
                                                         GError       **error);
GList   *g_paste_client_list_histories_sync             (GPasteClient  *self,
                                                         GError       **error);
gchar   *g_paste_client_merge_sync                      (GPasteClient  *self,
                                                         const gchar   *decoration,
                                                         const gchar   *separator,
                                                         const gchar * const *uuids,
                                                         GError       **error);
void     g_paste_client_report_extension_state_sync     (GPasteClient  *self,
                                                         gboolean       state,
                                                         GError       **error);
void     g_paste_client_reexecute_sync                  (GPasteClient  *self,
                                                         GError       **error);
gchar   *g_paste_client_replace_sync                    (GPasteClient  *self,
                                                         const gchar   *uuid,
                                                         const gchar   *contents,
                                                         GError       **error);
GList   *g_paste_client_search_sync                     (GPasteClient  *self,
                                                         const gchar   *pattern,
                                                         GError       **error);
void     g_paste_client_select_sync                     (GPasteClient  *self,
                                                         const gchar   *uuid,
                                                         GError       **error);
void     g_paste_client_set_favourite_sync              (GPasteClient  *self,
                                                         const gchar   *uuid,
                                                         gboolean       favourite,
                                                         GError       **error);
gchar   *g_paste_client_make_password_sync              (GPasteClient  *self,
                                                         const gchar   *uuid,
                                                         const gchar   *name,
                                                         guint          timeout,
                                                         GError       **error);
void     g_paste_client_show_history_sync               (GPasteClient  *self,
                                                         GError       **error);
void     g_paste_client_strip_rich_text_sync            (GPasteClient  *self,
                                                         const gchar   *uuid,
                                                         GError       **error);
void     g_paste_client_switch_history_sync             (GPasteClient  *self,
                                                         const gchar   *name,
                                                         GError       **error);
void     g_paste_client_set_active_sync                 (GPasteClient  *self,
                                                         gboolean       state,
                                                         GError       **error);
gchar   *g_paste_client_upload_sync                     (GPasteClient  *self,
                                                         const gchar   *uuid,
                                                         GError       **error);
gchar   *g_paste_client_upload_and_copy_sync            (GPasteClient  *self,
                                                         const gchar   *uuid,
                                                         GError       **error);

GPasteClientItem *g_paste_client_get_item_at_index_sync (GPasteClient  *self,
                                                         guint64        index,
                                                         GError       **error);
/*******************/
/* Methods / Async */
/*******************/

void g_paste_client_add_text                   (GPasteClient       *self,
                                                const gchar        *text,
                                                GCancellable       *cancellable,
                                                GAsyncReadyCallback callback,
                                                gpointer            user_data);
void g_paste_client_add_file                   (GPasteClient       *self,
                                                const gchar        *file,
                                                GCancellable       *cancellable,
                                                GAsyncReadyCallback callback,
                                                gpointer            user_data);
void g_paste_client_add_password               (GPasteClient       *self,
                                                const gchar        *name,
                                                const gchar        *password,
                                                guint               timeout,
                                                GCancellable       *cancellable,
                                                GAsyncReadyCallback callback,
                                                gpointer            user_data);
void g_paste_client_backup_history             (GPasteClient       *self,
                                                const gchar        *history,
                                                const gchar        *backup,
                                                GCancellable       *cancellable,
                                                GAsyncReadyCallback callback,
                                                gpointer            user_data);
void g_paste_client_change_passphrase          (GPasteClient       *self,
                                                GCancellable       *cancellable,
                                                GAsyncReadyCallback callback,
                                                gpointer            user_data);
void g_paste_client_delete_item                (GPasteClient       *self,
                                                const gchar        *uuid,
                                                GCancellable       *cancellable,
                                                GAsyncReadyCallback callback,
                                                gpointer            user_data);
void g_paste_client_delete_history             (GPasteClient       *self,
                                                const gchar        *name,
                                                GCancellable       *cancellable,
                                                GAsyncReadyCallback callback,
                                                gpointer            user_data);
void g_paste_client_delete_password            (GPasteClient       *self,
                                                const gchar        *name,
                                                GCancellable       *cancellable,
                                                GAsyncReadyCallback callback,
                                                gpointer            user_data);
void g_paste_client_doctor                     (GPasteClient       *self,
                                                GCancellable       *cancellable,
                                                GAsyncReadyCallback callback,
                                                gpointer            user_data);
void g_paste_client_empty_history              (GPasteClient       *self,
                                                const gchar        *name,
                                                GCancellable       *cancellable,
                                                GAsyncReadyCallback callback,
                                                gpointer            user_data);
void g_paste_client_get_item                   (GPasteClient       *self,
                                                const gchar        *uuid,
                                                GCancellable       *cancellable,
                                                GAsyncReadyCallback callback,
                                                gpointer            user_data);
void g_paste_client_get_item_at_index          (GPasteClient       *self,
                                                guint64             index,
                                                GCancellable       *cancellable,
                                                GAsyncReadyCallback callback,
                                                gpointer            user_data);
void g_paste_client_get_items                  (GPasteClient       *self,
                                                const gchar * const *uuids,
                                                GCancellable       *cancellable,
                                                GAsyncReadyCallback callback,
                                                gpointer            user_data);
void g_paste_client_get_favourites             (GPasteClient       *self,
                                                GCancellable       *cancellable,
                                                GAsyncReadyCallback callback,
                                                gpointer            user_data);
void g_paste_client_get_history                (GPasteClient       *self,
                                                GCancellable       *cancellable,
                                                GAsyncReadyCallback callback,
                                                gpointer            user_data);
void g_paste_client_get_history_size           (GPasteClient       *self,
                                                GCancellable       *cancellable,
                                                GAsyncReadyCallback callback,
                                                gpointer            user_data);
void g_paste_client_get_image                  (GPasteClient       *self,
                                                const gchar        *uuid,
                                                GCancellable       *cancellable,
                                                GAsyncReadyCallback callback,
                                                gpointer            user_data);
void g_paste_client_get_password_timeout       (GPasteClient       *self,
                                                const gchar        *uuid,
                                                GCancellable       *cancellable,
                                                GAsyncReadyCallback callback,
                                                gpointer            user_data);
void g_paste_client_get_uris                   (GPasteClient       *self,
                                                const gchar        *uuid,
                                                GCancellable       *cancellable,
                                                GAsyncReadyCallback callback,
                                                gpointer            user_data);
void g_paste_client_list_histories             (GPasteClient       *self,
                                                GCancellable       *cancellable,
                                                GAsyncReadyCallback callback,
                                                gpointer            user_data);
void g_paste_client_merge                      (GPasteClient       *self,
                                                const gchar        *decoration,
                                                const gchar        *separator,
                                                const gchar * const *uuids,
                                                GCancellable       *cancellable,
                                                GAsyncReadyCallback callback,
                                                gpointer            user_data);
void g_paste_client_report_extension_state     (GPasteClient       *self,
                                                gboolean            state,
                                                GCancellable       *cancellable,
                                                GAsyncReadyCallback callback,
                                                gpointer            user_data);
void g_paste_client_reexecute                  (GPasteClient       *self,
                                                GCancellable       *cancellable,
                                                GAsyncReadyCallback callback,
                                                gpointer            user_data);
void g_paste_client_replace                    (GPasteClient       *self,
                                                const gchar        *uuid,
                                                const gchar        *contents,
                                                GCancellable       *cancellable,
                                                GAsyncReadyCallback callback,
                                                gpointer            user_data);
void g_paste_client_search                     (GPasteClient       *self,
                                                const gchar        *pattern,
                                                GCancellable       *cancellable,
                                                GAsyncReadyCallback callback,
                                                gpointer            user_data);
void g_paste_client_select                     (GPasteClient       *self,
                                                const gchar        *uuid,
                                                GCancellable       *cancellable,
                                                GAsyncReadyCallback callback,
                                                gpointer            user_data);
void g_paste_client_set_favourite              (GPasteClient       *self,
                                                const gchar        *uuid,
                                                gboolean            favourite,
                                                GCancellable       *cancellable,
                                                GAsyncReadyCallback callback,
                                                gpointer            user_data);
void g_paste_client_make_password              (GPasteClient       *self,
                                                const gchar        *uuid,
                                                const gchar        *name,
                                                guint               timeout,
                                                GCancellable       *cancellable,
                                                GAsyncReadyCallback callback,
                                                gpointer            user_data);
void g_paste_client_show_history               (GPasteClient       *self,
                                                GCancellable       *cancellable,
                                                GAsyncReadyCallback callback,
                                                gpointer            user_data);
void g_paste_client_strip_rich_text            (GPasteClient       *self,
                                                const gchar        *uuid,
                                                GCancellable       *cancellable,
                                                GAsyncReadyCallback callback,
                                                gpointer            user_data);
void g_paste_client_switch_history             (GPasteClient       *self,
                                                const gchar        *name,
                                                GCancellable       *cancellable,
                                                GAsyncReadyCallback callback,
                                                gpointer            user_data);
void g_paste_client_set_active                 (GPasteClient       *self,
                                                gboolean            state,
                                                GCancellable       *cancellable,
                                                GAsyncReadyCallback callback,
                                                gpointer            user_data);
void g_paste_client_upload                     (GPasteClient       *self,
                                                const gchar        *uuid,
                                                GCancellable       *cancellable,
                                                GAsyncReadyCallback callback,
                                                gpointer            user_data);
void g_paste_client_upload_and_copy            (GPasteClient       *self,
                                                const gchar        *uuid,
                                                GCancellable       *cancellable,
                                                GAsyncReadyCallback callback,
                                                gpointer            user_data);

/****************************/
/* Methods / Async - Finish */
/****************************/

gchar   *g_paste_client_add_text_finish                   (GPasteClient *self,
                                                           GAsyncResult *result,
                                                           GError      **error);
gchar   *g_paste_client_add_file_finish                   (GPasteClient *self,
                                                           GAsyncResult *result,
                                                           GError      **error);
gchar   *g_paste_client_add_password_finish               (GPasteClient *self,
                                                           GAsyncResult *result,
                                                           GError      **error);
void     g_paste_client_backup_history_finish             (GPasteClient *self,
                                                           GAsyncResult *result,
                                                           GError      **error);
void     g_paste_client_change_passphrase_finish          (GPasteClient *self,
                                                           GAsyncResult *result,
                                                           GError      **error);
void     g_paste_client_delete_item_finish                (GPasteClient *self,
                                                           GAsyncResult *result,
                                                           GError      **error);
void     g_paste_client_delete_history_finish             (GPasteClient *self,
                                                           GAsyncResult *result,
                                                           GError      **error);
void     g_paste_client_delete_password_finish            (GPasteClient *self,
                                                           GAsyncResult *result,
                                                           GError      **error);
GStrv    g_paste_client_doctor_finish                     (GPasteClient *self,
                                                           GAsyncResult *result,
                                                           gboolean     *healthy,
                                                           GError      **error);
void     g_paste_client_empty_history_finish              (GPasteClient *self,
                                                           GAsyncResult *result,
                                                           GError      **error);
GPasteClientItem *g_paste_client_get_item_finish          (GPasteClient *self,
                                                           GAsyncResult *result,
                                                           GError      **error);
GList   *g_paste_client_get_items_finish                  (GPasteClient *self,
                                                           GAsyncResult *result,
                                                           GError      **error);
GList   *g_paste_client_get_favourites_finish             (GPasteClient *self,
                                                           GAsyncResult *result,
                                                           GError      **error);
GList   *g_paste_client_get_history_finish                (GPasteClient *self,
                                                           GAsyncResult *result,
                                                           GError      **error);
guint64  g_paste_client_get_history_size_finish           (GPasteClient *self,
                                                           GAsyncResult *result,
                                                           GError      **error);
GBytes  *g_paste_client_get_image_finish                  (GPasteClient *self,
                                                           GAsyncResult *result,
                                                           GError      **error);
guint    g_paste_client_get_password_timeout_finish       (GPasteClient *self,
                                                           GAsyncResult *result,
                                                           GError      **error);
GStrv    g_paste_client_get_uris_finish                   (GPasteClient *self,
                                                           GAsyncResult *result,
                                                           GError      **error);
GList   *g_paste_client_list_histories_finish             (GPasteClient *self,
                                                           GAsyncResult *result,
                                                           GError      **error);
gchar   *g_paste_client_merge_finish                      (GPasteClient *self,
                                                           GAsyncResult *result,
                                                           GError      **error);
void     g_paste_client_report_extension_state_finish     (GPasteClient *self,
                                                           GAsyncResult *result,
                                                           GError      **error);
void     g_paste_client_reexecute_finish                  (GPasteClient *self,
                                                           GAsyncResult *result,
                                                           GError      **error);
gchar   *g_paste_client_replace_finish                    (GPasteClient *self,
                                                           GAsyncResult *result,
                                                           GError      **error);
GList   *g_paste_client_search_finish                     (GPasteClient *self,
                                                           GAsyncResult *result,
                                                           GError      **error);
void     g_paste_client_select_finish                     (GPasteClient *self,
                                                           GAsyncResult *result,
                                                           GError      **error);
void     g_paste_client_set_favourite_finish              (GPasteClient *self,
                                                           GAsyncResult *result,
                                                           GError      **error);
gchar   *g_paste_client_make_password_finish              (GPasteClient *self,
                                                           GAsyncResult *result,
                                                           GError      **error);
void     g_paste_client_show_history_finish               (GPasteClient *self,
                                                           GAsyncResult *result,
                                                           GError      **error);
void     g_paste_client_strip_rich_text_finish            (GPasteClient *self,
                                                           GAsyncResult *result,
                                                           GError      **error);
void     g_paste_client_switch_history_finish             (GPasteClient *self,
                                                           GAsyncResult *result,
                                                           GError      **error);
void     g_paste_client_set_active_finish                 (GPasteClient *self,
                                                           GAsyncResult *result,
                                                           GError      **error);
gchar   *g_paste_client_upload_finish                     (GPasteClient *self,
                                                           GAsyncResult *result,
                                                           GError      **error);
gchar   *g_paste_client_upload_and_copy_finish            (GPasteClient *self,
                                                           GAsyncResult *result,
                                                           GError      **error);

GPasteClientItem *g_paste_client_get_item_at_index_finish (GPasteClient *self,
                                                           GAsyncResult *result,
                                                           GError      **error);

/**************/
/* Properties */
/**************/

gboolean             g_paste_client_is_active           (GPasteClient *self);
gchar               *g_paste_client_get_history_name    (GPasteClient *self);
gchar               *g_paste_client_get_version         (GPasteClient *self);
GPasteDaemonPresence g_paste_client_get_daemon_presence (GPasteClient *self);

gboolean g_paste_client_is_daemon_gone_error (const GError *error);

/**********************/
/* Following a daemon */
/**********************/

void g_paste_client_follow_daemon   (GPasteClient *self,
                                     gboolean      activate);
void g_paste_client_unfollow_daemon (GPasteClient *self);
void g_paste_client_retry_daemon    (GPasteClient *self);

/****************/
/* Constructors */
/****************/

GPasteClient *g_paste_client_new_sync   (GError            **error);
void          g_paste_client_new        (GAsyncReadyCallback callback,
                                         gpointer            user_data);
GPasteClient *g_paste_client_new_finish (GAsyncResult       *result,
                                         GError            **error);

G_END_DECLS
