// SPDX-FileCopyrightText: 2010-2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com>
// SPDX-License-Identifier: BSD-2-Clause

#include <gpaste-3/gpaste-client-history.h>
#include <gpaste-3/gpaste-client-private.h>
#include <gpaste-3/gpaste-error.h>
#include <gpaste-3/gpaste-gdbus-defines.h>
#include <gpaste-3/gpaste-gsettings-keys.h>
#include <gpaste-3/gpaste-util.h>
#include <gpaste-3/gpaste-util-private.h>

#include <errno.h>
#include <string.h>

#ifdef G_OS_UNIX
#include <signal.h>
#endif

#ifdef G_PASTE_ENABLE_PWQUALITY
#include <pwquality.h>
#endif

/* Every GPaste app is reached the same way: the standard interface a desktop
 * application exports, on the bus name and object path its own name makes. The
 * graphical tool is the one addressed by a caller that is not spawning it, so
 * it is spelled out rather than built. */
#define G_PASTE_APPLICATION_IFACE "org.freedesktop.Application"
#define G_PASTE_UI_BUS_NAME       "org.gnome.GPaste.Ui"
#define G_PASTE_UI_OBJECT_PATH    "/org/gnome/GPaste/Ui"

/* Copied from glib's gio/gapplication-tool.c */
static GVariant *
app_get_platform_data (void)
{
    g_auto (GVariantBuilder) builder;
    const gchar *startup_id;

    g_variant_builder_init_static (&builder, G_VARIANT_TYPE_VARDICT);

    if ((startup_id = g_getenv ("DESKTOP_STARTUP_ID")))
        g_variant_builder_add (&builder, "{sv}", "desktop-startup-id", g_variant_new_string (startup_id));

    return g_variant_builder_end (&builder);
}

static void
g_paste_util_spawn_on_proxy_ready (GObject      *source_object G_GNUC_UNUSED,
                                   GAsyncResult *res,
                                   gpointer      user_data G_GNUC_UNUSED)
{
    g_autoptr (GError) error = NULL;
    g_autoptr (GDBusProxy) proxy = g_dbus_proxy_new_for_bus_finish (res, &error);

    if (!proxy)
    {
        g_warning ("Failed to get D-Bus proxy: %s", error->message);
        return;
    }

    g_dbus_proxy_call (proxy,
                       "Activate",
                       g_variant_new ("(@a{sv})", app_get_platform_data ()),
                       G_DBUS_CALL_FLAGS_NONE,
                       -1,
                       NULL, /* cancellable */
                       NULL, /* callback */
                       NULL); /* user_data */
}

/**
 * g_paste_util_spawn:
 * @app: the GPaste app to spawn
 *
 * spawn a GPaste app
 */
G_PASTE_VISIBLE void
g_paste_util_spawn (const gchar *app)
{
    g_return_if_fail (g_utf8_validate (app, -1, NULL));

    g_autofree gchar *name = g_strdup_printf ("org.gnome.GPaste.%s", app);
    g_autofree gchar *object = g_strdup_printf ("/org/gnome/GPaste/%s", app);

    g_dbus_proxy_new_for_bus (G_BUS_TYPE_SESSION,
                              G_DBUS_PROXY_FLAGS_NONE,
                              NULL,
                              name,
                              object,
                              G_PASTE_APPLICATION_IFACE,
                              NULL,
                              g_paste_util_spawn_on_proxy_ready,
                              NULL);
}

static GDBusProxy *
_bus_proxy_new_sync (const gchar *app,
                     GError     **error)
{
    g_autofree gchar *name = g_strdup_printf ("org.gnome.GPaste.%s", app);
    g_autofree gchar *object = g_strdup_printf ("/org/gnome/GPaste/%s", app);

    return g_dbus_proxy_new_for_bus_sync (G_BUS_TYPE_SESSION,
                                          G_DBUS_PROXY_FLAGS_NONE,
                                          NULL,
                                          name,
                                          object,
                                          G_PASTE_APPLICATION_IFACE,
                                          NULL,
                                          error);
}

static gboolean
_spawn_sync (GDBusProxy *proxy,
             GError    **error)
{
    /* The call's own result is what says whether it worked: @error may be %NULL,
     * in which case there is nothing to look at. */
    g_autoptr (GVariant) res = g_dbus_proxy_call_sync (proxy,
                                                       "Activate",
                                                       g_variant_new ("(@a{sv})", app_get_platform_data ()),
                                                       G_DBUS_CALL_FLAGS_NONE,
                                                       -1,
                                                       NULL,
                                                       error);

    return !!res;
}

/**
 * g_paste_util_spawn_sync:
 * @app: the GPaste app to spawn
 * @error: return location for a #GError, or %NULL
 *
 * spawn a GPaste app
 *
 * The app is started through its org.freedesktop.Application interface, so a
 * failure is a %G_DBUS_ERROR or a %G_IO_ERROR rather than a %G_PASTE_ERROR.
 *
 * Returns: whether the spawn was successful
 */
G_PASTE_VISIBLE gboolean
g_paste_util_spawn_sync (const gchar *app,
                         GError     **error)
{
    g_return_val_if_fail (g_utf8_validate (app, -1, NULL), FALSE);
    g_return_val_if_fail (!error || !(*error), FALSE);

    g_autoptr (GDBusProxy) proxy = _bus_proxy_new_sync (app, error);

    if (!proxy)
        return FALSE;

    return _spawn_sync (proxy, error);
}

/* The ActivateAction payload, which is the whole of what the two flavours below
 * have in common: same interface, same action, same @arg wrapped in the "av" the
 * method takes, same platform data. */
static GVariant *
activate_ui_params (const gchar *action,
                    GVariant    *arg)
{
    g_auto (GVariantBuilder) params;

    g_variant_builder_init_static (&params, G_VARIANT_TYPE ("av"));

    if (arg)
        g_variant_builder_add (&params, "v", arg);

    return g_variant_new ("(sav@a{sv})", action, &params, app_get_platform_data ());
}

static void
g_paste_util_activate_ui_on_proxy_ready (GObject      *source_object G_GNUC_UNUSED,
                                         GAsyncResult *res,
                                         gpointer      user_data)
{
    g_autofree gpointer *data = (gpointer *) user_data;
    g_autofree gchar *action = data[0];
    g_autoptr (GVariant) arg = data[1];
    g_autoptr (GError) error = NULL;
    g_autoptr (GDBusProxy) proxy = g_dbus_proxy_new_for_bus_finish (res, &error);

    if (!proxy)
    {
        g_warning ("Failed to get D-Bus proxy: %s", error->message);
        return;
    }

    g_dbus_proxy_call (proxy,
                       "ActivateAction",
                       activate_ui_params (action, arg),
                       G_DBUS_CALL_FLAGS_NONE,
                       -1,
                       NULL, /* cancellable */
                       NULL, /* callback */
                       NULL); /* user_data */
}

/**
 * g_paste_util_activate_ui:
 * @action: the action to activate
 * @arg: (nullable): the action argument
 *
 * Activate an action on a GPaste app.
 *
 * A floating @arg is consumed. A caller owning @arg keeps its reference, and
 * may drop it as soon as this returns: @arg is held until the call is made.
 */
G_PASTE_VISIBLE void
g_paste_util_activate_ui (const gchar *action,
                          GVariant    *arg)
{
    g_return_if_fail (g_utf8_validate (action, -1, NULL));

    gpointer *data = g_new (gpointer, 2);
    data[0] = g_strdup (action);
    data[1] = (arg) ? g_variant_ref_sink (arg) : NULL;

    g_dbus_proxy_new_for_bus (G_BUS_TYPE_SESSION,
                              G_DBUS_PROXY_FLAGS_NONE,
                              NULL,
                              G_PASTE_UI_BUS_NAME,
                              G_PASTE_UI_OBJECT_PATH,
                              G_PASTE_APPLICATION_IFACE,
                              NULL,
                              g_paste_util_activate_ui_on_proxy_ready,
                              data);
}

/**
 * g_paste_util_activate_ui_sync:
 * @action: the action to activate
 * @arg: (nullable): the action argument
 * @error: return location for a #GError, or %NULL
 *
 * Activate an action on a GPaste app, and wait for the call to have been made.
 *
 * g_paste_util_activate_ui() only starts the work, finishing it from a callback
 * the main loop dispatches; a caller with no main loop to give it -- the command
 * line client -- would return before anything reached the bus, and exit
 * reporting the success of having asked. This is that caller's version.
 *
 * @arg is taken as g_paste_util_activate_ui() takes it.
 *
 * Returns: %FALSE, with @error set, when the app could not be reached
 */
G_PASTE_VISIBLE gboolean
g_paste_util_activate_ui_sync (const gchar *action,
                               GVariant    *arg,
                               GError     **error)
{
    g_return_val_if_fail (g_utf8_validate (action, -1, NULL), FALSE);

    g_autoptr (GVariant) owned = (arg) ? g_variant_ref_sink (arg) : NULL;
    g_autoptr (GDBusProxy) proxy = g_dbus_proxy_new_for_bus_sync (G_BUS_TYPE_SESSION,
                                                                  G_DBUS_PROXY_FLAGS_NONE,
                                                                  NULL,
                                                                  G_PASTE_UI_BUS_NAME,
                                                                  G_PASTE_UI_OBJECT_PATH,
                                                                  G_PASTE_APPLICATION_IFACE,
                                                                  NULL, /* cancellable */
                                                                  error);

    if (!proxy)
        return FALSE;

    g_autoptr (GVariant) ret = g_dbus_proxy_call_sync (proxy,
                                                       "ActivateAction",
                                                       activate_ui_params (action, owned),
                                                       G_DBUS_CALL_FLAGS_NONE,
                                                       -1,
                                                       NULL, /* cancellable */
                                                       error);

    return !!ret;
}

/**
 * g_paste_util_history_name_is_valid:
 * @name: (nullable): the name of a history
 *
 * Whether @name names a history and nothing else.
 *
 * The name goes straight into the file a history is stored in and into the
 * images directory it owns, so one carrying a path component names something
 * outside the history directory entirely: "../x" is a history file written
 * wherever the traversal lands, and deleting that history sweeps every file of
 * the directory it landed in. "." and ".." name the history directory itself.
 * Names reach us from the bus, so this is a refusal, not an assertion.
 *
 * Bounded too: a file name is 255 bytes at most on the filesystems a home
 * directory is on, and a plain file history is saved through its own name with
 * ".xml.tmp" after it. A name past that has a placeholder written and listed,
 * while no save of it could ever land. The other flavours need more room after
 * the name still -- the SQLite ones a "-journal" beside their database, the
 * encrypted file one the original a re-key keeps aside -- which only the
 * creation of a history asks of them (g_paste_storage_name_fits ()): a name a
 * history was saved under stays one.
 *
 * Installed and introspected, where the paths it guards are the daemon's alone:
 * a client with nowhere to report a refusal -- the GNOME Shell extension's
 * history chooser -- asks this before sending a name, and a copy of the rule
 * there would drift from the one the daemon enforces.
 *
 * Returns: whether @name may be turned into a path
 */
G_PASTE_VISIBLE gboolean
g_paste_util_history_name_is_valid (const gchar *name)
{
    if (!name || !*name || g_paste_str_equal (name, ".") || g_paste_str_equal (name, "..") ||
        strlen (name) > 255 - strlen (".xml.tmp"))
        return FALSE;

    /* Not G_IS_DIR_SEPARATOR alone: '/' separates paths wherever GLib builds,
     * and a name carrying one has to be refused whichever platform wrote it. */
    for (const gchar *c = name; *c; ++c)
    {
        if (*c == '/' || G_IS_DIR_SEPARATOR (*c))
            return FALSE;
    }

    return TRUE;
}

/**
 * g_paste_util_one_line:
 * @text: the initial text
 *
 * Fold @text onto a single line, replacing every carriage return, line feed,
 * tabulation and Unicode line break -- the next-line, line and paragraph
 * separators (U+0085, U+2028, U+2029), which Pango breaks a line at too --
 * with a space. This is what everything displaying an item in a one-line
 * context — the command line's --oneline, the history rows, the search
 * provider's results — has to do to it first.
 *
 * Returns: the newly allocated string
 */
G_PASTE_VISIBLE gchar *
g_paste_util_one_line (const gchar *text)
{
    g_return_val_if_fail (text, NULL);

    g_autoptr (GString) line = g_string_new (text);

    /* NEL as its UTF-8 bytes: C has no universal character name below U+00A0. */
    g_string_replace (line, "\xc2\x85", " ", 0);
    g_string_replace (line, "\u2028", " ", 0);
    g_string_replace (line, "\u2029", " ", 0);

    return g_strdelimit (g_string_free_and_steal (g_steal_pointer (&line)), "\n\r\t", ' ');
}

/* The uris a files item holds, as a line to read rather than a list to act on:
 * a local file shown as its path with $HOME written "~", anything else as the
 * uri it is. Percent-decoded, so a file named "a b" reads as one.
 *
 * Done here rather than in the daemon because it is presentation, and because
 * the daemon got it wrong when it did it: a blind substitution over the uri
 * spelled a home file "file://~/a". */
G_PASTE_VISIBLE gchar *
g_paste_util_uris_display_string (const gchar *value)
{
    g_auto (GStrv) uris = g_strsplit (value, "\n", -1);
    g_autoptr (GString) shown = g_string_new (NULL);
    const gchar *home = g_get_home_dir ();
    gsize home_len = (home) ? strlen (home) : 0;

    /* A $HOME spelled with a trailing slash names the same directory, which
     * the comparison below would otherwise only ever find itself in. */
    while (home_len > 1 && home[home_len - 1] == '/')
        --home_len;

    for (GStrv u = uris; *u; ++u)
    {
        const gchar *uri = *u;

        /* A value ending in a newline splits into a trailing empty piece, which
         * is no uri and would only hang a separator off the end of the line. */
        if (!*uri)
            continue;

        if (shown->len)
            g_string_append_c (shown, ' ');

        g_autofree gchar *path = g_filename_from_uri (uri, NULL, NULL);

        /* Anything but a local file -- another scheme, a uri that does not
         * decode -- is shown as the uri it is. */
        if (!path)
        {
            g_string_append (shown, uri);
            continue;
        }

        const gchar *p = path;

        /* Only a whole leading component, so /home/joe never shortens /home/joey. */
        if (home_len && !strncmp (p, home, home_len) && (!p[home_len] || p[home_len] == '/'))
        {
            g_string_append_c (shown, '~');
            p += home_len;
        }

        /* A name in another encoding than UTF-8 -- an old archive's Latin-1 --
         * decodes to bytes no label can draw and no D-Bus string can carry: it
         * is read in the filename encoding the user set (G_FILENAME_ENCODING),
         * and failing that, what reads as text is kept, the rest shown as
         * U+FFFD. */
        g_autofree gchar *display = g_filename_display_name (p);

        g_string_append (shown, display);
    }

    return g_string_free_and_steal (g_steal_pointer (&shown));
}

/**
 * g_paste_util_display_string:
 * @value: the value of an item
 * @kind: the kind of that item
 *
 * Compose what a client draws for an item: its @value, with the decoration its
 * @kind calls for around it.
 *
 * Composed by whoever draws the item rather than sent by the daemon so that it
 * comes out in *that* process's language: the daemon has a locale of its own,
 * and the gnome-shell extension a whole catalogue of its own; a client handed a
 * finished string could neither re-translate it nor read the value back out of
 * it. Here rather than on #GPasteClientItem so that everything
 * drawing an item shares the one implementation: the item caches what this
 * returns, the search provider describes its results with it, and the
 * gnome-shell extension calls it through introspection instead of keeping a
 * second copy of it in JavaScript.
 *
 * Only the words are translated. The brackets around them are punctuation, not
 * language, so they are spelled here.
 *
 * Returns: the newly allocated string
 */
G_PASTE_VISIBLE gchar *
g_paste_util_display_string (const gchar   *value,
                             GPasteItemKind kind)
{
    g_return_val_if_fail (value, NULL);

    switch (kind)
    {
    /* The one whose payload belongs inside the brackets: it reads as a
     * description of the image rather than as a name in front of one. */
    case G_PASTE_ITEM_KIND_IMAGE:
        return g_strdup_printf ("[%s, %s]", _("Image"), value);
    case G_PASTE_ITEM_KIND_COLOR:
        return g_strdup_printf ("[%s] %s", _("Color"), value);
    case G_PASTE_ITEM_KIND_URIS:
    {
        g_autofree gchar *uris = g_paste_util_uris_display_string (value);

        return g_strdup_printf ("[%s] %s", _("Files"), uris);
    }
    /* The value here is the password's *name*: the daemon masks the password
     * itself and never sends it. */
    case G_PASTE_ITEM_KIND_PASSWORD:
        return g_strdup_printf ("[%s] %s", _("Password"), value);
    /* Text wears nothing, and a kind we do not know is shown as it arrived
     * rather than mislabelled. */
    default:
        return g_strdup (value);
    }
}

/**
 * g_paste_util_has_gnome_shell:
 *
 * Check whether gnome-shell is installed or not
 *
 * Returns: %TRUE if gnome-shell is installed
 */
G_PASTE_VISIBLE gboolean
g_paste_util_has_gnome_shell (void)
{
    GSettingsSchemaSource *source = g_settings_schema_source_get_default ();

    if (!source)
        return FALSE;

    g_autoptr (GSettingsSchema) schema = g_settings_schema_source_lookup (source, G_PASTE_SHELL_SETTINGS_NAME, TRUE);

    return !!schema;
}

/* Where gnome-shell answers questions about the extensions it has loaded. */
#define G_PASTE_SHELL_BUS_NAME         "org.gnome.Shell"
#define G_PASTE_SHELL_OBJECT_PATH      "/org/gnome/Shell"
#define G_PASTE_SHELL_EXTENSIONS_IFACE "org.gnome.Shell.Extensions"

static void
on_extension_info (GObject      *source_object,
                   GAsyncResult *res,
                   gpointer      user_data)
{
    g_autoptr (GTask) task = user_data;
    g_autoptr (GError) error = NULL;
    g_autoptr (GVariant) reply = g_dbus_connection_call_finish (G_DBUS_CONNECTION (source_object), res, &error);

    if (!reply)
    {
        /* Said rather than swallowed: a shell that did not answer and a session
         * with no shell in it leave the same absent group behind, and this line
         * is the only thing that tells them apart afterwards. */
        g_debug ("Failed to ask the shell about its extensions: %s", error->message);
        g_task_return_boolean (task, FALSE);
        return;
    }

    /* A uuid the shell knows nothing about is not an error: it answers an empty
     * dictionary, so what says the extension is there is the dictionary having
     * anything in it, not the call having succeeded. */
    g_autoptr (GVariant) info = g_variant_get_child_value (reply, 0);

    g_task_return_boolean (task, g_variant_n_children (info) > 0);
}

static void
on_session_bus (GObject      *source_object G_GNUC_UNUSED,
                GAsyncResult *res,
                gpointer      user_data)
{
    g_autoptr (GTask) task = user_data;
    g_autoptr (GError) error = NULL;
    g_autoptr (GDBusConnection) connection = g_bus_get_finish (res, &error);

    if (!connection)
    {
        g_debug ("Failed to reach the session bus: %s", error->message);
        g_task_return_boolean (task, FALSE);
        return;
    }

    /* Read before the task is stolen: the two are arguments of one call, which
     * C is free to evaluate in either order. */
    GCancellable *cancellable = g_task_get_cancellable (task);

    /* The uuid the extension is installed under, compiled in from meson.build
     * and matched on by g_paste_settings_set_extension_enabled () too. */
    g_dbus_connection_call (connection,
                            G_PASTE_SHELL_BUS_NAME,
                            G_PASTE_SHELL_OBJECT_PATH,
                            G_PASTE_SHELL_EXTENSIONS_IFACE,
                            "GetExtensionInfo",
                            g_variant_new ("(s)", G_PASTE_EXTENSION_NAME),
                            G_VARIANT_TYPE ("(a{sv})"),
                            /* org.gnome.Shell is not activatable, so a session
                             * running no shell fails here at once rather than
                             * waiting out the timeout. */
                            G_DBUS_CALL_FLAGS_NO_AUTO_START,
                            /* The default timeout, since what takes the question
                             * back is the cancellable rather than a deadline. */
                            -1,
                            cancellable,
                            on_extension_info,
                            g_steal_pointer (&task));
}

/**
 * g_paste_util_has_gnome_shell_extension:
 * @cancellable: (nullable): a #GCancellable, or %NULL
 * @callback: (nullable): a #GAsyncReadyCallback to call with the answer
 * @user_data: (nullable): the data to pass to @callback
 *
 * Check whether GPaste's GNOME Shell extension is installed or not
 *
 * A different question from g_paste_util_has_gnome_shell(), which asks the
 * schema source whether gnome-shell itself is installed: only the shell knows
 * what it has, so this one goes over the bus and answers %FALSE when there is
 * no shell running to ask.
 *
 * Asynchronous because a shell that owns the name and is not dispatching --
 * starting up, or held up by another extension -- answers late or not at all,
 * and the caller is a preferences page being built: blocking it would freeze
 * the dialog with nothing drawn in it, and cutting the wait short would hide
 * the extension's own rows on a machine that has it.
 *
 * That same shell is why @cancellable is worth passing: the call is left the
 * 25-second D-Bus default, and cancelling is how a caller that has gone in the
 * meantime stops @user_data being held for the rest of it.
 */
G_PASTE_VISIBLE void
g_paste_util_has_gnome_shell_extension (GCancellable       *cancellable,
                                        GAsyncReadyCallback callback,
                                        gpointer            user_data)
{
    g_autoptr (GTask) task = g_task_new (NULL, cancellable, callback, user_data);

    g_task_set_source_tag (task, g_paste_util_has_gnome_shell_extension);

    g_bus_get (G_BUS_TYPE_SESSION, cancellable, on_session_bus, g_steal_pointer (&task));
}

/**
 * g_paste_util_has_gnome_shell_extension_finish:
 * @result: the #GAsyncResult the callback was handed
 *
 * Get the answer to a g_paste_util_has_gnome_shell_extension() call
 *
 * Nothing here fails: a bus that could not be reached, a shell that is not
 * running and a shell that does not have the extension are one answer, there
 * being no row to offer in any of those cases.
 *
 * Returns: %TRUE if the extension is installed
 */
G_PASTE_VISIBLE gboolean
g_paste_util_has_gnome_shell_extension_finish (GAsyncResult *result)
{
    g_return_val_if_fail (g_task_is_valid (result, NULL), FALSE);

    return g_task_propagate_boolean (G_TASK (result), NULL);
}

/**
 * g_paste_util_get_dbus_item_result:
 * @variant: a #GVariant
 *
 * Get an item out of the %G_PASTE_ITEM_VARIANT_STRING #GVariant the daemon
 * answers every single-item method with
 *
 * A kind this library does not know -- a newer daemon's, met while an upgrade
 * re-executes the daemon under a client still running the older library -- is
 * read as text, its value shown as it arrived: stored as it came, it would be
 * an enumeration value no binding can hand out, GJS throwing on
 * g_paste_client_item_get_kind (). An item with no valid uuid, which GPaste's
 * own daemon never sends, is no item at all.
 *
 * Returns: (transfer full) (nullable): The item, or %NULL for one with no
 *          valid uuid
 */
G_PASTE_VISIBLE GPasteClientItem *
g_paste_util_get_dbus_item_result (GVariant *variant)
{
    /* Owned, not borrowed: the format string is the one the daemon *builds*
     * these variants with, so it spells "s" rather than the "&s" that would
     * point into the variant, and g_variant_get hands back a copy of each
     * string for the caller to free. */
    g_autofree gchar *uuid = NULL;
    g_autofree gchar *value = NULL;
    g_auto (GStrv) notes = NULL;
    guint32 kind;
    gboolean favourite;

    g_variant_get (variant, G_PASTE_ITEM_VARIANT_FORMAT, &uuid, &value, &kind, &favourite, &notes);

    if (!g_uuid_string_is_valid (uuid))
        return NULL;

    if (kind == G_PASTE_ITEM_KIND_INVALID || !g_enum_get_value (g_type_class_get (G_PASTE_TYPE_ITEM_KIND), (gint) kind))
        kind = G_PASTE_ITEM_KIND_TEXT;

    return g_paste_client_item_new (uuid, value, kind, favourite, (const gchar * const *) notes);
}

/**
 * g_paste_util_get_dbus_items_result:
 * @variant: a #GVariant
 *
 * Get the %G_PASTE_ITEMS_VARIANT_STRING #GVariant as a list of items, those
 * g_paste_util_get_dbus_item_result () reads no item out of left out
 *
 * Returns: (element-type GPasteClientItem) (transfer full): The items
 */
G_PASTE_VISIBLE GList *
g_paste_util_get_dbus_items_result (GVariant *variant)
{
    GList *items = NULL;
    GVariantIter iter;

    g_variant_iter_init (&iter, variant);
    while (TRUE)
    {
        g_autoptr (GVariant) v = g_variant_iter_next_value (&iter);

        if (!v)
            break;

        GPasteClientItem *item = g_paste_util_get_dbus_item_result (v);

        if (item)
            items = g_list_prepend (items, item);
    }

    /* Prepended and reversed once: appending walks the whole list on every
     * item, which a full history makes quadratic. */
    return g_list_reverse (items);
}

/**
 * g_paste_util_get_dbus_histories_result:
 * @variant: a #GVariant
 *
 * Get the %G_PASTE_HISTORIES_VARIANT_STRING #GVariant as a list of histories
 *
 * Returns: (element-type GPasteClientHistory) (transfer full): The histories
 */
G_PASTE_VISIBLE GList *
g_paste_util_get_dbus_histories_result (GVariant *variant)
{
    GList *histories = NULL;
    GVariantIter iter;

    g_variant_iter_init (&iter, variant);

    /* The name belongs to the iteration that read it, so it is declared there:
     * one hoisted out of the loop and cleared by hand at the bottom of the body
     * is a free an early exit can forget, where this one's cleanup runs whichever
     * way the iteration ends. */
    while (TRUE)
    {
        g_autofree gchar *name = NULL;
        guint64 size;

        if (!g_variant_iter_next (&iter, G_PASTE_HISTORY_VARIANT_STRING, &name, &size))
            break;

        histories = g_list_prepend (histories, g_paste_client_history_new (name, size));
    }

    return g_list_reverse (histories);
}

static gchar *
g_paste_util_get_runtime_dir (const gchar *component)
{
    g_return_val_if_fail (component, NULL);

    return g_strdup_printf ("%s/" PACKAGE_NAME "/%s", g_get_user_runtime_dir (), component);
}

/**
 * g_paste_util_write_pid_file:
 * @component: The component we're handling
 *
 * Write the pid file
 */
G_PASTE_VISIBLE void
g_paste_util_write_pid_file (const gchar *component)
{
    g_return_if_fail (component);

    g_autofree gchar *dir = g_paste_util_get_runtime_dir (component);

    g_mkdir_with_parents (dir, 0700);

    g_autofree gchar *pidfile = g_strdup_printf ("%s/pid", dir);
    g_autofree gchar *contents = g_strdup_printf ("%" G_PID_FORMAT, getpid ());

    g_autoptr (GError) error = NULL;
    if (!g_file_set_contents (pidfile, contents, -1, &error))
        g_warning ("Failed to write pid file: %s", error->message);
}

/**
 * g_paste_util_read_pid_file:
 * @component: The component we're handling
 *
 * Read the pid file
 *
 * A component that wrote none -- one not started yet, or hosted somewhere that
 * writes no pid file -- is no failure of its own, and goes unreported.
 *
 * Returns: the pid, or -1 when there is no pid file or it names no process
 */
G_PASTE_VISIBLE GPid
g_paste_util_read_pid_file (const gchar *component)
{
    g_return_val_if_fail (component, (GPid) -1);

#ifdef G_OS_UNIX
    g_autofree gchar *dir = g_paste_util_get_runtime_dir (component);
    g_autofree gchar *pidfile = g_strdup_printf ("%s/pid", dir);
    g_autofree gchar *contents = NULL;

    g_autoptr (GError) error = NULL;
    if (!g_file_get_contents (pidfile, &contents, NULL, &error))
    {
        if (!g_error_matches (error, G_FILE_ERROR, G_FILE_ERROR_NOENT))
            g_warning ("Failed to read pid file: %s", error->message);
        return (GPid) -1;
    }

    /* Decimal and positive, as written: a 0 read out of a damaged file would
     * have the caller's kill () signal its own whole process group. */
    guint64 pid = 0;

    if (!g_ascii_isdigit (*contents) || !g_ascii_string_to_unsigned (contents, 10, 1, G_MAXINT, &pid, NULL))
        return (GPid) -1;

    return (GPid) pid;
#else
    return (GPid) -1;
#endif
}

/**
 * g_paste_util_reexecute_daemon:
 * @client: a connected #GPasteClient
 * @error: return location for a #GError, or %NULL
 *
 * Ask the daemon to re-execute itself through @client. It tears its D-Bus
 * connection down before replying, so a missing reply is the expected success,
 * not a failure -- which g_paste_client_reexecute_sync() already reads as such.
 *
 * It first waits for the reads still classifying a selection that has a
 * password countdown to bring forward, so that no password is handed to the
 * successor unmonitored. Classification can wait sixty seconds per attempt;
 * completion revalidation can retry within a thirty-second window, for up to
 * ninety seconds overall. The client allows two minutes. An in-process host
 * replies after accepting its restart; a standalone exec closes the connection.
 * A caller that must not block uses g_paste_client_reexecute().
 *
 * Returns: %TRUE if the daemon honoured the re-exec
 */
G_PASTE_VISIBLE gboolean
g_paste_util_reexecute_daemon (GPasteClient *client,
                               GError      **error)
{
    g_return_val_if_fail (G_PASTE_IS_CLIENT (client), FALSE);
    g_return_val_if_fail (!error || !*error, FALSE);

    GError *err = NULL;

    g_paste_client_reexecute_sync (client, &err);

    if (!err)
        return TRUE;

    g_propagate_error (error, err);

    return FALSE;
}

/* The interface a GPaste 45 or 50 serves, which knows no Reexecute of ours but
 * re-executes on SIGUSR1: a package update leaves one running until the
 * session ends. */
#define G_PASTE_LEGACY_IFACE "org.gnome.GPaste2"

/* Whether an Introspect answer of the daemon's path serves that interface. */
static gboolean
g_paste_util_introspected_legacy (GVariant *answer)
{
    const gchar *xml = NULL;

    g_variant_get (answer, "(&s)", &xml);

    g_autoptr (GDBusNodeInfo) node = g_dbus_node_info_new_for_xml (xml, NULL);

    return node && g_dbus_node_info_lookup_interface (node, G_PASTE_LEGACY_IFACE);
}

static void
on_legacy_introspected (GObject      *source_object,
                        GAsyncResult *res,
                        gpointer      user_data)
{
    g_autoptr (GTask) task = user_data;
    GError *error = NULL;
    g_autoptr (GVariant) answer = g_dbus_connection_call_finish (G_DBUS_CONNECTION (source_object), res, &error);

    if (!answer)
        g_task_return_error (task, error);
    else
        g_task_return_boolean (task, g_paste_util_introspected_legacy (answer));
}

/**
 * g_paste_util_daemon_is_legacy:
 * @client: a #GPasteClient
 * @cancellable: (nullable): a #GCancellable
 * @callback: (scope async): called with the answer
 * @user_data: data for @callback
 *
 * Ask whether the daemon owning the name is a GPaste 45 or 50, which serves an
 * interface of its own rather than this one: what a package update leaves
 * running until the session ends, and what a client of this version can never
 * reach (g_paste_util_reexecute_legacy_daemon ()).
 *
 * The daemon's path is asked what it serves: GDBus answers an unknown method
 * alike for such a daemon and for a current one that owns the name but has yet
 * to export anything.
 */
G_PASTE_VISIBLE void
g_paste_util_daemon_is_legacy (GPasteClient       *client,
                               GCancellable       *cancellable,
                               GAsyncReadyCallback callback,
                               gpointer            user_data)
{
    g_return_if_fail (G_PASTE_IS_CLIENT (client));
    g_return_if_fail (!cancellable || G_IS_CANCELLABLE (cancellable));

    GTask *task = g_task_new (NULL, cancellable, callback, user_data);

    g_task_set_source_tag (task, g_paste_util_daemon_is_legacy);
    g_dbus_connection_call (g_dbus_proxy_get_connection (G_DBUS_PROXY (client)),
                            G_PASTE_BUS_NAME, G_PASTE_DAEMON_OBJECT_PATH,
                            "org.freedesktop.DBus.Introspectable", "Introspect",
                            NULL, G_VARIANT_TYPE ("(s)"), G_DBUS_CALL_FLAGS_NO_AUTO_START, -1,
                            cancellable, on_legacy_introspected, task);
}

/**
 * g_paste_util_daemon_is_legacy_finish:
 * @result: the #GAsyncResult handed to the callback
 * @error: return location for a #GError, or %NULL
 *
 * Finish g_paste_util_daemon_is_legacy (). Fails with %G_DBUS_ERROR or
 * %G_IO_ERROR when the daemon's path could not be asked -- no daemon there,
 * above all.
 *
 * Returns: whether the daemon owning the name is a GPaste 45 or 50
 */
G_PASTE_VISIBLE gboolean
g_paste_util_daemon_is_legacy_finish (GAsyncResult *result,
                                      GError      **error)
{
    g_return_val_if_fail (g_task_is_valid (result, NULL), FALSE);

    return g_task_propagate_boolean (G_TASK (result), error);
}

typedef struct
{
    GPasteClient *client;
    gulong        presence_handler;
    /* Answering the wait with the cancellation once @cancellable is cancelled:
     * a source on the main context rather than a handler of the cancellable,
     * from whose emission the last reference to the task could not be dropped
     * -- the free disconnects it. */
    GSource      *cancelled;
    /* Whether the client followed the daemon before the wait did, as it then
     * goes on to once the wait is over. */
    gboolean      was_following;
    gboolean      answered;
} DaemonWait;

static void
daemon_wait_free (gpointer data)
{
    DaemonWait *wait = data;

    g_clear_signal_handler (&wait->presence_handler, wait->client);
    if (wait->cancelled)
    {
        g_source_destroy (wait->cancelled);
        g_source_unref (wait->cancelled);
    }
    if (!wait->was_following)
        g_paste_client_unfollow_daemon (wait->client);
    g_object_unref (wait->client);
    g_free (wait);
}

G_DEFINE_AUTOPTR_CLEANUP_FUNC (DaemonWait, daemon_wait_free)

/* Answer @task once, consuming the reference its wait holds; %NULL @error for a
 * daemon serving. */
static void
daemon_wait_answer (GTask  *task,
                    GError *error) /* (transfer full) (nullable) */
{
    DaemonWait *wait = g_task_get_task_data (task);

    if (wait->answered)
    {
        g_clear_error (&error);
        return;
    }

    wait->answered = TRUE;
    g_clear_signal_handler (&wait->presence_handler, wait->client);

    if (error)
        g_task_return_error (task, error);
    else
        g_task_return_boolean (task, TRUE);
    g_object_unref (task);
}

static void
on_daemon_wait_presence (GPasteClient *client,
                         GParamSpec   *pspec G_GNUC_UNUSED,
                         gpointer      user_data)
{
    switch (g_paste_client_get_daemon_presence (client))
    {
    case G_PASTE_DAEMON_PRESENCE_READY:
        daemon_wait_answer (user_data, NULL);
        break;
    case G_PASTE_DAEMON_PRESENCE_ABSENT:
        daemon_wait_answer (user_data, g_error_new_literal (G_IO_ERROR, G_IO_ERROR_NOT_CONNECTED, _("No GPaste daemon is serving a history.")));
        break;
    default:
        break;
    }
}

static void
on_daemon_wait_legacy (GObject      *source_object G_GNUC_UNUSED,
                       GAsyncResult *res,
                       gpointer      user_data)
{
    g_autoptr (GTask) task = user_data;

    /* Borrowed: what the answer consumes is the wait's own reference, the
     * probe's going with @task here. */
    if (g_paste_util_daemon_is_legacy_finish (res, NULL))
    {
        daemon_wait_answer (task,
                            g_error_new_literal (G_IO_ERROR, G_IO_ERROR_NOT_CONNECTED,
                                                 _("The GPaste daemon running is an older one, which serves none of this: restart it with “gpaste-client daemon-reexec”.")));
    }
}

static gboolean
on_daemon_wait_cancelled (GCancellable *cancellable,
                          gpointer      user_data)
{
    GError *error = NULL;

    g_cancellable_set_error_if_cancelled (cancellable, &error);
    daemon_wait_answer (user_data, error);

    return G_SOURCE_REMOVE;
}

/**
 * g_paste_util_wait_for_daemon:
 * @client: a #GPasteClient
 * @cancellable: (nullable): a #GCancellable
 * @callback: (scope async): called once a daemon serves, or none will
 * @user_data: data for @callback
 *
 * Wait for a daemon to serve @client before calling it, starting one if none
 * runs (g_paste_client_follow_daemon ()). A daemon owns the name before it
 * serves anything, settling its storage first -- one just started, one
 * re-executing -- and a call made in between finds no object to answer it. The
 * wait lasts for as long as the client deems one on its way, two minutes
 * without a history served at most, bar a GPaste 45 or 50 an update left
 * running, which owns the name and never serves this interface: asked once
 * whether that is who owns it, the wait fails at once, saying how to restart
 * it.
 */
G_PASTE_VISIBLE void
g_paste_util_wait_for_daemon (GPasteClient       *client,
                              GCancellable       *cancellable,
                              GAsyncReadyCallback callback,
                              gpointer            user_data)
{
    g_return_if_fail (G_PASTE_IS_CLIENT (client));
    g_return_if_fail (!cancellable || G_IS_CANCELLABLE (cancellable));

    GTask *task = g_task_new (client, cancellable, callback, user_data);
    DaemonWait *wait = g_new0 (DaemonWait, 1);

    g_task_set_source_tag (task, g_paste_util_wait_for_daemon);
    wait->client = g_object_ref (client);
    wait->was_following = g_paste_client_is_following (client);
    g_task_set_task_data (task, wait, daemon_wait_free);
    g_paste_client_follow_daemon (client, TRUE);
    wait->presence_handler = g_signal_connect (client, "notify::daemon-presence", G_CALLBACK (on_daemon_wait_presence), task);

    if (cancellable)
    {
        wait->cancelled = g_cancellable_source_new (cancellable);
        g_source_set_callback (wait->cancelled, G_SOURCE_FUNC (on_daemon_wait_cancelled), task, NULL);
        g_source_set_static_name (wait->cancelled, "[GPaste] daemon wait cancelled");
        g_source_attach (wait->cancelled, g_task_get_context (task));
    }

    if (g_paste_client_get_daemon_presence (client) == G_PASTE_DAEMON_PRESENCE_STARTING)
        g_paste_util_daemon_is_legacy (client, cancellable, on_daemon_wait_legacy, g_object_ref (task));
    on_daemon_wait_presence (client, NULL, task);
}

/**
 * g_paste_util_wait_for_daemon_finish:
 * @result: the #GAsyncResult handed to the callback
 * @error: return location for a #GError, or %NULL
 *
 * Fails with %G_IO_ERROR_NOT_CONNECTED when no daemon serves, or the one there
 * never will.
 *
 * Returns: whether a daemon serves
 */
G_PASTE_VISIBLE gboolean
g_paste_util_wait_for_daemon_finish (GAsyncResult *result,
                                     GError      **error)
{
    g_return_val_if_fail (G_IS_TASK (result) && g_task_get_source_tag (G_TASK (result)) == g_paste_util_wait_for_daemon, FALSE);

    return g_task_propagate_boolean (G_TASK (result), error);
}

/**
 * g_paste_util_reexecute_legacy_daemon:
 * @client: a #GPasteClient
 * @error: return location for a #GError, or %NULL
 *
 * Have a GPaste 45 or 50 owning the name re-execute, which it does on SIGUSR1:
 * a package update has replaced its binary, so what comes back is this
 * version's daemon. Two short calls to the bus, made synchronously.
 *
 * Only that daemon is signalled: one serving this interface has Reexecute, and
 * may be settling its storage behind a prompt the signal would tear down; and
 * the pid file names the daemon that wrote it and outlives it, so only when it
 * names the process owning the name does the signal reach a daemon rather than
 * whatever process got that pid since. Anything else fails with
 * %G_PASTE_ERROR_FAILED, and a question the bus could not answer with
 * %G_DBUS_ERROR or %G_IO_ERROR, as does a platform with no signals.
 *
 * Returns: whether the daemon was signalled
 */
G_PASTE_VISIBLE gboolean
g_paste_util_reexecute_legacy_daemon (GPasteClient *client,
                                      GError      **error)
{
    g_return_val_if_fail (G_PASTE_IS_CLIENT (client), FALSE);
    g_return_val_if_fail (!error || !*error, FALSE);

#ifdef G_OS_UNIX
    GDBusConnection *connection = g_dbus_proxy_get_connection (G_DBUS_PROXY (client));
    /* Both questions are asked of this one owner: asked of the name, the second
     * could reach a daemon that took it once the first was answered. */
    g_autofree gchar *unique = g_dbus_proxy_get_name_owner (G_DBUS_PROXY (client));

    if (!unique)
    {
        g_set_error_literal (error, G_PASTE_ERROR, G_PASTE_ERROR_FAILED, "nobody owns the name");
        return FALSE;
    }

    g_autoptr (GVariant) introspected = g_dbus_connection_call_sync (connection, unique, G_PASTE_DAEMON_OBJECT_PATH,
                                                                     "org.freedesktop.DBus.Introspectable", "Introspect",
                                                                     NULL, G_VARIANT_TYPE ("(s)"), G_DBUS_CALL_FLAGS_NO_AUTO_START, -1,
                                                                     NULL, error);

    if (!introspected)
        return FALSE;

    if (!g_paste_util_introspected_legacy (introspected))
    {
        g_set_error_literal (error, G_PASTE_ERROR, G_PASTE_ERROR_FAILED, "the daemon owning the name is not a GPaste 45 or 50");
        return FALSE;
    }

    g_autoptr (GVariant) owner = g_dbus_connection_call_sync (connection, "org.freedesktop.DBus", "/org/freedesktop/DBus",
                                                              "org.freedesktop.DBus", "GetConnectionUnixProcessID",
                                                              g_variant_new ("(s)", unique), G_VARIANT_TYPE ("(u)"),
                                                              G_DBUS_CALL_FLAGS_NONE, -1, NULL, error);

    if (!owner)
        return FALSE;

    guint32 owner_pid = 0;
    GPid pid = g_paste_util_read_pid_file ("Daemon");

    g_variant_get (owner, "(u)", &owner_pid);

    if (pid <= 0 || pid != (GPid) owner_pid)
    {
        g_set_error_literal (error, G_PASTE_ERROR, G_PASTE_ERROR_FAILED, "no pid file names the daemon owning the name");
        return FALSE;
    }

    if (kill (pid, SIGUSR1))
    {
        gint saved = errno;

        g_set_error_literal (error, G_IO_ERROR, g_io_error_from_errno (saved), g_strerror (saved));
        return FALSE;
    }

    return TRUE;
#else
    (void) client;
    g_set_error_literal (error, G_IO_ERROR, G_IO_ERROR_NOT_SUPPORTED, "no signal to re-execute a daemon with");

    return FALSE;
#endif
}

/**
 * g_paste_util_open_storage_migration:
 * @revision: (out): where to put the revision to restore if re-execution fails
 * @error: return location for a #GError, or %NULL
 *
 * Open the storage-migration gate before requesting daemon re-execution.
 * Resetting the revision marks the backend as never migrated. Call this on
 * the main context: the temporary #GPasteSettings wrapper caches settings and
 * receives their notifications there.
 *
 * The reset is read back, as the settings ask of a caller that has to know
 * whether a write took: one refused -- a key an administrator locked --
 * fails with %G_PASTE_ERROR_FAILED, so that nothing re-executes the daemon
 * for a migration its successor would find the gate closed on.
 *
 * The re-exec is the caller's own, and so is closing the gate again
 * (g_paste_util_cancel_storage_migration()) once there is no re-exec left to
 * expect: `gpaste-client migrate` has a second route to one -- signalling a
 * daemon too old for the method -- and a gate closed on the first route's
 * failure would leave that successor nothing to migrate.
 *
 * Returns: whether the gate is open
 */
G_PASTE_VISIBLE gboolean
g_paste_util_open_storage_migration (guint64 *revision,
                                     GError **error)
{
    g_return_val_if_fail (revision, FALSE);
    g_return_val_if_fail (!error || !(*error), FALSE);

    g_autoptr (GPasteSettings) settings = g_paste_settings_new ();

    *revision = g_paste_settings_get_storage_backend_revision (settings);

    g_paste_settings_reset (settings, G_PASTE_STORAGE_BACKEND_REVISION_SETTING);
    g_paste_settings_sync (settings);
    g_paste_settings_reload (settings);

    /* The revision the daemon will read, as reload () just read it from what is
     * stored -- not whether a user value is left: a system default, or a reset
     * the keyfile backend took in memory but could not write, leaves none and
     * the gate closed all the same. Back at the schema's 0 or refused, with no
     * revision of the daemon's own to compare to on this side. */
    if (g_paste_settings_get_storage_backend_revision (settings))
    {
        g_set_error_literal (error, G_PASTE_ERROR, G_PASTE_ERROR_FAILED, "the storage backend revision cannot be reset, so no migration can be asked for");
        return FALSE;
    }

    return TRUE;
}

/**
 * g_paste_util_prepare_storage_migration:
 *
 * Open the storage-migration gate, as g_paste_util_open_storage_migration ()
 * does, without saying whether it opened.
 *
 * Returns: the revision to restore if re-execution fails
 */
G_PASTE_VISIBLE guint64
g_paste_util_prepare_storage_migration (void)
{
    guint64 revision = 0;

    g_paste_util_open_storage_migration (&revision, NULL);

    return revision;
}

/**
 * g_paste_util_cancel_storage_migration:
 * @revision: the revision returned by g_paste_util_prepare_storage_migration()
 *
 * Restore the migration gate after a failed re-execution. A revision written
 * by a completed migration must survive a late transport error from its caller,
 * which is what the guard below is: a revision already back means the successor
 * migrated, and the error was reported over a request that in fact succeeded.
 *
 * What the guard cannot cover is the same error reported while the successor is
 * still starting, its revision not yet written -- the gate is then closed again
 * under a migration that is about to run, and the successor finds nothing to do.
 * Only the daemon knows which of the two it is, and it is not there to ask: a
 * re-exec tears the connection down. Closing the gate is the side to be wrong
 * on, a migration the user asks for again costing one more click where a gate
 * left open re-runs a migration on every start. A missing reply is not one of
 * these cases at all: g_paste_client_reexecute_finish() reads it as the success
 * it is, so an error here is a request that really did fail somewhere.
 */
G_PASTE_VISIBLE void
g_paste_util_cancel_storage_migration (guint64 revision)
{
    g_autoptr (GPasteSettings) settings = g_paste_settings_new ();

    if (!g_paste_settings_get_storage_backend_revision (settings))
    {
        /* Closed the way prepare () opened it: a gate that was open because the
         * key had no value at all is left with none, rather than with one written
         * over it that no other path produces. */
        if (revision)
            g_paste_settings_set_storage_backend_revision (settings, revision);
        else
            g_paste_settings_reset (settings, G_PASTE_STORAGE_BACKEND_REVISION_SETTING);
        g_paste_settings_sync (settings);
    }
}

/**
 * g_paste_util_pwquality_available:
 *
 * Whether this build can rate a password at all, i.e. whether it was built with
 * libpwquality. A form that cannot must say so rather than show a meter pinned
 * at zero.
 *
 * Returns: whether g_paste_util_password_strength() can rate anything
 */
G_PASTE_VISIBLE gboolean
g_paste_util_pwquality_available (void)
{
#ifdef G_PASTE_ENABLE_PWQUALITY
    return TRUE;
#else
    return FALSE;
#endif
}

#ifdef G_PASTE_ENABLE_PWQUALITY
/* The textual rating shown when the password passes the basic checks (so
 * libpwquality has no specific complaint to surface instead). */
static const gchar *
password_rating (guint level)
{
    switch (level)
    {
    case 1:
        return _("Weak");
    case 2:
        return _("Fair");
    case 3:
        return _("Good");
    case 4:
        return _("Strong");
    default:
        return "";
    }
}
#endif

/**
 * g_paste_util_password_strength:
 * @password: (nullable): the password to rate
 * @hint: (out) (transfer full) (nullable): the rating word, or libpwquality's
 *        own advice on a hard failure
 *
 * GNOME-style password rating via libpwquality (as gnome-control-center does):
 * map the 0-100 score to a 0-4 meter level and produce an actionable hint. On a
 * hard failure (too short, dictionary word, ...) libpwquality returns a negative
 * code whose localized reason becomes the hint.
 *
 * Built without libpwquality there is no rating to give: the level is 0 and
 * @hint is %NULL. A form should say so rather than leave the rating out —
 * someone choosing a password should know it is not being judged, instead of
 * reading a silent absence as approval.
 *
 * Returns: the meter level, from 0 (nothing to say) to 4 (strong)
 */
G_PASTE_VISIBLE guint
g_paste_util_password_strength (const gchar *password,
                                gchar      **hint)
{
    g_return_val_if_fail (hint, 0);

    *hint = NULL;

#ifdef G_PASTE_ENABLE_PWQUALITY
    if (!password || !*password)
        return 0;

    /* Re-reading the config on every keystroke would be wasteful, and it cannot
     * change under us within a process.
     *
     * Under a lock rather than on a bare first-use check, and held for the
     * rating itself: this is installed, introspected API, so the daemon being
     * single-threaded says nothing about who else calls it -- and a second
     * caller must neither find the settings published before their config has
     * been read nor be inside libpwquality's own dictionary lookup while the
     * first one is. */
    static GMutex                lock;
    static pwquality_settings_t *pwq = NULL;

    g_autoptr (GMutexLocker) locker = g_mutex_locker_new (&lock);

    if (!pwq)
    {
        pwquality_settings_t *settings = pwquality_default_settings ();

        /* Out of memory. Degrade to "no rating" rather than dereferencing it —
         * and note the guard re-runs next keystroke, so this retries rather
         * than latching. */
        if (!settings)
            return 0;

        pwquality_read_config (settings, NULL, NULL);
        pwq = settings;
    }

    void *auxerror = NULL;
    gint score = pwquality_check (pwq, password, NULL, NULL, &auxerror);

    if (score < 0)
    {
        /* pwquality_strerror also consumes auxerror, so this frees it too. */
        gchar buf[PWQ_MAX_ERROR_MESSAGE_LEN];

        *hint = g_strdup (pwquality_strerror (buf, sizeof (buf), score, auxerror));
        return 1;
    }

    guint level = (score < 50) ? 1
                : (score < 75) ? 2
                : (score < 90) ? 3
                :                G_PASTE_UTIL_STRENGTH_MAX;

    *hint = g_strdup (password_rating (level));

    return level;
#else
    (void) password;

    return 0;
#endif
}
