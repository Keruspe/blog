// SPDX-FileCopyrightText: 2010-2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com>
// SPDX-License-Identifier: BSD-2-Clause

#include <gpaste-3/gpaste-error.h>
#include <gpaste-3/gpaste-gsettings-keys.h>
#include <gpaste-3/gpaste-util.h>

#include <gpaste-daemon/gpaste-daemon-util.h>
#include <gpaste-daemon/gpaste-file-backend.h>
#include <gpaste-daemon/gpaste-noop-backend.h>
#include <gpaste-daemon/gpaste-storage-backend-private.h>
#include <gpaste-daemon/gpaste-storage-migration.h>

#ifdef G_PASTE_ENABLE_LIBSECRET
#include <gpaste-daemon/gpaste-storage-keyring.h>
#endif

#include <glib/gstdio.h>

#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

/* The import, re-key and store check workers running: see
 * g_paste_storage_is_busy (). Counted by g_paste_storage_run_worker () alone,
 * on the main thread each starts and reports on. */
static guint g_paste_storage_workers;

/* What a storage worker leaves while it runs, so that the next start can tell
 * an import or a change of passphrase this process did not live to finish:
 * "storage-journal" in the history directory, which names no history, those
 * being listed by their flavour's extension. Its first line is the operation
 * and the flavour it writes, each line after it a history written there,
 * escaped.
 *
 * An import's copies go at the next start, unless the setting already names
 * the flavour imported to -- the move happened, and what was written is the
 * store -- as a failed import takes them back. A change of passphrase cannot be
 * finished without both passphrases, so it is reported instead: the histories
 * listed are on the new one, the others on the old. Only a process dying
 * leaves either: a worker that ends removes it, its own report saying what
 * went wrong. */
#define G_PASTE_STORAGE_JOURNAL "storage-journal"

typedef enum
{
    JOURNAL_IMPORT,
    JOURNAL_REKEY,
    JOURNAL_N_OPERATIONS,
} JournalOperation;

static const gchar * const journal_operations[JOURNAL_N_OPERATIONS] = { "import", "rekey" };

/* The re-key the last process did not finish, its histories on the new
 * passphrase: reported by g_paste_storage_decryption_async (), once. */
static GStrv rekey_cut_short;

#ifdef G_PASTE_ENABLE_ENCRYPTION
/* g_paste_storage_decryption_needed () found the store another daemon's, and
 * left settling it and asking the keyring to g_paste_storage_decryption_async
 * (), once that daemon lets go. */
static gboolean decryption_left_to_gate;
#endif

static gchar *
journal_path (void)
{
    g_autofree gchar *dir = g_paste_util_get_history_dir_path ();

    return g_build_filename (dir, G_PASTE_STORAGE_JOURNAL, NULL);
}

/* Durable before what it records is written: a journal that a crash could
 * lose would be a journal of nothing. */
static gboolean
journal_write (JournalOperation operation,
               GPasteStorage    storage_kind,
               const GPtrArray *names,
               GError         **error)
{
    g_autoptr (GString) contents = g_string_new (NULL);

    g_string_append_printf (contents, "%s %d\n", journal_operations[operation], storage_kind);
    for (guint i = 0; i < names->len; ++i)
    {
        g_autofree gchar *escaped = g_strescape (g_ptr_array_index (names, i), NULL);

        g_string_append_printf (contents, "%s\n", escaped);
    }

    g_autofree gchar *path = journal_path ();

    /* That one logs why, and sets no error of its own. */
    if (!g_paste_util_ensure_history_dir_exists ())
    {
        g_set_error (error, G_IO_ERROR, G_IO_ERROR_FAILED, "Could not make the history directory to write %s in", path);
        return FALSE;
    }

    return g_file_set_contents_full (path, contents->str, contents->len,
                                     G_FILE_SET_CONTENTS_CONSISTENT | G_FILE_SET_CONTENTS_DURABLE, 0600, error);
}

static void
journal_remove (void)
{
    g_autofree gchar *path = journal_path ();

    if (g_unlink (path) && errno != ENOENT)
        g_warning ("Could not remove %s: %s", path, g_strerror (errno));
}

/* %FALSE for no journal, and for one that says nothing this GPaste can act on,
 * which goes. */
static gboolean
journal_read (JournalOperation *operation,
              GPasteStorage    *storage_kind,
              GStrv            *names)
{
    g_autofree gchar *path = journal_path ();
    g_autofree gchar *contents = NULL;

    if (!g_file_get_contents (path, &contents, NULL, NULL))
        return FALSE;

    g_auto (GStrv) lines = g_strsplit (contents, "\n", -1);
    /* An empty journal splits into no line at all. */
    g_auto (GStrv) head = g_strsplit ((lines[0]) ? lines[0] : "", " ", 2);
    g_autoptr (GStrvBuilder) builder = g_strv_builder_new ();
    gint64 kind = -1;

    *operation = JOURNAL_N_OPERATIONS;
    for (guint i = 0; i < JOURNAL_N_OPERATIONS; ++i)
    {
        if (!g_strcmp0 (head[0], journal_operations[i]))
            *operation = i;
    }

    if (*operation == JOURNAL_N_OPERATIONS || !head[1] ||
        !g_ascii_string_to_signed (head[1], 10, 0, G_PASTE_N_STORAGE - 1, &kind, NULL))
    {
        g_warning ("Dropping %s, which records nothing this GPaste knows of", path);
        journal_remove ();
        return FALSE;
    }

    for (GStrv line = lines + 1; *line; ++line)
    {
        g_autofree gchar *name = g_strcompress (*line);

        if (g_paste_util_history_name_is_valid (name))
            g_strv_builder_take (builder, g_steal_pointer (&name));
    }

    *storage_kind = kind;
    *names = g_strv_builder_end (builder);

    return TRUE;
}

/* What the last process left in the journal, before anything reads the
 * store: under the storage lock, and not while a worker of this process runs
 * -- an in-shell daemon taking over from a migration still running here. */
static void
journal_settle (GPasteSettings *settings)
{
    JournalOperation operation;
    GPasteStorage storage_kind;
    g_auto (GStrv) names = NULL;

    if (g_paste_storage_is_busy () || !g_paste_storage_backend_try_lock () ||
        !journal_read (&operation, &storage_kind, &names))
        return;

    if (operation == JOURNAL_REKEY)
    {
        g_autofree gchar *listed = g_strjoinv ("”, “", names);

        g_warning ("A change of passphrase was cut short: “%s” are on the new passphrase, the other histories on the previous one", listed);
        g_strfreev (rekey_cut_short);
        rekey_cut_short = g_steal_pointer (&names);
    }
    else if (g_paste_settings_get_storage_backend (settings) != storage_kind)
    {
        for (GStrv name = names; *name; ++name)
        {
            g_autoptr (GError) error = NULL;

            g_paste_storage_delete_history (storage_kind, *name, &error);
            if (error && !g_error_matches (error, G_IO_ERROR, G_IO_ERROR_NOT_FOUND))
            {
                /* Kept, to be taken back at the next start. */
                g_warning ("Could not take back the copy of “%s” an import cut short left: %s", *name, error->message);
                return;
            }
        }

        g_message ("Took back what an import cut short had copied");
    }

    journal_remove ();
}

typedef struct
{
    GAsyncReadyCallback done;
    gpointer            user_data;
} StorageWorker;

static void
on_storage_worker_done (GObject      *source,
                        GAsyncResult *result,
                        gpointer      user_data)
{
    g_autofree StorageWorker *worker = user_data;

    --g_paste_storage_workers;
    worker->done (source, result, worker->user_data);
}

/* Run @func on a thread of its own, for a task tagged @source_tag holding
 * @task_data, and answer @done on the main thread once it has ended -- the store
 * counted busy from the one to the other. */
static void
g_paste_storage_run_worker (gpointer            source_tag,
                            gpointer            task_data,
                            GDestroyNotify      task_data_free,
                            GTaskThreadFunc     func,
                            GAsyncReadyCallback done,
                            gpointer            user_data)
{
    StorageWorker *worker = g_new (StorageWorker, 1);

    worker->done = done;
    worker->user_data = user_data;

    g_autoptr (GTask) task = g_task_new (NULL, NULL, on_storage_worker_done, worker);

    g_task_set_source_tag (task, source_tag);
    g_task_set_task_data (task, task_data, task_data_free);
    ++g_paste_storage_workers;
    g_task_run_in_thread (task, func);
}

typedef struct
{
    GPasteSettings       *settings;
    GPastePrompt         *prompt;
    GTask                *task;

    /* The backend the history currently lives in (detected from the files on
     * disk): what we import from and clean up. */
    GPasteStorage         current;

    /* What the migration prompt last came back with. */
    GPasteStorage         chosen;
    gboolean              import;
    gboolean              cleanup;

#ifdef G_PASTE_ENABLE_ENCRYPTION
    /* The passphrase unlocking @current, once the keyring or the unlock prompt
     * has produced one that actually decrypts it. Kept here rather than in the
     * process-wide global because migrating between two encrypted flavors needs
     * the source key while the destination is being (re)keyed with another one.
     * Doubles as the "source already unlocked" flag, so a second Apply does not
     * ask again. In gcr secure memory; freed in migration_finish (). */
    GPastePassphrase     *source_passphrase;
    /* The process-wide passphrase as the migration found it, which is what
     * opens @current when this migration never unlocked it itself. */
    GPastePassphrase              *held_passphrase;

    /* Whether a new passphrase was asked for (only then is there a choice to
     * honour), and whether the user asked to remember it. Acted on once the
     * migration has actually applied, so a failed one never leaves the keyring
     * pointing at a history that was never written. */
    gboolean              passphrase_prompted;
    GPasteStorageRemember remember_passphrase;
#endif
} MigrationData;

/* Work out which backend the history currently lives in by looking at the files
 * on disk, independent of the (possibly stale or unset) settings value. The
 * active history is checked first; failing that, whichever flavour has the most
 * files on disk wins, so an existing setup is still recognised.
 *
 * The answer is @current, and %FALSE means there is none: the files could not be
 * read at all, and @current is then left as the caller found it. "There is
 * nothing stored" and "we could not look" are the same count and a very
 * different answer, and what comes out of here is written to storage-backend. */
static gboolean
detect_current_backend (GPasteSettings *settings,
                        GPasteStorage  *current)
{
    /* The storing flavours in tie-break precedence order: encrypted over plain,
     * then the encrypted file over the encrypted database but the plain
     * database over the plain file. Extensions come from
     * g_paste_storage_get_extension(), so a new flavour only needs adding here.
     *
     * Every one of them, whether or not this build can open it: what is on disk
     * is what the history is, and what can be done with it is the prompt's
     * rules' business (g_paste_prompt_can_import() and
     * g_paste_prompt_backend_changes() refuse a source this build cannot open).
     * Detected as the plain file such a build degrades it to, or as nothing,
     * it would be recorded as that in storage-backend, and forgotten by the
     * build that can open it. Only a build lacking a feature can tell this list
     * from one gated on the features built in: with every feature, the two are
     * the same. */
    static const GPasteStorage flavours[] = {
        G_PASTE_STORAGE_ENCRYPTED_FILE,
        G_PASTE_STORAGE_ENCRYPTED_SQLITE,
        G_PASTE_STORAGE_SQLITE,
        G_PASTE_STORAGE_FILE,
    };

    const gchar *name = g_paste_util_resolve_history_name (g_paste_settings_get_history_name (settings));
    GPasteStorage set = g_paste_settings_get_storage_backend (settings);

    /* The flavour storage-backend was set to, when the active history is stored
     * there: that is the one in use, and a copy left in another flavour by an
     * earlier migration -- which deletes the old data only when asked -- is
     * not, whatever its precedence. A setting at its default says nothing,
     * having never been chosen. "None" stores nothing to look for: chosen, it
     * is the one in use, and what an earlier flavour left is what the user
     * kept rather than what they went back to. */
    if (!g_paste_settings_is_default (settings, G_PASTE_STORAGE_BACKEND_SETTING))
    {
        if (set == G_PASTE_STORAGE_NOOP)
        {
            *current = set;

            return TRUE;
        }

        if (g_paste_util_history_is_stored (name, set))
        {
            *current = set;

            return TRUE;
        }
    }

    /* Otherwise the active history's own file wins, in the precedence order
     * above, so an existing encrypted setup is never demoted. */
    for (guint i = 0; i < G_N_ELEMENTS (flavours); ++i)
    {
        if (g_paste_util_history_is_stored (name, flavours[i]))
        {
            *current = flavours[i];

            return TRUE;
        }
    }

    /* No history under the active name: fall back to whichever flavour has the
     * most files on disk, ties broken by the same precedence. */
    g_autoptr (GStrvBuilder) suffix_builder = g_strv_builder_new ();
    guint counts[G_N_ELEMENTS (flavours)] = { 0 };

    for (guint i = 0; i < G_N_ELEMENTS (flavours); ++i)
        g_strv_builder_take (suffix_builder, g_strconcat (".", g_paste_storage_get_extension (flavours[i]), NULL));

    g_auto (GStrv) suffixes = g_strv_builder_end (suffix_builder);
    g_autoptr (GFile) dir = g_paste_util_get_history_dir ();
    g_autoptr (GError) error = NULL;
    g_auto (GStrv) files = g_paste_util_list_directory (dir, G_FILE_ATTRIBUTE_STANDARD_NAME, &error);

    /* A fresh profile has no directory yet and lists nothing, which is an
     * answer. A directory that is there but unreadable is not: its count would
     * come out zero and be written to storage-backend as "nothing is stored",
     * so it answers nothing at all instead. */
    if (!files)
    {
        g_warning ("Could not list the history directory to detect the current backend: %s", error->message);

        return FALSE;
    }

    for (GStrv file = files; *file; ++file)
    {
        /* The extensions are mutually non-suffixing (".xml" never matches
         * ".xmls", ".db" never ".dbs"), so each file counts for at most one. */
        for (guint i = 0; i < G_N_ELEMENTS (flavours); ++i)
        {
            if (g_str_has_suffix (*file, suffixes[i]))
            {
                ++counts[i];
                break;
            }
        }
    }

    /* Highest count wins; the array order breaks ties toward the higher-
     * precedence flavour (a later one must strictly exceed it). */
    guint best = 0;

    for (guint i = 1; i < G_N_ELEMENTS (flavours); ++i)
    {
        if (counts[i] > counts[best])
            best = i;
    }

    *current = counts[best] ? flavours[best] : G_PASTE_STORAGE_NOOP;

    return TRUE;
}

#ifdef G_PASTE_ENABLE_ENCRYPTION
/* The passphrase that already opens @storage_kind, without asking anyone: the
 * one this process holds, and failing that the one remembered in the keyring,
 * which is applied to the process when it verifies. %NULL when neither does and
 * the user has to be prompted.
 *
 * Everything that needs to unlock an existing history asks here, so they cannot
 * disagree about that order. */
static const gchar *
known_passphrase_for (GPasteStorage   storage_kind,
                      GPasteSettings *settings)
{
    const gchar *known = g_paste_storage_backend_get_passphrase ();

    if (known && g_paste_storage_passphrase_can_decrypt (storage_kind, settings, known))
        return known;

#ifdef G_PASTE_ENABLE_LIBSECRET
    /* The keyring's replaces the process passphrase to be verified, and a
     * refusal clears it: the one the daemon is persisting with is put back
     * then, or a prompt dismissed afterwards would leave it nothing to persist
     * with -- the reload that follows building the backend that stores
     * nothing. No test shows it: it takes a keyring holding a passphrase, and
     * the test environment runs no secret service. */
    g_autoptr (GPastePassphrase) held = (known) ? g_paste_passphrase_new (known) : NULL;

    if (g_paste_storage_keyring_apply_verified (storage_kind, settings))
        return g_paste_storage_backend_get_passphrase ();

    if (held)
        g_paste_storage_backend_set_passphrase (g_paste_passphrase_peek (held));
#else
    (void) settings;
#endif

    return NULL;
}
#endif

#ifdef G_PASTE_ENABLE_ENCRYPTION
/* Act on what the user said about remembering @cleartext. Only ever called
 * where the passphrase has just been proven, which is what makes it safe: a
 * wrong one is never written, and turning the switch off drops whatever was
 * remembered before. */
static void
remember_passphrase (GPasteStorageRemember remember,
                     const gchar          *cleartext)
{
#ifdef G_PASTE_ENABLE_LIBSECRET
    if (remember == G_PASTE_STORAGE_REMEMBER_YES)
        g_paste_storage_keyring_store (cleartext);
    else if (remember == G_PASTE_STORAGE_REMEMBER_NO)
        g_paste_storage_keyring_clear ();
#else
    (void) remember;
    (void) cleartext;
#endif
}
#endif

/* Hand a concern's outcome to whoever started it: the failure that ended it, or
 * plain success -- a dismissal included, since what the user chose has already
 * been applied by the time this runs. Shared by the three that answer nothing
 * else, which is what keeps them from disagreeing about what a %TRUE means. */
static void
storage_concern_return (GTask  *task,
                        GError *error) /* (transfer full) (nullable) */
{
    if (error)
        g_task_return_error (task, error);
    else
        g_task_return_boolean (task, TRUE);
}

/* One shape for those three _finish(): the source tag is what keeps one
 * concern's result from being read as another's. A mismatch is a wiring mistake
 * rather than anything the user can cause, but it still comes back as a
 * #GError -- every caller prints the message it gets, so leaving @error unset
 * would turn the diagnostic into a crash. g_paste_storage_doctor_finish () does
 * the same for its own. */
static gboolean
storage_concern_finish (GAsyncResult *result,
                        gpointer      source_tag,
                        GError      **error)
{
    if (!G_IS_TASK (result) || g_task_get_source_tag (G_TASK (result)) != source_tag)
    {
        g_set_error_literal (error, G_PASTE_ERROR, G_PASTE_ERROR_INVALID_ARGUMENT,
                             "This is not the result of the storage concern being finished");

        return FALSE;
    }

    return g_task_propagate_boolean (G_TASK (result), error);
}

/* Release the state and hand control back to the caller: the one way out of the
 * migration, whether it applied, was dismissed or never got started. @error is
 * the prompt failure that ended it, if any -- a dismissal is not one, and a
 * failure always ends the concern where it happened, so there is only ever the
 * one to report. */
static void
migration_finish (MigrationData *self,
                  GError        *error) /* (transfer full) (nullable) */
{
    g_autoptr (GTask) task = self->task;

#ifdef G_PASTE_ENABLE_ENCRYPTION
    g_paste_passphrase_free (self->source_passphrase);
    g_paste_passphrase_free (self->held_passphrase);
#endif

    g_object_unref (self->settings);
    g_object_unref (self->prompt);
    g_free (self);

    storage_concern_return (task, error);
}

G_PASTE_VISIBLE gboolean
g_paste_storage_migration_needed (GPasteSettings *settings)
{
    g_return_val_if_fail (G_PASTE_IS_SETTINGS (settings), FALSE);

    return g_paste_settings_get_storage_backend_revision (settings) != G_PASTE_STORAGE_BACKEND_REVISION;
}

/* Whether @written faithfully reproduces @source: same kind, same content. The
 * real value carries that for every kind, an image's being its checksum, which
 * is the same string whichever backend the bytes came back from. This
 * deliberately differs from g_paste_item_equals(): that dedup predicate ignores
 * the kind and treats two distinct passwords as never equal, whereas migration
 * must confirm a password's real value round-tripped (an encrypted backend
 * persists it) — so it is not a drop-in replacement here. */
static gboolean
imported_item_matches (GPasteItem *source,
                       GPasteItem *written)
{
    if (g_paste_item_get_kind (source) != g_paste_item_get_kind (written))
        return FALSE;

    return g_paste_str_equal (g_paste_item_get_real_value (source), g_paste_item_get_real_value (written));
}

/* Returns TRUE only if every history was copied into @chosen and reads back
 * with the same items — matched by uuid in order, contents verified — so the
 * caller never deletes the originals on a genuinely failed write (e.g. an
 * encrypted write that ran out of memory deriving the key, or a row that
 * committed with a corrupt payload). Two things are deliberately not failures:
 * the destination legitimately dropping items it cannot store (only the plain
 * flavors, which never persist passwords — an encrypted destination does, so a
 * password missing there *is* a failure), and in-memory sizes differing across
 * backends (an image read back from a database blob carries its PNG bytes
 * while a path-based one does not).
 *
 * A failure takes back what it already wrote to @chosen, with @error saying
 * which history stopped it: the next start detects the current backend from
 * the files on disk, the active history's first and the flavours in a fixed
 * order (see detect_current_backend()). A copy left behind under a flavour
 * that comes first would be taken for the history in use, every entry copied
 * since the failure lost behind it. */
static gboolean
import_histories (GPasteSettings *settings,
                  GPasteStorage   current,
                  const gchar    *current_passphrase,
                  GPasteStorage   chosen,
                  const gchar    *chosen_passphrase,
                  GError        **error)
{
    /* Both keys are passed explicitly: source and destination may both be
     * encrypted under two different passphrases, which the single process-wide
     * one cannot express. */
    g_autoptr (GPasteStorageBackend) previous = g_paste_storage_backend_new_with_passphrase (current, settings, current_passphrase);
    g_autoptr (GPasteStorageBackend) next = g_paste_storage_backend_new_with_passphrase (chosen, settings, chosen_passphrase);
    g_autoptr (GError) list_error = NULL;
    g_auto (GStrv) names = g_paste_storage_backend_list_histories (previous, &list_error);
    /* Every item each history stores, and so every one its copy reads back:
     * read as a load does, the size cap and images-support would leave out
     * what the cleanup that may follow deletes along with the rest. */
    g_paste_storage_backend_read_whole (previous);
    g_paste_storage_backend_read_whole (next);
    /* Only the plain flavors drop password items; an encrypted destination stores
     * them, so a password missing from the read-back is a genuine write failure
     * there and must not be waved through (the caller may then delete the source). */
    const gboolean chosen_stores_passwords = g_paste_storage_is_encrypted (chosen);
    gboolean ok = TRUE;

    /* A source we could not even list is not an empty one: importing nothing and
     * reporting success would let the caller delete histories still on disk. */
    if (!names)
    {
        g_propagate_prefixed_error (error, g_steal_pointer (&list_error),
                                    "Could not list the histories to migrate: ");
        return FALSE;
    }

    /* Refused before anything is written, as a new history is under a name the
     * storage in use cannot keep every file of (g_paste_storage_name_fits ()):
     * its write would fail half way through the import, or -- the encrypted
     * file flavour's re-key -- every change of passphrase afterwards would. */
    for (GStrv name = names; *name; ++name)
    {
        if (!g_paste_storage_name_fits (chosen, *name))
        {
            g_set_error (error, G_PASTE_ERROR, G_PASTE_ERROR_FAILED,
                         "The history “%s” has too long a name for the new storage backend", *name);
            return FALSE;
        }
    }

    /* Past the last history written to @chosen, which a failure takes back. A
     * copy the import replaced goes with it: what it held went with the write,
     * and the source still holds what replaced it. One whose write failed is
     * as it was, and stays, an older copy an earlier migration kept included. */
    GStrv written_end = names;
    /* What the journal names, which a crash leaves for the next start to take
     * back: each history before its write, the write being what may leave
     * something of it -- a database created, images, in clear for a plain
     * destination. */
    g_autoptr (GPtrArray) journaled = g_ptr_array_new ();

    for (GStrv name = names; ok && *name; ++name)
    {
        g_autolist (GPasteItem) history = NULL;
        gsize size = 0;

        /* Never let a source we could not actually read (a wrong passphrase, a
         * transient I/O error) pass as an empty history: writing that "empty"
         * into the destination and reporting success would let the caller delete
         * the still-intact originals. Bail out instead so the migration is kept
         * for a retry with the data untouched. */
        if (!g_paste_storage_backend_read_history (previous, *name, NULL /* cancellable */, &history, &size))
        {
            g_set_error (error, G_PASTE_ERROR, G_PASTE_ERROR_FAILED,
                         "Could not read the history “%s”", *name);
            ok = FALSE;
            break;
        }

        /* A destination already holding this history and unable to read it --
         * written by a newer GPaste, under another passphrase -- is one a write
         * refuses to touch, and the rollback below would then delete it all the
         * same: the import stops before it, leaving it exactly as it is. */
        g_autofree gchar *destination = g_paste_storage_backend_get_history_file_path (next, *name);

        if (g_file_test (destination, G_FILE_TEST_EXISTS))
        {
            g_autolist (GPasteItem) existing = NULL;
            gsize existing_size = 0;

            if (!g_paste_storage_backend_read_history (next, *name, NULL /* cancellable */, &existing, &existing_size))
            {
                g_set_error (error, G_PASTE_ERROR, G_PASTE_ERROR_FAILED,
                             "The new storage backend already holds a history “%s” it cannot read", *name);
                ok = FALSE;
                break;
            }
        }

        g_autoptr (GError) journal_error = NULL;

        g_ptr_array_add (journaled, *name);
        if (!journal_write (JOURNAL_IMPORT, chosen, journaled, &journal_error))
        {
            g_set_error (error, G_PASTE_ERROR, G_PASTE_ERROR_FAILED,
                         "Could not record the import of the history “%s”: %s", *name, journal_error->message);
            ok = FALSE;
            break;
        }

        if (!g_paste_storage_backend_write_history (next, *name, history))
        {
            g_set_error (error, G_PASTE_ERROR, G_PASTE_ERROR_FAILED,
                         "The history “%s” could not be written", *name);
            ok = FALSE;
            break;
        }
        written_end = name + 1;

        g_autolist (GPasteItem) written = NULL;
        gsize written_size = 0;

        /* Unreadable is what a truncated or undecryptable destination answers,
         * with whatever it got through before stopping, which may well be every
         * item: matching those would let the caller delete the originals of a
         * copy no read will accept. */
        if (!g_paste_storage_backend_read_history (next, *name, NULL /* cancellable */, &written, &written_size))
        {
            g_set_error (error, G_PASTE_ERROR, G_PASTE_ERROR_FAILED,
                         "The history “%s” could not be read back once written", *name);
            ok = FALSE;
            break;
        }

        const GList *w = written;

        for (const GList *h = history; ok && h; h = g_list_next (h))
        {
            if (w && g_paste_str_equal (g_paste_item_get_uuid (h->data), g_paste_item_get_uuid (w->data)))
            {
                ok = imported_item_matches (h->data, w->data);
                w = g_list_next (w);
            }
            else
                ok = !chosen_stores_passwords && g_paste_item_get_kind (h->data) == G_PASTE_ITEM_KIND_PASSWORD;
        }

        /* Nothing may read back that was not written. */
        if (w)
            ok = FALSE;

        if (!ok)
        {
            g_set_error (error, G_PASTE_ERROR, G_PASTE_ERROR_FAILED,
                         "The history “%s” did not read back as it was written", *name);
        }
    }

    if (ok)
        return TRUE;

    /* The destination's image directory goes only once no flavour stores the
     * name, which the source still does: that is the base delete_history()'s
     * rule, and it keeps the source's own images. */
    for (GStrv name = names; name != written_end; ++name)
    {
        g_autoptr (GError) delete_error = NULL;

        g_paste_storage_backend_delete_history (next, *name, &delete_error);

        if (delete_error)
            g_warning ("Could not remove the incomplete copy of the history “%s”: %s", *name, delete_error->message);
    }

    journal_remove ();

    return FALSE;
}

/* Delete what the import copied out of. %FALSE, with @error saying what first
 * went wrong, when any of it is still there: the user asked for their old
 * clipboard history to be deleted, and everything past this point (the revision
 * bump included) treats the migration as done, so this is the last chance to say
 * that part of it was not. */
static gboolean
cleanup_histories (GPasteSettings *settings,
                   GPasteStorage   current,
                   const gchar    *current_passphrase,
                   GError        **error)
{
    g_autoptr (GPasteStorageBackend) previous = g_paste_storage_backend_new_with_passphrase (current, settings, current_passphrase);
    g_autoptr (GError) failure = NULL;
    g_auto (GStrv) names = g_paste_storage_backend_list_histories (previous, &failure);

    if (!names)
    {
        g_propagate_prefixed_error (error, g_steal_pointer (&failure),
                                    "Could not list the migrated histories to clean up: ");

        return FALSE;
    }

    /* Every history that can go, goes: stopping at the first failure would leave
     * behind data that had nothing wrong with it. */
    for (GStrv name = names; *name; ++name)
    {
        g_autoptr (GError) delete_error = NULL;

        g_paste_storage_backend_delete_history (previous, *name, &delete_error);

        if (!delete_error)
            continue;

        g_warning ("Could not delete the migrated history \"%s\": %s", *name, delete_error->message);

        if (!failure)
            failure = g_steal_pointer (&delete_error);
    }

    if (!failure)
        return TRUE;

    g_propagate_error (error, g_steal_pointer (&failure));

    return FALSE;
}

/* What the import needs, copied so the worker touches nothing the main thread
 * still owns. The passphrases are its own references into secure memory. */
typedef struct
{
    GPasteSettings   *settings;
    GPasteStorage     current;
    GPasteStorage     chosen;
    GPastePassphrase *current_passphrase;
    GPastePassphrase *chosen_passphrase;
} ImportWork;

static void
import_work_free (gpointer data)
{
    ImportWork *work = data;

    g_paste_passphrase_free (work->current_passphrase);
    g_paste_passphrase_free (work->chosen_passphrase);
    g_object_unref (work->settings);
    g_free (work);
}

G_DEFINE_AUTOPTR_CLEANUP_FUNC (ImportWork, import_work_free)

/* Runs on a worker thread. Importing an encrypted history derives an Argon2id
 * key per stream — read the source, write the destination, read it back to
 * verify — at MODERATE limits, so a few hundred milliseconds and a few hundred
 * megabytes each, several times over per history. On the main loop that is a
 * frozen daemon; hosted inside gnome-shell it is a frozen desktop, which is
 * what this exists to avoid. Nothing else touches the store meanwhile: a
 * migration runs before the daemon is built, or after it has been flushed and
 * stopped. */
static void
import_work_run (GTask        *task,
                 gpointer      source      G_GNUC_UNUSED,
                 gpointer      task_data,
                 GCancellable *cancellable G_GNUC_UNUSED)
{
    ImportWork *work = task_data;
    g_autoptr (GError) error = NULL;

    if (import_histories (work->settings,
                          work->current,
                          g_paste_passphrase_peek (work->current_passphrase),
                          work->chosen,
                          g_paste_passphrase_peek (work->chosen_passphrase),
                          &error))
        g_task_return_boolean (task, TRUE);
    else
        g_task_return_error (task, g_steal_pointer (&error));
}

/* Everything after the import: settings, cleanup and keyring, all back on the
 * main thread where their ordering against the rest of the daemon holds. */
static void
apply_migration_settle (MigrationData *self,
                        gboolean       imported,
                        const GError  *import_error)
{
    GPasteStorage chosen = self->chosen;
    gboolean import = self->import;
    gboolean cleanup = self->cleanup;
    /* The source keeps the key it was unlocked with, the destination gets the
     * one just set (the process-wide passphrase), so an encrypted -> encrypted
     * migration re-keys the history instead of reading the old data with the
     * new key. Both %NULL for the plain flavors, which need none. */
    const gchar *current_passphrase = NULL;

#ifdef G_PASTE_ENABLE_ENCRYPTION
    current_passphrase = g_paste_passphrase_peek (self->source_passphrase);
#endif
#if defined(G_PASTE_ENABLE_ENCRYPTION) && defined(G_PASTE_ENABLE_LIBSECRET)
    /* Only ever read to decide what to remember, which is the one thing that
     * needs the keyring. */
    const gchar *chosen_passphrase = g_paste_storage_backend_get_passphrase ();
#endif

    /* Whether the history moved to @chosen. Not when the import genuinely
     * failed, nor when GSettings refused to store the new backend (a locked
     * key): the daemon then reads the backend the setting still names, and the
     * old data is all it has. Either way keep the current backend, data and
     * revision untouched, so nothing is lost or hidden and the migration is
     * offered again next time rather than silently leaving an empty or unread
     * backend. A failed import has already taken back what it wrote to
     * @chosen; a complete one refused by the lock stays where it is, the
     * same lock refusing the detection that could prefer it. A reply naming
     * the backend the setting already holds reads back equal under a lock
     * too, so it still settles -- "Keep as is", normally: the way out of a
     * dialog that would otherwise come back at every start. */
    gboolean moved = FALSE;

    if (import && !imported)
    {
        g_autofree gchar *message = g_strconcat (g_paste_prompt_text (G_PASTE_PROMPT_TEXT_IMPORT_FAILED_DESCRIPTION),
                                                 "\n\n", import_error->message, NULL);

        g_warning ("History import failed; keeping the current storage backend and old data: %s", import_error->message);
        /* As with a failed cleanup below: the dialog has closed, and the user
         * would otherwise find it back at the next start with no idea why. */
        g_paste_prompt_report (self->prompt,
                               g_paste_prompt_text (G_PASTE_PROMPT_TEXT_IMPORT_FAILED_TITLE),
                               message);
    }
    else
    {
        g_paste_settings_set_storage_backend (self->settings, chosen);
        g_paste_settings_sync_key (self->settings, G_PASTE_STORAGE_BACKEND_SETTING);
        moved = (g_paste_settings_get_storage_backend (self->settings) == chosen);

        if (!moved)
            g_warning ("Could not store the new storage backend; keeping the current one and old data");
    }

    /* The import is settled: what it wrote is the store, or a complete copy
     * the lock refused, which stays as an older copy does. */
    journal_remove ();

    if (!moved)
    {
#ifdef G_PASTE_ENABLE_ENCRYPTION
        /* We are staying on the source backend, so the process has to go back to
         * the passphrase that opens it — which is the one we unlocked it with,
         * or the one the process held coming in, none for a plain flavor.
         * Leaving the destination's in place would look to everything downstream
         * like the history is already unlocked: no prompt, and a backend built
         * with a key its data does not take; dropping the one held would have it
         * asked for again, or, dismissed, nothing stored for the session. */
        g_paste_storage_backend_set_passphrase (g_paste_passphrase_peek (self->source_passphrase ? self->source_passphrase : self->held_passphrase));
#endif
    }
    else
    {
        /* Whether the old data is actually gone, which is not the same as having
         * been told to delete it: the keyring decision below turns on the former. */
        gboolean cleaned = FALSE;

        /* Only delete the old data once the import is confirmed, so a failed
         * import can never wipe the history it was meant to migrate. */
        if (cleanup && imported)
        {
            g_autoptr (GError) cleanup_error = NULL;

            /* Told, not retried: the revision is bumped either way, because the
             * dialog cannot offer this again -- the backend it would come back
             * on is the one we just moved to, and "delete the old data" is only
             * offered for a migration that changes backend. So the user hears
             * that their old clipboard history is still on disk, once, while
             * they are still looking. */
            cleaned = cleanup_histories (self->settings, self->current, current_passphrase, &cleanup_error);

            if (!cleaned)
            {
                g_autofree gchar *message = g_strconcat (g_paste_prompt_text (G_PASTE_PROMPT_TEXT_CLEANUP_FAILED_DESCRIPTION),
                                                         "\n\n", cleanup_error->message, NULL);

                g_paste_prompt_report (self->prompt,
                                       g_paste_prompt_text (G_PASTE_PROMPT_TEXT_CLEANUP_FAILED_TITLE),
                                       message);
            }
        }

        g_paste_settings_set_storage_backend_revision (self->settings, G_PASTE_STORAGE_BACKEND_REVISION);

#if defined(G_PASTE_ENABLE_ENCRYPTION) && defined(G_PASTE_ENABLE_LIBSECRET)
        /* The new passphrase now opens what is actually on disk, so this is when
         * the user's choice about remembering it can be honoured. Only when one
         * was asked for *and* the destination is still the encrypted backend it
         * was asked for: anything else never offered the choice, and must not
         * silently discard an entry that still unlocks a history. */
        if (self->passphrase_prompted && g_paste_storage_is_encrypted (chosen))
            remember_passphrase (self->remember_passphrase, chosen_passphrase);
        /* Leaving encryption behind for good: once the encrypted history it
         * opened is gone, a remembered passphrase is a secret kept for nothing.
         * Only once it is actually gone, though — data we kept is still locked
         * with it, and migrating back would want it. Which is why this asks
         * @cleaned rather than what the user ticked: a cleanup that failed
         * leaves those .xmls files exactly where they were, and dropping the
         * only passphrase that opens them would finish what it could not. */
        else if (g_paste_storage_is_encrypted (self->current) && !g_paste_storage_is_encrypted (chosen) &&
                 cleaned)
            g_paste_storage_keyring_clear ();
#endif
    }

    migration_finish (self, NULL);
}

static void
on_import_done (GObject      *source G_GNUC_UNUSED,
                GAsyncResult *result,
                gpointer      user_data)
{
    g_autoptr (GError) error = NULL;
    gboolean imported = g_task_propagate_boolean (G_TASK (result), &error);

    apply_migration_settle (user_data, imported, error);
}

static void
apply_migration (MigrationData *self)
{
    /* Import (if any) before switching the backend, so a failed write never
     * leaves the daemon pointed at an empty new backend with the real data
     * orphaned. Nothing else below is expensive — deleting the old data unlinks
     * files and derives no key — so this is the only step that goes to a thread. */
    if (!self->import)
    {
        apply_migration_settle (self, TRUE, NULL);
        return;
    }

    g_autoptr (ImportWork) work = g_new0 (ImportWork, 1);

    work->settings = g_object_ref (self->settings);
    work->current = self->current;
    work->chosen = self->chosen;
#ifdef G_PASTE_ENABLE_ENCRYPTION
    work->current_passphrase = g_paste_passphrase_copy (self->source_passphrase);
    work->chosen_passphrase = g_paste_passphrase_new (g_paste_storage_backend_get_passphrase ());
#endif

    g_paste_storage_run_worker (apply_migration, g_steal_pointer (&work), import_work_free, import_work_run, on_import_done, self);
}

#ifdef G_PASTE_ENABLE_ENCRYPTION
/* @unlocked says whether a passphrase that actually decrypts is now installed.
 * Asking the process-wide global instead would be wrong: continue_apply() only
 * prompts when the global is absent *or* does not decrypt this flavour, so on a
 * dismissal a stale one is still sitting there and would read as success. */
/* @error is borrowed and only set when the prompt implementation failed, which
 * is not the same as the user dismissing it (@unlocked %FALSE, @error %NULL). */
typedef void (*UnlockDoneFunc) (gboolean  unlocked,
                                GError   *error,
                                gpointer  user_data);

typedef struct
{
    GPastePrompt   *prompt;
    GPasteSettings *settings;
    GPasteStorage   storage_kind; /* the encrypted flavour being unlocked */
    /* Whether the passphrase is asked twice: see unlock_prompt (). */
    gboolean        confirm;
    UnlockDoneFunc  done;
    gpointer        user_data;
} UnlockPrompt;

static void
on_unlock_reply (GObject      *source,
                 GAsyncResult *result,
                 gpointer      user_data)
{
    UnlockPrompt *prompt = user_data;
    GPasteStorageRemember remember;
    /* A dismissal comes back as %NULL with no error set; an error means the
     * prompt implementation itself failed, which the built-in ones never do but
     * an out-of-tree one (gnome-shell's) can. Both end the same way -- there is
     * no passphrase -- so it is only worth saying which happened. */
    g_autoptr (GError) prompt_error = NULL;
    g_autoptr (GPastePassphrase) passphrase = g_paste_prompt_passphrase_finish (G_PASTE_PROMPT (source), result,
                                                                                &remember, &prompt_error);

    if (prompt_error)
        g_warning ("The passphrase prompt failed: %s", prompt_error->message);

    /* A wrong passphrase would load an empty history and let the next save
     * overwrite the real data, so never accept one that does not decrypt: ask
     * again instead. */
    const gchar *cleartext = g_paste_passphrase_peek (passphrase);

    if (passphrase && !g_paste_storage_passphrase_can_decrypt (prompt->storage_kind, prompt->settings, cleartext))
    {
        /* Carry the switch's state into the retry: it is the same question, and
         * re-deriving it from the keyring would quietly undo the answer. */
        g_paste_prompt_passphrase_async (prompt->prompt, prompt->confirm,
                                         _("Wrong passphrase, please try again"),
                                         remember, on_unlock_reply, prompt);
        return;
    }

    /* NULL on dismissal: leave no passphrase set. */
    if (passphrase)
    {
        g_paste_storage_backend_set_passphrase (cleartext);

        remember_passphrase (remember, cleartext);
    }

    UnlockDoneFunc done = prompt->done;
    gpointer done_data = prompt->user_data;
    gboolean unlocked = (passphrase != NULL);

    g_object_unref (prompt->prompt);
    g_object_unref (prompt->settings);
    g_free (prompt);

    if (done)
        done (unlocked, prompt_error, done_data);
}

/* Shared "unlock an existing encrypted history" prompt: ask for the passphrase,
 * verify it actually decrypts, re-prompt on a wrong one, then call @done once
 * settled (the passphrase is set on success, left unset on dismissal). Callers
 * try the keyring first; this is the prompt half they fall back to. */
static void
unlock_prompt (GPastePrompt   *ui,
               GPasteSettings *settings,
               GPasteStorage   storage_kind,
               UnlockDoneFunc  done,
               gpointer        user_data)
{
    UnlockPrompt *prompt = g_new0 (UnlockPrompt, 1);

    /* This outlives the call — for as long as the dialog is up, and across
     * every wrong-passphrase retry — so it cannot borrow either of them. The
     * shell host drops its last reference to the settings the moment the
     * extension is disabled, which can happen with the prompt still on screen. */
    prompt->prompt = g_object_ref (ui);
    prompt->settings = g_object_ref (settings);
    prompt->storage_kind = storage_kind;
    /* A store holding nothing to check a passphrase against takes whatever is
     * typed, which then keys every history written: a new key, asked for twice
     * as the migration and the re-key ask for one. */
    prompt->confirm = !g_paste_storage_passphrase_verifiable (storage_kind, settings);
    prompt->done = done;
    prompt->user_data = user_data;

    g_paste_prompt_passphrase_async (ui, prompt->confirm, NULL, G_PASTE_STORAGE_REMEMBER_UNCHANGED,
                                     on_unlock_reply, prompt);
}

static void continue_apply (MigrationData *self);
static void ask_migration (MigrationData *self);

/* Take a copy of the (already verified) passphrase unlocking the source. */
static void
set_source_passphrase (MigrationData *self,
                       const gchar   *passphrase)
{
    g_paste_passphrase_free (self->source_passphrase);
    self->source_passphrase = g_paste_passphrase_new (passphrase);
}

static void
on_passphrase_set (GObject      *source,
                   GAsyncResult *result,
                   gpointer      user_data)
{
    MigrationData *self = user_data;
    GPasteStorageRemember remember;
    /* As in on_unlock_reply(): a dismissal is %NULL with no error set. */
    g_autoptr (GError) prompt_error = NULL;
    g_autoptr (GPastePassphrase) passphrase = g_paste_prompt_passphrase_finish (G_PASTE_PROMPT (source), result,
                                                                                &remember, &prompt_error);

    /* A prompt that failed outright is not a question the user can answer
     * differently: end the concern on it rather than putting the same dialog
     * back up, which an implementation that fails reliably (a JS exception in an
     * out-of-tree one) would otherwise do for every round of the loop below. */
    if (prompt_error)
    {
        g_warning ("The passphrase prompt failed: %s", prompt_error->message);
        migration_finish (self, g_steal_pointer (&prompt_error));
        return;
    }

    /* Cancelled: ask again, so another backend can be picked. The state gathered
     * so far is kept, so the second time round only asks what is still
     * missing. */
    if (!passphrase)
    {
        ask_migration (self);
        return;
    }

    /* The destination may already hold histories, kept by an earlier migration
     * away from it: a passphrase they refuse would have the import write the
     * history under one and leave them under another, which nothing then opens
     * together. The one they take is what to type, or another flavour. */
    if (!g_paste_storage_passphrase_can_decrypt (self->chosen, self->settings, g_paste_passphrase_peek (passphrase)))
    {
        g_paste_prompt_passphrase_async (G_PASTE_PROMPT (source), TRUE,
                                         _("This storage already holds histories under another passphrase, please type that one"),
                                         remember, on_passphrase_set, self);
        return;
    }

    /* Remembering it waits until the migration has applied — see
     * apply_migration(). */
    self->passphrase_prompted = TRUE;
    self->remember_passphrase = remember;

    /* The destination's key, and from now on the daemon's: the callers all read
     * it back from here once the migration is done. */
    g_paste_storage_backend_set_passphrase (g_paste_passphrase_peek (passphrase));
    apply_migration (self);
}

/* Once the source encrypted history is unlocked, keep its passphrase aside (the
 * process-wide one is about to be replaced by the destination's) and carry on
 * with the next step; on dismissal (no passphrase) ask again instead. */
static void
on_source_unlocked (gboolean unlocked,
                    GError  *error,
                    gpointer user_data)
{
    MigrationData *self = user_data;

    /* As in on_passphrase_set(): a prompt that failed cannot be re-asked. */
    if (error)
    {
        migration_finish (self, g_error_copy (error));
        return;
    }

    if (!unlocked)
    {
        ask_migration (self);
        return;
    }

    set_source_passphrase (self, g_paste_storage_backend_get_passphrase ());

    continue_apply (self);
}
#endif

/* Apply the chosen backend, gathering whatever passphrases are still missing
 * first: the source's (to read the encrypted history we import from or delete)
 * then the destination's (a new one, so a re-keying migration never silently
 * reuses the source's). Each prompt re-enters here once answered, and the state
 * gathered so far is kept, so a second Apply only asks what is still missing. */
static void
continue_apply (MigrationData *self)
{
#ifdef G_PASTE_ENABLE_ENCRYPTION
    GPasteStorage chosen = self->chosen;

    /* Importing from (or deleting) an existing encrypted history needs its
     * passphrase to read or list it. Prefer one this process already holds, then
     * one remembered in the keyring, and only prompt when there is none or it has
     * gone stale. Done before asking for the destination's passphrase so a
     * wrong-passphrase retry happens before the user has picked a new one, not
     * after. */
    if (g_paste_storage_is_encrypted (self->current) && !self->source_passphrase &&
        (self->import || self->cleanup))
    {
        const gchar *known = known_passphrase_for (self->current, self->settings);

        if (!known)
        {
            unlock_prompt (self->prompt, self->settings, self->current, on_source_unlocked, self);
            return;
        }

        set_source_passphrase (self, known);
    }

    /* Switching to encrypted storage always needs a new passphrase to store with,
     * confirmed (and optionally remembered in the keyring) by the prompt. That
     * holds just as much when the source was encrypted too: the history is
     * re-keyed, never handed the source's passphrase behind the user's back.
     * Keeping the existing encrypted backend is the one case that needs nothing
     * here: its passphrase is obtained later through the daemon's normal unlock
     * flow. */
    if (g_paste_storage_is_encrypted (chosen) && chosen != self->current)
    {
        g_paste_prompt_passphrase_async (self->prompt, TRUE, NULL, G_PASTE_STORAGE_REMEMBER_UNCHANGED,
                                         on_passphrase_set, self);
        return;
    }
#endif

    apply_migration (self);
}

/* The migration prompt was answered. Dismissing it leaves the revision
 * untouched so it comes back on the next start: the user has to make a
 * deliberate choice, and the detected current backend (written by
 * g_paste_storage_migration_async() below) is what this session keeps in the
 * meantime. */
static void
on_migration_reply (GObject      *source,
                    GAsyncResult *result,
                    gpointer      user_data)
{
    MigrationData *self = user_data;

    /* As for the passphrase prompt: %FALSE is a dismissal, an error is the
     * implementation failing. Either way there is no answer to act on. */
    g_autoptr (GError) prompt_error = NULL;

    if (!g_paste_prompt_migration_finish (G_PASTE_PROMPT (source), result,
                                          &self->chosen, &self->import, &self->cleanup, &prompt_error))
    {
        if (prompt_error)
            g_warning ("The migration prompt failed: %s", prompt_error->message);

        migration_finish (self, g_steal_pointer (&prompt_error));
        return;
    }

    /* The storage chosen is one the prompt was offered:
     * g_paste_prompt_request_reply_migration (), which every prompt answers
     * through, dismisses any other (/storage/migration/unoffered-choice).
     *
     * Both toggles are clamped rather than trusted: a prompt backend is a
     * public, introspectable interface, and "delete the old data" answered for
     * a migration that is not moving anywhere would wipe the current history
     * with nothing imported to replace it -- as would one answered for a format
     * this build cannot open, through the backend standing in for it. Clamping
     * the fields, as the answer comes in, is also what keeps continue_apply()
     * from making the user unlock an encrypted history for an import and a
     * cleanup that will not happen. */
    self->import = self->import && g_paste_prompt_can_import (self->current, self->chosen);
    self->cleanup = self->cleanup && g_paste_prompt_backend_changes (self->current, self->chosen);

    continue_apply (self);
}

static void
ask_migration (MigrationData *self)
{
    GPasteStorage offered[G_PASTE_N_STORAGE];
    guint n_offered = 0;

    /* What this build can open, in the enum's order, and no storage last. */
    for (GPasteStorage kind = G_PASTE_STORAGE_NOOP + 1; kind < G_PASTE_N_STORAGE; ++kind)
    {
        if (g_paste_storage_is_supported (kind))
            offered[n_offered++] = kind;
    }
    offered[n_offered++] = G_PASTE_STORAGE_NOOP;

    g_paste_prompt_migration_async (self->prompt, offered, n_offered, self->current,
                                    on_migration_reply, self);
}

static void
storage_lock_thread (GTask        *task,
                     gpointer      source_object G_GNUC_UNUSED,
                     gpointer      task_data,
                     GCancellable *cancellable   G_GNUC_UNUSED)
{
    g_task_return_boolean (task, g_paste_storage_backend_lock_since (GPOINTER_TO_UINT (task_data), NULL));
}

/* What a startup gate does with the store waits for this process to hold the
 * storage lock: a daemon taken over from goes on rewriting the store until its
 * workers are done -- a re-key, an import -- keeping the lock meanwhile, and a
 * passphrase verified, a backend detected or a history imported before then
 * would be checked against, or taken from, a store about to change under it.
 * The wait is as long as that rewrite, so it runs on a thread of its own; no
 * storage worker counts it, since it writes nothing.
 *
 * @gate is the gate's task, whose task data is the settings, handed to
 * @callback once the wait is over: whether the lock was had is the result's
 * boolean (when_storage_locked_finish ()).
 *
 * This process letting go of the lock is counted from here, not from when a
 * pool thread gets to the wait: one letting go in between -- the in-shell
 * daemon stopped, with gnome-shell going on -- would otherwise go unseen, and
 * the wait install a lock nobody wants, for as long as gnome-shell runs. */
static void
when_storage_locked (GTask              *gate,
                     GAsyncReadyCallback callback)
{
    g_autoptr (GTask) wait = g_task_new (NULL, NULL /* cancellable */, callback, gate);

    g_task_set_source_tag (wait, when_storage_locked);
    g_task_set_name (wait, "gpaste-storage-lock-wait");
    g_task_set_task_data (wait, GUINT_TO_POINTER (g_paste_storage_backend_get_releases ()), NULL);
    g_task_run_in_thread (wait, storage_lock_thread);
}

/* Whether the gate goes on, the settings it carries read again if it does.
 * Without the lock -- this process having let go of it, as standing down does
 * -- the store is not the gate's to touch, and it ends with nothing done. With
 * it, or with no lock file to take, which no daemon can hold either, what the
 * daemon taken over from settled on is stored by now, and the notification
 * saying so may still be on its way. */
static gboolean
when_storage_locked_finish (GTask        *gate,
                            GAsyncResult *result)
{
    g_return_val_if_fail (g_task_get_source_tag (G_TASK (result)) == when_storage_locked, FALSE);

    if (!g_task_propagate_boolean (G_TASK (result), NULL))
    {
        g_task_return_boolean (gate, TRUE);
        return FALSE;
    }

    g_paste_settings_reload (g_task_get_task_data (gate));

    return TRUE;
}

static void
on_migration_locked (GObject      *source_object G_GNUC_UNUSED,
                     GAsyncResult *result,
                     gpointer      user_data)
{
    g_autoptr (GTask) task = user_data;

    if (!when_storage_locked_finish (task, result))
        return;

    GPastePrompt *prompt = g_task_get_source_object (task);
    GPasteSettings *settings = g_task_get_task_data (task);

#ifdef G_PASTE_ENABLE_ENCRYPTION
    /* Ahead of the import that may read one, as in
     * g_paste_storage_decryption_needed(). */
    g_paste_file_backend_settle_rekeys ();
#endif
    /* Ahead of the import too, which a copy cut short that does not read back
     * would stop (/storage/migration/import-cut-short-then-migrate). */
    journal_settle (settings);

    /* Done by the daemon taken over from, once it let go of the store. */
    if (!g_paste_storage_migration_needed (settings))
    {
        g_task_return_boolean (task, TRUE);
        return;
    }

    /* Detect the backend the history currently lives in from the files on disk,
     * and apply it right away so this session keeps the right backend even if the
     * prompt is dismissed without an explicit choice (importantly, an encrypted
     * history is not silently downgraded to "none").
     *
     * A detection that could not read the disk writes nothing: the stored setting
     * is then the best thing we know, and overwriting it with a guess is how an
     * encrypted history gets recorded as "no storage" and stops being offered for
     * import. */
    GPasteStorage current = g_paste_settings_get_storage_backend (settings);

    /* Read back, rather than taken as detected: a storage-backend GSettings
     * refuses to store -- a locked key -- leaves the daemon on the backend it
     * holds, and that one is what an import reads and a cleanup deletes. */
    if (detect_current_backend (settings, &current))
    {
        g_paste_settings_set_storage_backend (settings, current);
        g_paste_settings_sync_key (settings, G_PASTE_STORAGE_BACKEND_SETTING);
        current = g_paste_settings_get_storage_backend (settings);
    }

    MigrationData *self = g_new0 (MigrationData, 1);

    self->settings = g_object_ref (settings);
    self->prompt = g_object_ref (prompt);
    self->task = g_steal_pointer (&task);
    self->current = current;
#ifdef G_PASTE_ENABLE_ENCRYPTION
    self->held_passphrase = g_paste_passphrase_new (g_paste_storage_backend_get_passphrase ());
#endif

    ask_migration (self);
}

/**
 * g_paste_storage_migration_async:
 * @prompt: the #GPastePrompt to ask through
 * @settings: a #GPasteSettings instance
 * @callback: (scope async): called once the migration settled or was dismissed
 * @user_data: data passed to @callback
 *
 * Ask the user where GPaste should store the history, and act on the answer:
 * once this process holds the storage lock, so after a daemon taken over from
 * is done rewriting the store, and only should the migration still be needed
 * then.
 */
G_PASTE_VISIBLE void
g_paste_storage_migration_async (GPastePrompt       *prompt,
                                 GPasteSettings     *settings,
                                 GAsyncReadyCallback callback,
                                 gpointer            user_data)
{
    g_return_if_fail (G_PASTE_IS_PROMPT (prompt));
    g_return_if_fail (G_PASTE_IS_SETTINGS (settings));

    GTask *task = g_task_new (prompt, NULL /* cancellable */, callback, user_data);

    /* The concerns hand their results back through the same task type, so the
     * tag is what keeps one from being read as another. */
    g_task_set_source_tag (task, g_paste_storage_migration_async);
    g_task_set_task_data (task, g_object_ref (settings), g_object_unref);
    when_storage_locked (task, on_migration_locked);
}

/**
 * g_paste_storage_migration_finish:
 * @result: the #GAsyncResult handed to the callback
 * @error: return location for a #GError, or %NULL
 *
 * Collect the outcome of g_paste_storage_migration_async().
 *
 * The only failure is the #GPastePrompt implementation itself, so the domain is
 * whichever one that reports in: the built-in prompts never fail, an
 * out-of-tree one may raise anything (%G_PASTE_ERROR, %G_IO_ERROR,
 * %G_DBUS_ERROR, ...). Handing in the result of another operation is
 * %G_PASTE_ERROR.
 *
 * Returns: %TRUE unless the prompt implementation failed outright
 */
G_PASTE_VISIBLE gboolean
g_paste_storage_migration_finish (GAsyncResult *result,
                                  GError      **error)
{
    return storage_concern_finish (result, g_paste_storage_migration_async, error);
}

/**
 * g_paste_storage_is_busy:
 *
 * Whether a migration's import, a change of passphrase or a check of the store
 * is rewriting the store, on a thread of its own. The process ending, exec'ing
 * or letting go of the storage lock meanwhile cuts that write short, leaving a
 * copy the next start may take for the history or a history half re-keyed: a
 * host waits for this to answer %FALSE first.
 *
 * Returns: whether a storage worker is running
 */
G_PASTE_VISIBLE gboolean
g_paste_storage_is_busy (void)
{
    return g_paste_storage_workers > 0;
}

/* Ready whenever no worker runs: checked as the main context iterates, which it
 * does when the last worker's report is dispatched, so a wait costs no wake-up
 * of its own. */
static gboolean
g_paste_storage_idle_prepare (GSource *source G_GNUC_UNUSED,
                              gint    *timeout)
{
    *timeout = -1;

    return !g_paste_storage_workers;
}

static gboolean
g_paste_storage_idle_check (GSource *source G_GNUC_UNUSED)
{
    return !g_paste_storage_workers;
}

static gboolean
g_paste_storage_idle_dispatch (GSource    *source G_GNUC_UNUSED,
                               GSourceFunc callback,
                               gpointer    user_data)
{
    ((GSourceOnceFunc) (void (*) (void)) callback) (user_data);

    return G_SOURCE_REMOVE;
}

static GSourceFuncs g_paste_storage_idle_funcs = {
    .prepare  = g_paste_storage_idle_prepare,
    .check    = g_paste_storage_idle_check,
    .dispatch = g_paste_storage_idle_dispatch,
};

/**
 * g_paste_storage_when_idle:
 * @callback: (scope notified) (closure user_data) (destroy destroy): what to run
 * @user_data: the data to pass to @callback
 * @destroy: (nullable): what frees @user_data
 *
 * Run @callback once, on the main context, as soon as no worker rewrites the
 * store (g_paste_storage_is_busy ()): from its next iteration when none does
 * already, else once the last one has reported. What a host ending, exec'ing
 * or letting go of the storage lock waits on.
 *
 * Returns: the id of the wait, which g_source_remove () gives up on
 */
G_PASTE_VISIBLE guint
g_paste_storage_when_idle (GSourceOnceFunc callback,
                           gpointer        user_data,
                           GDestroyNotify  destroy)
{
    g_return_val_if_fail (callback, 0);

    g_autoptr (GSource) source = g_source_new (&g_paste_storage_idle_funcs, sizeof (GSource));

    g_source_set_callback (source, (GSourceFunc) (void (*) (void)) callback, user_data, destroy);
    g_source_set_static_name (source, "[GPaste] storage idle");

    return g_source_attach (source, NULL);
}

#ifdef G_PASTE_ENABLE_ENCRYPTION
/* Whether an encrypted history this process holds no passphrase for needs
 * unlocking, as both g_paste_storage_decryption_needed () and
 * g_paste_storage_decryption_async () ask, the first applying the keyring
 * besides: only in a build that can open it, one that cannot keeping nothing
 * at all instead and verifying no passphrase -- every one would be accepted,
 * then used for nothing. */
static gboolean
decryption_pending (GPasteStorage storage_kind)
{
    return g_paste_storage_is_encrypted (storage_kind) &&
           g_paste_storage_is_supported (storage_kind) &&
           !g_paste_storage_backend_get_passphrase ();
}
#endif

/**
 * g_paste_storage_decryption_needed:
 * @settings: a #GPasteSettings instance
 *
 * Whether an encrypted history still needs decrypting before it can be loaded:
 * the backend is encrypted and no passphrase is set yet. When libsecret is
 * built, a keyring passphrase that unlocks the history is applied as a side
 * effect (answering %FALSE then), so %TRUE means a prompt is genuinely
 * required: to ask for the passphrase, or to tell that a change of it the last
 * process did not live to finish left the histories on two, which
 * g_paste_storage_decryption_async() does either way.
 *
 * Every start asks this before loading anything, so it is also where the store
 * is made fit to be read, whatever its flavour: a change of passphrase the last
 * process left unfinished is settled, the copies an import it did not finish
 * wrote are taken back, and, once per process, the images GPaste 50 kept in
 * the history directory's shared images/ that no history names any more are
 * deleted.
 *
 * Returns: whether g_paste_storage_decryption_async() has something to ask or
 *     tell
 */
G_PASTE_VISIBLE gboolean
g_paste_storage_decryption_needed (GPasteSettings *settings)
{
    g_return_val_if_fail (G_PASTE_IS_SETTINGS (settings), FALSE);

    /* Every start asks this before loading anything, which is what the sweep
     * needs: see g_paste_file_backend_sweep_legacy_images (). Once per process,
     * gnome-shell asking again before an in-place migration, with a history
     * loaded. */
    static gsize legacy_images_swept = 0;

    if (g_once_init_enter (&legacy_images_swept))
    {
        g_paste_file_backend_sweep_legacy_images ();
        g_once_init_leave (&legacy_images_swept, 1);
    }

#ifdef G_PASTE_ENABLE_ENCRYPTION
    GPasteStorage storage_kind = g_paste_settings_get_storage_backend (settings);

    /* Every start asks this before loading anything or verifying a passphrase,
     * which is when a passphrase change the last process did not finish has
     * to be put back or done with: a history it left half re-keyed refuses
     * every read until then. */
    g_paste_file_backend_settle_rekeys ();
#endif
    /* And, once each history is whole, what the journal says of the set. */
    journal_settle (settings);
#ifdef G_PASTE_ENABLE_ENCRYPTION
    gboolean pending = decryption_pending (storage_kind);

    /* A store another daemon still holds may change under any passphrase
     * verified against it now, and what it leaves is not ours to settle yet:
     * g_paste_storage_decryption_async () does both once it lets go. */
    if (!g_paste_storage_backend_try_lock ())
    {
        decryption_left_to_gate = TRUE;
        return TRUE;
    }

#ifdef G_PASTE_ENABLE_LIBSECRET
    /* A keyring passphrase that unlocks the history is applied here, so no prompt
     * is needed at all: the caller can load straight away with the passphrase now
     * set in this process. */
    if (pending && g_paste_storage_keyring_apply_verified (storage_kind, settings))
        pending = FALSE;
#endif

    /* A change cut short between two histories is said through the prompt
     * g_paste_storage_decryption_async () has, whether or not it then asks
     * for anything. */
    return pending || rekey_cut_short;
#else
    return FALSE;
#endif
}

#ifdef G_PASTE_ENABLE_ENCRYPTION
/* The caller carries on either way: an encrypted history that stayed locked
 * loads as unreadable, which the history already refuses to overwrite. So only
 * a prompt that failed outright is worth reporting. */
static void
on_decryption_settled (gboolean unlocked G_GNUC_UNUSED,
                       GError  *error,
                       gpointer user_data)
{
    g_autoptr (GTask) task = user_data;

    storage_concern_return (task, (error) ? g_error_copy (error) : NULL);
}

/* A change cut short between two histories, said through @prompt whether or
 * not the gate then asks for anything. */
static void
report_rekey_cut_short (GPastePrompt *prompt)
{
    if (!rekey_cut_short)
        return;

    g_autofree gchar *listed = g_strjoinv ("”, “", rekey_cut_short);
    g_autofree gchar *message = g_strdup_printf ("%s\n\nThe change of passphrase was cut short: “%s” are on the new passphrase.",
                                                 g_paste_prompt_text (G_PASTE_PROMPT_TEXT_REKEY_SPLIT_DESCRIPTION),
                                                 listed);

    g_clear_pointer (&rekey_cut_short, g_strfreev);
    g_paste_prompt_report (prompt, g_paste_prompt_text (G_PASTE_PROMPT_TEXT_REKEY_FAILED_TITLE), message);
}

/* Once the store is this process's: what g_paste_storage_decryption_needed ()
 * left to the gate (@taken_over), then the prompt, when still needed. */
static void
decryption_unlock (GTask   *gate,
                   gboolean taken_over)
{
    g_autoptr (GTask) task = gate;
    GPastePrompt *prompt = g_task_get_source_object (task);
    GPasteSettings *settings = g_task_get_task_data (task);
    GPasteStorage storage_kind = g_paste_settings_get_storage_backend (settings);
    gboolean pending = decryption_pending (storage_kind);

    /* What a change of passphrase the daemon taken over from did not live to
     * finish left, settled as on_migration_locked () settles it, and the
     * keyring asked, before any prompt. */
    if (taken_over)
    {
        g_paste_file_backend_settle_rekeys ();
        journal_settle (settings);
        report_rekey_cut_short (prompt);
#ifdef G_PASTE_ENABLE_LIBSECRET
        if (pending && g_paste_storage_keyring_apply_verified (storage_kind, settings))
            pending = FALSE;
#endif
    }

    if (!pending)
    {
        g_task_return_boolean (task, TRUE);
        return;
    }

    /* The task is the callback's user_data, and on_decryption_settled owns it. */
    unlock_prompt (prompt, settings, storage_kind, on_decryption_settled, g_steal_pointer (&task));
}

static void
on_decryption_locked (GObject      *source_object G_GNUC_UNUSED,
                      GAsyncResult *result,
                      gpointer      user_data)
{
    g_autoptr (GTask) task = user_data;

    if (when_storage_locked_finish (task, result))
        decryption_unlock (g_steal_pointer (&task), FALSE);
}

static void
on_decryption_taken_over (GObject      *source_object G_GNUC_UNUSED,
                          GAsyncResult *result,
                          gpointer      user_data)
{
    g_autoptr (GTask) task = user_data;

    if (when_storage_locked_finish (task, result))
        decryption_unlock (g_steal_pointer (&task), TRUE);
}
#endif

/**
 * g_paste_storage_decryption_async:
 * @prompt: the #GPastePrompt to ask through
 * @settings: a #GPasteSettings instance
 * @callback: (scope async): called once the history is unlocked or the prompt dismissed
 * @user_data: data passed to @callback
 *
 * Unlock an already-encrypted history through a passphrase prompt.
 */
G_PASTE_VISIBLE void
g_paste_storage_decryption_async (GPastePrompt       *prompt,
                                  GPasteSettings     *settings,
                                  GAsyncReadyCallback callback,
                                  gpointer            user_data)
{
    g_return_if_fail (G_PASTE_IS_PROMPT (prompt));
    g_return_if_fail (G_PASTE_IS_SETTINGS (settings));

    g_autoptr (GTask) task = g_task_new (prompt, NULL /* cancellable */, callback, user_data);

    g_task_set_source_tag (task, g_paste_storage_decryption_async);

#ifdef G_PASTE_ENABLE_ENCRYPTION
    report_rekey_cut_short (prompt);

    /* What g_paste_storage_decryption_needed () left to the gate is done once
     * the daemon holding the store lets go of it, whatever is pending. */
    if (decryption_left_to_gate)
    {
        decryption_left_to_gate = FALSE;
        g_task_set_task_data (task, g_object_ref (settings), g_object_unref);
        when_storage_locked (g_steal_pointer (&task), on_decryption_taken_over);
        return;
    }

    /* Nothing to unlock otherwise, the keyring aside. Prompting then would
     * accept whatever is typed -- a flavour holding nothing encrypted refutes
     * nothing -- and remember it in the keyring for nothing. Asked again once
     * the store is this process's (on_decryption_locked ()). */
    if (decryption_pending (g_paste_settings_get_storage_backend (settings)))
    {
        g_task_set_task_data (task, g_object_ref (settings), g_object_unref);
        when_storage_locked (g_steal_pointer (&task), on_decryption_locked);
        return;
    }
#else
    (void) settings;
#endif

    g_task_return_boolean (task, TRUE);
}

/**
 * g_paste_storage_decryption_finish:
 * @result: the #GAsyncResult handed to the callback
 * @error: return location for a #GError, or %NULL
 *
 * Collect the outcome of g_paste_storage_decryption_async().
 *
 * As for g_paste_storage_migration_finish(): the only failure is the
 * #GPastePrompt implementation itself, in whichever domain it reports
 * (%G_PASTE_ERROR, %G_IO_ERROR, %G_DBUS_ERROR, ...), and handing in the result
 * of another operation is %G_PASTE_ERROR.
 *
 * Returns: %TRUE unless the prompt implementation failed outright
 */
G_PASTE_VISIBLE gboolean
g_paste_storage_decryption_finish (GAsyncResult *result,
                                   GError      **error)
{
    return storage_concern_finish (result, g_paste_storage_decryption_async, error);
}

#ifdef G_PASTE_ENABLE_ENCRYPTION
typedef struct
{
    GPastePrompt         *prompt;
    GPasteSettings       *settings;
    GTask                *task;

    /* The encrypted flavor being re-keyed, and the passphrase it is currently
     * encrypted with once we have one that actually decrypts it (in gcr secure
     * memory). */
    GPasteStorage         storage_kind;
    GPastePassphrase     *current_passphrase;

    /* What the worker is re-keying to, and what to do about remembering it
     * once it has — both settled before the hop, acted on after. */
    GPastePassphrase     *new_passphrase;
    GPasteStorageRemember remember;

    /* Set by the worker when a failed re-key could not be undone either, so the
     * histories are left split across two passphrases. Written on the worker
     * thread and read once it has completed, which the task's completion orders
     * for us. It picks which failure the user is told about: "nothing changed"
     * would be a lie here, and the reassuring one. */
    gboolean              split;
} RekeyData;

/* As migration_finish(): the one way out, carrying whatever ended it. */
static void
rekey_finish (RekeyData *self,
              GError    *error) /* (transfer full) (nullable) */
{
    g_autoptr (GTask) task = self->task;

    g_paste_passphrase_free (self->current_passphrase);
    g_paste_passphrase_free (self->new_passphrase);
    g_object_unref (self->settings);
    g_object_unref (self->prompt);
    g_free (self);

    storage_concern_return (task, error);
}

/* Re-key @name on its own backend: a backend caches whatever it last opened, so
 * giving each history a fresh one keeps a re-keyed database from being reopened
 * through an instance that still holds the old key. */
static gboolean
rekey_history (GPasteStorage   storage_kind,
               GPasteSettings *settings,
               const gchar    *name,
               const gchar    *from,
               const gchar    *to,
               gboolean       *split)
{
    g_autoptr (GPasteStorageBackend) backend = g_paste_storage_backend_new_with_passphrase (storage_kind, settings, from);

    return g_paste_storage_backend_rekey (backend, name, to, split);
}

/* Re-encrypt every history of the current flavor with @passphrase. Each one is
 * re-keyed whole or put back as it was, short of the filesystem refusing even
 * that, and they go one at a time: the first failure stops the loop and puts
 * the ones already re-keyed back on the passphrase they all shared, so the set
 * is left on one passphrase -- or, where something could not be put back,
 * reported split (@split in #RekeyData), which no later change repairs: it
 * keeps every history the passphrase in use does not open where it is. */
static gboolean
rekey_histories (RekeyData   *self,
                 const gchar *passphrase,
                 GError     **error)
{
    const gchar *current = g_paste_passphrase_peek (self->current_passphrase);
    g_autoptr (GPasteStorageBackend) backend = g_paste_storage_backend_new_with_passphrase (self->storage_kind,
                                                                                            self->settings,
                                                                                            current);
    g_autoptr (GError) list_error = NULL;
    g_auto (GStrv) names = g_paste_storage_backend_list_histories (backend, &list_error);

    /* Not "no histories" (that is an empty list): the listing itself failed, so
     * we have no idea what would be left behind. */
    if (!names)
    {
        g_propagate_prefixed_error (error, g_steal_pointer (&list_error),
                                    "Could not list the histories to change their passphrase: ");

        return FALSE;
    }

    /* The ones re-keyed so far, which are what a failure puts back. */
    g_autoptr (GPtrArray) rekeyed = g_ptr_array_new ();

    for (GStrv name = names; *name; ++name)
    {
        gboolean split = FALSE;
        g_autoptr (GError) journal_error = NULL;

        if (rekey_history (self->storage_kind, self->settings, *name, current, passphrase, &split))
        {
            g_ptr_array_add (rekeyed, *name);
            /* Recorded before the next is touched, so that a process dying
             * between two leaves which is on what said (journal_settle ()). */
            if (journal_write (JOURNAL_REKEY, self->storage_kind, rekeyed, &journal_error))
                continue;
        }
        else
        {
            /* A history this passphrase does not open is on another -- what a
             * change whose rollback failed leaves -- and stays on it: the
             * active history decides the passphrase
             * (g_paste_storage_passphrase_can_decrypt ()), and re-keying the
             * ones it opens is what lets the user carry on. Asked once its
             * re-key has failed, which changed nothing then, it having nothing
             * it could read: asked first, every history would have a key
             * derived and its document decrypted twice. Not asked of one whose
             * re-key could not put back what it changed, which is the failure
             * to report whatever its document now refutes -- no test leaves
             * that document on the new passphrase, the moves
             * /storage/rekey/split fails stopping a re-key before it is
             * installed. */
            if (!split && g_paste_storage_backend_refutes_passphrase (backend, *name))
            {
                g_warning ("The history \"%s\" is on another passphrase, which it keeps", *name);
                continue;
            }

            /* The failing one has put back what it had changed, unless it says
             * it could not: then it is on both passphrases whatever happens to
             * the others, which is the failure the user has to hear about. */
            if (split)
            {
                g_warning ("The history \"%s\" is left partly on the new passphrase", *name);
                self->split = TRUE;
            }
        }

        /* Put the ones that did move back on the passphrase they all still
         * shared a moment ago, rather than leave the set split between two — a
         * split one cannot be repaired by running this again, since it starts
         * from a single passphrase. The journal follows, for a process dying
         * half way through. */
        for (guint i = rekeyed->len; i > 0; --i)
        {
            const gchar *done = g_ptr_array_index (rekeyed, i - 1);

            if (!rekey_history (self->storage_kind, self->settings, done, passphrase, current, NULL))
            {
                g_warning ("The history \"%s\" is left on the new passphrase while the others keep the old one", done);
                self->split = TRUE;
                continue;
            }

            g_ptr_array_remove_index (rekeyed, i - 1);
            journal_write (JOURNAL_REKEY, self->storage_kind, rekeyed, NULL);
        }

        /* What this left, the report says. */
        journal_remove ();

        if (journal_error)
            g_set_error (error, G_PASTE_ERROR, G_PASTE_ERROR_FAILED,
                         "Could not record the change of passphrase: %s", journal_error->message);
        else
            g_set_error (error, G_PASTE_ERROR, G_PASTE_ERROR_FAILED,
                         "Failed to change the passphrase of the history \"%s\"", *name);

        return FALSE;
    }

    journal_remove ();

    /* An encrypted backend with nothing stored under it is not something we can
     * meaningfully re-key, and it is also what a flavor this build cannot
     * construct degrades to — adopting a passphrase then, and remembering it,
     * would hand out a key that opens nothing. */
    if (!rekeyed->len)
    {
        g_set_error_literal (error, G_PASTE_ERROR, G_PASTE_ERROR_NOT_FOUND,
                             "There is no stored history to change the passphrase of");

        return FALSE;
    }

    return TRUE;
}

static void
rekey_work_run (GTask        *task,
                gpointer      source      G_GNUC_UNUSED,
                gpointer      task_data   G_GNUC_UNUSED,
                GCancellable *cancellable G_GNUC_UNUSED)
{
    RekeyData *self = g_task_get_task_data (task);
    g_autoptr (GError) error = NULL;

    /* Unlike the import worker this one reports why: a re-key that did not
     * happen leaves the user holding a passphrase their history does not take,
     * which is the one outcome they have to be told about. */
    if (rekey_histories (self, g_paste_passphrase_peek (self->new_passphrase), &error))
        g_task_return_boolean (task, TRUE);
    else
        g_task_return_error (task, g_steal_pointer (&error));
}

/* Back on the main thread: only adopt the new passphrase once the data on disk
 * actually speaks it, or the daemon would reload an unreadable history — and
 * only remember it then, for the same reason. A re-key that gave up part way
 * leaves the keyring alone: it still holds the passphrase the untouched
 * histories take, and its failure is what the caller is told about. */
static void
on_rekey_done (GObject      *source G_GNUC_UNUSED,
               GAsyncResult *result,
               gpointer      user_data)
{
    RekeyData *self = user_data;
    g_autoptr (GError) error = NULL;

    if (g_task_propagate_boolean (G_TASK (result), &error))
    {
        const gchar *cleartext = g_paste_passphrase_peek (self->new_passphrase);

        g_paste_storage_backend_set_passphrase (cleartext);

        remember_passphrase (self->remember, cleartext);
    }
    else
    {
        /* The user typed a new passphrase, watched the dialog close, and their
         * history still takes the old one. Nothing downstream can tell them
         * that: the caller only gets a %FALSE it can log, and the D-Bus request
         * that asked for the change was answered before any of this ran. The
         * worker never fails without saying why (see rekey_work_run), so there
         * is always a reason to show.
         *
         * Which of the two failures it was matters more than the reason: a
         * re-key that could not be undone leaves histories on both passphrases,
         * and telling that user "nothing changed" would send them off with the
         * one passphrase that no longer opens everything. */
        g_autofree gchar *message = g_strconcat (g_paste_prompt_text (self->split
                                                                      ? G_PASTE_PROMPT_TEXT_REKEY_SPLIT_DESCRIPTION
                                                                      : G_PASTE_PROMPT_TEXT_REKEY_FAILED_DESCRIPTION),
                                                 "\n\n", error->message, NULL);

        g_paste_prompt_report (self->prompt,
                               g_paste_prompt_text (G_PASTE_PROMPT_TEXT_REKEY_FAILED_TITLE),
                               message);
    }

    rekey_finish (self, g_steal_pointer (&error));
}

static void
on_rekey_passphrase_set (GObject      *source,
                         GAsyncResult *result,
                         gpointer      user_data)
{
    RekeyData *self = user_data;
    GPasteStorageRemember remember;
    /* As in on_unlock_reply(): a dismissal is %NULL with no error set. */
    g_autoptr (GError) prompt_error = NULL;
    g_autoptr (GPastePassphrase) passphrase = g_paste_prompt_passphrase_finish (G_PASTE_PROMPT (source), result,
                                                                                &remember, &prompt_error);

    if (prompt_error)
    {
        g_warning ("The passphrase prompt failed: %s", prompt_error->message);
        rekey_finish (self, g_steal_pointer (&prompt_error));
        return;
    }

    /* Dismissed: nothing has been touched yet, so there is nothing to undo. */
    if (!passphrase)
    {
        rekey_finish (self, NULL);
        return;
    }

    /* Re-encrypting every history derives an Argon2id key per history, twice
     * over when one fails and the rest have to be put back — the same reason
     * the import runs off the main loop. Keep the passphrase and the choice
     * alive across the hop; the rest is decided back here. */
    self->new_passphrase = g_paste_passphrase_copy (passphrase);
    self->remember = remember;

    /* Borrowed: rekey_finish() owns it, and it outlives the task either way. */
    g_paste_storage_run_worker (on_rekey_passphrase_set, self, NULL, rekey_work_run, on_rekey_done, self);
}

/* The current history is unlocked: ask for the passphrase to replace it with.
 * Same prompt the migration uses to set up a new encrypted history — two
 * entries, the strength meter, the data-loss warning, and the switch that
 * remembers it in the keyring (which is what updates the stored one). */
static void
rekey_prompt_new_passphrase (RekeyData *self)
{
    g_paste_prompt_passphrase_async (self->prompt, TRUE, NULL, G_PASTE_STORAGE_REMEMBER_UNCHANGED,
                                     on_rekey_passphrase_set, self);
}

static void
on_rekey_source_unlocked (gboolean unlocked,
                          GError  *error,
                          gpointer user_data)
{
    RekeyData *self = user_data;

    /* As in the migration: a prompt that failed cannot be re-asked. */
    if (error)
    {
        rekey_finish (self, g_error_copy (error));
        return;
    }

    /* Dismissed without unlocking: there is no passphrase to change. */
    if (!unlocked)
    {
        rekey_finish (self, NULL);
        return;
    }

    self->current_passphrase = g_paste_passphrase_new (g_paste_storage_backend_get_passphrase ());

    rekey_prompt_new_passphrase (self);
}
#endif

/**
 * g_paste_storage_rekey_async:
 * @prompt: the #GPastePrompt to ask through
 * @settings: a #GPasteSettings instance
 * @callback: (scope async): called once the passphrase was changed, or the prompt dismissed
 * @user_data: data passed to @callback
 *
 * Change the passphrase of the encrypted history, re-encrypting everything with
 * the new one. Unlike the migration dialog this never moves the history: the
 * data stays in the backend it is in, only its key changes.
 *
 * Unlocks the history first (from this process, the keyring, or a prompt), then
 * asks for the new passphrase with a confirmation. Completes immediately when
 * the history is not encrypted, so there is no passphrase to change.
 */
G_PASTE_VISIBLE void
g_paste_storage_rekey_async (GPastePrompt       *prompt,
                             GPasteSettings     *settings,
                             GAsyncReadyCallback callback,
                             gpointer            user_data)
{
    g_return_if_fail (G_PASTE_IS_PROMPT (prompt));
    g_return_if_fail (G_PASTE_IS_SETTINGS (settings));

    g_autoptr (GTask) task = g_task_new (prompt, NULL /* cancellable */, callback, user_data);

    g_task_set_source_tag (task, g_paste_storage_rekey_async);

#ifdef G_PASTE_ENABLE_ENCRYPTION
    GPasteStorage storage_kind = g_paste_settings_get_storage_backend (settings);

    /* As in decryption_pending (): a store this build cannot open verifies no
     * passphrase, the one that would unlock it included. */
    if (g_paste_storage_is_encrypted (storage_kind) && !g_paste_storage_is_supported (storage_kind))
    {
        g_task_return_new_error (task, G_PASTE_ERROR, G_PASTE_ERROR_FAILED,
                                 "This build cannot open the history to change its passphrase");
        return;
    }

    if (g_paste_storage_is_encrypted (storage_kind))
    {
        RekeyData *self = g_new0 (RekeyData, 1);

        self->prompt = g_object_ref (prompt);
        self->settings = g_object_ref (settings);
        self->task = g_steal_pointer (&task);
        self->storage_kind = storage_kind;

        /* The passphrase this process already holds is the common case (the
         * daemon has been serving the history with it), then the keyring, then
         * ask — the same order the migration unlocks a source with. */
        const gchar *known = known_passphrase_for (storage_kind, settings);

        if (!known)
        {
            unlock_prompt (prompt, settings, storage_kind, on_rekey_source_unlocked, self);
            return;
        }

        self->current_passphrase = g_paste_passphrase_new (known);

        rekey_prompt_new_passphrase (self);

        return;
    }

    g_warning ("The history is not encrypted: there is no passphrase to change");
#else
    (void) settings;
#endif

    g_task_return_boolean (task, TRUE);
}

/**
 * g_paste_storage_rekey_finish:
 * @result: the #GAsyncResult handed to the callback
 * @error: return location for a #GError, or %NULL
 *
 * Collect the outcome of g_paste_storage_rekey_async().
 *
 * Unlike the other two concerns this one can fail on its own account: a re-key
 * that could not rewrite the histories on disk reports %G_PASTE_ERROR, as does
 * handing in the result of another operation, and histories that could not
 * even be listed report the listing's own %G_IO_ERROR. A failing #GPastePrompt
 * implementation reports in whichever domain it uses (%G_PASTE_ERROR,
 * %G_IO_ERROR, %G_DBUS_ERROR, ...).
 *
 * Returns: %TRUE unless the histories could not be re-encrypted, or the prompt
 *          implementation failed outright
 */
G_PASTE_VISIBLE gboolean
g_paste_storage_rekey_finish (GAsyncResult *result,
                              GError      **error)
{
    return storage_concern_finish (result, g_paste_storage_rekey_async, error);
}

/* What a check of the store found, carried from one step to the next: the
 * steps that read or rewrite histories run on a worker thread, and the ones
 * asking for a passphrase back on the main one, each starting once the one
 * before it is done with this. */
typedef struct
{
    GPastePrompt     *prompt;
    GPasteSettings   *settings;
    GTask            *task;
    GPasteStorage     storage_kind;

    /* The passphrase the history in use takes, %NULL unless the store is
     * encrypted and unlocked; the one last typed for @refuting; and the
     * histories that one is wanted for, which this one does not open. */
    GPastePassphrase *passphrase;
    GPastePassphrase *other;
    GPtrArray        *refuting;
    gboolean          other_opened;

    GStrvBuilder     *report;
    gboolean          healthy;
} DoctorData;

typedef struct
{
    GStrv    report;
    gboolean healthy;
} DoctorOutcome;

static void
doctor_outcome_free (gpointer data)
{
    DoctorOutcome *outcome = data;

    g_strfreev (outcome->report);
    g_free (outcome);
}

G_DEFINE_AUTOPTR_CLEANUP_FUNC (DoctorOutcome, doctor_outcome_free)

/* As migration_finish(): the one way out. A prompt that failed is what ends the
 * check with @error; everything else it found is in the report. */
static void
doctor_finish (DoctorData *self,
               GError     *error) /* (transfer full) (nullable) */
{
    g_autoptr (GTask) task = self->task;
    g_autoptr (GStrvBuilder) report = self->report;
    gboolean healthy = self->healthy;

#ifdef G_PASTE_ENABLE_ENCRYPTION
    g_paste_passphrase_free (self->passphrase);
    g_paste_passphrase_free (self->other);
#endif
    g_clear_pointer (&self->refuting, g_ptr_array_unref);
    g_object_unref (self->settings);
    g_object_unref (self->prompt);
    g_free (self);

    if (error)
    {
        g_task_return_error (task, error);
        return;
    }

    DoctorOutcome *outcome = g_new0 (DoctorOutcome, 1);

    outcome->report = g_strv_builder_end (report);
    outcome->healthy = healthy;

    g_task_return_pointer (task, outcome, doctor_outcome_free);
}

/* One line of the report. @fixed says what the line tells is done with --
 * repaired, or in order -- rather than something still wrong, which is what
 * makes the store unhealthy. */
G_GNUC_PRINTF (3, 4)
static void
doctor_note (DoctorData  *self,
             gboolean     fixed,
             const gchar *format,
             ...)
{
    va_list args;

    va_start (args, format);

    g_autofree gchar *line = g_strdup_vprintf (format, args);

    va_end (args);
    /* The report goes out as UTF-8 strings, over D-Bus or into GJS, and the
     * names it carries are files', which need not be UTF-8. Nor need they be
     * one line, anybody able to write into the history folder naming a file
     * there: a line break in one would add lines of its choosing to a report
     * of one finding per line, so every control character is shown as
     * U+FFFD. */
    g_autofree gchar *valid = g_utf8_make_valid (line, -1);
    GString *shown = g_string_new (NULL);

    for (const gchar *c = valid; *c; c = g_utf8_next_char (c))
    {
        gunichar u = g_utf8_get_char (c);

        if (g_unichar_iscntrl (u))
            g_string_append (shown, "\xef\xbf\xbd");
        else
            g_string_append_unichar (shown, u);
    }
    g_strv_builder_take (self->report, g_string_free_and_steal (shown));

    if (!fixed)
        self->healthy = FALSE;
}

/* Restrict the directory @fd stands for, @path, and every directory under it,
 * to its owner, and say what in there belongs to somebody else. Only
 * directories have their mode changed: what is in them can be reached through
 * them alone, and the backends write their files through the umask, so
 * restricting those would only be undone by the next write and reported again
 * by the next check. A symbolic link in there is not followed, what it points
 * at not being GPaste's: each entry is looked at, changed and walked through a
 * descriptor opened relative to its parent's, never by its name again, so one
 * swapped for a link once looked at is refused rather than followed. */
static void
doctor_restrict_at (DoctorData  *self,
                    gint         fd,
                    const gchar *path)
{
    /* The report travels as UTF-8, which a file name need not be. */
    g_autofree gchar *shown = g_filename_display_name (path);
    struct stat st;

    if (fstat (fd, &st) < 0)
    {
        gint saved_errno = errno;

        doctor_note (self, FALSE, _("Could not inspect %s: %s"), shown, g_strerror (saved_errno));
        return;
    }

    if (st.st_uid != getuid ())
        doctor_note (self, FALSE, _("%s belongs to another user"), shown);

    if (st.st_mode & 077)
    {
        if (fchmod (fd, 0700) < 0)
        {
            gint saved_errno = errno;

            doctor_note (self, FALSE, _("Could not restrict %s to its owner: %s"), shown, g_strerror (saved_errno));
        }
        else
            doctor_note (self, TRUE, _("Restricted %s to its owner"), shown);
    }

    /* Its own descriptor, which closedir () closes. */
    gint listed = dup (fd);
    DIR *dir = (listed < 0) ? NULL : fdopendir (listed);

    if (!dir)
    {
        gint saved_errno = errno;

        if (listed >= 0)
            close (listed);
        doctor_note (self, FALSE, _("Could not inspect %s: %s"), shown, g_strerror (saved_errno));
        return;
    }

    /* A listing cut short fails there, rather than end quietly and have what
     * follows go unchecked; no suite makes a read fail part way. */
    for (;;)
    {
        errno = 0;

        struct dirent *entry = readdir (dir);

        if (!entry)
        {
            gint saved_errno = errno;

            if (saved_errno)
                doctor_note (self, FALSE, _("Could not inspect %s: %s"), shown, g_strerror (saved_errno));
            break;
        }
        if (g_paste_str_equal (entry->d_name, ".") || g_paste_str_equal (entry->d_name, ".."))
            continue;

        g_autofree gchar *child = g_build_filename (path, entry->d_name, NULL);
        g_autofree gchar *child_shown = g_filename_display_name (child);
        struct stat child_st;

        if (fstatat (fd, entry->d_name, &child_st, AT_SYMLINK_NOFOLLOW) < 0)
        {
            gint saved_errno = errno;

            if (saved_errno != ENOENT)
                doctor_note (self, FALSE, _("Could not inspect %s: %s"), child_shown, g_strerror (saved_errno));
            continue;
        }

        if (!S_ISDIR (child_st.st_mode))
        {
            if (child_st.st_uid != getuid ())
                doctor_note (self, FALSE, _("%s belongs to another user"), child_shown);
            continue;
        }

        gint child_fd = openat (fd, entry->d_name, O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);

        if (child_fd < 0)
        {
            gint saved_errno = errno;

            if (saved_errno != ENOENT)
                doctor_note (self, FALSE, _("Could not inspect %s: %s"), child_shown, g_strerror (saved_errno));
            continue;
        }

        doctor_restrict_at (self, child_fd, child);
        close (child_fd);
    }

    closedir (dir);
}

/* The history folder, @path: GPaste's however it is reached, a link to it --
 * the folder moved to another disk -- included, and walked from there by
 * doctor_restrict_at (). */
static void
doctor_restrict (DoctorData  *self,
                 const gchar *path)
{
    gint fd = g_open (path, O_RDONLY | O_DIRECTORY | O_CLOEXEC, 0);

    if (fd < 0)
    {
        gint saved_errno = errno;
        g_autofree gchar *shown = g_filename_display_name (path);

        if (saved_errno != ENOENT)
            doctor_note (self, FALSE, _("Could not inspect %s: %s"), shown, g_strerror (saved_errno));
        return;
    }

    doctor_restrict_at (self, fd, path);
    close (fd);
}

/* Runs on a worker thread: reading a history of an encrypted flavour derives an
 * Argon2id key, as in import_work_run (). Every history is read, the ones the
 * passphrase in use does not open set aside for the passphrase they take. */
static void
doctor_inspect_run (GTask        *task,
                    gpointer      source      G_GNUC_UNUSED,
                    gpointer      task_data,
                    GCancellable *cancellable G_GNUC_UNUSED)
{
    DoctorData *self = task_data;
    g_autofree gchar *history_dir = g_paste_util_get_history_dir_path ();

    doctor_restrict (self, history_dir);

    if (self->storage_kind == G_PASTE_STORAGE_NOOP)
    {
        g_task_return_boolean (task, TRUE);
        return;
    }

    if (!g_paste_storage_is_supported (self->storage_kind))
    {
        doctor_note (self, FALSE, _("This build of GPaste cannot open the storage backend the history is in"));
        g_task_return_boolean (task, TRUE);
        return;
    }

    gboolean encrypted = g_paste_storage_is_encrypted (self->storage_kind);

    /* Locked, and left so: what it holds cannot be read, which the report
     * already says. */
    if (encrypted && !self->passphrase)
    {
        g_task_return_boolean (task, TRUE);
        return;
    }

#ifdef G_PASTE_ENABLE_ENCRYPTION
    const gchar *passphrase = g_paste_passphrase_peek (self->passphrase);
#else
    const gchar *passphrase = NULL;
#endif
    g_autoptr (GPasteStorageBackend) backend = g_paste_storage_backend_new_with_passphrase (self->storage_kind,
                                                                                            self->settings,
                                                                                            passphrase);
    g_autoptr (GError) error = NULL;

    /* Every item a history stores, past max-history-size and whatever
     * images-support says, as an import reads them: damage in what a load
     * leaves unread is damage all the same (/storage/doctor/reads-whole). */
    g_paste_storage_backend_read_whole (backend);

    g_auto (GStrv) names = g_paste_storage_backend_list_histories (backend, &error);

    if (!names)
    {
        doctor_note (self, FALSE, _("Could not list the histories: %s"), error->message);
        g_task_return_boolean (task, TRUE);
        return;
    }

    for (GStrv name = names; *name; ++name)
    {
#ifdef G_PASTE_ENABLE_ENCRYPTION
        /* Asked before the read, though a history the passphrase opens then
         * has its key derived twice, where rekey_histories () reads first: a
         * read of one on another passphrase warns it could not be decrypted,
         * and a store left on two passphrases is what this check is there to
         * find, not something gone wrong under it. doctor_rekey_run () asks
         * first for the same reason. */
        if (encrypted && g_paste_storage_backend_refutes_passphrase (backend, *name))
        {
            g_ptr_array_add (self->refuting, g_strdup (*name));
            continue;
        }
#endif

        g_autolist (GPasteItem) items = NULL;
        gsize size = 0;

        if (!g_paste_storage_backend_read_history (backend, *name, NULL /* cancellable */, &items, &size))
            doctor_note (self, FALSE, _("The history “%s” could not be read"), *name);
    }

    g_task_return_boolean (task, TRUE);
}

#ifdef G_PASTE_ENABLE_ENCRYPTION
static void doctor_ask (DoctorData  *self,
                        const gchar *error_message);
#endif

static void
on_doctor_inspected (GObject      *source G_GNUC_UNUSED,
                     GAsyncResult *result G_GNUC_UNUSED,
                     gpointer      user_data)
{
    DoctorData *self = user_data;

#ifdef G_PASTE_ENABLE_ENCRYPTION
    if (self->refuting->len)
    {
        doctor_ask (self, NULL);
        return;
    }
#endif

    doctor_finish (self, NULL);
}

static void
doctor_inspect (DoctorData *self)
{
    /* The data borrowed rather than owned: @self is done with by
     * doctor_finish (), which a later step runs. */
    g_paste_storage_run_worker (doctor_inspect, self, NULL, doctor_inspect_run, on_doctor_inspected, self);
}

#ifdef G_PASTE_ENABLE_ENCRYPTION
/* Runs on a worker thread, re-keying as rekey_work_run () does: each history
 * @self->other opens is encrypted with the passphrase in use, the others kept
 * for the next one the user types. */
static void
doctor_rekey_run (GTask        *task,
                  gpointer      source      G_GNUC_UNUSED,
                  gpointer      task_data,
                  GCancellable *cancellable G_GNUC_UNUSED)
{
    DoctorData *self = task_data;
    const gchar *other = g_paste_passphrase_peek (self->other);
    const gchar *passphrase = g_paste_passphrase_peek (self->passphrase);
    g_autoptr (GPasteStorageBackend) backend = g_paste_storage_backend_new_with_passphrase (self->storage_kind,
                                                                                            self->settings,
                                                                                            other);
    g_autoptr (GPtrArray) refuting = g_steal_pointer (&self->refuting);

    self->refuting = g_ptr_array_new_with_free_func (g_free);
    self->other_opened = FALSE;

    for (guint i = 0; i < refuting->len; ++i)
    {
        const gchar *name = g_ptr_array_index (refuting, i);
        gboolean split = FALSE;

        if (g_paste_storage_backend_refutes_passphrase (backend, name))
        {
            g_ptr_array_add (self->refuting, g_strdup (name));
            continue;
        }

        self->other_opened = TRUE;

        if (rekey_history (self->storage_kind, self->settings, name, other, passphrase, &split))
            doctor_note (self, TRUE, _("Encrypted the history “%s” with the passphrase in use"), name);
        else if (split)
            doctor_note (self, FALSE, _("The history “%s” is left partly on each passphrase"), name);
        else
            doctor_note (self, FALSE, _("Could not encrypt the history “%s” with the passphrase in use"), name);
    }

    g_task_return_boolean (task, TRUE);
}

static void
on_doctor_rekeyed (GObject      *source G_GNUC_UNUSED,
                   GAsyncResult *result G_GNUC_UNUSED,
                   gpointer      user_data)
{
    DoctorData *self = user_data;

    if (!self->refuting->len)
    {
        doctor_finish (self, NULL);
        return;
    }

    /* Some were opened: the rest are on yet another passphrase, asked for
     * afresh. None were: the one typed was wrong. */
    doctor_ask (self, (self->other_opened) ? NULL : g_paste_prompt_text (G_PASTE_PROMPT_TEXT_OTHER_PASSPHRASE_WRONG));
}

static void
on_doctor_other_passphrase (GObject      *source,
                            GAsyncResult *result,
                            gpointer      user_data)
{
    DoctorData *self = user_data;
    g_autoptr (GError) prompt_error = NULL;
    GPastePassphrase *other = g_paste_prompt_passphrase_finish (G_PASTE_PROMPT (source), result, NULL, &prompt_error);

    /* As in the migration: a prompt that failed cannot be asked again. */
    if (prompt_error)
    {
        doctor_finish (self, g_steal_pointer (&prompt_error));
        return;
    }

    if (!other)
    {
        for (guint i = 0; i < self->refuting->len; ++i)
        {
            doctor_note (self, FALSE, _("The history “%s” is still encrypted with another passphrase"),
                         (const gchar *) g_ptr_array_index (self->refuting, i));
        }

        doctor_finish (self, NULL);
        return;
    }

    g_paste_passphrase_free (self->other);
    self->other = other;

    g_paste_storage_run_worker (doctor_rekey_run, self, NULL, doctor_rekey_run, on_doctor_rekeyed, self);
}

/* Ask for the passphrase the histories in @self->refuting take, naming them:
 * one passphrase may open several, or only some. */
static void
doctor_ask (DoctorData  *self,
            const gchar *error_message)
{
    g_autoptr (GStrvBuilder) names = g_strv_builder_new ();

    for (guint i = 0; i < self->refuting->len; ++i)
        g_strv_builder_add (names, g_ptr_array_index (self->refuting, i));

    g_auto (GStrv) listed = g_strv_builder_end (names);
    g_autofree gchar *joined = g_strjoinv (", ", listed);
    g_autofree gchar *description = g_strdup_printf (g_paste_prompt_text (G_PASTE_PROMPT_TEXT_OTHER_PASSPHRASE_DESCRIPTION),
                                                     joined);

    g_paste_prompt_other_passphrase_async (self->prompt, description, error_message, on_doctor_other_passphrase, self);
}

static void
on_doctor_unlocked (gboolean unlocked,
                    GError  *error,
                    gpointer user_data)
{
    DoctorData *self = user_data;

    if (error)
    {
        doctor_finish (self, g_error_copy (error));
        return;
    }

    if (unlocked)
        self->passphrase = g_paste_passphrase_new (g_paste_storage_backend_get_passphrase ());
    else
        doctor_note (self, FALSE, _("The history is locked, so what it holds was not checked"));

    doctor_inspect (self);
}
#endif

/**
 * g_paste_storage_doctor_async:
 * @prompt: the #GPastePrompt to ask through
 * @settings: a #GPasteSettings instance
 * @callback: (scope async): called once the store was checked
 * @user_data: data passed to @callback
 *
 * Check the store and put right what can be: restrict the history folder and
 * every folder in it to their owner, read every history, and encrypt the ones
 * left under another passphrase -- what a change of passphrase that could not
 * be undone leaves -- with the one the history in use takes, asking for theirs.
 *
 * Unlocks the history first when it is encrypted and locked (from the keyring,
 * or a prompt). The passphrase asked for other histories is never remembered.
 */
G_PASTE_VISIBLE void
g_paste_storage_doctor_async (GPastePrompt       *prompt,
                              GPasteSettings     *settings,
                              GAsyncReadyCallback callback,
                              gpointer            user_data)
{
    g_return_if_fail (G_PASTE_IS_PROMPT (prompt));
    g_return_if_fail (G_PASTE_IS_SETTINGS (settings));

    DoctorData *self = g_new0 (DoctorData, 1);

    self->prompt = g_object_ref (prompt);
    self->settings = g_object_ref (settings);
    self->task = g_task_new (prompt, NULL /* cancellable */, callback, user_data);
    self->storage_kind = g_paste_settings_get_storage_backend (settings);
    self->refuting = g_ptr_array_new_with_free_func (g_free);
    self->report = g_strv_builder_new ();
    self->healthy = TRUE;

    g_task_set_source_tag (self->task, g_paste_storage_doctor_async);

#ifdef G_PASTE_ENABLE_ENCRYPTION
    /* As every start does (g_paste_storage_decryption_needed ()): a change of
     * passphrase left unfinished -- the split a failed one sends the user here
     * for -- is put back or done with before anything is read or unlocked, or
     * its history would be reported as one that cannot be read. */
    g_paste_file_backend_settle_rekeys ();

    if (g_paste_storage_is_encrypted (self->storage_kind) && g_paste_storage_is_supported (self->storage_kind))
    {
        const gchar *known = known_passphrase_for (self->storage_kind, settings);

        if (!known)
        {
            unlock_prompt (prompt, settings, self->storage_kind, on_doctor_unlocked, self);
            return;
        }

        self->passphrase = g_paste_passphrase_new (known);
    }
#endif

    doctor_inspect (self);
}

/**
 * g_paste_storage_doctor_finish:
 * @result: the #GAsyncResult handed to the callback
 * @report: (out) (optional) (transfer full) (array zero-terminated=1): what the
 *          check found and did, one line each, in the user's words
 * @healthy: (out) (optional): whether nothing is left wrong
 * @error: return location for a #GError, or %NULL
 *
 * Collect the outcome of g_paste_storage_doctor_async().
 *
 * What the check finds wrong is not an error but a line of @report, @healthy
 * saying whether any is left. As for g_paste_storage_migration_finish(), the
 * failure is the #GPastePrompt implementation's, in whichever domain it
 * reports (%G_PASTE_ERROR, %G_IO_ERROR, %G_DBUS_ERROR, ...), and handing in the
 * result of another operation is %G_PASTE_ERROR.
 *
 * Returns: %TRUE unless the prompt implementation failed outright
 */
G_PASTE_VISIBLE gboolean
g_paste_storage_doctor_finish (GAsyncResult *result,
                               GStrv        *report,
                               gboolean     *healthy,
                               GError      **error)
{
    if (report)
        *report = NULL;
    if (healthy)
        *healthy = FALSE;

    if (!G_IS_TASK (result) || g_task_get_source_tag (G_TASK (result)) != g_paste_storage_doctor_async)
    {
        g_set_error_literal (error, G_PASTE_ERROR, G_PASTE_ERROR_INVALID_ARGUMENT,
                             "This is not the result of the storage concern being finished");

        return FALSE;
    }

    g_autoptr (DoctorOutcome) outcome = g_task_propagate_pointer (G_TASK (result), error);

    if (!outcome)
        return FALSE;

    if (report)
        *report = g_steal_pointer (&outcome->report);
    if (healthy)
        *healthy = outcome->healthy;

    return TRUE;
}
