// SPDX-FileCopyrightText: 2010-2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com>
// SPDX-License-Identifier: BSD-2-Clause

#pragma once

#include <gpaste-3/gpaste-macros.h>
#include <gpaste-3/gpaste-storage.h>
#include <gpaste-3/gpaste-util.h>

#include <gio/gio.h>

G_BEGIN_DECLS

/* The half of the utility helpers only the daemon library has ever used: where
 * a history lives on disk, and the XML escaping the file backend writes it
 * with. They sit here rather than in libgpaste's gpaste-util.h because nothing
 * outside this library -- not the UI, not the command line, not the extension
 * -- calls them, and this header is not installed, so they stay off the
 * introspection data. */

gchar *g_paste_util_replace (const gchar *text,
                             const gchar *pattern,
                             const gchar *substitution);

gchar *g_paste_util_xml_decode (const gchar *text);
gchar *g_paste_util_xml_encode (const gchar *text);

/* Every path built from a history name goes through the two builders below,
 * which refuse one g_paste_util_history_name_is_valid () (gpaste-util.h)
 * rejects; the bus checks it itself, so a caller gets an error rather than a
 * critical. */
gchar *g_paste_util_get_history_dir_path  (void);
GFile *g_paste_util_get_history_dir       (void);
gchar *g_paste_util_get_history_file_path (const gchar *name,
                                           const gchar *extension);
GFile *g_paste_util_get_history_file      (const gchar *name,
                                           const gchar *extension);

/* Whether the @storage flavour stores a history of @name: what is on disk under
 * that flavour's extension, whether or not this build can open it. The second
 * asks it of every flavour that stores anything. */
gboolean g_paste_util_history_is_stored          (const gchar  *name,
                                                  GPasteStorage storage);
gboolean g_paste_util_history_is_stored_anywhere (const gchar  *name);

gboolean g_paste_util_ensure_history_dir_exists (void);

/* The history @name stands for: itself, or G_PASTE_DEFAULT_HISTORY in place of
 * a name no history can have -- which, for the configured name, is the one a
 * daemon loads, so a storage check looks at the history that daemon would. */
const gchar *g_paste_util_resolve_history_name (const gchar *name);

/* Wiping what was decrypted. A read hands back the very thing the passphrase was
 * protecting, and releasing it with g_free() leaves it in the heap for whatever
 * allocates that block next -- and in any core dump taken meanwhile.
 *
 * They live here rather than beside the converter because the read paths holding
 * a cleartext buffer are compiled whether or not this build has encryption; in a
 * build without, nothing was ever encrypted and freeing is all there is to do.
 *
 * #GPasteCleartext is a NUL-terminated one, so a scope with several ways out can
 * declare it g_autoptr and not have to remember. Anything else -- an image's
 * bytes, a whole history document -- carries its length and wipes with
 * g_paste_util_wipe(). */
typedef gchar GPasteCleartext;

void g_paste_util_wipe           (gpointer         data,
                                  gsize            length);
void g_paste_util_free_cleartext (GPasteCleartext *cleartext);

#ifdef G_PASTE_ENABLE_ENCRYPTION
/* Release a block gcr_secure_memory_alloc() handed out, wiping its @size bytes
 * first: once the locked pool cannot grow, gcr hands out ordinary memory, and
 * frees that as it is. Every key and buffer a passphrase protects goes back
 * through here. */
void g_paste_util_secure_free (gpointer data,
                               gsize    size);
#endif

G_DEFINE_AUTOPTR_CLEANUP_FUNC (GPasteCleartext, g_paste_util_free_cleartext)

/* Every directory listing in this library goes through here. Whether a directory
 * that is not there counts as a failure, and whether an enumeration that stopped
 * half way does, are decided once here rather than at each of the four places
 * that enumerate one -- and getting the second one wrong is how a migration
 * imports half a history and its cleanup deletes the rest. */
GStrv g_paste_util_list_directory (GFile        *dir,
                                   const gchar  *attribute,
                                   GError      **error);

G_END_DECLS
