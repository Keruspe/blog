// SPDX-FileCopyrightText: 2010-2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com>
// SPDX-License-Identifier: BSD-2-Clause

#pragma once

#include <gpaste-3/gpaste-settings.h>

#include <gpaste-daemon/gpaste-password-item.h>

G_BEGIN_DECLS

#define G_PASTE_TYPE_HISTORY (g_paste_history_get_type ())

G_PASTE_FINAL_TYPE (History, history, HISTORY, GObject)

void                g_paste_history_add             (GPasteHistory *self,
                                                     GPasteItem    *item);
void                g_paste_history_remove          (GPasteHistory *self,
                                                     guint64        index);
gboolean            g_paste_history_remove_by_uuid  (GPasteHistory *self,
                                                     const gchar   *uuid);
GPasteItem         *g_paste_history_get             (GPasteHistory *self,
                                                     guint64        index);
GPasteItem         *g_paste_history_get_by_uuid     (GPasteHistory *self,
                                                     const gchar   *uuid);
GPasteItem         *g_paste_history_dup             (GPasteHistory *self,
                                                     guint64        index);
gboolean            g_paste_history_select          (GPasteHistory *self,
                                                     const gchar   *uuid);
gchar              *g_paste_history_replace         (GPasteHistory *self,
                                                     const gchar   *uuid,
                                                     const gchar   *contents);
gboolean            g_paste_history_strip_rich_text (GPasteHistory *self,
                                                     const gchar   *uuid,
                                                     gboolean      *found);
gboolean            g_paste_history_set_favourite   (GPasteHistory *self,
                                                     const gchar   *uuid,
                                                     gboolean       favourite);
gchar              *g_paste_history_make_password   (GPasteHistory *self,
                                                     const gchar   *uuid,
                                                     const gchar   *name,
                                                     guint          timeout);
GPastePasswordItem *g_paste_history_get_password    (GPasteHistory *self,
                                                     const gchar   *name);
gboolean            g_paste_history_delete_password (GPasteHistory *self,
                                                     const gchar   *name);
gboolean     g_paste_history_empty       (GPasteHistory *self,
                                          GError       **error);
void         g_paste_history_flush       (GPasteHistory *self);
void         g_paste_history_resume      (GPasteHistory *self);
gboolean     g_paste_history_sync        (GPasteHistory *self,
                                          const gchar   *name,
                                          GError       **error);
void         g_paste_history_reload_backend (GPasteHistory *self);
void     g_paste_history_copy_async (GPasteHistory      *self,
                                     const gchar        *name,
                                     const gchar        *target,
                                     GAsyncReadyCallback callback,
                                     gpointer            user_data);
gboolean g_paste_history_copy_finish (GPasteHistory      *self,
                                      GAsyncResult       *result,
                                      GError            **error);
void     g_paste_history_empty_other_async  (GPasteHistory      *self,
                                             const gchar        *name,
                                             GAsyncReadyCallback callback,
                                             gpointer            user_data);
gboolean g_paste_history_empty_other_finish (GPasteHistory *self,
                                             GAsyncResult  *result,
                                             GError       **error);
gboolean g_paste_history_is_unreadable (GPasteHistory *self);
gboolean g_paste_history_is_loading    (GPasteHistory *self);
void     g_paste_history_load_async (GPasteHistory *self,
                                     const gchar   *name);
gboolean g_paste_history_switch     (GPasteHistory *self,
                                     const gchar   *name);
gboolean g_paste_history_delete     (GPasteHistory *self,
                                     const gchar   *name,
                                     GError       **error);
const GPtrArray *g_paste_history_get_history (GPasteHistory *self);
guint64      g_paste_history_get_length  (GPasteHistory *self);
const gchar *g_paste_history_get_current (GPasteHistory *self);

/* The longest query a search takes, in bytes: room for whatever a user types,
 * escaped by a front end (a character becoming at most two). It bounds the
 * pattern, not what matching it costs: one no front end escaped, with nested
 * quantifiers, can run every item into PCRE2's match limit, tens of
 * milliseconds apiece. */
#define G_PASTE_HISTORY_MAX_SEARCH_LENGTH 4096

GStrv g_paste_history_search (GPasteHistory *self,
                              const gchar   *pattern);

GPasteHistory *g_paste_history_new (GPasteSettings *settings);

GStrv    g_paste_history_list     (GPasteHistory *self,
                                   GError       **error);
guint64  g_paste_history_get_size (GPasteHistory *self,
                                   const gchar   *name);

G_END_DECLS
