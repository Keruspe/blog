// SPDX-FileCopyrightText: 2010-2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com>
// SPDX-License-Identifier: BSD-2-Clause

#include "gpaste-clipboard-gdk.h"
#include "gpaste-clipboard-x11-hints.h"
#include "gpaste-text-content-provider.h"

#include <gpaste-gtk4/gpaste-gtk-util.h>

#include <gpaste-daemon/gpaste-clipboard-content.h>
#include <gpaste-daemon/gpaste-clipboard-provider-private.h>
#include <gpaste-daemon/gpaste-color-item.h>
#include <gpaste-daemon/gpaste-image-item.h>
#include <gpaste-daemon/gpaste-password-item.h>
#include <gpaste-daemon/gpaste-sensitive-mime.h>
#include <gpaste-daemon/gpaste-special-mime.h>
#include <gpaste-daemon/gpaste-text-item.h>
#include <gpaste-daemon/gpaste-uris-item.h>

enum
{
    C_CHANGED,

    C_LAST_SIGNAL
};

typedef struct _GPasteClipboardGdkFormatsWait GPasteClipboardGdkFormatsWait;

struct _GPasteClipboardGdk
{
    GObject parent_instance;

    GdkClipboard                  *real;
    gboolean                       is_clipboard;
    GPasteSettings                *settings;

    GPasteClipboardContent         content;

    /* The update in flight on this selection, cleared when it concludes: see
     * @slot on #GPasteClipboardUpdate. */
    GPasteClipboardUpdate         *update;
    /* A new owner's TARGETS reply still pending: see update (). */
    GPasteClipboardGdkFormatsWait *formats_wait;
    /* Set for as long as on_real_changed () is emitting ::changed, so that a
     * formats wait knows whether a change is what asked for it: see
     * @after_change on #GPasteClipboardGdkFormatsWait. */
    gboolean                       emitting_change;
    /* A wait a change asked for concluded with the selection still owned, so the
     * copy that change announced was never read: its targets, whenever they come,
     * are that copy and not the answer to some later read. See
     * on_real_changed (). */
    gboolean                       copy_owed;
    /* The mirror of @copy_owed: a wait no change asked for -- the manager's
     * bootstrap read, or one asked to identify the selection -- concluded with
     * the selection still owned, so what that owner carries was never identified.
     * Its targets, whenever they come, answer that question and are no copy. See
     * on_real_changed (). */
    gboolean                       identify_owed;

    /* Reads the hints GDK cannot: see gpaste-clipboard-x11-hints.c. */
    GPasteClipboardX11Hints       *hints;

    gulong                         c_signals[C_LAST_SIGNAL];
};

static void g_paste_clipboard_gdk_provider_iface_init (GPasteClipboardProviderInterface *iface);

G_PASTE_DEFINE_TYPE_WITH_INTERFACE (ClipboardGdk, clipboard_gdk, G_TYPE_OBJECT,
                                    G_PASTE_TYPE_CLIPBOARD_PROVIDER, g_paste_clipboard_gdk_provider_iface_init)

/* @text is (transfer full) and nullable: a selection's text can be megabytes,
 * and the read already allocated it, so it is handed over rather than copied. */
typedef void (*GPasteClipboardGdkTextCallback)    (GPasteClipboardGdk *self,
                                                   gchar              *text,
                                                   gpointer            user_data);

typedef void (*GPasteClipboardGdkTextureCallback) (GPasteClipboardGdk *self,
                                                   GdkTexture         *texture,
                                                   gpointer            user_data);

/* How long a selection whose formats came back empty is given to say what it
 * carries, in milliseconds.
 *
 * Deliberately not G_PASTE_CLIPBOARD_READ_TIMEOUT: that one is the rope a stuck
 * *transfer* is given, where this bounds the silence between one owner letting
 * go of a selection and the next one publishing its targets -- a round trip GDK
 * makes on its own, and one that is over in milliseconds. It bounds that
 * announcement alone and is never re-armed: the transfer that follows is the
 * read guard's business, so a large image or a long file list may take many
 * times this without any of it firing. Short on purpose: the wait counts as
 * is_reading (), which holds synchronization, password expiry and the Reexecute
 * waiting on it, so a selection nobody owns must not park any of them for as
 * long as a transfer may take.
 *
 * This is the length for a selection whose owner may yet publish. One the server
 * has already announced a release of waits %G_PASTE_CLIPBOARD_GDK_RELEASE_GRACE
 * instead, having nothing left to find out.
 *
 * A daemon standing down inside that window leaves the wait unanswered, and the
 * record its selection holds is then not acted on -- the same shape a content
 * read has, and the same answer: the caller awaits
 * g_paste_clipboards_manager_expire_password_async () rather than this deadline
 * being tightened. Nothing is left behind by it either way. Empty formats are
 * another client's doing -- a selection this daemon owns offers what it
 * published -- so the copy a wait is pending over is one somebody else has
 * already taken away or is in the middle of replacing, and what would outlive
 * the daemon there is that owner's content and not ours. */
#define G_PASTE_CLIPBOARD_GDK_FORMATS_TIMEOUT 5000

/* How long that same wait is when X already says nobody owns the selection, in
 * milliseconds.
 *
 * The deadline above exists to find out which of a release and a slow owner a
 * set of empty formats is, and that question has an answer the moment they
 * arrive: the server knows who owns the selection, and is asked
 * (g_paste_clipboard_x11_hints_get_owner ()). The full deadline would hold an
 * answer already in hand for five seconds, and with it synchronization,
 * password expiry and the Reexecute waiting on them -- five seconds of a
 * selection pasting nothing, the head being what goes back on it.
 *
 * Asked of the server and not of the last ownership notification, although that
 * notification carries the same thing and costs nothing: GDK connects its own
 * GdkDisplay::xevent handler when it creates its clipboards, which is before
 * this daemon has one to connect, and that handler claims empty formats from
 * inside itself -- so by the time the change reaches here, our handler has not
 * seen the notification for the very change that brought it. What it holds is
 * the *previous* one, which on the release this grace is written for still names
 * the application that has just closed. A round trip per owner change is what
 * that costs, and it is the one question whose answer cannot be one event stale.
 *
 * A grace and not zero, because no owner is an instant and not a state: a copy
 * in progress passes through it between one client letting go and the next
 * claiming, and the head going back there competes with the owner about to
 * arrive. Long enough for that claim to have been made, short enough that
 * closing the application you copied from puts the copy back within a blink.
 *
 * Nothing else about the wait differs. It ends in the same question asked of the
 * same server, so a claim that landed inside the grace is an owner like any
 * other and is held as one. */
#define G_PASTE_CLIPBOARD_GDK_RELEASE_GRACE 300

/* An unresolved owner owes notify () an answer even if TARGETS never arrives.
 * No content is read here: only a callback and its deadline are needed.
 *
 * The provider is held weakly, dispose () being what supersedes the wait (see
 * AGENTS.md on what an object tracks so that its own dispose() can end it). */
struct _GPasteClipboardGdkFormatsWait
{
    GWeakRef                              self;
    /* Whether the update this wait answers for records its copy: see @record
     * on #GPasteClipboardUpdate. */
    gboolean                              record;
    GPasteClipboardProviderUpdateCallback callback;
    gpointer                              user_data;
    guint                                 source_id;
    /* Whether the update this wait answers for was asked in response to a
     * ::changed this backend raised, rather than by the manager on its own --
     * its bootstrap read, or a re-read asked to identify a selection. Only the
     * former has a change of its own to follow: see on_real_changed (). */
    gboolean                              after_change;
};

/* The wait itself, and nothing it owes: its callback is its caller's to answer
 * or to hand on. */
static void
g_paste_clipboard_gdk_formats_wait_free (GPasteClipboardGdkFormatsWait *wait)
{
    g_weak_ref_clear (&wait->self);
    g_free (wait);
}

static void
g_paste_clipboard_gdk_formats_wait_answer (GPasteClipboardGdkFormatsWait *wait,
                                           gboolean                       superseded)
{
    g_autoptr (GPasteClipboardGdk) self = g_weak_ref_get (&wait->self);
    GPasteClipboardProviderUpdateCallback callback = wait->callback;
    gpointer user_data = wait->user_data;
    gboolean after_change = wait->after_change;

    g_paste_clipboard_gdk_formats_wait_free (wait);

    /* A provider gone by now was disposed, which superseded the wait: the
     * callback only releases its state then. */
    superseded |= !self;

    /* A whole wait with no TARGETS reply is a selection nobody owns -- a release,
     * which GTK announces with the same empty formats as a new owner -- or an
     * owner nothing can paste from either.
     * Neither holds what a record names, so the answer is a no, retiring it
     * rather than leaving it unconfirmed until the next copy
     * (/gdk/formats/deadline).
     *
     * And the cache is cleared, not ignored: the selection is then empty, which
     * is what has ensure_not_empty () put the history's head back on it. That
     * restoration is the whole of why closing the app you copied from does not
     * lose the copy -- what the mutter backend does on a release too -- so what
     * the wait buys is *delaying* it past the window where empty formats are a
     * new owner still publishing its targets, never dropping it (the same test).
     * An ignored cache here would leave the selection empty for the rest of the
     * session.
     *
     * The deadline alone does not say which of the two it is, which is why it is
     * not taken for a release on its own: an owner slow to serve TARGETS -- a
     * busy application, a forwarded display -- is still there, and restoring
     * the head over it replaces the copy the user has just made and retires the
     * record for a password still sitting there. X is asked who owns the
     * selection, the one thing that tells the two apart, and an owner that is
     * there answers nothing: the deadline is then this selection going
     * unidentified, which every reader of %G_PASTE_CLIPBOARD_SECRET_UNKNOWN
     * already knows how to hold (/gdk/formats/deadline-slow-owner). It is asked
     * here rather than when the formats came back empty, so the milliseconds a
     * local owner takes to publish its targets cost nothing.
     *
     * Only %G_PASTE_CLIPBOARD_X11_HINTS_OWNER_NONE is a release, never the
     * absence of an answer: a display that could not be asked is held like a slow
     * owner (/gdk/formats/deadline-unknown-owner). Releasing is the half that
     * overwrites a live copy, so it takes the server saying there is no owner --
     * which a display with no XFixes still says, the atoms the question needs
     * being interned ahead of the check that stops the rest of the workaround.
     *
     * Unidentified means the cache holds no value either, which is what
     * set_ignored () is for: the owner that has the selection is not the one this
     * cache was filled for, so a value kept here is one the provider reports for
     * content its selection has already replaced -- and every route asking what
     * this selection carries reads that cache. A standing password record would
     * be confirmed against the previous owner's text
     * (g_paste_clipboards_manager_confirm_password ()), which is the one answer
     * no reader of an unknown is meant to get. Ignored rather than cleared: the
     * selection has an owner, so it is not empty and the head must not go back on
     * it. */
    gboolean released = !superseded &&
                        g_paste_clipboard_x11_hints_get_owner (self->hints) == G_PASTE_CLIPBOARD_X11_HINTS_OWNER_NONE;

    if (released)
        g_paste_clipboard_content_clear (&self->content);
    /* A superseded wait says nothing about the selection, and the read that took
     * over answers for the cache. */
    else if (!superseded)
        g_paste_clipboard_content_set_ignored (&self->content);

    /* A slow owner is still owed its copy, or its identification, whichever the
     * wait was asked for: see @copy_owed and @identify_owed. */
    if (!released && !superseded)
    {
        if (after_change)
            self->copy_owed = TRUE;
        else
            self->identify_owed = TRUE;
    }

    if (callback)
        callback (G_PASTE_CLIPBOARD_PROVIDER (self), NULL, superseded, (released) ? G_PASTE_CLIPBOARD_SECRET_NO : G_PASTE_CLIPBOARD_SECRET_UNKNOWN, user_data);
}

static void
g_paste_clipboard_gdk_formats_wait_timed_out (gpointer user_data)
{
    GPasteClipboardGdkFormatsWait *wait = user_data;
    g_autoptr (GPasteClipboardGdk) self = g_weak_ref_get (&wait->self);

    if (self)
        self->formats_wait = NULL;
    g_paste_clipboard_gdk_formats_wait_answer (wait, FALSE);
}

static void
g_paste_clipboard_gdk_formats_wait_superseded (gpointer user_data)
{
    g_paste_clipboard_gdk_formats_wait_answer (user_data, TRUE);
}

/* As g_paste_clipboard_update_supersede () does for a read: no longer reading
 * from here on, but answered on the next main-loop turn, never under the
 * notify () or the publication that took over. Disposal preserves this ordering:
 * the callback can re-enter its manager, whose teardown may still be on the
 * stack. In a continuing process the idle delivers cleanup; process exit/exec
 * releases the address space. A caller needing completion before stopping its
 * loop must await expiry, as documented beside the formats timeout. */
static void
g_paste_clipboard_gdk_supersede_formats_wait (GPasteClipboardGdk *self)
{
    GPasteClipboardGdkFormatsWait *wait = g_steal_pointer (&self->formats_wait);

    if (!wait)
        return;

    g_source_remove (wait->source_id);
    wait->source_id = g_idle_add_once (g_paste_clipboard_gdk_formats_wait_superseded, wait);
    g_source_set_name_by_id (wait->source_id, "[GPaste] superseded clipboard formats wait");
}

static void
g_paste_clipboard_gdk_wait_for_formats (GPasteClipboardGdk                   *self,
                                        gboolean                              released,
                                        gboolean                              record,
                                        GPasteClipboardProviderUpdateCallback callback,
                                        gpointer                              user_data)
{
    GPasteClipboardGdkFormatsWait *wait = g_new (GPasteClipboardGdkFormatsWait, 1);
    guint timeout = (released) ? G_PASTE_CLIPBOARD_GDK_RELEASE_GRACE : G_PASTE_CLIPBOARD_GDK_FORMATS_TIMEOUT;

    g_weak_ref_init (&wait->self, self);
    wait->record = record;
    wait->callback = callback;
    wait->user_data = user_data;
    wait->after_change = self->emitting_change;
    wait->source_id = g_timeout_add_once (timeout, g_paste_clipboard_gdk_formats_wait_timed_out, wait);
    g_source_set_name_by_id (wait->source_id, "[GPaste] clipboard formats wait");
    self->formats_wait = wait;
}

/* Every write and every change makes both the read and the formats wait in
 * flight stale. */
static void
g_paste_clipboard_gdk_supersede (GPasteClipboardGdk *self)
{
    g_paste_clipboard_update_supersede (&self->update);
    g_paste_clipboard_gdk_supersede_formats_wait (self);
}

static gboolean
g_paste_clipboard_gdk_is_clipboard (GPasteClipboardGdk *self)
{
    return self->is_clipboard;
}

static gboolean
g_paste_clipboard_gdk_is_reading (GPasteClipboardGdk *self)
{
    return self->update || self->formats_wait;
}

static const gchar *
g_paste_clipboard_gdk_get_text (GPasteClipboardGdk *self)
{
    return g_paste_clipboard_content_get_text (&self->content);
}

static void
g_paste_clipboard_gdk_private_set_text (GPasteClipboardGdk *self,
                                        const gchar        *text)
{
    g_debug ("%s: set text", g_paste_clipboard_provider_target_name (self->is_clipboard));

    g_paste_clipboard_content_set_text (&self->content, text);
}

typedef struct
{
    GPasteClipboardGdk            *self; /* ref'd for the duration of the read */
    GPasteClipboardUpdate         *update; /* what the read counts into, and what says it still matters */
    GPasteClipboardGdkTextCallback callback;
} GPasteClipboardGdkTextCallbackData;

static void
g_paste_clipboard_gdk_on_text_ready (GObject      *source_object,
                                     GAsyncResult *res,
                                     gpointer      user_data)
{
    g_autofree GPasteClipboardGdkTextCallbackData *data = user_data;
    g_autoptr (GPasteClipboardGdk) self = data->self; /* ref taken in set_text */
    g_autoptr (GError) error = NULL;
    g_autofree gchar *text = gdk_clipboard_read_text_finish (GDK_CLIPBOARD (source_object), res, &error);

    /* Superseded and timed-out updates only count the reply out: see
     * g_paste_clipboard_update_is_expired (). */
    if (g_paste_clipboard_update_is_expired (data->update))
    {
        if (data->callback)
            data->callback (self, NULL, data->update);
        return;
    }

    if (!text)
    {
        if (error)
            g_debug ("Failed to read text from clipboard: %s", error->message);
        if (data->callback)
            data->callback (self, NULL, data->update);
        return;
    }

    if (data->callback)
        data->callback (self, g_steal_pointer (&text), data->update);
}

static void
g_paste_clipboard_gdk_set_text (GPasteClipboardGdk            *self,
                                GPasteClipboardUpdate         *update,
                                GPasteClipboardGdkTextCallback callback)
{
    GPasteClipboardGdkTextCallbackData *data = g_new (GPasteClipboardGdkTextCallbackData, 1);

    /* Hold a ref for the whole read, as the meta backend does. The update holds
     * the provider too, but only until it concludes, and a read can outlive
     * that: an owner that never answers keeps it pending in GDK, holding this
     * ref -- and the provider, which the daemon keeps for its whole life anyway
     * -- for as long. @update needs none: this read is counted into it and an
     * update is freed by the last read to report, so it outlives every one of
     * them by construction. */
    data->self = g_object_ref (self);
    data->update = update;
    data->callback = callback;

    gdk_clipboard_read_text_async (self->real,
                                   update->guard.cancellable,
                                   g_paste_clipboard_gdk_on_text_ready,
                                   data);
}

/* Publish @provider, the cache already saying what it carries. GDK refuses a
 * claim another client won meanwhile -- it asks the server who owns the
 * selection right after taking it -- and the selection then carries that
 * client's copy, not ours: neither the cache nor the answer may say otherwise.
 * That owner's change notification follows, and reading it is what fills the
 * cache again. */
static GPasteClipboardPublication
g_paste_clipboard_gdk_claim (GPasteClipboardGdk *self,
                             GdkContentProvider *provider)
{
    if (gdk_clipboard_set_content (self->real, provider))
        return G_PASTE_CLIPBOARD_PUBLICATION_PUBLISHED;

    g_debug ("%s: another client owns the selection", g_paste_clipboard_provider_target_name (self->is_clipboard));
    g_paste_clipboard_content_set_ignored (&self->content);

    return G_PASTE_CLIPBOARD_PUBLICATION_REFUSED;
}

static GPasteClipboardPublication
g_paste_clipboard_gdk_select_text (GPasteClipboardGdk *self,
                                   const gchar        *text)
{
    g_debug ("%s: select text", g_paste_clipboard_provider_target_name (self->is_clipboard));

    g_paste_clipboard_gdk_supersede (self);
    g_paste_clipboard_gdk_private_set_text (self, text);

    g_autoptr (GdkContentProvider) provider = g_paste_text_content_provider_new (text);

    return g_paste_clipboard_gdk_claim (self, provider);
}

static void
g_paste_clipboard_gdk_sync_ready (GObject      *source_object,
                                  GAsyncResult *res,
                                  gpointer      user_data)
{
    g_autoptr (GPasteClipboardSyncData) data = user_data; /* built in sync_text */
    g_autoptr (GError) error = NULL;
    g_autofree gchar *text = gdk_clipboard_read_text_finish (GDK_CLIPBOARD (source_object), res, &error);

    if (error)
        g_debug ("Failed to sync clipboard text: %s", error->message);
    else
        g_paste_clipboard_sync_data_deliver (data, text);
}

/* Whether the selection offers its text as a bare text/plain alone, which
 * g_paste_clipboard_gdk_on_bare_text_read () says how to read. */
static gboolean
g_paste_clipboard_gdk_offers_bare_text (GPasteClipboardGdk *self)
{
    GdkContentFormats *formats = gdk_clipboard_get_formats (self->real);

    return !gdk_content_formats_contain_mime_type (formats, "text/plain;charset=utf-8") &&
           gdk_content_formats_contain_mime_type (formats, "text/plain");
}

static void g_paste_clipboard_gdk_sync_bare_text (GPasteClipboardGdk      *self,
                                                  GPasteClipboardSyncData *data);

static void
g_paste_clipboard_gdk_sync_text (GPasteClipboardGdk         *self,
                                 GPasteClipboardGdk         *other,
                                 GPasteClipboardSyncCallback callback,
                                 gpointer                    user_data,
                                 GDestroyNotify              destroy)
{
    GPasteClipboardSyncData *data = g_paste_clipboard_sync_data_new (G_PASTE_CLIPBOARD_PROVIDER (other),
                                                                     callback, user_data, destroy);

    if (!data)
    {
        /* Nothing was built to hand what the caller gave us to, and nothing will
         * be published: releasing it is this call's to do. */
        if (destroy)
            destroy (user_data);

        return;
    }

    if (g_paste_clipboard_gdk_offers_bare_text (self))
        g_paste_clipboard_gdk_sync_bare_text (self, data);
    else
        gdk_clipboard_read_text_async (self->real, data->guard.cancellable, g_paste_clipboard_gdk_sync_ready, data);
}

static void
g_paste_clipboard_gdk_store_async_done (GObject      *source_object,
                                        GAsyncResult *res,
                                        gpointer      user_data G_GNUC_UNUSED)
{
    g_autoptr (GError) error = NULL;

    if (!gdk_clipboard_store_finish (GDK_CLIPBOARD (source_object), res, &error))
        g_warning ("Failed to store clipboard: %s", error->message);
}

static void
g_paste_clipboard_gdk_store (GPasteClipboardGdk *self)
{
    g_debug ("%s: store", g_paste_clipboard_provider_target_name (self->is_clipboard));

    gdk_clipboard_store_async (self->real,
                               G_PRIORITY_DEFAULT,
                               NULL, /* cancellable */
                               g_paste_clipboard_gdk_store_async_done,
                               NULL);
}

static const gchar *
g_paste_clipboard_gdk_get_image_checksum (GPasteClipboardGdk *self)
{
    return g_paste_clipboard_content_get_image_checksum (&self->content);
}

static gboolean
g_paste_clipboard_gdk_is_identified (GPasteClipboardGdk *self)
{
    return g_paste_clipboard_content_is_identified (&self->content);
}

static void
g_paste_clipboard_gdk_private_set_image_checksum (GPasteClipboardGdk *self,
                                                  const gchar        *image_checksum)
{
    g_paste_clipboard_content_set_image_checksum (&self->content, image_checksum);
}

static void
g_paste_clipboard_gdk_private_set_color (GPasteClipboardGdk *self,
                                         const GdkRGBA      *rgba)
{
    g_debug ("%s: set color", g_paste_clipboard_provider_target_name (self->is_clipboard));

    g_paste_clipboard_content_set_color (&self->content, rgba);
}

static void
g_paste_clipboard_gdk_private_set_file_list (GPasteClipboardGdk *self,
                                             GdkFileList        *file_list)
{
    g_debug ("%s: set file list", g_paste_clipboard_provider_target_name (self->is_clipboard));

    g_paste_clipboard_content_set_file_list (&self->content, file_list);
}

static GPasteClipboardPublication
g_paste_clipboard_gdk_private_select_texture (GPasteClipboardGdk *self,
                                              GdkTexture         *texture,
                                              const gchar        *checksum)
{
    g_return_val_if_fail (GDK_IS_TEXTURE (texture), G_PASTE_CLIPBOARD_PUBLICATION_INVALID);

    g_paste_clipboard_gdk_supersede (self);

    g_debug ("%s: select image", g_paste_clipboard_provider_target_name (self->is_clipboard));

    g_paste_clipboard_gdk_private_set_image_checksum (self, checksum);

    g_autoptr (GdkContentProvider) provider = gdk_content_provider_new_typed (GDK_TYPE_TEXTURE, texture);

    return g_paste_clipboard_gdk_claim (self, provider);
}

typedef struct
{
    GPasteClipboardGdk               *self; /* ref'd for the duration of the read */
    GPasteClipboardUpdate            *update; /* what the read counts into, and what says it still matters */
    GPasteClipboardGdkTextureCallback callback;
} GPasteClipboardGdkTextureCallbackData;

static void
g_paste_clipboard_gdk_on_texture_ready (GObject      *source_object,
                                        GAsyncResult *res,
                                        gpointer      user_data)
{
    g_autofree GPasteClipboardGdkTextureCallbackData *data = user_data;
    g_autoptr (GPasteClipboardGdk) self = data->self; /* ref taken in set_texture */
    g_autoptr (GError) error = NULL;
    g_autoptr (GdkTexture) texture = gdk_clipboard_read_texture_finish (GDK_CLIPBOARD (source_object), res, &error);

    /* Superseded or timed out, the cache is the only place this could reach: see
     * on_text_ready (). */
    if (g_paste_clipboard_update_is_expired (data->update))
    {
        if (data->callback)
            data->callback (self, NULL, data->update);
        return;
    }

    if (!texture)
    {
        if (error)
            g_debug ("Failed to read texture from clipboard: %s", error->message);
        if (data->callback)
            data->callback (self, NULL, data->update);
        return;
    }

    g_autofree gchar *checksum = g_paste_image_item_compute_checksum (texture);
    GdkTexture *result = NULL;

    /* Not re-owned: the selection stays its owner's, with every format it
     * offers, and the history's head goes back on it if the owner releases it. */
    if (self->content.kind == CLIPBOARD_CONTENT_IMAGE && g_paste_str_equal (checksum, self->content.str))
        data->update->unchanged = TRUE;
    else
        result = texture;  /* borrowed from the g_autoptr above */

    if (data->callback)
        data->callback (self, result, data->update);
}

static void
g_paste_clipboard_gdk_set_texture (GPasteClipboardGdk               *self,
                                   GPasteClipboardUpdate            *update,
                                   GPasteClipboardGdkTextureCallback callback)
{
    GPasteClipboardGdkTextureCallbackData *data = g_new (GPasteClipboardGdkTextureCallbackData, 1);

    /* A ref for the whole read, and none on the update (see set_text). */
    data->self = g_object_ref (self);
    data->update = update;
    data->callback = callback;

    gdk_clipboard_read_texture_async (self->real,
                                      update->guard.cancellable,
                                      g_paste_clipboard_gdk_on_texture_ready,
                                      data);
}

typedef void (*GPasteClipboardGdkRGBACallback) (GPasteClipboardGdk *self,
                                               const GdkRGBA       *rgba,
                                               gpointer             user_data);

typedef struct
{
    GPasteClipboardGdk            *self; /* ref'd for the duration of the read */
    GPasteClipboardUpdate         *update; /* what the read counts into, and what says it still matters */
    GPasteClipboardGdkRGBACallback callback;
} GPasteClipboardGdkRGBACallbackData;

static void
g_paste_clipboard_gdk_on_rgba_ready (GObject      *source_object,
                                     GAsyncResult *res,
                                     gpointer      user_data)
{
    g_autofree GPasteClipboardGdkRGBACallbackData *data = user_data;
    g_autoptr (GPasteClipboardGdk) self = data->self; /* ref taken in set_color */
    g_autoptr (GError) error = NULL;
    const GValue *value = gdk_clipboard_read_value_finish (GDK_CLIPBOARD (source_object), res, &error);

    /* Superseded or timed out, the cache is the only place this could reach: see
     * on_text_ready (). */
    if (g_paste_clipboard_update_is_expired (data->update))
    {
        if (data->callback)
            data->callback (self, NULL, data->update);
        return;
    }

    if (!value)
    {
        if (error)
            g_debug ("Failed to read color from clipboard: %s", error->message);
        if (data->callback)
            data->callback (self, NULL, data->update);
        return;
    }

    const GdkRGBA *rgba = g_value_get_boxed (value);

    if (!rgba)
    {
        if (data->callback)
            data->callback (self, NULL, data->update);
        return;
    }

    if (self->content.kind == CLIPBOARD_CONTENT_COLOR && gdk_rgba_equal (rgba, &self->content.rgba))
    {
        data->update->unchanged = TRUE;
        if (data->callback)
            data->callback (self, NULL, data->update);
        return;
    }

    if (data->callback)
        data->callback (self, rgba, data->update);
}

static void
g_paste_clipboard_gdk_set_color (GPasteClipboardGdk            *self,
                                 GPasteClipboardUpdate         *update,
                                 GPasteClipboardGdkRGBACallback callback)
{
    GPasteClipboardGdkRGBACallbackData *data = g_new (GPasteClipboardGdkRGBACallbackData, 1);

    /* A ref for the whole read, and none on the update (see set_text). */
    data->self = g_object_ref (self);
    data->update = update;
    data->callback = callback;

    gdk_clipboard_read_value_async (self->real,
                                    GDK_TYPE_RGBA,
                                    G_PRIORITY_DEFAULT,
                                    update->guard.cancellable,
                                    g_paste_clipboard_gdk_on_rgba_ready,
                                    data);
}

typedef void (*GPasteClipboardGdkBytesCallback) (GPasteClipboardGdk *self,
                                                 GBytes             *bytes,
                                                 gpointer            user_data);

typedef struct
{
    GPasteClipboardGdk             *self; /* ref'd for the duration of the read */
    GCancellable                   *cancellable; /* ref'd: the second half goes out on it */
    GOutputStream                  *ostream; /* what the transfer is drained into */
    GPasteClipboardGdkBytesCallback callback;
    gpointer                        user_data;
} GPasteClipboardGdkBytesData;

static void
g_paste_clipboard_gdk_bytes_data_free (GPasteClipboardGdkBytesData *data)
{
    g_clear_object (&data->self);
    g_clear_object (&data->cancellable);
    g_clear_object (&data->ostream);
    g_free (data);
}

G_DEFINE_AUTOPTR_CLEANUP_FUNC (GPasteClipboardGdkBytesData, g_paste_clipboard_gdk_bytes_data_free)

static void
g_paste_clipboard_gdk_on_mime_bytes_ready (GObject      *source_object,
                                           GAsyncResult *res,
                                           gpointer      user_data)
{
    g_autoptr (GPasteClipboardGdkBytesData) data = user_data; /* built in fetch_mime */
    g_autoptr (GError) error = NULL;

    if (g_output_stream_splice_finish (G_OUTPUT_STREAM (source_object), res, &error) < 0)
    {
        if (error)
            g_debug ("Failed to read mime bytes: %s", error->message);
        data->callback (data->self, NULL, data->user_data);
        return;
    }

    /* steal_as_bytes requires a closed stream, which the splice above did
     * (%G_OUTPUT_STREAM_SPLICE_CLOSE_TARGET). */
    g_autoptr (GBytes) bytes = g_memory_output_stream_steal_as_bytes (G_MEMORY_OUTPUT_STREAM (data->ostream));

    data->callback (data->self, bytes, data->user_data);
}

static void
g_paste_clipboard_gdk_on_mime_stream_ready (GObject      *source_object,
                                            GAsyncResult *res,
                                            gpointer      user_data)
{
    /* Released here unless the splice below takes @data over. */
    g_autoptr (GPasteClipboardGdkBytesData) data = user_data; /* built in fetch_mime */
    g_autoptr (GError) error = NULL;
    const gchar *actual_mime = NULL;
    g_autoptr (GInputStream) stream = gdk_clipboard_read_finish (GDK_CLIPBOARD (source_object), res, &actual_mime, &error);

    if (error || !stream)
    {
        if (error)
            g_debug ("Failed to read mime stream: %s", error->message);
        data->callback (data->self, NULL, data->user_data);
        return;
    }

    /* Held here rather than read off @data in the call below: the steal that
     * hands @data to the callback writes %NULL over it, and nothing orders that
     * after the two arguments beside it -- gcc evaluates the last one first, so
     * both of those would be read off a pointer already cleared. */
    GOutputStream *ostream = data->ostream;
    GCancellable *cancellable = data->cancellable;

    /* Spliced rather than read once: a #GdkX11SelectionInputStream hands back
     * whatever a single property already holds, which for an INCR transfer is
     * the first chunk of it -- and a representation truncated there is the one
     * that would be stored on the item and re-published on every later paste.
     * Draining it into a memory stream is what the mutter backend's transfer
     * does, so both backends end up with the whole of what the owner sent. */
    g_output_stream_splice_async (ostream,
                                  stream,
                                  G_OUTPUT_STREAM_SPLICE_CLOSE_SOURCE | G_OUTPUT_STREAM_SPLICE_CLOSE_TARGET,
                                  G_PRIORITY_DEFAULT,
                                  cancellable,
                                  g_paste_clipboard_gdk_on_mime_bytes_ready,
                                  g_steal_pointer (&data));
}

/* Read one named mimetype off the selection, whatever it is being read for: the
 * mimetype is all this needs, so the caller carries what it means in @user_data.
 * @callback is required, and both halves report through it on every path, error
 * ones above all: it is what counts the read out of the update that fired it, so
 * one that went out without it would leave that update unable to conclude.
 *
 * gdk_clipboard_read_async() resolves to a single stream (the first of the
 * requested mimetypes the owner provides), so distinct mimetypes cannot be
 * collapsed into one read; update() already fires these reads in parallel. */
static void
g_paste_clipboard_gdk_fetch_mime (GPasteClipboardGdk             *self,
                                  const gchar                    *mimetype,
                                  GCancellable                   *cancellable,
                                  GPasteClipboardGdkBytesCallback callback,
                                  gpointer                        user_data)
{
    GPasteClipboardGdkBytesData *data = g_new0 (GPasteClipboardGdkBytesData, 1);

    /* Refs for the whole read (see set_text), across both of its halves: the
     * second one goes out on the cancellable the first was fired with, and what
     * keeps that alive is nothing this read can see. */
    data->self = g_object_ref (self);
    data->cancellable = g_object_ref (cancellable);
    data->ostream = g_memory_output_stream_new_resizable ();
    data->callback = callback;
    data->user_data = user_data;

    const gchar *mime_types[] = { mimetype, NULL };

    gdk_clipboard_read_async (self->real,
                              mime_types,
                              G_PRIORITY_DEFAULT,
                              cancellable,
                              g_paste_clipboard_gdk_on_mime_stream_ready,
                              data);
}

/* What a selection offering nothing but a bare text/plain answers: GDK decodes
 * that as ASCII, escaping every other byte as \XX, where the convention X11
 * clients follow -- and g_paste_text_content_provider_new () serving one -- is
 * UTF-8 under that name. Read as such, as the mutter backend reads every text
 * (g_paste_clipboard_text_from_bytes ()), and through GDK's own conversion only
 * when it is not valid UTF-8 after all. */
static void
g_paste_clipboard_gdk_on_bare_text_read (GPasteClipboardGdk *self,
                                         GBytes             *bytes,
                                         gpointer            user_data)
{
    GPasteClipboardGdkTextCallbackData *data = user_data;
    gboolean convert = FALSE;
    g_autofree gchar *text = (g_paste_clipboard_update_is_expired (data->update)) ? NULL : g_paste_clipboard_text_from_bytes (bytes, &convert);

    if (convert)
    {
        gdk_clipboard_read_text_async (self->real,
                                       data->update->guard.cancellable,
                                       g_paste_clipboard_gdk_on_text_ready,
                                       data);
        return;
    }

    g_autofree GPasteClipboardGdkTextCallbackData *owned = data;
    g_autoptr (GPasteClipboardGdk) ref = owned->self; /* ref taken in read_text */

    if (owned->callback)
        owned->callback (self, g_steal_pointer (&text), owned->update);
}

static void
g_paste_clipboard_gdk_read_text (GPasteClipboardGdk            *self,
                                 GPasteClipboardUpdate         *update,
                                 GPasteClipboardGdkTextCallback callback)
{
    if (!g_paste_clipboard_gdk_offers_bare_text (self))
    {
        g_paste_clipboard_gdk_set_text (self, update, callback);
        return;
    }

    GPasteClipboardGdkTextCallbackData *data = g_new (GPasteClipboardGdkTextCallbackData, 1);

    data->self = g_object_ref (self);
    data->update = update;
    data->callback = callback;
    g_paste_clipboard_gdk_fetch_mime (self, "text/plain", update->guard.cancellable,
                                      g_paste_clipboard_gdk_on_bare_text_read, data);
}

/* The same for a sync's read: see g_paste_clipboard_gdk_on_bare_text_read (),
 * asking first whether the sync still has anywhere to go, as the mutter
 * backend's sync read does before its own copy. */
static void
g_paste_clipboard_gdk_on_sync_bare_text_read (GPasteClipboardGdk *self,
                                              GBytes             *bytes,
                                              gpointer            user_data)
{
    GPasteClipboardSyncData *data = user_data;
    gboolean convert = FALSE;
    g_autofree gchar *text = (g_paste_clipboard_sync_data_wants_text (data)) ? g_paste_clipboard_text_from_bytes (bytes, &convert) : NULL;

    if (convert)
    {
        gdk_clipboard_read_text_async (self->real, data->guard.cancellable, g_paste_clipboard_gdk_sync_ready, data);
        return;
    }

    g_autoptr (GPasteClipboardSyncData) owned = data; /* built in sync_text */

    g_paste_clipboard_sync_data_deliver (owned, text);
}

static void
g_paste_clipboard_gdk_sync_bare_text (GPasteClipboardGdk      *self,
                                      GPasteClipboardSyncData *data)
{
    g_paste_clipboard_gdk_fetch_mime (self, "text/plain", data->guard.cancellable,
                                      g_paste_clipboard_gdk_on_sync_bare_text_read, data);
}

/* Every read below counts into the same #GPasteClipboardUpdate: what it holds,
 * what concluding it means and what releases it are the mutter backend's too,
 * and live in gpaste-clipboard-content.c. Only the calls that fetch the bytes
 * are this backend's. */

static void
g_paste_clipboard_gdk_update_on_file_list_ready (GObject      *source_object,
                                                 GAsyncResult *res,
                                                 gpointer      user_data)
{
    GPasteClipboardUpdate *update = user_data;
    g_autoptr (GError) error = NULL;
    const GValue *value = gdk_clipboard_read_value_finish (GDK_CLIPBOARD (source_object), res, &error);

    /* Superseded or timed out, the cache is the only place this could reach: see
     * on_text_ready (). Asked before the provider is read off @update, a
     * concluded one having handed it on. */
    if (g_paste_clipboard_update_is_expired (update))
    {
        g_paste_clipboard_update_maybe_done (update);
        return;
    }

    GPasteClipboardGdk *self = G_PASTE_CLIPBOARD_GDK (update->provider);

    if (!value)
    {
        if (error)
            g_debug ("Failed to read file list from clipboard: %s", error->message);
        g_paste_clipboard_update_maybe_done (update);
        return;
    }

    GdkFileList *file_list = g_value_get_boxed (value);
    /* (transfer container): the container is ours, the GFiles are not. */
    g_autoptr (GSList) files = (file_list) ? gdk_file_list_get_files (file_list) : NULL;

    if (!files)
    {
        g_paste_clipboard_update_maybe_done (update);
        return;
    }

    if (g_paste_clipboard_file_list_equal (g_paste_clipboard_content_get_file_list (&self->content), file_list))
    {
        update->unchanged = TRUE;
        g_paste_clipboard_update_maybe_done (update);
        return;
    }

    update->produced = TRUE;
    update->file_list = g_boxed_copy (GDK_TYPE_FILE_LIST, file_list);

    g_paste_clipboard_update_maybe_done (update);
}

static void
g_paste_clipboard_gdk_fetch_file_list (GPasteClipboardGdk    *self,
                                       GPasteClipboardUpdate *update)
{
    gdk_clipboard_read_value_async (self->real,
                                    GDK_TYPE_FILE_LIST,
                                    G_PRIORITY_DEFAULT,
                                    update->guard.cancellable,
                                    g_paste_clipboard_gdk_update_on_file_list_ready,
                                    update);
}

static void
g_paste_clipboard_gdk_update_on_text_ready (GPasteClipboardGdk *self G_GNUC_UNUSED,
                                            gchar              *text,
                                            gpointer            user_data)
{
    GPasteClipboardUpdate *update = user_data;

    update->produced = !!text;
    g_set_str_take (&update->text, text);
    g_paste_clipboard_update_maybe_done (update);
}

static void
g_paste_clipboard_gdk_update_on_texture_ready (GPasteClipboardGdk *self G_GNUC_UNUSED,
                                               GdkTexture         *texture,
                                               gpointer            user_data)
{
    GPasteClipboardUpdate *update = user_data;

    update->produced = !!texture;
    g_set_object (&update->texture, texture);
    g_paste_clipboard_update_maybe_done (update);
}

static void
g_paste_clipboard_gdk_update_on_color_ready (GPasteClipboardGdk *self G_GNUC_UNUSED,
                                             const GdkRGBA      *rgba,
                                             gpointer            user_data)
{
    GPasteClipboardUpdate *update = user_data;

    if (rgba)
    {
        update->produced = TRUE;
        update->rgba = *rgba;
    }

    g_paste_clipboard_update_maybe_done (update);
}

/* The backend only adapts the callback's shape. @user_data identifies the MIME
 * read; the shared update interprets its bytes and counts it out. */
static void
g_paste_clipboard_gdk_on_mime_read (GPasteClipboardGdk *self G_GNUC_UNUSED,
                                    GBytes             *bytes,
                                    gpointer            user_data)
{
    g_paste_clipboard_update_on_mime_read (user_data, bytes);
}

/* The two halves this backend answers g_paste_clipboard_update_read_mimes ()
 * with: what a selection offers is its GdkContentFormats, and a read of one
 * mimetype is a fetch reporting to on_mime_read (). Which mimetypes are asked
 * for is that function's, not this file's. */
static gboolean
g_paste_clipboard_gdk_offers_mime (gconstpointer offer,
                                   const gchar  *mimetype)
{
    return gdk_content_formats_contain_mime_type ((GdkContentFormats *) offer, mimetype);
}

static void
g_paste_clipboard_gdk_read_mime (gpointer                backend,
                                 const gchar            *mimetype,
                                 GCancellable           *cancellable,
                                 GPasteClipboardMimeCtx *ctx)
{
    g_paste_clipboard_gdk_fetch_mime (backend, mimetype, cancellable, g_paste_clipboard_gdk_on_mime_read, ctx);
}

/* The guard concluding an update rather than failing its reads is not a choice:
 * cancelling cannot fail them. gdk_x11_clipboard_read_async () and the selection
 * input stream behind it hand the cancellable to their #GTask and never connect
 * to it, so an owner that stopped answering leaves the read exactly where it was
 * whatever we ask of it -- and the update would never conclude, which is the
 * whole of what that guard is for. The cancel is still worth asking for: a read
 * that does honour it fails and counts itself out.
 *
 * What that leaves is the update outliving its own conclusion, freed only if
 * those reads ever land. Nothing can be done about the struct itself -- they
 * hold the pointer -- but everything of any size is let go of at the conclusion
 * instead (g_paste_clipboard_update_release_content ()), so what a stuck owner
 * leaves behind is a counter and not the content that was read, nor the ref that
 * keeps our requestor window on the server. */
static void
g_paste_clipboard_gdk_update (GPasteClipboardGdk                   *self,
                              gboolean                              record,
                              GPasteClipboardProviderUpdateCallback callback,
                              gpointer                              user_data)
{
    GdkContentFormats *formats = gdk_clipboard_get_formats (self->real);
    GPasteClipboardContentKind content_kind = CLIPBOARD_CONTENT_NONE;
    /* Text before an image: a copy offering both -- spreadsheet cells, which come
     * with a picture of themselves -- is the text, and an image is only what is
     * copied when it is all there is. */
    if (gdk_content_formats_contain_gtype (formats, GDK_TYPE_FILE_LIST))
        content_kind = CLIPBOARD_CONTENT_FILE_LIST;
    else if (gdk_content_formats_contain_gtype (formats, GDK_TYPE_RGBA))
        content_kind = CLIPBOARD_CONTENT_COLOR;
    else if (gdk_content_formats_contain_gtype (formats, G_TYPE_STRING))
        content_kind = CLIPBOARD_CONTENT_TEXT;
    else if (g_paste_settings_get_images_support (self->settings) &&
             gdk_content_formats_contain_gtype (formats, GDK_TYPE_TEXTURE))
        content_kind = CLIPBOARD_CONTENT_IMAGE;
    else if (gdk_content_formats_is_empty (formats))
    {
        gboolean released = (g_paste_clipboard_x11_hints_get_owner (self->hints) ==
                             G_PASTE_CLIPBOARD_X11_HINTS_OWNER_NONE);

        /* A release ends the update in flight with what it read, the owner gone
         * having served its content (g_paste_clipboard_update_owner_gone ()):
         * what it has left is the hints' own conversion, sent behind the
         * content read, and the reads riding along with it. A new owner's empty
         * formats supersede it, as any other change does. */
        if (released)
        {
            g_paste_clipboard_update_owner_gone (&self->update);
            g_paste_clipboard_gdk_supersede_formats_wait (self);
        }
        else
            g_paste_clipboard_gdk_supersede (self);

        /* Empty formats identify neither a release nor the new owner's value.
         * Keep expiry and sync waiting for TARGETS; reporting empty would let
         * ensure_not_empty () overwrite the copy being negotiated. What the
         * deadline answers is g_paste_clipboard_gdk_formats_wait_answer ()'s: a
         * selection nobody owns is a release, answered no with the cache
         * cleared so the history's head goes back; an owner that is slow, or
         * that X could not be asked about, is answered unknown with the cache
         * ignored, so nothing is published over it.
         *
         * How long it waits is what the server decides: a selection nobody owns
         * has already told the two apart, leaving only the gap a release and the
         * claim after it pass through (%G_PASTE_CLIPBOARD_GDK_RELEASE_GRACE). */
        g_paste_clipboard_gdk_wait_for_formats (self, released, record, callback, user_data);
        return;
    }
    else
    {
        /* The owner only provides types we don't handle (e.g. an image
         * while images-support is disabled). Don't track it, but flag the
         * clipboard as non-empty so ensure_not_empty doesn't override it --
         * and give up on the update the previous owner was being read for. */
        g_paste_clipboard_gdk_supersede (self);
        g_paste_clipboard_content_set_ignored (&self->content);
        if (callback)
            callback (G_PASTE_CLIPBOARD_PROVIDER (self), NULL, FALSE, G_PASTE_CLIPBOARD_SECRET_NO, user_data);
        return;
    }

    g_paste_clipboard_gdk_supersede_formats_wait (self);

    GPasteClipboardUpdate *update = g_paste_clipboard_update_new (G_PASTE_CLIPBOARD_PROVIDER (self),
                                                                  self->settings,
                                                                  content_kind,
                                                                  &self->update,
                                                                  &self->content,
                                                                  callback,
                                                                  user_data);

    /* Nothing here can have failed its preconditions, but the caller's own
     * bookkeeping is released by the callback and by nothing else, so the one
     * path that fires no read still answers (/gdk/update/unmade). */
    if (!update)
    {
        if (callback)
            callback (G_PASTE_CLIPBOARD_PROVIDER (self), NULL, FALSE, G_PASTE_CLIPBOARD_SECRET_UNKNOWN, user_data);
        return;
    }

    update->record = record;

    /* Counted in beside the read it counts, never before the switch: an arm that
     * fires nothing would leave the update pending on a read that does not
     * exist. */
    switch (content_kind)
    {
    case CLIPBOARD_CONTENT_FILE_LIST:
        g_paste_clipboard_update_add_read (update);
        g_paste_clipboard_gdk_fetch_file_list (self, update);
        break;
    case CLIPBOARD_CONTENT_COLOR:
        g_paste_clipboard_update_add_read (update);
        g_paste_clipboard_gdk_set_color (self, update, g_paste_clipboard_gdk_update_on_color_ready);
        break;
    case CLIPBOARD_CONTENT_TEXT:
        g_paste_clipboard_update_add_read (update);
        g_paste_clipboard_gdk_read_text (self, update, g_paste_clipboard_gdk_update_on_text_ready);
        break;
    case CLIPBOARD_CONTENT_IMAGE:
        g_paste_clipboard_update_add_read (update);
        g_paste_clipboard_gdk_set_texture (self, update, g_paste_clipboard_gdk_update_on_texture_ready);
        break;
    case CLIPBOARD_CONTENT_IGNORED:
    case CLIPBOARD_CONTENT_WITHHELD:
    case CLIPBOARD_CONTENT_NONE:
        g_assert_not_reached ();
    }

    /* Every special value asked for on top of the content, the formats saying
     * which are there to ask for. The hints are not among them -- GDK leaves
     * those names out of the formats -- and are read by the workaround, or off
     * those formats where it cannot run (below).
     *
     * On the primary selection as much as on the clipboard, which is a TARGETS
     * conversion per mouse selection: a password is copied with the mouse like
     * anything else, and a primary the hints were never read for is one every
     * route reads as ordinary text -- the sync out of it above all, which would
     * then publish the cleartext onto the clipboard stripped of what says it is
     * a secret. The round trip rides along with the content read already out for
     * the same change, so what it costs is one request beside a transfer, not a
     * wait of its own -- an owner leaving once it served the content, before it
     * answered this, having its release end the update with that content
     * (g_paste_clipboard_update_owner_gone ()). */
    if (g_paste_clipboard_x11_hints_available (self->hints))
    {
        g_paste_clipboard_update_read_special_mimes (update, formats, g_paste_clipboard_gdk_offers_mime,
                                                     self, g_paste_clipboard_gdk_read_mime);
        g_paste_clipboard_x11_hints_read (self->hints, update);
    }
    else
    {
        /* Nothing here can convert the selection -- no XFixes, an atom that could
         * not be interned -- so the hints are asked of the formats, like the
         * special values beside them. GDK leaves their names out of those, so
         * what this costs is recognising a password another application copied:
         * a feature lost where the workaround cannot run.
         *
         * The alternative is not "no hints" but "no answer": asking the
         * workaround anyway has every text read come back with its secrecy
         * unknown, for the rest of the session and on both selections, and an
         * unknown is kept rather than acted on everywhere it lands -- a strip the
         * user asked for is refused by every later read
         * (g_paste_clipboards_manager_finish_refresh ()), a trimmed clipboard is
         * never re-owned with the stripped text
         * (g_paste_clipboard_update_conclude ()), every sync out of a selection
         * whose record went unconfirmed is refused, and every plain copy of a
         * recorded password's value is taken for that password
         * (g_paste_clipboards_manager_preserve_password ()). A silence that never
         * ends is not the silence any of those are written for. */
        g_paste_clipboard_update_read_mimes (update, formats, g_paste_clipboard_gdk_offers_mime,
                                             self, g_paste_clipboard_gdk_read_mime);
    }

    g_paste_clipboard_update_maybe_done (update);
}

static GPasteClipboardPublication
g_paste_clipboard_gdk_select_item (GPasteClipboardGdk *self,
                                   GPasteItem         *item)
{
    g_debug ("%s: select item", g_paste_clipboard_provider_target_name (self->is_clipboard));

    if (G_PASTE_IS_IMAGE_ITEM (item))
    {
        GdkTexture *texture = g_paste_image_item_get_image (G_PASTE_IMAGE_ITEM (item));
        const gchar *checksum = g_paste_image_item_get_checksum (G_PASTE_IMAGE_ITEM (item));

        if (!texture)
            return G_PASTE_CLIPBOARD_PUBLICATION_INVALID;

        return g_paste_clipboard_gdk_private_select_texture (self, texture, checksum);
    }

    g_paste_clipboard_gdk_supersede (self);

    if (G_PASTE_IS_COLOR_ITEM (item))
    {
        const GdkRGBA *rgba = g_paste_color_item_get_rgba (G_PASTE_COLOR_ITEM (item));

        g_paste_clipboard_gdk_private_set_color (self, rgba);

        /* Offer the colour itself plus its textual form, so it can be pasted both
         * into colour-aware apps (application/x-color) and into plain text fields. */
        GdkContentProvider *providers[] = {
            gdk_content_provider_new_typed (GDK_TYPE_RGBA, rgba),
            g_paste_text_content_provider_new (g_paste_item_get_real_value (item)),
        };
        g_autoptr (GdkContentProvider) provider = gdk_content_provider_new_union (providers, G_N_ELEMENTS (providers));

        return g_paste_clipboard_gdk_claim (self, provider);
    }

    g_autoptr (GPtrArray) providers = g_ptr_array_new ();

    if (G_PASTE_IS_URIS_ITEM (item))
    {
        GdkFileList *file_list = g_paste_uris_item_get_file_list (G_PASTE_URIS_ITEM (item));
        g_paste_clipboard_gdk_private_set_file_list (self, file_list);
        g_ptr_array_add (providers, gdk_content_provider_new_typed (GDK_TYPE_FILE_LIST, file_list));
    }
    else
    {
        const gchar *real_value = g_paste_item_get_real_value (item);
        g_paste_clipboard_gdk_private_set_text (self, real_value);
        g_ptr_array_add (providers, g_paste_text_content_provider_new (real_value));
    }

    for (const GSList *sv = g_paste_item_get_special_values (item); sv; sv = sv->next)
    {
        GPasteBinaryData *v = sv->data;
        g_ptr_array_add (providers, gdk_content_provider_new_for_bytes (g_paste_special_mime_get (g_paste_binary_data_get_mime (v)), g_paste_binary_data_get_bytes (v)));
    }

    /* Say that what is on offer is a secret, so a clipboard manager reading
     * these keeps it out of its own history. Only we can say it: a password
     * travels as ordinary text, and nothing about the text says so.
     *
     * Offered here and served by nobody, on this backend as it stands: the hint
     * reaches every client's TARGETS, gdk_x11_clipboard_formats_to_targets ()
     * (gdk/x11/gdkclipboard-x11.c) passing every mimetype in the formats through
     * as an atom, but the request that comes back for its value is refused.
     * gdk_x11_selection_output_streams_request () resolves the target through
     * gdk_intern_mime_type (), which answers %NULL for a name with no '/' in it,
     * and the branch that would consult the provider is skipped -- so the reply
     * is property None, and the manager that asked records the password like any
     * other text. Reading the hint has no such hole (gpaste-clipboard-x11-hints.c
     * goes around GTK for it) and the mutter backend publishes it through a
     * source of its own, so this is the one half of the feature that waits on
     * GTK. It is still published: the value is what decides, the same
     * key being how an owner says its content is *not* a secret, so the day the
     * refusal goes away this starts working with nothing here to change. */
    if (G_PASTE_IS_PASSWORD_ITEM (item))
    {
        for (GPasteSensitiveMime mime = G_PASTE_SENSITIVE_MIME_FIRST; mime < G_PASTE_SENSITIVE_MIME_LAST; ++mime)
        {
            g_ptr_array_add (providers, gdk_content_provider_new_for_bytes (g_paste_sensitive_mime_get (mime),
                                                                            g_paste_sensitive_mime_get_bytes (mime)));
        }
    }

    g_autoptr (GdkContentProvider) provider = NULL;
    if (providers->len == 1)
        provider = g_ptr_array_index (providers, 0);
    else
        provider = gdk_content_provider_new_union ((GdkContentProvider **) providers->pdata, providers->len);

    return g_paste_clipboard_gdk_claim (self, provider);
}

static gboolean
g_paste_clipboard_gdk_is_empty (GPasteClipboardGdk *self)
{
    return g_paste_clipboard_content_is_empty (&self->content);
}

static void
g_paste_clipboard_gdk_on_real_changed (GPasteClipboardGdk *self)
{
    /* GdkClipboard::changed fires for our own writes too; skip them rather than
     * re-process the content we just published. */
    if (gdk_clipboard_is_local (self->real))
        return;

    /* Every change is passed on, the empty formats a new owner is announced with
     * included -- and neither half of why that is right is visible from here.
     *
     * GTK raises two changes per external copy: the empty formats first, then the
     * owner's targets once GDK has converted TARGETS. Filtering the empty one
     * loses the other thing it announces, since a release comes with the same
     * empty formats and has no second change to follow: the head would never go
     * back on a selection whose owner went away, for the rest of the session
     * (/gdk/formats/deadline). Passing it on is only safe because update () has
     * an arm for empty formats that defers instead of answering empty -- without
     * it they reach the branch for an owner offering nothing we handle, which
     * clears the cache and has ensure_not_empty () put the history's head over
     * the copy the user is making (/gdk/formats/new-copy).
     *
     * What the empty change does here is retire the previous owner's read and
     * suspend the cache's consumers -- a password deadline must not overwrite a
     * new copy while its TARGETS reply is pending -- and start the wait that
     * tells a release from an owner that has yet to publish.
     *
     * Holding that change back and raising one of our own once the wait has
     * concluded is a different proposal from filtering it out, and it is the open
     * lead on the two notifications one copy costs the manager: see the FIXME on
     * g_paste_clipboards_manager_notify (). */
    /* ...except for the targets arriving under a wait no change asked for.
     *
     * A GdkClipboard is created with empty formats and fills them in once its own
     * TARGETS conversion comes back, raising a change as it does, so the read the
     * manager bootstraps a selection with -- and a re-read it asks to identify
     * one -- finds them empty and waits like any other. The targets arriving
     * are then not a new owner: they are the answer to that very read. Raising a
     * change for them would supersede the wait and hand the selection to the
     * manager's copy path, which records what was already sitting there as a
     * new copy -- over the history's head and its stored password timeout, and
     * onto the other selection with synchronization on -- where the read asked
     * for says only what the selection carries (identify_ready ()). So the read
     * goes on under the callback it was asked with (/gdk/formats/bootstrap).
     *
     * A wait a change did ask for gets its change as any other does: that is
     * the one the empty formats announced, and the copy path is where it goes
     * (/gdk/formats/bootstrap-then-copy). A new owner claiming the selection
     * while an identifying wait is out announces itself with empty formats of
     * its own first, which supersedes that wait through the ordinary route.
     *
     * Nor while a copy is owed (@copy_owed): an owner slow enough that the wait
     * its change asked for timed out with it still there has had that change
     * announced and never read, and an identifying read the manager asks for in
     * the meantime -- a countdown, an expiry wait, a strip -- waits on the very
     * same targets. Those are that owner's copy, and continuing the identifying
     * read with them would identify it without ever recording it: nothing
     * entering the history, nothing synchronized
     * (/gdk/formats/owed-copy). They get their change instead, which
     * supersedes the identifying wait as any change does. */
    GPasteClipboardGdkFormatsWait *wait = self->formats_wait;

    if (wait && !wait->after_change && !self->copy_owed && !gdk_content_formats_is_empty (gdk_clipboard_get_formats (self->real)))
    {
        gboolean record = wait->record;
        GPasteClipboardProviderUpdateCallback callback = wait->callback;
        gpointer user_data = wait->user_data;

        g_debug ("%s: targets for the read that was waiting on them", g_paste_clipboard_provider_target_name (self->is_clipboard));
        self->identify_owed = FALSE;
        self->formats_wait = NULL;
        g_source_remove (wait->source_id);
        g_paste_clipboard_gdk_formats_wait_free (wait);
        g_paste_clipboard_gdk_update (self, record, callback, user_data);
        return;
    }

    /* And with no wait out at all, the targets of an owner whose identification
     * is owed (@identify_owed) answer that identification: the read that asked
     * has given up already, so the manager is asked for another one rather than
     * told of a copy -- which would record what was already sitting on the
     * selection, over the history's head and, with synchronization on, onto the
     * other selection (/gdk/formats/bootstrap-late). A new owner announces
     * itself with empty formats first, and takes the ordinary route below. */
    if (self->identify_owed && !self->copy_owed && !self->formats_wait && !self->update &&
        !gdk_content_formats_is_empty (gdk_clipboard_get_formats (self->real)))
    {
        g_debug ("%s: targets for an identification owed", g_paste_clipboard_provider_target_name (self->is_clipboard));
        self->identify_owed = FALSE;
        g_paste_clipboard_provider_emit_reidentify (G_PASTE_CLIPBOARD_PROVIDER (self));
        return;
    }

    g_debug ("%s: owner change", g_paste_clipboard_provider_target_name (self->is_clipboard));
    /* Raised now, whether it is the owed copy or a new owner's, which owes the
     * previous owner nothing either. */
    self->copy_owed = FALSE;
    self->identify_owed = FALSE;
    self->emitting_change = TRUE;
    g_paste_clipboard_provider_emit_changed (G_PASTE_CLIPBOARD_PROVIDER (self));
    self->emitting_change = FALSE;
}

/* GPasteClipboardProvider interface adapters */
G_PASTE_CLIPBOARD_PROVIDER_DEFINE_VFUNCS (gdk, GDK)

static void
g_paste_clipboard_gdk_dispose (GObject *object)
{
    GPasteClipboardGdk *self = G_PASTE_CLIPBOARD_GDK (object);

    if (self->settings)
    {
        /* The read in flight goes too, not just the wait. Only an explicit
         * g_object_run_dispose () can find one -- an update holds the provider
         * until it concludes -- and its conclusion would then re-own the
         * selection for a trimmed text through a cleared @real. */
        g_paste_clipboard_gdk_supersede (self);
        g_signal_handler_disconnect (self->real, self->c_signals[C_CHANGED]);
        g_clear_object (&self->hints);
        g_clear_object (&self->real);
        g_clear_object (&self->settings);
    }

    G_OBJECT_CLASS (g_paste_clipboard_gdk_parent_class)->dispose (object);
}

static void
g_paste_clipboard_gdk_finalize (GObject *object)
{
    GPasteClipboardGdk *self = G_PASTE_CLIPBOARD_GDK (object);

    g_paste_clipboard_content_clear (&self->content);

    G_OBJECT_CLASS (g_paste_clipboard_gdk_parent_class)->finalize (object);
}

static void
g_paste_clipboard_gdk_class_init (GPasteClipboardGdkClass *klass)
{
    GObjectClass *object_class = G_OBJECT_CLASS (klass);

    object_class->dispose = g_paste_clipboard_gdk_dispose;
    object_class->finalize = g_paste_clipboard_gdk_finalize;
}

static void
g_paste_clipboard_gdk_init (GPasteClipboardGdk *self G_GNUC_UNUSED)
{
}

static GPasteClipboardProvider *
_g_paste_clipboard_gdk_new (GPasteSettings *settings,
                            gboolean        is_clipboard)
{
    GPasteClipboardGdk *self = g_object_new (G_PASTE_TYPE_CLIPBOARD_GDK, NULL);

    GdkDisplay *display = gdk_display_get_default ();
    self->real = g_object_ref (is_clipboard ? gdk_display_get_clipboard (display)
                                            : gdk_display_get_primary_clipboard (display));
    self->is_clipboard = is_clipboard;
    self->settings = g_object_ref (settings);
    self->hints = g_paste_clipboard_x11_hints_new (self->real, is_clipboard);

    self->c_signals[C_CHANGED] = g_signal_connect_swapped (self->real,
                                                           "changed",
                                                           G_CALLBACK (g_paste_clipboard_gdk_on_real_changed),
                                                           self);

    return G_PASTE_CLIPBOARD_PROVIDER (self);
}

/**
 * g_paste_clipboard_gdk_new_clipboard:
 * @settings: a #GPasteSettings instance
 *
 * Create a new GDK-backed #GPasteClipboardProvider for the clipboard
 *
 * Returns: (transfer full): a newly allocated #GPasteClipboardProvider
 *          free it with g_object_unref
 */
GPasteClipboardProvider *
g_paste_clipboard_gdk_new_clipboard (GPasteSettings *settings)
{
    g_return_val_if_fail (G_PASTE_IS_SETTINGS (settings), NULL);

    return _g_paste_clipboard_gdk_new (settings, TRUE);
}

/**
 * g_paste_clipboard_gdk_new_primary:
 * @settings: a #GPasteSettings instance
 *
 * Create a new GDK-backed #GPasteClipboardProvider for the primary selection
 *
 * Returns: (transfer full): a newly allocated #GPasteClipboardProvider
 *          free it with g_object_unref
 */
GPasteClipboardProvider *
g_paste_clipboard_gdk_new_primary (GPasteSettings *settings)
{
    g_return_val_if_fail (G_PASTE_IS_SETTINGS (settings), NULL);

    return _g_paste_clipboard_gdk_new (settings, FALSE);
}
