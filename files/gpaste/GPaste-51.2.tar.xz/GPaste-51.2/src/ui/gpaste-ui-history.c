// SPDX-FileCopyrightText: 2010-2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com>
// SPDX-License-Identifier: BSD-2-Clause

#include <gpaste-3/gpaste-gsettings-keys.h>
#include <gpaste-3/gpaste-update-enums.h>

#include <gpaste-gtk4/gpaste-gtk-util.h>

#include <adwaita.h>

#include <gpaste-ui-history.h>
#include <gpaste-ui-history-model.h>
#include <gpaste-ui-item.h>
#include <gpaste-ui-pick-selection.h>
#include <gpaste-ui-window.h>

struct _GPasteUiHistory
{
    GtkBox parent_instance;

    GPasteClient         *client;
    GPasteSettings       *settings;
    /* Both weak: a reply still out holds a reference on us, and a window going
     * away only unparents its children, so we can outlive the panel and the
     * window -- our dispose () waiting on that reply's reference, not on the
     * window. Each reply reaching for either checks it is still there. */
    GPasteUiPanel        *panel;

    AdwStatusPage        *status_page;
    GtkWidget            *retry_button;
    GtkScrolledWindow    *scroll;
    GtkListView          *list_view;
    GPasteUiHistoryModel *model;
    GtkSelectionModel    *selection_model; /* borrowed: the list view owns it */

    /* Weak too, for the same reason as the panel, though no test shows the
     * difference: GTK keeps a destroyed window's memory past such a reply, and
     * gtk_window_close () on it does nothing. Held weakly all the same rather
     * than trusting that to last. */
    GtkWindow            *rootwin;

    guint64               size;         /* number of rows currently in the model */
    guint64               limit;        /* how many items we currently allow on screen; grows lazily */
    guint64               available;    /* last known total size of the history */
    gboolean              loading;      /* a positional refresh is in flight */
    guint64               loading_from; /* the first row it refetches */

    /* The call listing the rows, cancelled and replaced by every refresh and
     * every search. Refresh and filter write the same rows (indices vs. uuids),
     * so whichever went out last is the one that may land. What cancelling the
     * listing it replaced buys is display_callback_data_new ()'s to say. */
    GCancellable         *display;

    gboolean              selection_mode; /* merge mode: rows are multi-selectable */
    GArray               *selection;       /* the Picks, in the order they were made */
    gint32                item_height;

    gchar                *search;
    gboolean              favourites; /* show only the pinned items */
    /* A filter is out, and Enter in the search asked for its first match:
     * see g_paste_ui_history_select_first (). */
    gboolean              filtering;
    gboolean              select_first;

    /* Whether the list had the focus before a daemon change hid it, and gets it
     * back once rows are shown again, including after a failed load and retry. */
    gboolean              refocus;
};

enum
{
    SELECTION_CHANGED,

    LAST_SIGNAL
};

static guint signals[LAST_SIGNAL] = { 0 };

enum
{
    PROP_0,
    PROP_SELECTION_MODE,

    N_PROPERTIES
};

static GParamSpec *properties[N_PROPERTIES] = { NULL };

G_PASTE_DEFINE_TYPE (UiHistory, ui_history, GTK_TYPE_BOX)

static void
g_paste_ui_history_show_status (GPasteUiHistory *self,
                                const gchar     *icon,
                                const gchar     *title,
                                const gchar     *description)
{
    /* A spinner left there by g_paste_ui_history_show_starting () would win
     * over the icon. */
    adw_status_page_set_paintable (self->status_page, NULL);
    gtk_widget_set_visible (self->retry_button, FALSE);
    adw_status_page_set_icon_name (self->status_page, icon);
    adw_status_page_set_title (self->status_page, title);
    adw_status_page_set_description (self->status_page, description);
    gtk_widget_set_visible (GTK_WIDGET (self->status_page), TRUE);
    gtk_widget_set_visible (GTK_WIDGET (self->scroll), FALSE);
}

/* A daemon on its way, or the rows a retry asked for: the page says only
 * that something is being loaded. */
static void
g_paste_ui_history_show_starting (GPasteUiHistory *self)
{
    g_autoptr (AdwSpinnerPaintable) spinner = adw_spinner_paintable_new (GTK_WIDGET (self->status_page));

    g_paste_ui_history_show_status (self, NULL, "", NULL);
    adw_status_page_set_paintable (self->status_page, GDK_PAINTABLE (spinner));
}

static void
g_paste_ui_history_show_list (GPasteUiHistory *self)
{
    /* A focused Retry button may stay the root's focus after its page is
     * hidden. Record that focus before hiding it, even when no retry was
     * clicked; leave focus on another widget where the user put it. */
    GtkRoot *root = gtk_widget_get_root (GTK_WIDGET (self));
    GtkWidget *focus = (root) ? gtk_root_get_focus (root) : NULL;
    gboolean focus_status = focus && gtk_widget_is_ancestor (focus, GTK_WIDGET (self->status_page));
    gboolean refocus = focus_status || (self->refocus && !focus);

    self->refocus = FALSE;
    gtk_widget_set_visible (GTK_WIDGET (self->status_page), FALSE);
    gtk_widget_set_visible (GTK_WIDGET (self->scroll), TRUE);

    if (root && refocus)
        gtk_widget_grab_focus (GTK_WIDGET (self->list_view));
}

/* A page saying there are no rows, unlike a spinner or an error: nothing more
 * is coming that the focus would be waiting for, so a list filled later does
 * not take it. Every such page goes through here. */
static void
g_paste_ui_history_show_answer (GPasteUiHistory *self,
                                const gchar     *icon_name,
                                const gchar     *title,
                                const gchar     *description)
{
    g_paste_ui_history_show_status (self, icon_name, title, description);
    self->refocus = FALSE;
}

/* What the history says of itself before it has said anything: the state the
 * list is built in, and the one it goes back to whenever a refresh finds it
 * empty. One copy, so the two cannot drift apart. */
static void
g_paste_ui_history_show_empty (GPasteUiHistory *self)
{
    g_paste_ui_history_show_answer (self, G_PASTE_ICON_NAME "-symbolic", _("No Items"),
                                    _("Copy something to start building your history."));
}

/* The list's focus stays owed, as on every page that waits for rows rather
 * than answering that there are none (g_paste_ui_history_show_answer ()): a
 * retry, or an update, that brings the rows back hands it over. It counts only
 * where GTK's own move -- at the next paint of a window left without a focus,
 * to whatever comes first -- lands elsewhere than the list -- a sidebar row, at
 * times, after another window -- which nothing makes it do reliably, so no test
 * shows it. Above the function rather than the call: xgettext hands a comment
 * just before a translatable string to the translators. */
static void
g_paste_ui_history_show_load_error (GPasteUiHistory *self)
{
    g_paste_ui_history_show_status (self, "dialog-warning-symbolic", _("Could Not Load History"), NULL);
    gtk_widget_set_visible (self->retry_button, TRUE);
}

/* Take the initial focus the first time the list makes it on screen. Left alone,
 * GTK hands it to the first focusable widget it can find, which is the sidebar's
 * "Switch to history" entry: an editable, so it would swallow everything typed
 * at the window instead of letting it through to the search bar. A widget can
 * only take the focus once it is mapped, which is what this waits for -- and it
 * disconnects itself, so a later refresh can never pull the focus out of
 * whatever the user is busy with. */
static void
on_list_view_mapped (GtkWidget *list_view,
                     gpointer   user_data G_GNUC_UNUSED)
{
    g_signal_handlers_disconnect_by_func (list_view, on_list_view_mapped, NULL);

    gtk_widget_grab_focus (list_view);
}

/* What picking a row is in selection mode, a click and an activation alike. */
static void
g_paste_ui_history_toggle_pick (GPasteUiHistory *self,
                                guint            position)
{
    if (gtk_selection_model_is_selected (self->selection_model, position))
        gtk_selection_model_unselect_item (self->selection_model, position);
    else
        gtk_selection_model_select_item (self->selection_model, position, FALSE);
}

/* In merge mode a plain click should toggle that one row, where the list view
 * would otherwise replace the whole selection, so claim the press before its own
 * gesture runs. The gesture lives on the row widget, which its #GtkListItem owns
 * and outlives, so the list item can be borrowed to ask where the row sits. */
static void
on_row_pressed (GtkGestureClick *gesture,
                gint             n_press G_GNUC_UNUSED,
                gdouble          x       G_GNUC_UNUSED,
                gdouble          y       G_GNUC_UNUSED,
                gpointer         user_data)
{
    GPasteUiHistory *self = user_data;

    if (!self->selection_mode || !self->selection_model)
        return;

    GtkListItem *list_item = g_object_get_data (G_OBJECT (gesture), "gpaste-list-item");
    guint position = gtk_list_item_get_position (list_item);

    if (position == GTK_INVALID_LIST_POSITION)
        return;

    gtk_gesture_set_state (GTK_GESTURE (gesture), GTK_EVENT_SEQUENCE_CLAIMED);
    g_paste_ui_history_toggle_pick (self, position);
    /* Claimed, the press never reaches the row's own gesture, which is what
     * gives a clicked row the focus: given here, or Enter would pick the row
     * the keyboard was left on. */
    gtk_list_view_scroll_to (self->list_view, position, GTK_LIST_SCROLL_FOCUS, NULL);
}

/* The list view recycles a small pool of row widgets: "setup" builds one empty
 * row, "bind" points it at the model item it should display (which kicks off the
 * async fetch of its content), and "unbind" clears it so a fetch from the
 * previous binding cannot land on the reused widget. */
static void
g_paste_ui_history_setup_item (GtkListItemFactory *factory G_GNUC_UNUSED,
                               GtkListItem        *list_item,
                               gpointer            user_data)
{
    GPasteUiHistory *self = user_data;
    /* The window is there: a list its window let go of is on no screen, and
     * the factory builds no row for it (see the rootwin field). */
    GtkWidget *item = g_paste_ui_item_new (self->client, self->settings, self->rootwin, (guint64) -1);
    GtkGesture *gesture = gtk_gesture_click_new ();

    /* A row's own actions have no business being offered while the list is
     * picking items to merge. Bound at setup, so it covers the rows built later
     * as well as the ones recycled since. */
    g_object_bind_property (self, "selection-mode", item, "selection-mode", G_BINDING_SYNC_CREATE);

    gtk_event_controller_set_propagation_phase (GTK_EVENT_CONTROLLER (gesture), GTK_PHASE_CAPTURE);
    g_object_set_data (G_OBJECT (gesture), "gpaste-list-item", list_item);
    g_signal_connect_object (gesture, "pressed", G_CALLBACK (on_row_pressed), self, 0);
    gtk_widget_add_controller (item, GTK_EVENT_CONTROLLER (gesture));

    gtk_list_item_set_child (list_item, item);
}

static void
g_paste_ui_history_bind_item (GtkListItemFactory *factory G_GNUC_UNUSED,
                              GtkListItem        *list_item,
                              gpointer            user_data G_GNUC_UNUSED)
{
    GPasteUiHistoryItem *model_item = gtk_list_item_get_item (list_item);
    GtkWidget *widget = gtk_list_item_get_child (list_item);
    const gchar *uuid = g_paste_ui_history_item_get_uuid (model_item);

    g_paste_ui_history_item_set_widget (model_item, widget);

    /* A search row knows its uuid; a positional one's history index is simply
     * where it sits, so there is no second copy of it to go stale. */
    if (uuid)
        g_paste_ui_item_set_uuid (G_PASTE_UI_ITEM (widget), uuid);
    else
        g_paste_ui_item_set_index (G_PASTE_UI_ITEM (widget), gtk_list_item_get_position (list_item));
}

static void
g_paste_ui_history_unbind_item (GtkListItemFactory *factory G_GNUC_UNUSED,
                                GtkListItem        *list_item,
                                gpointer            user_data G_GNUC_UNUSED)
{
    GPasteUiHistoryItem *model_item = gtk_list_item_get_item (list_item);
    GtkWidget *widget = gtk_list_item_get_child (list_item);

    if (model_item)
        g_paste_ui_history_item_set_widget (model_item, NULL);

    /* Clears the row, and invalidates whatever this binding left in flight. */
    g_paste_ui_item_set_index (G_PASTE_UI_ITEM (widget), (guint64) -1);
}

static void     g_paste_ui_history_filter            (GPasteUiHistory *self);
static void     g_paste_ui_history_refresh           (GPasteUiHistory *self,
                                                      guint64          from_index);
static gboolean g_paste_ui_history_activate_position (GPasteUiHistory *self,
                                                      guint64          position);

/* One batch is a viewport's worth of items: enough to fill the visible area so
 * the list always has something to scroll to while more history remains. Until
 * a row has been measured and the viewport allocated, fall back to a fixed
 * count and let the lazy-growth loop top it up to fill the window. */
#define G_PASTE_UI_HISTORY_DEFAULT_BATCH 20

/* Smallest plausible row height in pixels. Used to bound eager filling: dividing
 * the viewport height by it yields the most rows that could ever be needed, so a
 * run of not-yet-laid-out (zero-height) rows can't keep loading the whole history. */
#define G_PASTE_UI_HISTORY_MIN_ROW_HEIGHT 16.0

static guint64
g_paste_ui_history_batch (GPasteUiHistory *self)
{
    if (self->item_height > 0 && self->scroll)
    {
        GtkAdjustment *vadjustment = gtk_scrolled_window_get_vadjustment (self->scroll);
        gdouble page = gtk_adjustment_get_page_size (vadjustment);

        if (page > 0)
            return (guint64) (page / self->item_height) + 1;
    }

    return G_PASTE_UI_HISTORY_DEFAULT_BATCH;
}

/* Carried by both the refresh and the filter callbacks. Both @self and
 * @cancellable are owned: the widget's only owner is the widget tree, so a
 * window closing mid-flight would otherwise finalize it before the reply lands,
 * and the cancellable is the one this listing went out on rather than whichever
 * @self holds by then.
 *
 * @searched records which of the two calls the filter made, because the reply
 * has to be finished as the call it was: reading self->search back at reply
 * time would ask a Search result for its favourites the moment the search is
 * cleared while one is in flight. */
typedef struct
{
    GPasteUiHistory *self;
    GCancellable    *cancellable;
    gchar           *name;
    guint64          from_index;
    gboolean         searched;
} DisplayCallbackData;

static void
display_callback_data_free (DisplayCallbackData *data)
{
    g_clear_object (&data->self);
    g_clear_object (&data->cancellable);
    g_free (data->name);
    g_free (data);
}

G_DEFINE_AUTOPTR_CLEANUP_FUNC (DisplayCallbackData, display_callback_data_free)

/* Allocating the data is what supersedes the listing before it: this is called
 * from the two places a listing goes out, and each of them goes out on the
 * cancellable it leaves behind.
 *
 * Cancelling is the client giving up, not the daemon stopping: D-Bus has no way
 * to call off a method already sent, so a superseded Search still matches the
 * whole history and its reply is dropped on arrival. What it buys is this side
 * letting go at once -- the callback runs with the cancellation, releasing the
 * widget it holds -- and a reply that can never be mistaken for the current
 * one. What keeps searches from going out once per character is the search
 * entry's own delay ("search-changed"), not this. */
static DisplayCallbackData *
display_callback_data_new (GPasteUiHistory *self,
                           guint64          from_index)
{
    DisplayCallbackData *data = g_new0 (DisplayCallbackData, 1);

    g_paste_clear_cancellable (&self->display);
    self->display = g_cancellable_new ();

    data->self = g_object_ref (self);
    data->cancellable = g_object_ref (self->display);
    data->from_index = from_index;

    return data;
}

static void
g_paste_ui_history_refresh_history (GObject      *source_object G_GNUC_UNUSED,
                                    GAsyncResult *res,
                                    gpointer      user_data)
{
    g_autoptr (DisplayCallbackData) cdata = user_data;
    GPasteUiHistory *self = cdata->self;

    if (!self->client)
        return;

    /* A later refresh or filter superseded this one: leave self->loading to
     * whichever did (a refresh clears it on its own reply, a filter as it goes
     * out) and don't re-index from this stale from_index, which could leave
     * shifted rows with wrong indices — or, for a filtered view, overwrite the
     * uuids it just installed. Asked before the _finish () below, which a
     * cancelled call answers with an error of no interest to anyone. */
    if (g_cancellable_is_cancelled (cdata->cancellable))
        return;

    /* The size is of whatever history the daemon held when it handled the call,
     * and the reply does not say which: it is the one this refresh was issued
     * under only while that is still the current one. A switch that landed in
     * between makes the number another history's, and would go on the sidebar
     * row of the one it is not; the refresh the switch itself triggers is what
     * reports it. */
    g_autofree gchar *current = g_paste_client_get_history_name (self->client);

    if (!current || !g_paste_str_equal (current, cdata->name))
    {
        self->loading = FALSE;

        return;
    }

    g_autoptr (GError) error = NULL;
    guint64 old_size = self->size;
    guint64 new_size = g_paste_client_get_history_size_finish (self->client, res, &error);

    self->loading = FALSE;

    /* A failed size says nothing about the rows already shown. With none, show
     * an error and a way to retry rather than leaving a loading page up. */
    if (error)
    {
        /* Its daemon gone, the presence says so and lists again: no failure
         * to report, the page staying as it is until then
         * (g_paste_client_is_daemon_gone_error ()). */
        if (g_paste_client_is_daemon_gone_error (error))
            return;

        g_warning ("Could not get the size of history \"%s\": %s", cdata->name, error->message);
        if (!self->size)
            g_paste_ui_history_show_load_error (self);
        return;
    }

    self->available = new_size;
    /* Never keep a display limit larger than what the history can fill: when it
     * shrinks (items removed, emptied, or a smaller history selected), drop back
     * so lazy growth restarts from a single batch instead of eagerly reloading
     * the old depth should the history grow again. */
    self->limit = MIN (self->limit, MAX (g_paste_ui_history_batch (self), new_size));
    self->size = MIN (new_size, self->limit);

    if (self->size)
        g_paste_ui_history_show_list (self);
    else
        g_paste_ui_history_show_empty (self);

    if (self->panel)
        g_paste_ui_panel_update_history_length (self->panel, cdata->name, new_size);

    gboolean rebuilt = g_paste_ui_history_model_set_size (self->model, self->size);

    /* The rows the resize just added or dropped are already accounted for. The
     * ones that survive it keep their positions but not necessarily their
     * contents — history entries shift as one is added or removed — so those
     * from @from_index on have to refetch. */
    guint64 kept = MIN (old_size, self->size);

    if (!rebuilt && cdata->from_index < kept)
        g_paste_ui_history_model_invalidate (self->model, cdata->from_index, kept - cdata->from_index);
}

static void
g_paste_ui_history_refresh (GPasteUiHistory *self,
                            guint64          from_index)
{
    if (!self->client)
        return;

    /* Nothing is asked of a daemon that is not there, whichever view is up: the
     * call is what the bus would start one on (see
     * g_paste_ui_history_on_daemon_presence ()). A search typed, a filter
     * toggled, a search bar emptying on its way out and a deferred app.search
     * all come through here, so this holds them all back at once; a daemon
     * turning up refreshes the list itself. What is dropped is what the
     * nameless history below drops, for the same reasons. */
    if (g_paste_client_get_daemon_presence (self->client) != G_PASTE_DAEMON_PRESENCE_READY)
    {
        g_paste_clear_cancellable (&self->display);
        self->loading = FALSE;
        self->filtering = FALSE;
        self->select_first = FALSE;

        return;
    }

    /* Both filters list uuids rather than positions, so they share a path. */
    if (self->search || self->favourites)
    {
        g_paste_ui_history_filter (self);
        return;
    }

    self->filtering = FALSE;
    self->select_first = FALSE;

    /* Sizing the history is the only call; its name is a cached property, and is
     * needed here only to tell the panel which row to update. That cache is
     * emptied whenever the daemon leaves the bus, which a re-exec on upgrade
     * does, and a nameless history is one we cannot report a length for. Keep
     * showing what is there; the daemon announces itself once it is back, and
     * that refresh finds the name again. */
    g_autofree gchar *name = g_paste_client_get_history_name (self->client);

    if (!name)
    {
        /* Still a refresh, so whatever was in flight is superseded by it and
         * must not land: the cancel is what display_callback_data_new () would
         * have done, and the only part of it that still applies. Without it a
         * search reply from before this call would pass the staleness check and
         * install its rows into a view that has moved on. No successor is
         * allocated to replace it, this refresh having no call to name with one.
         *
         * And nothing is in flight for us either, however the superseded call
         * ends -- it bails on that check without clearing the flag it set. Left
         * standing it would wedge lazy growth for good, the list refusing to
         * load another row however far it is scrolled. */
        g_paste_clear_cancellable (&self->display);
        self->loading = FALSE;

        return;
    }

    /* The refresh this one supersedes would have refetched from its own index
     * on, which its reply, dropped, now never does: this one takes over from
     * the earlier of the two. */
    if (self->loading)
        from_index = MIN (from_index, self->loading_from);

    self->loading = TRUE;
    self->loading_from = from_index;

    DisplayCallbackData *cdata = display_callback_data_new (self, from_index);

    cdata->name = g_steal_pointer (&name);

    g_paste_client_get_history_size (self->client, cdata->cancellable, g_paste_ui_history_refresh_history, cdata);
}

static void
on_retry_load_clicked (GtkButton *button G_GNUC_UNUSED,
                       gpointer   user_data)
{
    GPasteUiHistory *self = user_data;

    if (!self->client)
        return;

    /* A focused Retry hands the focus to the rows through
     * g_paste_ui_history_show_list (), the page it is on holding it. */
    g_paste_ui_history_show_starting (self);
    g_paste_ui_history_refresh (self, 0);
}

static gboolean
g_paste_ui_history_can_grow (GPasteUiHistory *self)
{
    /* size is MIN (available, limit), so there is more to load iff the history
     * holds more items than our current display limit. */
    return self->client && !self->search && !self->favourites && !self->loading && self->available > self->limit;
}

static void
g_paste_ui_history_grow (GPasteUiHistory *self)
{
    self->limit += g_paste_ui_history_batch (self);
    g_paste_ui_history_refresh (self, self->size);
}

/* While the loaded items do not yet overflow the viewport, keep loading more so
 * the view always offers something to scroll to when further items exist. The
 * vertical adjustment emits "changed" when its content or viewport is resized. */
static void
g_paste_ui_history_on_adjustment_changed (GtkAdjustment *adjustment,
                                          gpointer       user_data)
{
    GPasteUiHistory *self = user_data;
    gdouble page = gtk_adjustment_get_page_size (adjustment);
    gdouble upper = gtk_adjustment_get_upper (adjustment);

    /* The list view owns the rows, so ask the laid-out content how tall one is
     * rather than measuring a widget we do not hold: upper covers every row in
     * the model, extrapolated from the ones actually realised -- once they
     * overflow the viewport, upper being the page itself until then, which
     * would make one row as tall as the window and a batch two rows. */
    if (upper > page && self->size)
        self->item_height = MAX (1, (gint32) (upper / self->size));

    /* Cap eager filling assuming a sane minimum row height, so zero/near-zero
     * height rows can't keep upper <= page forever and load the whole history. */
    guint64 max_fill = (guint64) (page / G_PASTE_UI_HISTORY_MIN_ROW_HEIGHT) + 2;

    /* page <= 0 means the viewport is not allocated yet. */
    if (page > 0 && upper <= page &&
        self->size < max_fill && g_paste_ui_history_can_grow (self))
        g_paste_ui_history_grow (self);
}

/* Once the items overflow the viewport, load another batch each time the user
 * scrolls to the bottom, lazily pulling in the rest of the history on demand. */
static void
g_paste_ui_history_on_edge_reached (GtkScrolledWindow *scroll G_GNUC_UNUSED,
                                    GtkPositionType    pos,
                                    gpointer           user_data)
{
    GPasteUiHistory *self = user_data;

    if (pos == GTK_POS_BOTTOM && g_paste_ui_history_can_grow (self))
        g_paste_ui_history_grow (self);
}

/* The reply to whichever call g_paste_ui_history_filter made: both answer the
 * same list of items, so only the filtering left to do here differs. */
static void
on_filter_ready (GObject      *source_object G_GNUC_UNUSED,
                 GAsyncResult *res,
                 gpointer      user_data)
{
    g_autoptr (DisplayCallbackData) cdata = user_data;
    GPasteUiHistory *self = cdata->self;

    /* Only meaningful because cdata holds a ref: dispose clears the client, so a
     * NULL one means we were disposed mid-flight. */
    if (!self->client)
        return;

    /* A newer search or refresh already owns these rows. Without this, typing
     * "a" then "ab" leaves whichever reply happens to land last on screen. */
    if (g_cancellable_is_cancelled (cdata->cancellable))
        return;

    gboolean select_first = self->select_first;

    self->filtering = FALSE;
    self->select_first = FALSE;

    g_autoptr (GError) error = NULL;
    g_autolist (GPasteClientItem) items = (cdata->searched)
        ? g_paste_client_search_finish (self->client, res, &error)
        : g_paste_client_get_favourites_finish (self->client, res, &error);

    /* Its daemon gone, no answer that nothing matched: the page stays as it is
     * until the presence lists again (g_paste_client_is_daemon_gone_error ();
     * /ui/daemon-presence/listing-daemon-gone). Any other failure reads as no
     * match: the daemon answered, and what it said was not a list. */
    if (g_paste_client_is_daemon_gone_error (error))
        return;

    g_autoptr (GStrvBuilder) uuids = g_strv_builder_new ();

    for (const GList *i = items; i; i = i->next)
    {
        /* Only the matches of a search need sifting here: the favourites on
         * their own were asked for as such and arrive pinned. */
        if (self->favourites && cdata->searched && !g_paste_client_item_is_favourite (i->data))
            continue;

        g_strv_builder_add (uuids, g_paste_client_item_get_uuid (i->data));
    }

    g_auto (GStrv) results = g_strv_builder_end (uuids);

    self->size = g_strv_length (results);

    /* No lazy growth to stage here: the view realises only the rows on screen,
     * so every match can be listed and each fetches its own content on demand. */
    g_paste_ui_history_model_set_uuids (self->model, (const gchar * const *) results);

    if (self->size)
        g_paste_ui_history_show_list (self);
    else if (cdata->searched)
    {
        g_paste_ui_history_show_answer (self, "edit-find-symbolic", _("No Results"),
                                        _("Try a different search."));
    }
    else
    {
        g_paste_ui_history_show_answer (self, "non-starred-symbolic", _("No Pinned Items"),
                                        _("Pin an item to keep it out of reach of the size and memory limits."));
    }

    if (select_first && self->size)
        g_paste_ui_history_activate_position (self, 0);
}

/* List by uuid rather than by position: a search asks the daemon to match, the
 * favourites filter asks it for the pinned items, and with both on the matches
 * are sifted for the flag they carry. */
static void
g_paste_ui_history_filter (GPasteUiHistory *self)
{
    DisplayCallbackData *cdata = display_callback_data_new (self, 0);

    /* This supersedes any positional refresh in flight, and that one now bails
     * before clearing the flag it set. Nothing here grows lazily, so taking the
     * flag down is the whole of the handover. Enter's first match stays asked
     * for: an update listing the same search again answers it as well, and a
     * search of its own takes it down (g_paste_ui_history_search ()). */
    self->loading = FALSE;
    self->filtering = TRUE;

    cdata->searched = (self->search != NULL);

    /* What is typed is text, and Search takes a regular expression: escaped,
     * as Search in org.gnome.GPaste3.xml asks of a front end. '(' would not
     * compile otherwise, and '.' would match what was not typed. */
    if (cdata->searched)
    {
        g_autofree gchar *pattern = g_regex_escape_string (self->search, -1);

        g_paste_client_search (self->client, pattern, cdata->cancellable, on_filter_ready, cdata);
    }
    else
        g_paste_client_get_favourites (self->client, cdata->cancellable, on_filter_ready, cdata);
}

/**
 * g_paste_ui_history_search:
 * @self: a #GPasteUiHistory instance
 * @search: the search
 *
 * Apply a search to the history list
 */
void
g_paste_ui_history_search (GPasteUiHistory *self,
                           const gchar     *search)
{
    g_return_if_fail (G_PASTE_IS_UI_HISTORY (self));

    if (!self->client)
        return;

    /* The same search again while its listing is out -- the search entry's
     * delay running out after Enter applied it (g_paste_ui_history_select_first
     * ()) -- leaves that listing be: it answers this one too, and Enter waits
     * on it. */
    if (self->filtering && g_paste_str_equal ((search && *search) ? search : NULL, self->search))
        return;

    if (g_paste_str_equal (search, ""))
        g_clear_pointer (&self->search, g_free);
    else
        g_set_str (&self->search, search);

    /* Enter's first match, asked of the search this replaces, is not to be
     * taken from this one. */
    self->select_first = FALSE;
    g_paste_ui_history_refresh (self, 0);
}

static void
g_paste_ui_history_clear_display (GPasteUiHistory *self,
                                  gboolean         waiting)
{
    /* Hiding the list takes the focus off it, leaving the window with none,
     * and nothing would give it back: Enter would no longer paste the top
     * item. So whether it had it is noted first, and it is handed back once
     * the list shows rows again (g_paste_ui_history_show_list ()), however
     * many presence changes come in between. */
    GtkRoot *root = gtk_widget_get_root (GTK_WIDGET (self));
    GtkWidget *focus = (root) ? gtk_root_get_focus (root) : NULL;

    if (focus && gtk_widget_is_ancestor (focus, GTK_WIDGET (self)))
        self->refocus = TRUE;

    g_paste_clear_cancellable (&self->display);
    self->loading = FALSE;
    self->size = 0;
    self->available = 0;
    g_paste_ui_history_model_set_size (self->model, 0);

    /* An Enter waiting on the search given up here goes with it, as the
     * refresh of a daemon not there drops it: the listing answers at its
     * cancelled check, which leaves both flags to whoever clears them, and the
     * next daemon's first listing of that search would select its first match
     * -- replacing the clipboard, and with close-on-select closing the window.
     * Whether the listing fails before the presence edge cancels it is the
     * bus's ordering, which /ui/daemon-presence/search-enter-restart cannot
     * choose; this makes the order not matter. */
    self->filtering = FALSE;
    self->select_first = FALSE;

    /* The banner says why a daemon is unavailable. */
    if (waiting)
        g_paste_ui_history_show_starting (self);
    else
        g_paste_ui_history_show_status (self, G_PASTE_ICON_NAME "-symbolic", _("History Unavailable"), NULL);
}

/* A daemon that is there is listed afresh: it announces itself rather than
 * replaying the updates that filled the old rows. One that is not is shown no
 * rows at all -- a bound row asks for its item, which could bus-activate a
 * daemon the user just stopped. */
static void
g_paste_ui_history_on_daemon_presence (GPasteClient *client,
                                       GParamSpec   *pspec G_GNUC_UNUSED,
                                       gpointer      user_data)
{
    GPasteUiHistory *self = user_data;
    GPasteDaemonPresence presence = g_paste_client_get_daemon_presence (client);

    if (presence == G_PASTE_DAEMON_PRESENCE_READY)
        g_paste_ui_history_refresh (self, 0);
    else
        g_paste_ui_history_clear_display (self, presence == G_PASTE_DAEMON_PRESENCE_STARTING);
}

/**
 * g_paste_ui_history_set_favourites:
 * @self: a #GPasteUiHistory instance
 * @favourites: whether to list only the pinned items
 *
 * Show only the pinned items, or the whole history again
 */
void
g_paste_ui_history_set_favourites (GPasteUiHistory *self,
                                   gboolean         favourites)
{
    g_return_if_fail (G_PASTE_IS_UI_HISTORY (self));

    if (self->favourites == favourites)
        return;

    self->favourites = favourites;

    g_paste_ui_history_refresh (self, 0);
}

static void
g_paste_ui_history_select_uuid (GPasteUiHistory *self,
                                const gchar     *uuid)
{
    g_paste_client_select (self->client, uuid,
                           NULL /* cancellable */,
                           g_paste_ui_report_void_cb,
                           g_paste_ui_report_void (GTK_WIDGET (self), g_paste_client_select_finish,
                                                   _("Could not select the item")));

    /* Reached from a reply too (on_activate_element_ready ()), which the
     * window may not have waited for. */
    if (g_paste_settings_get_close_on_select (self->settings) && self->rootwin)
        gtk_window_close (self->rootwin); /* Exit the application */
}

static void
on_activate_element_ready (GObject      *source_object G_GNUC_UNUSED,
                           GAsyncResult *res,
                           gpointer      user_data)
{
    g_autoptr (GPasteUiHistory) self = user_data;

    if (!self->client)
        return;

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClientItem) item = g_paste_client_get_item_at_index_finish (self->client, res, &error);

    /* The activation simply does not happen otherwise, which is worth a word:
     * the user pressed a row and nothing at all moved. */
    if (!item)
    {
        g_warning ("Could not get the item to activate: %s", (error) ? error->message : "the daemon answered with no usable item");
        g_paste_gtk_util_toast (GTK_WIDGET (self), _("Could not select the item"));
        return;
    }

    g_paste_ui_history_select_uuid (self, g_paste_client_item_get_uuid (item));
}

/* Rows are only realised while they are on screen, so the item to activate may
 * have no widget to ask, or one whose fetch has not landed: for a search row the
 * model still holds its uuid, and a positional one is at the index it sits at,
 * which is a round trip away. That holds past the rows loaded so far too, as far
 * as the history goes, which is where Ctrl+9 reaches in a short window.
 *
 * In selection mode, activating picks, as a click does: what the row would
 * paste is not what the mode is for. */
static gboolean
g_paste_ui_history_activate_position (GPasteUiHistory *self,
                                      guint64          position)
{
    if (!self->client)
        return FALSE;

    GPasteUiHistoryItem *item = g_paste_ui_history_model_peek (self->model, position);

    if (self->selection_mode)
    {
        if (!item || !self->selection_model)
            return FALSE;

        g_paste_ui_history_toggle_pick (self, (guint) position);

        return TRUE;
    }

    gboolean positional = !self->search && !self->favourites;

    if (!item && !(positional && position < self->available))
        return FALSE;

    GtkWidget *widget = (item) ? g_paste_ui_history_item_get_widget (item) : NULL;

    if (widget && g_paste_ui_item_activate (G_PASTE_UI_ITEM (widget)))
        return TRUE;

    const gchar *uuid = (item) ? g_paste_ui_history_item_get_uuid (item) : NULL;

    if (uuid)
        g_paste_ui_history_select_uuid (self, uuid);
    else
        g_paste_client_get_item_at_index (self->client, position, NULL /* cancellable */, on_activate_element_ready, g_object_ref (self));

    return TRUE;
}

/* The row's context menu is where its actions all are, so the keyboard needs a
 * way in. The shortcut cannot live on the row: what takes the focus is the
 * GtkListItem above it, so a local controller there would never see the key.
 * The list view does, and its focused child is the list item whose only child
 * is the row. */
static gboolean
on_context_menu (GtkWidget *widget,
                 GVariant  *args G_GNUC_UNUSED,
                 gpointer   user_data G_GNUC_UNUSED)
{
    GtkWidget *list_item = gtk_widget_get_focus_child (widget);

    if (!list_item)
        return FALSE;

    GtkWidget *row = gtk_widget_get_first_child (list_item);

    if (!G_PASTE_IS_UI_ITEM (row))
        return FALSE;

    g_paste_ui_item_popup_menu (G_PASTE_UI_ITEM (row));

    return TRUE;
}

static void
add_context_menu_shortcuts (GtkWidget *list_view)
{
    GtkEventController *shortcuts = gtk_shortcut_controller_new ();
    g_auto (GStrv) accelerators = g_strsplit (G_PASTE_UI_HISTORY_CONTEXT_MENU_ACCELERATORS, " ", -1);

    gtk_shortcut_controller_set_scope (GTK_SHORTCUT_CONTROLLER (shortcuts), GTK_SHORTCUT_SCOPE_LOCAL);

    for (GStrv accelerator = accelerators; *accelerator; ++accelerator)
    {
        guint keyval;
        GdkModifierType modifiers;

        if (!gtk_accelerator_parse (*accelerator, &keyval, &modifiers))
            g_return_if_reached ();

        GtkShortcutTrigger *trigger = gtk_keyval_trigger_new (keyval, modifiers);

        gtk_shortcut_controller_add_shortcut (GTK_SHORTCUT_CONTROLLER (shortcuts),
                                              gtk_shortcut_new (trigger,
                                                                gtk_callback_action_new (on_context_menu, NULL, NULL)));
    }

    gtk_widget_add_controller (list_view, shortcuts);
}

static void
on_item_activated (GtkListView *list_view G_GNUC_UNUSED,
                   guint        position,
                   gpointer     user_data)
{
    g_paste_ui_history_activate_position (user_data, position);
}

/**
 * g_paste_ui_history_select_first:
 * @self: a #GPasteUiHistory instance
 * @search: the search the first match is to be of
 *
 * Select the first match of @search, which is what Enter in the search asks
 * for: once that search is listed, rather than whatever the list shows the
 * moment the key is pressed -- the entry's delay may not have applied it yet,
 * or its listing may still be out.
 *
 * returns: whether anything was, or will be, selected
 */
gboolean
g_paste_ui_history_select_first (GPasteUiHistory *self,
                                 const gchar     *search)
{
    g_return_val_if_fail (G_PASTE_IS_UI_HISTORY (self), FALSE);
    g_return_val_if_fail (search, FALSE);

    /* Asked of the daemon again even when that search is what is listed: an
     * item edited out of the match stays listed until the search runs again
     * (a replaced item is only redrawn where it is), and the first match is
     * the daemon's to say, not the first row shown. One round trip on a key
     * press. */
    g_paste_ui_history_search (self, search);

    if (self->filtering)
    {
        self->select_first = TRUE;
        return TRUE;
    }

    return g_paste_ui_history_activate_position (self, 0);
}

/**
 * g_paste_ui_history_activate_index:
 * @self: a #GPasteUiHistory instance
 * @index: the position (0-based) of the item to activate
 *
 * Activate the item at @index of the history or the search listed -- read when
 * its row is not loaded yet, up to what the listing holds -- or, in selection
 * mode, pick it or leave it out.
 *
 * Returns: whether there is an item at @index
 */
gboolean
g_paste_ui_history_activate_index (GPasteUiHistory *self,
                                   guint64          index)
{
    g_return_val_if_fail (G_PASTE_IS_UI_HISTORY (self), FALSE);

    return g_paste_ui_history_activate_position (self, index);
}

static void
g_paste_ui_history_on_update (GPasteClient      *client G_GNUC_UNUSED,
                              GPasteUpdateAction action,
                              GPasteUpdateTarget target,
                              const gchar       *uuid,
                              guint64            position,
                              gpointer           user_data)
{
    GPasteUiHistory *self = user_data;
    gboolean refresh = FALSE;

    if (!self->client)
        return;

    switch (target)
    {
    case G_PASTE_UPDATE_TARGET_ALL:
        refresh = TRUE;
        break;
    case G_PASTE_UPDATE_TARGET_ITEM:
        switch (action)
        {
        case G_PASTE_UPDATE_ACTION_REPLACE:
            /* A named view lists uuids, so it finds the row by the one the
             * update carries; a positional one is at @position, which lazy
             * loading may put past the rows we hold at all (a password renamed
             * deep in the history, say). The model shrugs off both: it only
             * reports what it has.
             *
             * The favourites view is the exception, and pinning is the very
             * change that reaches it: whether a row still belongs in a list of
             * pinned items is exactly what just changed, and the update says
             * which item, not what became of its flag. So it asks again --
             * cheaply, the daemon answering the pinned items alone. */
            if (self->favourites)
                refresh = TRUE;
            else if (self->search)
                g_paste_ui_history_model_item_replaced_by_uuid (self->model, uuid);
            else
                g_paste_ui_history_model_item_replaced (self->model, position);
            break;
        case G_PASTE_UPDATE_ACTION_REMOVE:
            refresh = TRUE;
            break;
        default:
            g_assert_not_reached ();
        }
        break;
    default:
        g_assert_not_reached ();
    }

    if (refresh)
        g_paste_ui_history_refresh (self, position);
}

/* A row picked for a merge: where it sits, and the uuid of what it showed when
 * it was picked, or %NULL for a row that showed nothing yet -- its read not
 * back, or never on screen, as select-all reaches -- which the merge reads by
 * its position. */
typedef struct
{
    guint  position;
    gchar *uuid;
} Pick;

static void
pick_clear (gpointer data)
{
    g_free (((Pick *) data)->uuid);
}

/* Where @position sits in the pick order, or -1 when it is not picked. */
static gint
g_paste_ui_history_picked_at (GPasteUiHistory *self,
                              guint            position)
{
    for (guint i = 0; i < self->selection->len; ++i)
    {
        if (g_array_index (self->selection, Pick, i).position == position)
            return (gint) i;
    }

    return -1;
}

/* Keep the picks in step with the selection model's own bitset, which
 * #GtkMultiSelection splices on every items-changed: what the splice removed
 * loses its bit, and what sat after it moves by the difference. The picks name
 * the same rows, in the order they were picked, so they are spliced the same
 * way -- otherwise a merge acts on whatever slid into the remembered positions,
 * or on a row that is no longer there at all.
 *
 * The order the picks are held in is the order they were made in, which the
 * merge depends on, so they are edited in place rather than rebuilt. */
static void
on_selection_items_changed (GListModel *model G_GNUC_UNUSED,
                            guint       position,
                            guint       removed,
                            guint       added,
                            gpointer    user_data)
{
    GPasteUiHistory *self = user_data;

    if (!removed && !added)
        return;

    gboolean dropped = FALSE;

    for (guint i = self->selection->len; i > 0; --i)
    {
        Pick *picked = &g_array_index (self->selection, Pick, i - 1);

        if (picked->position < position)
            continue;

        if (picked->position < position + removed)
        {
            g_array_remove_index (self->selection, i - 1);
            dropped = TRUE;
        }
        else
            picked->position += added - removed;
    }

    if (dropped)
        g_signal_emit (self, signals[SELECTION_CHANGED], 0, self->selection->len);
}

/* Rows that kept their place but show something else: a history that is being
 * watched changes under the picking whenever the clipboard does. Each bound
 * row reads its item again where it stands, keeping its widget and with it the
 * keyboard focus, and what was picked there is no longer what the row shows,
 * so the pick goes -- unselected, which on_selection_changed () drops from the
 * picks in the same pass, rather than leaving Merge holding rows the list no
 * longer shows as picked. */
static void
on_rows_invalidated (GPasteUiHistoryModel *model,
                     guint64               position,
                     guint64               n_items,
                     gpointer              user_data)
{
    GPasteUiHistory *self = user_data;

    for (guint64 i = position; i < position + n_items; ++i)
    {
        GPasteUiHistoryItem *item = g_paste_ui_history_model_peek (model, i);
        GtkWidget *widget = g_paste_ui_history_item_get_widget (item);
        const gchar *uuid = g_paste_ui_history_item_get_uuid (item);

        if (!widget)
            continue;

        if (uuid)
            g_paste_ui_item_set_uuid (G_PASTE_UI_ITEM (widget), uuid);
        else
            g_paste_ui_item_set_index (G_PASTE_UI_ITEM (widget), i);
    }

    if (self->selection_mode && self->selection_model)
        gtk_selection_model_unselect_range (self->selection_model, (guint) position, (guint) n_items);
}

/* The uuid of what the row at @position shows, or %NULL when it shows nothing
 * yet: a search row's is in the model, and a positional one's is the one its
 * read brought, which a row not bound or not read yet does not have -- nor
 * does one being read again where it stands, which is about to show what its
 * position then holds (on_rows_invalidated ()). */
static const gchar *
g_paste_ui_history_shown_uuid (GPasteUiHistory *self,
                               guint            position)
{
    GPasteUiHistoryItem *item = g_paste_ui_history_model_peek (self->model, position);
    const gchar *uuid = (item) ? g_paste_ui_history_item_get_uuid (item) : NULL;
    GtkWidget *widget = (item) ? g_paste_ui_history_item_get_widget (item) : NULL;

    if (uuid || !widget || !g_paste_ui_item_is_read (G_PASTE_UI_ITEM (widget)))
        return uuid;

    return g_paste_ui_item_get_uuid (G_PASTE_UI_ITEM (widget));
}

/* The selection model tracks which positions are picked; the merge wants them in
 * the order they were picked, which a #GtkBitset cannot express. So mirror each
 * change into @selection, which keeps that order.
 *
 * With the uuid of what each row showed as it was picked: the history may move
 * under the picks before the refresh that would drop them lands, and the merge
 * is of what the user picked, not of whatever sits at those positions then. */
static void
on_selection_changed (GtkSelectionModel *model,
                      guint              position,
                      guint              n_items,
                      gpointer           user_data)
{
    GPasteUiHistory *self = user_data;

    for (guint i = position; i < position + n_items; ++i)
    {
        gint at = g_paste_ui_history_picked_at (self, i);

        if (gtk_selection_model_is_selected (model, i))
        {
            if (at < 0)
            {
                Pick pick = { i, g_strdup (g_paste_ui_history_shown_uuid (self, i)) };

                g_array_append_val (self->selection, pick);
            }
        }
        else if (at >= 0)
            g_array_remove_index (self->selection, at);
    }

    g_signal_emit (self, signals[SELECTION_CHANGED], 0, self->selection->len);
}

/**
 * g_paste_ui_history_get_selection_mode:
 * @self: a #GPasteUiHistory instance
 *
 * Returns: whether the merge selection mode is on
 */
gboolean
g_paste_ui_history_get_selection_mode (GPasteUiHistory *self)
{
    g_return_val_if_fail (G_PASTE_IS_UI_HISTORY (self), FALSE);

    return self->selection_mode;
}

/**
 * g_paste_ui_history_set_selection_mode:
 * @self: a #GPasteUiHistory instance
 * @selection_mode: whether to enter the multi-selection "merge" mode
 *
 * Toggle the merge selection mode: rows become multi-selectable (and stop
 * activating/pasting on click) so several entries can be picked for merging.
 */
void
g_paste_ui_history_set_selection_mode (GPasteUiHistory *self,
                                       gboolean         selection_mode)
{
    g_return_if_fail (G_PASTE_IS_UI_HISTORY (self));

    gboolean changed = (self->selection_mode != selection_mode);

    self->selection_mode = selection_mode;
    /* Selectability is the selection model's to grant
     * (gpaste-ui-pick-selection.c), and what was picked goes either way. */
    g_paste_ui_pick_selection_set_picking (G_PASTE_UI_PICK_SELECTION (self->selection_model), selection_mode);
    g_array_set_size (self->selection, 0);

    /* Clicking picks rather than pastes while picking. */
    gtk_list_view_set_single_click_activate (self->list_view, !selection_mode);

    g_signal_emit (self, signals[SELECTION_CHANGED], 0, 0u);

    if (changed)
        g_object_notify_by_pspec (G_OBJECT (self), properties[PROP_SELECTION_MODE]);
}

/* A pick no row could fill: its slot among the uuids, and the position it is
 * read by. */
typedef struct
{
    guint   slot;
    guint64 position;
} ResolutionRead;

/* What resolving the picks waits on: one slot per pick, in pick order, the ones
 * a pick could not fill read by their position, one after the other. Each read
 * brings an item whole for its uuid alone, and a select-all over a long history
 * has hundreds of picks no row ever showed: in turn, what is out at any time is
 * one item, and a failed read, which fails the merge, leaves the rest unasked. */
typedef struct
{
    GPasteClient *client;
    GPtrArray    *uuids;
    GArray       *unread;
    guint         next;
} Resolution;

static void
resolution_free (Resolution *resolution)
{
    g_clear_object (&resolution->client);
    g_ptr_array_unref (resolution->uuids);
    g_array_unref (resolution->unread);
    g_free (resolution);
}

G_DEFINE_AUTOPTR_CLEANUP_FUNC (Resolution, resolution_free)

static void on_pick_read (GObject      *source_object,
                          GAsyncResult *res,
                          gpointer      user_data);

/* The next pick read, or the uuids once none is left. */
static void
resolution_read_next (GTask *task)
{
    Resolution *resolution = g_task_get_task_data (task);

    if (resolution->next < resolution->unread->len)
    {
        const ResolutionRead *read = &g_array_index (resolution->unread, ResolutionRead, resolution->next);

        g_paste_client_get_item_at_index (resolution->client, read->position, NULL /* cancellable */, on_pick_read, g_object_ref (task));
        return;
    }

    g_autoptr (GStrvBuilder) builder = g_strv_builder_new ();

    for (guint i = 0; i < resolution->uuids->len; ++i)
        g_strv_builder_add (builder, resolution->uuids->pdata[i]);

    g_task_return_pointer (task, g_strv_builder_end (builder), (GDestroyNotify) g_strfreev);
}

static void
on_pick_read (GObject      *source_object,
              GAsyncResult *res,
              gpointer      user_data)
{
    g_autoptr (GTask) task = user_data;
    Resolution *resolution = g_task_get_task_data (task);
    const ResolutionRead *read = &g_array_index (resolution->unread, ResolutionRead, resolution->next++);
    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClientItem) item = g_paste_client_get_item_at_index_finish (G_PASTE_CLIENT (source_object), res, &error);

    if (!item)
    {
        g_task_return_error (task, (error) ? g_steal_pointer (&error) : g_error_new_literal (G_PASTE_ERROR, G_PASTE_ERROR_FAILED, "the daemon answered with no usable item"));
        return;
    }

    g_set_str ((gchar **) &resolution->uuids->pdata[read->slot], g_paste_client_item_get_uuid (item));
    resolution_read_next (task);
}

/**
 * g_paste_ui_history_get_selected_uuids:
 * @self: a #GPasteUiHistory instance
 * @callback: called once the picks are resolved
 * @user_data: data for @callback
 *
 * Collect the uuids of the rows picked in merge mode, in the order they were
 * picked (so the merge keeps that order): each the uuid of what its row showed
 * as it was picked, and a row that showed nothing yet read by its position,
 * alone and one after the other.
 */
void
g_paste_ui_history_get_selected_uuids (GPasteUiHistory    *self,
                                       GAsyncReadyCallback callback,
                                       gpointer            user_data)
{
    g_return_if_fail (G_PASTE_IS_UI_HISTORY (self));

    g_autoptr (GTask) task = g_task_new (self, NULL, callback, user_data);
    Resolution *resolution = g_new0 (Resolution, 1);

    resolution->uuids = g_ptr_array_new_with_free_func (g_free);
    resolution->unread = g_array_new (FALSE, FALSE, sizeof (ResolutionRead));
    g_task_set_task_data (task, resolution, (GDestroyNotify) resolution_free);

    for (guint i = 0; i < self->selection->len; ++i)
    {
        Pick *pick = &g_array_index (self->selection, Pick, i);

        g_ptr_array_add (resolution->uuids, g_strdup (pick->uuid));

        if (!pick->uuid && self->client)
        {
            ResolutionRead read = { i, pick->position };

            g_array_append_val (resolution->unread, read);
        }
    }

    /* With no client, no pick was left to read. */
    resolution->client = (self->client) ? g_object_ref (self->client) : NULL;
    resolution_read_next (task);
}

/**
 * g_paste_ui_history_get_selected_uuids_finish:
 * @self: a #GPasteUiHistory instance
 * @result: the #GAsyncResult handed to the callback
 * @error: return location for a #GError, or %NULL
 *
 * Finish g_paste_ui_history_get_selected_uuids (). Fails with the
 * #GPasteClient domains when a row never shown could not be read.
 *
 * Returns: (transfer full): a %NULL-terminated array of uuids, or %NULL on
 *          failure
 */
GStrv
g_paste_ui_history_get_selected_uuids_finish (GPasteUiHistory *self,
                                              GAsyncResult    *result,
                                              GError         **error)
{
    g_return_val_if_fail (g_task_is_valid (result, self), NULL);

    return g_task_propagate_pointer (G_TASK (result), error);
}

static void
g_paste_ui_history_dispose (GObject *object)
{
    GPasteUiHistory *self = G_PASTE_UI_HISTORY (object);

    g_clear_pointer (&self->selection, g_array_unref);

    g_clear_pointer (&self->search, g_free);
    g_clear_object (&self->model);

    /* Cancelled before the client goes, so a listing still out is given up on
     * rather than left to land on a view that can no longer finish it. */
    g_paste_clear_cancellable (&self->display);

    g_clear_object (&self->client);
    g_clear_object (&self->settings);

    /* All borrowed but the panel and the window, which are weak (see their
     * fields), and chaining up destroys the children (and with them the
     * selection model). A callback that survives us checks the client above,
     * but g_paste_ui_history_refresh_history() also reaches for these, so leave
     * nothing behind that still looks alive. */
    g_clear_weak_pointer (&self->panel);
    g_clear_weak_pointer (&self->rootwin);
    self->status_page = NULL;
    self->retry_button = NULL;
    self->scroll = NULL;
    self->list_view = NULL;
    self->selection_model = NULL;

    G_OBJECT_CLASS (g_paste_ui_history_parent_class)->dispose (object);
}

static void
g_paste_ui_history_get_property (GObject    *object,
                                 guint       prop_id,
                                 GValue     *value,
                                 GParamSpec *pspec)
{
    GPasteUiHistory *self = G_PASTE_UI_HISTORY (object);

    switch (prop_id)
    {
    case PROP_SELECTION_MODE:
        g_value_set_boolean (value, self->selection_mode);
        break;
    default:
        G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
    }
}

static void
g_paste_ui_history_set_property (GObject      *object,
                                 guint         prop_id,
                                 const GValue *value,
                                 GParamSpec   *pspec)
{
    GPasteUiHistory *self = G_PASTE_UI_HISTORY (object);

    switch (prop_id)
    {
    case PROP_SELECTION_MODE:
        g_paste_ui_history_set_selection_mode (self, g_value_get_boolean (value));
        break;
    default:
        G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
    }
}

static void
g_paste_ui_history_class_init (GPasteUiHistoryClass *klass)
{
    GObjectClass *object_class = G_OBJECT_CLASS (klass);

    object_class->dispose = g_paste_ui_history_dispose;
    object_class->get_property = g_paste_ui_history_get_property;
    object_class->set_property = g_paste_ui_history_set_property;

    /**
     * GPasteUiHistory:selection-mode:
     *
     * Whether the merge selection mode is on: rows become multi-selectable and
     * stop pasting on click.
     *
     * G_PARAM_EXPLICIT_NOTIFY: the setter does the work and notifies only when
     * the mode actually flipped.
     */
    properties[PROP_SELECTION_MODE] = g_param_spec_boolean ("selection-mode", NULL, NULL, FALSE,
                                                            G_PARAM_READWRITE | G_PARAM_STATIC_STRINGS | G_PARAM_EXPLICIT_NOTIFY);

    g_object_class_install_properties (object_class, N_PROPERTIES, properties);

    signals[SELECTION_CHANGED] = g_signal_new ("selection-changed",
                                               G_PASTE_TYPE_UI_HISTORY,
                                               G_SIGNAL_RUN_LAST,
                                               0, /* class offset */
                                               NULL, /* accumulator */
                                               NULL, /* accumulator data */
                                               g_cclosure_marshal_VOID__UINT,
                                               G_TYPE_NONE,
                                               1,
                                               G_TYPE_UINT);
}

static void
g_paste_ui_history_init (GPasteUiHistory *self)
{
    self->selection = g_array_new (FALSE, FALSE, sizeof (Pick));
    g_array_set_clear_func (self->selection, pick_clear);
    self->model = g_paste_ui_history_model_new ();
    g_signal_connect (self->model, "invalidated", G_CALLBACK (on_rows_invalidated), self);
}

/**
 * g_paste_ui_history_new:
 * @client: a #GPasteClient instance
 * @settings: a #GPasteSettings instance
 * @panel: the #GPasteUiPanel
 * @rootwin: the root #GtkWindow
 *
 * Create a new #GPasteUiHistory for GPaste history
 *
 * Returns: a newly allocated #GPasteUiHistory
 *          free it with g_object_unref
 */
GtkWidget *
g_paste_ui_history_new (GPasteClient   *client,
                        GPasteSettings *settings,
                        GPasteUiPanel  *panel,
                        GtkWindow      *rootwin)
{
    g_return_val_if_fail (G_PASTE_IS_CLIENT (client), NULL);
    g_return_val_if_fail (G_PASTE_IS_SETTINGS (settings), NULL);
    g_return_val_if_fail (G_PASTE_IS_UI_PANEL (panel), NULL);
    g_return_val_if_fail (GTK_IS_WINDOW (rootwin), NULL);

    GtkWidget *widget = g_object_new (G_PASTE_TYPE_UI_HISTORY,
                                      "orientation", GTK_ORIENTATION_VERTICAL,
                                      NULL);
    GPasteUiHistory *self = G_PASTE_UI_HISTORY (widget);
    GtkBox *box = GTK_BOX (self);

    self->client = g_object_ref (client);
    self->settings = g_object_ref (settings);
    g_set_weak_pointer (&self->panel, panel);
    g_set_weak_pointer (&self->rootwin, rootwin);
    self->limit = G_PASTE_UI_HISTORY_DEFAULT_BATCH;

    GtkWidget *status_page = adw_status_page_new ();
    self->status_page = ADW_STATUS_PAGE (status_page);
    GtkWidget *retry_button = gtk_button_new_with_label (_("Retry"));

    self->retry_button = retry_button;
    gtk_widget_set_halign (retry_button, GTK_ALIGN_CENTER);
    gtk_widget_add_css_class (retry_button, "suggested-action");
    adw_status_page_set_child (self->status_page, retry_button);
    g_signal_connect_object (retry_button, "clicked", G_CALLBACK (on_retry_load_clicked), self, 0);
    gtk_widget_set_hexpand (status_page, TRUE);
    gtk_widget_set_vexpand (status_page, TRUE);
    gtk_box_append (box, status_page);

    GtkListItemFactory *factory = gtk_signal_list_item_factory_new ();
    g_signal_connect_object (factory, "setup", G_CALLBACK (g_paste_ui_history_setup_item), self, 0);
    g_signal_connect_object (factory, "bind", G_CALLBACK (g_paste_ui_history_bind_item), self, 0);
    g_signal_connect_object (factory, "unbind", G_CALLBACK (g_paste_ui_history_unbind_item), self, 0);

    self->selection_model = GTK_SELECTION_MODEL (g_paste_ui_pick_selection_new (G_LIST_MODEL (self->model)));
    g_signal_connect_object (self->selection_model, "selection-changed", G_CALLBACK (on_selection_changed), self, 0);
    /* The picks are positions, so a splice moves what they name. */
    g_signal_connect_object (self->selection_model, "items-changed", G_CALLBACK (on_selection_items_changed), self, 0);

    GtkWidget *list_view = gtk_list_view_new (self->selection_model, factory);
    self->list_view = GTK_LIST_VIEW (list_view);

    GtkWidget *scroll = gtk_scrolled_window_new ();
    self->scroll = GTK_SCROLLED_WINDOW (scroll);
    gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scroll), GTK_POLICY_NEVER, GTK_POLICY_AUTOMATIC);
    gtk_widget_set_hexpand (scroll, TRUE);
    gtk_widget_set_vexpand (scroll, TRUE);
    gtk_widget_set_halign (scroll, GTK_ALIGN_FILL);
    gtk_widget_set_valign (scroll, GTK_ALIGN_FILL);
    gtk_scrolled_window_set_child (GTK_SCROLLED_WINDOW (scroll), list_view);
    gtk_box_append (box, scroll);

    /* Both children are in place, so the empty state can be what the list is
     * shown in until the first size answer says otherwise. */
    g_paste_ui_history_show_empty (self);

    GtkAdjustment *vadjustment = gtk_scrolled_window_get_vadjustment (GTK_SCROLLED_WINDOW (scroll));
    g_signal_connect_object (vadjustment, "changed", G_CALLBACK (g_paste_ui_history_on_adjustment_changed), self, 0);
    g_signal_connect_object (scroll, "edge-reached", G_CALLBACK (g_paste_ui_history_on_edge_reached), self, 0);

    add_context_menu_shortcuts (list_view);

    g_signal_connect_object (list_view, "activate", G_CALLBACK (on_item_activated), self, 0);
    g_signal_connect (list_view, "map", G_CALLBACK (on_list_view_mapped), NULL);

    g_paste_ui_history_set_selection_mode (self, FALSE);

    g_signal_connect_object (client,
                             "update",
                             G_CALLBACK (g_paste_ui_history_on_update),
                             self, 0);
    g_signal_connect_object (client,
                             "notify::daemon-presence",
                             G_CALLBACK (g_paste_ui_history_on_daemon_presence),
                             self, 0);

    g_paste_ui_history_on_daemon_presence (client, NULL, self);

    return widget;
}
