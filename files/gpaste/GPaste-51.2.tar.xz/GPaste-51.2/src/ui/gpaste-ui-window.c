// SPDX-FileCopyrightText: 2010-2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com>
// SPDX-License-Identifier: BSD-2-Clause

#include <gpaste-gtk4/gpaste-gtk-preferences-dialog.h>
#include <gpaste-gtk4/gpaste-gtk-util.h>

#include <gpaste-ui-header.h>
#include <gpaste-ui-history.h>
#include <gpaste-ui-new-item.h>
#include <gpaste-ui-password-dialog.h>
#include <gpaste-ui-window.h>
#include <gpaste-ui-shortcuts-window.h>

#include <string.h>

/* G_PASTE_KEYBINDER_REBIND_DELAY, the delay the daemon coalesces a rebind burst
 * over: a close is coalesced over that same burst (on_shortcuts_obsolete ()). */
#define G_PASTE_UI_WINDOW_SHORTCUTS_CLOSE_DELAY 250 /* ms */

/* Below this width the two panes become two pages the user navigates between.
 * Uncollapsed, the sidebar's 240 and the history page's header need about 653
 * with minimize, maximize and close (the wide layouts g_paste_ui_window_init ()
 * sizes the minimum for), so the panes collapse before they would overflow,
 * with room to spare. Both in px and in sp, whichever is wider: the text scale
 * widens the sidebar, which libadwaita sizes in sp, and the header's labels
 * with it, so above 1 (Large Text) a breakpoint in px would let the band above
 * it overflow; below 1, the window's buttons and the header's icons, sized in
 * px, do not shrink with the text, and a breakpoint in sp would.
 * /ui/daemon-presence/collapse-width checks both sides of it, at text scales
 * below and above 1. */
#define G_PASTE_UI_WINDOW_COLLAPSE_WIDTH 680

struct _GPasteUiWindow
{
    AdwApplicationWindow parent_instance;

    AdwHeaderBar           *header;
    GPasteUiHistory        *history;
    GtkWidget              *panel;
    GPasteClient           *client;
    GPasteSettings         *settings;

    AdwNavigationSplitView *split_view;
    GtkSearchBar           *search_bar;
    GtkSearchEntry         *search_entry;
    GtkBox                 *content_box;
    AdwToastOverlay        *toast_overlay;
    AdwBanner              *banner;
    /* Weak, the overlay owning it: the offer to restart a daemon older than
     * the window (g_paste_ui_window_update_version_toast ()), made once for
     * each daemon. */
    AdwToast               *version_toast;
    gboolean                version_offered;
    /* A NULL owner can mean either no Shell or a watch awaiting its first
     * answer; only the latter withholds the restart offer. */
    guint                   shell_watch;
    gchar                  *shell_owner;
    gboolean                shell_owner_known;

    GtkActionBar           *merge_bar;
    GtkWidget              *merge_button;
    GtkWidget              *merge_entry; /* custom separator */

    /* All three weak: the dialog belongs to whatever is presenting it, and we
     * only keep it to raise the one already up rather than stack a second. */
    AdwDialog              *shortcuts;
    AdwDialog              *preferences;
    AdwDialog              *about;
    /* Takes down a shortcuts dialog the settings have moved on from. */
    guint                   shortcuts_source;

    GSignalGroup           *search_signals;
    GSignalGroup           *client_signals;

    gboolean                initialized;
    /* Actions asked for before the daemon connection concluded, run in order
     * once it has. */
    GSList                 *deferred;

    /* Whether a g_paste_client_new () is still on its way: until it lands
     * there is no client to follow the daemon (see
     * g_paste_client_follow_daemon ()). */
    gboolean                connecting;

    /* Whether the daemon owning the name is a GPaste 45 or 50, and the
     * question out to find out: see g_paste_ui_window_probe_legacy (). */
    gboolean                legacy;
    GCancellable           *legacy_probe;
    /* A restart of that daemon is out: see on_banner_retry (). */
    gboolean                legacy_restarting;
};

G_PASTE_DEFINE_TYPE (UiWindow, ui_window, ADW_TYPE_APPLICATION_WINDOW)

/* An action the application can be asked to perform before the window has
 * finished connecting to the daemon: held until it has, and run in the order
 * they were asked for. @arg is owned, and NULL for the ones that take none;
 * @needs_client says whether the action has anything to act on when the
 * connection concluded without one. */
typedef struct
{
    gchar   *arg;
    void   (*run) (GPasteUiWindow *self,
                   const gchar    *arg);
    gboolean needs_client;
} DeferredAction;

static void
deferred_action_free (gpointer user_data)
{
    DeferredAction *deferred = user_data;

    g_free (deferred->arg);
    g_free (deferred);
}

G_DEFINE_AUTOPTR_CLEANUP_FUNC (DeferredAction, deferred_action_free)

/* Run what was asked for before the connection concluded, and forget it either
 * way. Concluded without a client means it failed, and the banner is saying so;
 * the actions that would have talked to the daemon are skipped, and the ones
 * that would not -- About, which is the application's own, and the preferences,
 * which are GSettings -- still run: they are exactly what is still worth
 * showing when there is no daemon to reach.
 *
 * Called from wherever @initialized is set, rather than waited for from an idle:
 * an idle that returns G_SOURCE_CONTINUE until a condition holds is dispatched
 * again immediately, which spins a core for as long as the connection takes --
 * and that is longest exactly when the daemon has to be bus-activated, which is
 * the case this whole path exists for. */
static void
g_paste_ui_window_run_deferred_actions (GPasteUiWindow *self)
{
    g_autoslist (DeferredAction) deferred = g_steal_pointer (&self->deferred);

    for (GSList *d = deferred; d; d = d->next)
    {
        DeferredAction *action = d->data;

        if (action->needs_client && !self->client)
            continue;

        action->run (self, action->arg);
    }
}

static void
run_when_initialized (GPasteUiWindow *self,
                      void          (*run) (GPasteUiWindow *self, const gchar *arg),
                      const gchar    *arg,
                      gboolean        needs_client)
{
    DeferredAction *deferred = g_new (DeferredAction, 1);

    deferred->arg = g_strdup (arg);
    deferred->run = run;
    deferred->needs_client = needs_client;

    self->deferred = g_slist_append (self->deferred, deferred);

    if (self->initialized)
        g_paste_ui_window_run_deferred_actions (self);
}

/* @window is owned, so a call outliving nothing in particular still has
 * somewhere to report to; @message is a translated literal and is not. */
typedef struct
{
    GPasteUiWindow      *window;
    const gchar         *message;
    GPasteUiVoidFinish   void_finish;
    GPasteUiStringFinish string_finish;
} GPasteUiReport;

static gpointer
report_new (GtkWidget   *origin,
            const gchar *message)
{
    GtkRoot *root = gtk_widget_get_root (origin);
    GPasteUiReport *report = g_new0 (GPasteUiReport, 1);

    /* A row is only ever in a window of ours, but it is asked rather than
     * assumed: the reply still has to be finished either way. */
    if (G_PASTE_IS_UI_WINDOW (root))
        report->window = g_object_ref (G_PASTE_UI_WINDOW (root));

    report->message = message;

    return report;
}

static void
report_done (GPasteUiReport *report,
             const GError   *error)
{
    if (error)
    {
        g_warning ("%s: %s", report->message, error->message);

        if (report->window)
            g_paste_gtk_util_toast (GTK_WIDGET (report->window), report->message);
    }

    g_clear_object (&report->window);
    g_free (report);
}

/**
 * g_paste_ui_report_void:
 * @origin: any widget inside the window to report through
 * @finish: the call's _finish ()
 * @message: what to say should the call have failed
 *
 * Returns: (transfer full): the user_data to pass alongside
 *          g_paste_ui_report_void_cb ()
 */
gpointer
g_paste_ui_report_void (GtkWidget         *origin,
                        GPasteUiVoidFinish finish,
                        const gchar       *message)
{
    GPasteUiReport *report = report_new (origin, message);

    report->void_finish = finish;

    return report;
}

/**
 * g_paste_ui_report_string:
 * @origin: any widget inside the window to report through
 * @finish: the call's _finish ()
 * @message: what to say should the call have failed
 *
 * Returns: (transfer full): the user_data to pass alongside
 *          g_paste_ui_report_string_cb ()
 */
gpointer
g_paste_ui_report_string (GtkWidget           *origin,
                          GPasteUiStringFinish finish,
                          const gchar         *message)
{
    GPasteUiReport *report = report_new (origin, message);

    report->string_finish = finish;

    return report;
}

void
g_paste_ui_set_icon_button_label (GtkWidget   *button,
                                  const gchar *label)
{
    gtk_widget_set_tooltip_text (button, label);
    gtk_accessible_update_property (GTK_ACCESSIBLE (button), GTK_ACCESSIBLE_PROPERTY_LABEL, label, -1);
}

/**
 * g_paste_ui_report_void_cb:
 * @source_object: the #GPasteClient the call was made on
 * @result: the #GAsyncResult handed to the callback
 * @user_data: what g_paste_ui_report_void () returned
 *
 * Finish a call whose only interesting outcome is whether it failed.
 */
void
g_paste_ui_report_void_cb (GObject      *source_object,
                           GAsyncResult *result,
                           gpointer      user_data)
{
    GPasteUiReport *report = user_data;
    g_autoptr (GError) error = NULL;

    report->void_finish (G_PASTE_CLIENT (source_object), result, &error);
    report_done (report, error);
}

/**
 * g_paste_ui_report_string_cb:
 * @source_object: the #GPasteClient the call was made on
 * @result: the #GAsyncResult handed to the callback
 * @user_data: what g_paste_ui_report_string () returned
 *
 * Finish a call answering the uuid it created, which nothing here wants: the
 * item it stands for arrives as an update of its own.
 */
void
g_paste_ui_report_string_cb (GObject      *source_object,
                             GAsyncResult *result,
                             gpointer      user_data)
{
    GPasteUiReport *report = user_data;
    g_autoptr (GError) error = NULL;
    g_autofree gchar *uuid = report->string_finish (G_PASTE_CLIENT (source_object), result, &error);

    report_done (report, error);
}

/* Connected swapped, so the button is the emitter and its state is read back
 * from it rather than carried by the signal. */
static void
on_favourites_toggled (GPasteUiWindow  *self,
                       GtkToggleButton *button)
{
    g_paste_ui_history_set_favourites (self->history, gtk_toggle_button_get_active (button));
}

static void exit_selection_mode                  (GPasteUiWindow *self);
static void g_paste_ui_window_update_key_capture (GPasteUiWindow *self);
static void g_paste_ui_window_release_focus      (GPasteUiWindow *self,
                                                  GtkWidget      *widget);

/* The three the application's own actions run -- from the search provider,
 * the launcher's desktop actions or gpaste-client -- bring the window to the
 * front: an ActivateAction emits no activate, and the window may be behind
 * others, minimized or on another workspace. A search asked for from outside
 * is the user's, and the picks name rows of the list it replaces, so selection
 * mode goes first. */
static void
do_search (GPasteUiWindow *self,
           const gchar    *search)
{
    gtk_window_present (GTK_WINDOW (self));

    /* The search and its results are on the content page, which a collapsed
     * window may have left for the histories. */
    if (self->split_view && adw_navigation_split_view_get_collapsed (self->split_view))
        adw_navigation_split_view_set_show_content (self->split_view, TRUE);

    if (g_paste_ui_history_get_selection_mode (self->history))
        exit_selection_mode (self);

    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (g_paste_ui_header_get_search_button (self->header)), TRUE);
    gtk_editable_set_text (GTK_EDITABLE (self->search_entry), search);
}

/**
 * g_paste_ui_window_search:
 * @self: the #GPasteUiWindow
 * @search: the text to search
 *
 * Do a search
 */
void
g_paste_ui_window_search (GPasteUiWindow *self,
                          const gchar    *search)
{
    g_return_if_fail (G_PASTE_IS_UI_WINDOW (self));
    g_return_if_fail (g_utf8_validate (search, -1, NULL));

    run_when_initialized (self, do_search, search, TRUE);
}

static void
do_show_prefs (GPasteUiWindow *self,
               const gchar    *arg G_GNUC_UNUSED)
{
    gtk_window_present (GTK_WINDOW (self));
    g_action_group_activate_action (G_ACTION_GROUP (self), "preferences", NULL);
}

static void
do_show_about (GPasteUiWindow *self,
               const gchar    *arg G_GNUC_UNUSED)
{
    gtk_window_present (GTK_WINDOW (self));
    g_action_group_activate_action (G_ACTION_GROUP (self), "about", NULL);
}

/**
 * g_paste_ui_window_show_prefs:
 * @self: the #GPasteUiWindow
 *
 * Show the prefs pane
 */
void
g_paste_ui_window_show_prefs (GPasteUiWindow *self)
{
    g_return_if_fail (G_PASTE_IS_UI_WINDOW (self));

    run_when_initialized (self, do_show_prefs, NULL, FALSE);
}

/**
 * g_paste_ui_window_show_about:
 * @self: the #GPasteUiWindow
 *
 * Show the about dialog
 */
void
g_paste_ui_window_show_about (GPasteUiWindow *self)
{
    g_return_if_fail (G_PASTE_IS_UI_WINDOW (self));

    run_when_initialized (self, do_show_about, NULL, FALSE);
}

/* Take down the snapshot that is up, if any, and call off the close armed for
 * it. Let go of it before asking it to close, rather than when the close
 * transition gets around to unparenting it and the weak pointer follows: a
 * present in between would raise the very snapshot this is retiring. */
static void
retire_shortcuts (GPasteUiWindow *self)
{
    g_clear_handle_id (&self->shortcuts_source, g_source_remove);

    /* Gone on its own while we were waiting for the burst to settle: whatever
     * comes next is built from the settings as they are now anyway. */
    if (!self->shortcuts)
        return;

    AdwDialog *shortcuts = self->shortcuts;

    g_clear_weak_pointer (&self->shortcuts);
    adw_dialog_close (shortcuts);
}

static gboolean
close_obsolete_shortcuts (gpointer user_data)
{
    g_autoptr (GPasteUiWindow) self = g_weak_ref_get (user_data);

    if (!self)
        return G_SOURCE_REMOVE;

    /* Let go of this source before retiring: the close it does calls off the
     * one armed for the dialog, and this is the source being dispatched. */
    self->shortcuts_source = 0;

    retire_shortcuts (self);

    return G_SOURCE_REMOVE;
}

/* The dialog is a snapshot of the settings it was built from, and an
 * AdwShortcutsDialog can neither drop a section nor update an accelerator:
 * close it when what it shows changes -- the master switch flipped from the
 * preferences in this very process, or from anywhere else -- so the next
 * present builds one that tells the truth.
 * Coalesced the way the daemon coalesces a rebind, and over the same burst: an
 * accelerator typed into the preferences writes its GSettings key on every
 * keystroke, and closing on the first of them takes the dialog out from under
 * an edit that has not settled yet. The delay is measured from the last write,
 * so one edit costs one close.
 * The source holds the window weakly: dispose () is the one thing that cancels
 * it, and a reference of its own would put that out of reach. */
static void
on_shortcuts_obsolete (GPasteUiWindow *self,
                       const gchar    *key G_GNUC_UNUSED)
{
    g_clear_handle_id (&self->shortcuts_source, g_source_remove);

    /* Nothing to close, and nothing to arm a close for: a dialog the user shut
     * themselves took the one armed for it with it, and leaving that behind
     * would have on_show_help_overlay () read a dialog that is not up as one
     * whose snapshot has gone stale. */
    if (!self->shortcuts)
        return;

    self->shortcuts_source = g_timeout_add_full (G_PRIORITY_DEFAULT, G_PASTE_UI_WINDOW_SHORTCUTS_CLOSE_DELAY,
                                                 close_obsolete_shortcuts,
                                                 g_paste_weak_ref_new (self), g_paste_weak_ref_free);
    g_source_set_name_by_id (self->shortcuts_source, "[GPaste] close obsolete shortcuts");
}

static void
on_shortcuts_enabled_changed (GPasteUiWindow *self,
                              GParamSpec     *pspec G_GNUC_UNUSED)
{
    on_shortcuts_obsolete (self, NULL);
}

static void
on_show_help_overlay (GSimpleAction *action    G_GNUC_UNUSED,
                      GVariant      *parameter G_GNUC_UNUSED,
                      gpointer       user_data)
{
    GPasteUiWindow *self = user_data;

    /* A close armed for the dialog that is up says what it shows has gone out of
     * date, and the user asking for it is asking for one that tells the truth:
     * retire it here rather than raising it and letting the pending close shut
     * it a moment later, which would read as the accelerator dismissing the
     * dialog. It also calls off a close armed for a dialog that has since gone,
     * which would otherwise shut the fresh snapshot below -- everything that
     * close was making room for. */
    if (self->shortcuts_source)
        retire_shortcuts (self);

    g_autoptr (AdwDialog) shortcuts = NULL;

    /* Built fresh once the previous one is gone. Presenting the live one again
     * only raises it, which is what the accelerator firing again while the
     * dialog is up must do.
     * The dialog comes back floating, and presenting it is what sinks that
     * reference: hold one until it has. A present that does not take the dialog
     * -- no dialog host to parent it to -- would otherwise leak it and leave a
     * weak pointer that never clears, and every later request would re-present
     * a dialog that is not up. */
    if (!self->shortcuts)
    {
        shortcuts = ADW_DIALOG (g_object_ref_sink (g_paste_ui_shortcuts_window_new (self->settings)));

        g_set_weak_pointer (&self->shortcuts, shortcuts);
    }

    adw_dialog_present (self->shortcuts, GTK_WIDGET (self));
}

static void
on_new_item (GSimpleAction *action    G_GNUC_UNUSED,
             GVariant      *parameter G_GNUC_UNUSED,
             gpointer       user_data)
{
    GPasteUiWindow *self = user_data;

    g_paste_ui_new_item_show (self->client, GTK_WINDOW (self));
}

static void
on_new_password (GSimpleAction *action    G_GNUC_UNUSED,
                 GVariant      *parameter G_GNUC_UNUSED,
                 gpointer       user_data)
{
    GPasteUiWindow *self = user_data;

    g_paste_ui_password_dialog_add (self->client, self->settings, GTK_WINDOW (self));
}

static void
on_toggle_search (GSimpleAction *action    G_GNUC_UNUSED,
                  GVariant      *parameter G_GNUC_UNUSED,
                  gpointer       user_data)
{
    GPasteUiWindow *self = user_data;
    GtkToggleButton *button = g_paste_ui_header_get_search_button (self->header);

    gtk_toggle_button_set_active (button, !gtk_toggle_button_get_active (button));
}

static void
on_preferences (GSimpleAction *action    G_GNUC_UNUSED,
                GVariant      *parameter G_GNUC_UNUSED,
                gpointer       user_data)
{
    GPasteUiWindow *self = user_data;

    /* Presenting the one already up raises it; building a second would stack
     * two dialogs saying the same thing. */
    if (!self->preferences)
    {
        self->preferences = g_paste_gtk_preferences_dialog_new (NULL);
        g_object_add_weak_pointer (G_OBJECT (self->preferences), (gpointer *) &self->preferences);
    }

    adw_dialog_present (self->preferences, GTK_WIDGET (self));
}

/* @user_data is a weak reference to the window: the question is the window's,
 * and a reference of its own would keep the window from ever being disposed --
 * which is what answers a question whose window is destroyed under it, so the
 * window, its dialog and their client would all leak. */
static void
on_reexec_confirmed (gboolean confirmed,
                     gpointer user_data)
{
    g_autoptr (GPasteUiWindow) self = g_weak_ref_get (user_data);

    g_paste_weak_ref_free (user_data);

    /* As in g_paste_ui_window_set_tracking (). */
    if (confirmed && self && g_paste_client_get_daemon_presence (self->client) == G_PASTE_DAEMON_PRESENCE_READY)
    {
        g_paste_client_reexecute (self->client,
                                  NULL /* cancellable */,
                                  g_paste_ui_report_void_cb,
                                  g_paste_ui_report_void (GTK_WIDGET (self),
                                                          g_paste_client_reexecute_finish,
                                                          _("Could not restart the daemon")));
    }
}

static void
on_restart_daemon (GSimpleAction *action    G_GNUC_UNUSED,
                   GVariant      *parameter G_GNUC_UNUSED,
                   gpointer       user_data)
{
    GPasteUiWindow *self = user_data;

    g_paste_gtk_util_confirm_dialog (GTK_WINDOW (self),
                                     _("Restart the GPaste Daemon?"),
                                     _("The clipboard is not recorded while it restarts."),
                                     _("Restart"),
                                     ADW_RESPONSE_DEFAULT,
                                     on_reexec_confirmed,
                                     g_paste_weak_ref_new (self));
}

/* Asks the daemon, and sets nothing: the check follows the daemon's own
 * "tracking" signal, so a refused call leaves it where it was and the menu never
 * claims something the daemon did not do. It does say so, though. */
static void
g_paste_ui_window_set_tracking (GPasteUiWindow *self,
                                gboolean        state)
{
    /* Reached from a confirmation, which the daemon may have left while it was
     * up: the window takes away what would ask one while there is none
     * (g_paste_ui_window_update_sensitivity ()), and a call made then would be
     * what the bus starts one on, or reach one standing down. The banner says
     * why nothing happens. */
    if (g_paste_client_get_daemon_presence (self->client) != G_PASTE_DAEMON_PRESENCE_READY)
        return;

    g_paste_client_set_active (self->client, state,
                               NULL /* cancellable */,
                               g_paste_ui_report_void_cb,
                               g_paste_ui_report_void (GTK_WIDGET (self),
                                                       g_paste_client_set_active_finish,
                                                       (state) ? _("Could not start tracking the clipboard")
                                                               : _("Could not stop tracking the clipboard")));
}

/* Handed the window as on_reexec_confirmed () is. */
static void
on_track_confirmed (gboolean confirmed,
                    gpointer user_data)
{
    g_autoptr (GPasteUiWindow) self = g_weak_ref_get (user_data);

    g_paste_weak_ref_free (user_data);

    if (confirmed && self)
        g_paste_ui_window_set_tracking (self, FALSE);
}

static void
on_track_changes (GSimpleAction *action,
                  GVariant      *parameter G_GNUC_UNUSED,
                  gpointer       user_data)
{
    GPasteUiWindow *self = user_data;
    g_autoptr (GVariant) state = g_action_get_state (G_ACTION (action));

    if (g_variant_get_boolean (state))
    {
        g_paste_gtk_util_confirm_dialog (GTK_WINDOW (self),
                                         _("Stop Tracking the Clipboard?"),
                                         _("What you copy will not be added to the history until tracking is turned back on."),
                                         _("Stop"),
                                         ADW_RESPONSE_DEFAULT,
                                         on_track_confirmed,
                                         g_paste_weak_ref_new (self));
    }
    else
        g_paste_ui_window_set_tracking (self, TRUE);
}

static void
on_tracking_changed (GPasteClient *client G_GNUC_UNUSED,
                     gboolean      state,
                     gpointer      user_data)
{
    GPasteUiWindow *self = user_data;
    GAction *action = g_action_map_lookup_action (G_ACTION_MAP (self), "track-changes");

    if (action)
        g_simple_action_set_state (G_SIMPLE_ACTION (action), g_variant_new_boolean (state));
}

static void
on_about (GSimpleAction *action    G_GNUC_UNUSED,
          GVariant      *parameter G_GNUC_UNUSED,
          gpointer       user_data)
{
    GPasteUiWindow *self = user_data;
    const gchar *authors[] = {
        "Marc-Antoine Perennou <Marc-Antoine@Perennou.com>",
        NULL
    };

    if (self->about)
    {
        adw_dialog_present (self->about, GTK_WIDGET (self));
        return;
    }

    /* Held until presented, as the shortcuts dialog is, for the reason
     * on_show_help_overlay () gives. No test shows it: the leak is a present
     * that does not take the dialog, which takes a window to fail on. */
    g_autoptr (AdwDialog) held = ADW_DIALOG (g_object_ref_sink (adw_about_dialog_new ()));
    AdwAboutDialog *dialog = ADW_ABOUT_DIALOG (held);

    adw_about_dialog_set_application_name (dialog, PACKAGE_NAME);
    adw_about_dialog_set_version (dialog, PACKAGE_VERSION);
    adw_about_dialog_set_application_icon (dialog, G_PASTE_ICON_NAME);
    adw_about_dialog_set_license_type (dialog, GTK_LICENSE_BSD);
    adw_about_dialog_set_developers (dialog, authors);
    adw_about_dialog_set_copyright (dialog, "Copyright (c) 2010-2026, Marc-Antoine Perennou");
    adw_about_dialog_set_comments (dialog, _("Clipboard management system"));
    adw_about_dialog_set_website (dialog, "https://www.imagination-land.org/tags/GPaste.html");
    adw_about_dialog_set_issue_url (dialog, "https://github.com/Keruspe/GPaste/issues");
    adw_about_dialog_set_support_url (dialog, "https://github.com/Keruspe/GPaste/issues");
    adw_about_dialog_add_link (dialog, _("Sponsor on GitHub"), "https://github.com/sponsors/Keruspe");
    adw_about_dialog_add_link (dialog, _("Donate with PayPal"), "https://paypal.me/keruspe/");
    /* Translators: put your names here, one per line, and they show up in the
     * about dialog's credits. */
    adw_about_dialog_set_translator_credits (dialog, _("translator-credits"));

    g_set_weak_pointer (&self->about, held);
    adw_dialog_present (self->about, GTK_WIDGET (self));
}

/* The two actions with nothing to ask the daemon: About is the application's own
 * and the preferences are GSettings. Added whichever way the connection
 * concluded, so they are there for a window presented for the failure banner
 * alone -- which is what lets `gpaste-client about` work with no daemon
 * running. */
static void
add_daemonless_window_actions (GPasteUiWindow *self)
{
    static const GActionEntry entries[] = {
        { "about",          on_about,          NULL, NULL,    NULL, { 0 } },
        { "preferences",    on_preferences,    NULL, NULL,    NULL, { 0 } },
    };

    g_action_map_add_action_entries (G_ACTION_MAP (self), entries, G_N_ELEMENTS (entries), self);

    gtk_application_set_accels_for_action (gtk_window_get_application (GTK_WINDOW (self)),
                                           "win.preferences",
                                           (const char *[]) { G_PASTE_UI_PREFERENCES_ACCELERATOR, NULL });
}

/* Every control in the header drives one of these, so the window owns the state
 * and the header owns only how it is shown -- which is what lets the rare,
 * app-level ones live in a menu rather than as an icon apiece. */
static void
add_window_actions (GPasteUiWindow *self)
{
    static const GActionEntry entries[] = {
        { "new-item",       on_new_item,       NULL, NULL,    NULL, { 0 } },
        { "new-password",   on_new_password,   NULL, NULL,    NULL, { 0 } },
        { "restart-daemon", on_restart_daemon, NULL, NULL,    NULL, { 0 } },
        { "toggle-search",  on_toggle_search,  NULL, NULL,    NULL, { 0 } },
        { "track-changes",  on_track_changes,  NULL, "false", NULL, { 0 } },
    };

    g_action_map_add_action_entries (G_ACTION_MAP (self), entries, G_N_ELEMENTS (entries), self);

    add_daemonless_window_actions (self);

    g_autoptr (GSimpleAction) show_shortcuts = g_simple_action_new ("show-help-overlay", NULL);
    g_signal_connect_object (show_shortcuts, "activate", G_CALLBACK (on_show_help_overlay), self, 0);
    g_action_map_add_action (G_ACTION_MAP (self), G_ACTION (show_shortcuts));

    on_tracking_changed (self->client, g_paste_client_is_active (self->client), self);

    GtkApplication *app = gtk_window_get_application (GTK_WINDOW (self));

    struct { const gchar *action; const gchar *accel; } accels[] = {
        { "win.show-help-overlay", G_PASTE_UI_SHORTCUTS_ACCELERATOR },
        { "win.toggle-search",     G_PASTE_UI_SEARCH_ACCELERATOR },
        { "win.new-item",          G_PASTE_UI_NEW_ITEM_ACCELERATOR },
        { "win.new-password",      G_PASTE_UI_NEW_PASSWORD_ACCELERATOR },
        { "window.close",          G_PASTE_UI_CLOSE_ACCELERATOR },
    };

    for (guint i = 0; i < G_N_ELEMENTS (accels); ++i)
    {
        gtk_application_set_accels_for_action (app, accels[i].action,
                                               (const char *[]) { accels[i].accel, NULL });
    }
}

/* Ctrl+0-9 activates the item displayed at that index, mirroring the GNOME
 * Shell extension (the index is shown to the left of each item). Only once
 * there is a list: a window presented for the connection-failure banner alone
 * has no history (nor merge bar) behind it. */
static gboolean
activate_index (GtkWidget *widget,
                GVariant  *args,
                gpointer   user_data G_GNUC_UNUSED)
{
    GPasteUiWindow *self = G_PASTE_UI_WINDOW (widget);

    if (!self->history)
        return FALSE;

    return g_paste_ui_history_activate_index (self->history, g_variant_get_uint32 (args));
}

static gboolean
on_escape (GtkWidget *widget,
           GVariant  *args      G_GNUC_UNUSED,
           gpointer   user_data G_GNUC_UNUSED)
{
    GPasteUiWindow *self = G_PASTE_UI_WINDOW (widget);

    /* Escape reaching the window is one the focus did not take: the bar closes
     * itself only through its entry, and while no daemon is there the list,
     * the panel and the search button are insensitive, so the focus may be on
     * none of them (g_paste_ui_window_update_sensitivity ()). The bar is the
     * first thing it closes, rather than the window under it, and the toggle
     * is not there to do it then (/ui/daemon-presence/follow). A window
     * presented for the connection-failure banner alone has no bar. */
    if (self->search_bar && gtk_search_bar_get_search_mode (self->search_bar))
    {
        gtk_search_bar_set_search_mode (self->search_bar, FALSE);
        return TRUE;
    }

    if (self->merge_bar && gtk_action_bar_get_revealed (self->merge_bar))
    {
        exit_selection_mode (self);
        return TRUE;
    }

    gtk_window_close (GTK_WINDOW (self));
    return TRUE;
}

static void
add_shortcuts (GPasteUiWindow *self)
{
    GtkEventController *shortcuts = gtk_shortcut_controller_new ();

    gtk_event_controller_set_propagation_phase (shortcuts, GTK_PHASE_BUBBLE);

    for (guint index = 0; index < 10; ++index)
    {
        /* One trigger per digit covers the keypad twin too: GTK knows KP_0-9
         * are aliases of 0-9, so there is no second range to spell out. */
        GtkShortcutTrigger *trigger = gtk_shortcut_trigger_create_with_aliases (GDK_KEY_0 + index,
                                                                                GDK_CONTROL_MASK);
        GtkShortcutAction *action = gtk_callback_action_new (activate_index, NULL, NULL);
        GtkShortcut *shortcut = gtk_shortcut_new (trigger, action);

        gtk_shortcut_set_arguments (shortcut, g_variant_new_uint32 (index));
        gtk_shortcut_controller_add_shortcut (GTK_SHORTCUT_CONTROLLER (shortcuts), shortcut);
    }

    gtk_shortcut_controller_add_shortcut (GTK_SHORTCUT_CONTROLLER (shortcuts),
                                          gtk_shortcut_new (gtk_keyval_trigger_new (GDK_KEY_Escape, 0),
                                                            gtk_callback_action_new (on_escape, NULL, NULL)));

    gtk_widget_add_controller (GTK_WIDGET (self), shortcuts);
}

static void
on_search_activate (GtkSearchEntry *entry,
                    gpointer        user_data)
{
    GPasteUiWindow *self = user_data;
    const gchar *search = gtk_editable_get_text (GTK_EDITABLE (entry));

    if (self->history && search && *search)
        g_paste_ui_history_select_first (self->history, search);
}

static void
on_search (GtkSearchEntry *entry,
           gpointer        user_data)
{
    GPasteUiWindow *self = user_data;

    if (!self->history)
        return;

    g_paste_ui_history_search (self->history, gtk_editable_get_text (GTK_EDITABLE (entry)));
}

/* The banner says what is keeping the window from showing a history, and its
 * button is an offer only where there is one to make. Hidden, it keeps the
 * words it had, so it slides away still saying them. */
static void
g_paste_ui_window_update_banner (GPasteUiWindow *self)
{
    GPasteDaemonPresence presence = (self->client) ? g_paste_client_get_daemon_presence (self->client)
                                                   : G_PASTE_DAEMON_PRESENCE_ABSENT;

    if (presence == G_PASTE_DAEMON_PRESENCE_READY)
    {
        adw_banner_set_revealed (self->banner, FALSE);
        return;
    }

    /* A g_paste_client_new () still out is a daemon on its way with nothing to
     * ask it of yet, and a retry offered there is one on_banner_retry () would
     * refuse. */
    gboolean starting = self->connecting || presence == G_PASTE_DAEMON_PRESENCE_STARTING;

    /* One that will never be ready for this version, however long it is
     * waited for or retried: what it takes is restarting it. */
    if (self->legacy && !self->connecting)
    {
        adw_banner_set_title (self->banner, _("An older GPaste daemon is still running"));
        adw_banner_set_button_label (self->banner, _("Restart"));
        adw_banner_set_revealed (self->banner, TRUE);
        return;
    }

    adw_banner_set_title (self->banner, (starting) ? _("Connecting to GPaste…") : _("Couldn’t connect to GPaste"));
    adw_banner_set_button_label (self->banner, (starting) ? NULL : _("Retry"));
    adw_banner_set_revealed (self->banner, TRUE);
}

/* Whether restarting the daemon could do anything: one is there, and it is
 * known not to be the experimental in-shell one. That one owns its name on the
 * Shell's own connection, so the two names share their owner, and a restart
 * has nothing to offer there -- its Reexecute answers without restarting
 * anything, the Shell being unable to reload the extension's code short of a
 * new session -- so neither the menu nor the version toast offers one. The
 * owner rather than the experimental-meta-daemon setting, which the extension
 * reads only as it is enabled, so the two disagree until it restarts. Not
 * before both owners are known: the Shell's watch has to answer once. */
static gboolean
g_paste_ui_window_restart_can_help (GPasteUiWindow *self)
{
    if (g_paste_client_get_daemon_presence (self->client) != G_PASTE_DAEMON_PRESENCE_READY || !self->shell_owner_known)
        return FALSE;

    /* Unknown is not elsewhere: the proxy can learn its daemon's owner only
     * after that daemon's history made it ready, and until then the in-shell
     * daemon would read as not in the Shell
     * (/ui/daemon-presence/version-toast-in-shell). */
    g_autofree gchar *owner = g_dbus_proxy_get_name_owner (G_DBUS_PROXY (self->client));

    return owner && !g_paste_str_equal (owner, self->shell_owner);
}

static void
g_paste_ui_window_update_restart (GPasteUiWindow *self)
{
    g_simple_action_set_enabled (G_SIMPLE_ACTION (g_action_map_lookup_action (G_ACTION_MAP (self), "restart-daemon")),
                                 g_paste_ui_window_restart_can_help (self));
}

/* What acts on a daemon, taken away while there is none to act on, for the
 * reason the list empties itself (g_paste_ui_history_on_daemon_presence ()).
 * What the window offers of its own -- the preferences, the shortcuts, About,
 * closing -- stays. */
static void
g_paste_ui_window_update_sensitivity (GPasteUiWindow *self)
{
    /* toggle-search too, which g_paste_ui_window_update_key_capture () holds. */
    static const gchar * const daemon_actions[] = { "new-item", "new-password", "track-changes" };
    gboolean ready = g_paste_client_get_daemon_presence (self->client) == G_PASTE_DAEMON_PRESENCE_READY;

    for (guint i = 0; i < G_N_ELEMENTS (daemon_actions); ++i)
        g_simple_action_set_enabled (G_SIMPLE_ACTION (g_action_map_lookup_action (G_ACTION_MAP (self), daemon_actions[i])), ready);
    g_paste_ui_window_update_restart (self);

    /* The list lets go of the focus on its own, being hidden first; the Merge
     * button's entry is released by on_selection_changed (), the list's
     * emptying having dropped the picks. */
    if (!ready)
        g_paste_ui_window_release_focus (self, self->panel);

    gtk_widget_set_sensitive (self->panel, ready);
    gtk_widget_set_sensitive (GTK_WIDGET (self->history), ready);
    gtk_widget_set_sensitive (GTK_WIDGET (g_paste_ui_header_get_search_button (self->header)), ready);
    gtk_widget_set_sensitive (GTK_WIDGET (g_paste_ui_header_get_favourites_button (self->header)), ready);
    gtk_widget_set_sensitive (g_paste_ui_header_get_merge_button (self->header), ready);

    g_paste_ui_window_update_key_capture (self);

    /* The picks go: they name the old list's rows, which the next daemon's
     * listing rebuilds. The search stays, entry and all -- a daemon away for a
     * moment, a handoff to another or a re-exec, would otherwise throw away
     * what the user typed -- and only asks again once a daemon is there
     * (g_paste_ui_history_refresh ()), which is what lists the new one's
     * matches (/ui/daemon-presence/follow). */
    if (!ready)
        exit_selection_mode (self);
}

/* GPaste versions have numeric runs and named prereleases (see meson.build).
 * Compare each digit run by value without overflowing an integer, and put
 * letters before digits so a series' alpha, beta and rc precede its .0, and
 * one another as their names compare -- letters one by one, digit runs by
 * value -- which has to be the order meson.build ranks them in
 * (/ui/daemon-presence/version-comparison checks its table). A bare major is
 * its own .0, as meson.build encodes it: a side running out while the other
 * goes on reads on as ".0", as often as it runs out, so "51", "51.0" and
 * "51.0.0" are all one version and the order stays transitive. That ends: a
 * pad matches only what the other side has left, ".0" by ".0", so both run
 * out together. */
static gint
g_paste_ui_window_compare_versions (const gchar *left,
                                    const gchar *right)
{
    static const gchar *zero = ".0";

    for (;;)
    {
        if (!*left && !*right)
            return 0;
        if (!*left)
            left = zero;
        else if (!*right)
            right = zero;

        gboolean left_digit = g_ascii_isdigit (*left);
        gboolean right_digit = g_ascii_isdigit (*right);

        if (left_digit && right_digit)
        {
            const gchar *left_end = left;
            const gchar *right_end = right;

            while (g_ascii_isdigit (*left_end))
                ++left_end;
            while (g_ascii_isdigit (*right_end))
                ++right_end;

            while (left < left_end && *left == '0')
                ++left;
            while (right < right_end && *right == '0')
                ++right;

            gsize left_length = left_end - left;
            gsize right_length = right_end - right;

            if (left_length != right_length)
                return left_length < right_length ? -1 : 1;

            gint difference = strncmp (left, right, left_length);

            if (difference)
                return difference < 0 ? -1 : 1;

            left = left_end;
            right = right_end;
            continue;
        }

        if (left_digit != right_digit)
            return left_digit ? 1 : -1;

        if (*left != *right)
            return (guchar) *left < (guchar) *right ? -1 : 1;

        ++left;
        ++right;
    }
}

/* A daemon of another version than the window's -- the one an update
 * replaced, still running until something restarts it -- can lack what the
 * window asks of it, a method added since, so the window offers to restart it.
 * Once per daemon, and for the toasts' usual time -- one kept up until the user
 * dismissed it would hold back every toast queued behind it, an upload's
 * outcome included -- going early with the daemon it was about, or with its
 * restart becoming one that could not help. */
static void
g_paste_ui_window_withdraw_version_toast (GPasteUiWindow *self)
{
    if (self->version_toast)
        adw_toast_dismiss (self->version_toast);
    g_clear_weak_pointer (&self->version_toast);
    self->version_offered = FALSE;
}

static void
g_paste_ui_window_update_version_toast (GPasteUiWindow *self)
{
    if (!g_paste_ui_window_restart_can_help (self))
    {
        g_paste_ui_window_withdraw_version_toast (self);
        return;
    }

    if (self->version_offered)
        return;
    self->version_offered = TRUE;

    g_autofree gchar *version = g_paste_client_get_version (self->client);

    /* Only for a daemon older than the window: a newer one is what a restart
     * would bring back, the window being what is out of date, and the offer
     * would come back with it after every restart. */
    if (!version || g_paste_ui_window_compare_versions (version, PACKAGE_VERSION) >= 0)
        return;

    AdwToast *toast = adw_toast_new (_("The GPaste daemon is out of date"));

    /* As in g_paste_gtk_util_toast (). */
    adw_toast_set_use_markup (toast, FALSE);
    adw_toast_set_button_label (toast, _("Restart"));
    adw_toast_set_action_name (toast, "win.restart-daemon");
    g_set_weak_pointer (&self->version_toast, toast);
    adw_toast_overlay_add_toast (self->toast_overlay, toast);
}

/* Either name changing hands can make a restart one that could help, or one
 * that could not, with no change of presence to say so: the proxy can learn
 * its daemon's owner after the history that makes it ready, and the Shell's is
 * watched apart. Only what a restart is offered through is touched. */
static void
g_paste_ui_window_on_daemon_host (GPasteUiWindow *self)
{
    if (!self->client)
        return;

    g_paste_ui_window_update_restart (self);
    g_paste_ui_window_update_version_toast (self);
}

static void
on_daemon_owner_changed (GPasteClient *client G_GNUC_UNUSED,
                         GParamSpec   *pspec  G_GNUC_UNUSED,
                         gpointer      user_data)
{
    g_paste_ui_window_on_daemon_host (user_data);
}

/* The watch is dropped in dispose (), after which no callback runs, so @self
 * is borrowed. */
static void
g_paste_ui_window_on_shell_owner (GPasteUiWindow *self,
                                  const gchar    *owner)
{
    g_set_str (&self->shell_owner, owner);
    self->shell_owner_known = TRUE;
    g_paste_ui_window_on_daemon_host (self);
}

static void
on_shell_appeared (GDBusConnection *connection G_GNUC_UNUSED,
                   const gchar     *name       G_GNUC_UNUSED,
                   const gchar     *name_owner,
                   gpointer         user_data)
{
    g_paste_ui_window_on_shell_owner (user_data, name_owner);
}

static void
on_shell_vanished (GDBusConnection *connection G_GNUC_UNUSED,
                   const gchar     *name       G_GNUC_UNUSED,
                   gpointer         user_data)
{
    g_paste_ui_window_on_shell_owner (user_data, NULL);
}

static void
on_legacy_probed (GObject      *source_object G_GNUC_UNUSED,
                  GAsyncResult *res,
                  gpointer      user_data)
{
    g_autoptr (GPasteUiWindow) self = g_weak_ref_get (user_data);
    g_autoptr (GError) error = NULL;
    gboolean legacy = g_paste_util_daemon_is_legacy_finish (res, &error);

    g_paste_weak_ref_free (user_data);

    /* Given up on by a newer question, or by dispose (). Any other failure
     * reads as no older daemon: the banner's usual offer stands then. */
    if (!self || g_error_matches (error, G_IO_ERROR, G_IO_ERROR_CANCELLED))
        return;

    g_clear_object (&self->legacy_probe);
    self->legacy = legacy;
    g_paste_ui_window_update_banner (self);
}

/* A GPaste 45 or 50 left running by a package update owns the name and serves
 * none of this interface, so it is never ready for this version: the window
 * would say it is connecting, then offer a retry that waits for it forever.
 * Asked whenever the presence moves while something owns the name, the window
 * held weakly, as the question is one dispose () ends. */
static void
g_paste_ui_window_probe_legacy (GPasteUiWindow *self)
{
    g_paste_clear_cancellable (&self->legacy_probe);
    self->legacy = FALSE;

    if (g_paste_client_get_daemon_presence (self->client) == G_PASTE_DAEMON_PRESENCE_READY)
        return;

    g_autofree gchar *owner = g_dbus_proxy_get_name_owner (G_DBUS_PROXY (self->client));

    if (!owner)
        return;

    self->legacy_probe = g_cancellable_new ();
    g_paste_util_daemon_is_legacy (self->client, self->legacy_probe, on_legacy_probed, g_paste_weak_ref_new (self));
}

/* The list and the sidebar follow the daemon on their own; the window says so
 * and takes away what would act on one that is not there. */
static void
on_daemon_presence_changed (GPasteClient *client G_GNUC_UNUSED,
                            GParamSpec   *pspec  G_GNUC_UNUSED,
                            gpointer      user_data)
{
    GPasteUiWindow *self = user_data;

    g_paste_ui_window_probe_legacy (self);
    g_paste_ui_window_update_banner (self);
    g_paste_ui_window_update_sensitivity (self);
    g_paste_ui_window_update_version_toast (self);
}

/* Whether GTK still lists the window, which gtk_window_destroy () stops it
 * doing: see on_client_ready (). */
static gboolean
g_paste_ui_window_is_toplevel (GPasteUiWindow *self)
{
    GListModel *toplevels = gtk_window_get_toplevels ();
    guint n_items = g_list_model_get_n_items (toplevels);

    for (guint i = 0; i < n_items; ++i)
    {
        g_autoptr (GObject) toplevel = g_list_model_get_item (toplevels, i);

        if (toplevel == G_OBJECT (self))
            return TRUE;
    }

    return FALSE;
}

static void on_client_ready (GObject      *source_object,
                             GAsyncResult *res,
                             gpointer      user_data);

/* Its two calls to the bus made off the main thread, short as they are. */
static void
reexecute_legacy_in_thread (GTask        *task,
                            gpointer      source_object G_GNUC_UNUSED,
                            gpointer      task_data,
                            GCancellable *cancellable G_GNUC_UNUSED)
{
    GError *error = NULL;

    if (g_paste_util_reexecute_legacy_daemon (task_data, &error))
        g_task_return_boolean (task, TRUE);
    else
        g_task_return_error (task, error);
}

static void
on_legacy_reexecuted (GObject      *source_object G_GNUC_UNUSED,
                      GAsyncResult *res,
                      gpointer      user_data)
{
    g_autoptr (GPasteUiWindow) self = user_data;
    g_autoptr (GError) error = NULL;
    gboolean restarted = g_task_propagate_boolean (G_TASK (res), &error);

    self->legacy_restarting = FALSE;

    if (!restarted)
        g_warning ("Could not restart the older daemon: %s", error->message);

    /* As in on_client_ready (): a window disposed meanwhile has no widgets left
     * to say anything with. Closing it does not get there, gtk_window_destroy ()
     * leaving the dispose to the last reference, which this callback holds --
     * so no test can, short of disposing it by hand. */
    if (!self->banner)
        return;

    /* What comes back is a daemon starting, until the presence says more. */
    if (restarted)
    {
        self->legacy = FALSE;
        g_paste_ui_window_update_banner (self);
    }
    else
        g_paste_gtk_util_toast (GTK_WIDGET (self), _("Could not restart the older daemon"));
}

/* The banner's button, an offer only while there is no daemon: ask for one now,
 * this being the user asking, and wait for it from the start again. */
static void
on_banner_retry (AdwBanner *banner G_GNUC_UNUSED,
                 gpointer   user_data)
{
    GPasteUiWindow *self = user_data;

    /* A connection still in flight owns the setup that follows it; a second one
     * started here would build the window's content twice over. */
    if (self->connecting)
        return;

    /* Restarted by signal (g_paste_util_reexecute_legacy_daemon ()): what comes
     * back is this version's daemon, which the presence follows. Once: a
     * second press would find the new daemon and say the restart failed, or
     * signal the old one again as it execs, before the new one handles it. */
    if (self->legacy)
    {
        if (self->legacy_restarting)
            return;

        g_autoptr (GTask) task = g_task_new (NULL, NULL, on_legacy_reexecuted, g_object_ref (self));

        self->legacy_restarting = TRUE;

        g_task_set_task_data (task, g_object_ref (self->client), g_object_unref);
        g_task_run_in_thread (task, reexecute_legacy_in_thread);
        return;
    }

    /* No proxy at all (see on_client_ready ()), so what it takes is asking for
     * one again. */
    if (!self->client)
    {
        self->connecting = TRUE;
        /* The callback owns this ref (see on_client_ready). */
        g_paste_client_new (on_client_ready, g_object_ref (self));
        g_paste_ui_window_update_banner (self);
        return;
    }

    g_paste_client_retry_daemon (self->client);
}

/* Which history is in use is a property, so the subtitle follows its notify
 * rather than a signal, and the initial value is simply read off the proxy's
 * cache -- no call, nothing in flight for dispose to race. */
static void
on_history_changed (GPasteClient *client,
                    GParamSpec   *pspec G_GNUC_UNUSED,
                    gpointer      user_data)
{
    GPasteUiWindow *self = user_data;
    g_autofree gchar *history = g_paste_client_get_history_name (client);

    /* A daemon leaving the bus empties that cache rather than changing it, and
     * the subtitle takes a string: keep the name we were showing. */
    if (!history)
        return;

    g_paste_ui_header_set_subtitle (self->header, history);

    /* Collapsed, the sidebar and the list are two pages rather than two panes:
     * having picked a history, the user wants to see it. */
    if (self->split_view && adw_navigation_split_view_get_collapsed (self->split_view))
        adw_navigation_split_view_set_show_content (self->split_view, TRUE);
}

/* Collapsed, the history the user chose is shown -- the one in use too, which
 * changes nothing on_history_changed () would hear of. */
static void
on_history_chosen (GPasteUiPanel *panel G_GNUC_UNUSED,
                   gpointer       user_data)
{
    GPasteUiWindow *self = user_data;

    if (self->split_view && adw_navigation_split_view_get_collapsed (self->split_view))
        adw_navigation_split_view_set_show_content (self->split_view, TRUE);
}

/* The focus taken off @widget while that still reaches whatever holds it, ahead
 * of @widget going insensitive: GTK drops the focus of an insensitive widget
 * without telling it, and an entry in there -- the sidebar's "Switch or
 * Create", the Merge popover's separator -- would go on believing it has it,
 * its input method never released and a later click never focusing it again.
 * GTK warns about it the next time the entry is shown. */
static void
g_paste_ui_window_release_focus (GPasteUiWindow *self,
                                 GtkWidget      *widget)
{
    GtkWidget *focus = gtk_root_get_focus (GTK_ROOT (self));

    if (focus && gtk_widget_is_ancestor (focus, widget))
        gtk_window_set_focus (GTK_WINDOW (self), NULL);
}

/* Typing is how the search bar opens itself, and Ctrl+F the other way, which
 * are offers only while there is a daemon to search and no items are being
 * picked -- keys belong to the list then, and a search typed would narrow the
 * rows being picked from, dropping the picks. */
static void
g_paste_ui_window_update_key_capture (GPasteUiWindow *self)
{
    gboolean capture = !g_paste_ui_history_get_selection_mode (self->history) &&
                       g_paste_client_get_daemon_presence (self->client) == G_PASTE_DAEMON_PRESENCE_READY;

    g_simple_action_set_enabled (G_SIMPLE_ACTION (g_action_map_lookup_action (G_ACTION_MAP (self), "toggle-search")), capture);

    if (self->search_bar)
        gtk_search_bar_set_key_capture_widget (self->search_bar, (capture) ? GTK_WIDGET (self) : NULL);
}

static void
on_split_view_uncollapsed (AdwNavigationSplitView *split_view,
                           GParamSpec             *pspec     G_GNUC_UNUSED,
                           gpointer                user_data G_GNUC_UNUSED)
{
    if (!adw_navigation_split_view_get_collapsed (split_view))
        adw_navigation_split_view_set_show_content (split_view, TRUE);
}

static void
exit_selection_mode (GPasteUiWindow *self)
{
    g_paste_ui_history_set_selection_mode (self->history, FALSE);
    g_paste_ui_header_set_selection_mode (self->header, FALSE);
    gtk_action_bar_set_revealed (self->merge_bar, FALSE);
    g_paste_ui_window_update_key_capture (self);
}

static void
on_enter_selection_mode (GtkButton *button G_GNUC_UNUSED,
                         gpointer   user_data)
{
    GPasteUiWindow *self = user_data;

    g_paste_ui_history_set_selection_mode (self->history, TRUE);
    g_paste_ui_header_set_selection_mode (self->header, TRUE);
    g_paste_ui_header_set_selection_count (self->header, 0);
    gtk_action_bar_set_revealed (self->merge_bar, TRUE);

    /* The header just took the search toggle off the bar as well, so nothing
     * would close a search typed now. */
    g_paste_ui_window_update_key_capture (self);
}

static void
on_cancel_selection_mode (GtkButton *button G_GNUC_UNUSED,
                          gpointer   user_data)
{
    exit_selection_mode (user_data);
}

static void
on_selection_changed (GPasteUiHistory *history G_GNUC_UNUSED,
                      guint            count,
                      gpointer         user_data)
{
    GPasteUiWindow *self = user_data;

    g_paste_ui_header_set_selection_count (self->header, count);

    /* Merging is only meaningful with at least two items. Fewer, and the
     * popover has nothing left to merge either: closed, and the focus off its
     * entry before the button goes insensitive (see
     * g_paste_ui_window_release_focus ()). The picks drop to none with the
     * daemon going too, the list emptying. */
    if (count < 2)
    {
        gtk_menu_button_popdown (GTK_MENU_BUTTON (self->merge_button));
        g_paste_ui_window_release_focus (self, self->merge_button);
    }

    gtk_widget_set_sensitive (self->merge_button, count >= 2);
}

typedef struct
{
    GPasteUiWindow *window;
    gchar          *separator;
} MergeData;

static void
merge_data_free (MergeData *data)
{
    g_clear_object (&data->window);
    g_free (data->separator);
    g_free (data);
}

G_DEFINE_AUTOPTR_CLEANUP_FUNC (MergeData, merge_data_free)

static void
on_selection_resolved (GObject      *source_object,
                       GAsyncResult *res,
                       gpointer      user_data)
{
    g_autoptr (MergeData) data = user_data;
    g_autoptr (GError) error = NULL;
    g_auto (GStrv) uuids = g_paste_ui_history_get_selected_uuids_finish (G_PASTE_UI_HISTORY (source_object), res, &error);

    if (!uuids)
    {
        g_warning ("Could not read the history to resolve the selection: %s", error->message);
        g_paste_gtk_util_toast (GTK_WIDGET (data->window), _("Could not read the history"));
        return;
    }

    /* uuids are in selection order, so the merge keeps it. */
    if (g_strv_length (uuids) >= 2)
    {
        g_paste_client_merge (data->window->client, "", data->separator, (const gchar * const *) uuids,
                              NULL /* cancellable */,
                              g_paste_ui_report_string_cb,
                              g_paste_ui_report_string (GTK_WIDGET (data->window), g_paste_client_merge_finish,
                                                        _("Could not merge the selected items")));
    }
}

/* The picks are resolved as they stand, and selection mode left at once: what
 * the merge needs of them is already in hand. */
static void
do_merge (GPasteUiWindow *self,
          GtkWidget      *origin,
          const gchar    *separator)
{
    MergeData *data = g_new0 (MergeData, 1);

    data->window = g_object_ref (self);
    data->separator = g_strdup (separator);

    gtk_popover_popdown (GTK_POPOVER (gtk_widget_get_ancestor (origin, GTK_TYPE_POPOVER)));
    g_paste_ui_history_get_selected_uuids (self->history, on_selection_resolved, data);
    exit_selection_mode (self);
}

static void
on_separator_chosen (GtkButton *button,
                     gpointer   user_data)
{
    do_merge (user_data, GTK_WIDGET (button), g_object_get_data (G_OBJECT (button), "separator"));
}

static void
on_custom_separator (GtkWidget *widget,
                     gpointer   user_data)
{
    GPasteUiWindow *self = user_data;

    do_merge (self, widget, gtk_editable_get_text (GTK_EDITABLE (self->merge_entry)));
}

static void
add_separator_choice (GtkBox         *box,
                      GPasteUiWindow *self,
                      const gchar    *label,
                      const gchar    *separator)
{
    GtkWidget *button = gtk_button_new_with_label (label);

    gtk_button_set_has_frame (GTK_BUTTON (button), FALSE);
    g_object_set_data_full (G_OBJECT (button), "separator", g_strdup (separator), g_free);
    g_signal_connect (button, "clicked", G_CALLBACK (on_separator_chosen), self);
    gtk_box_append (box, button);
}

static GtkWidget *
build_merge_bar (GPasteUiWindow *self)
{
    GtkWidget *box = gtk_box_new (GTK_ORIENTATION_VERTICAL, 0);
    gtk_widget_set_margin_top (box, 6);
    gtk_widget_set_margin_bottom (box, 6);
    gtk_widget_set_margin_start (box, 6);
    gtk_widget_set_margin_end (box, 6);

    /* translators: separators inserted between the merged items */
    add_separator_choice (GTK_BOX (box), self, _("New Line"), "\n");
    add_separator_choice (GTK_BOX (box), self, _("Space"), " ");
    add_separator_choice (GTK_BOX (box), self, _("Comma"), ", ");
    add_separator_choice (GTK_BOX (box), self, _("Tab"), "\t");

    gtk_box_append (GTK_BOX (box), gtk_separator_new (GTK_ORIENTATION_HORIZONTAL));

    GtkWidget *custom = gtk_box_new (GTK_ORIENTATION_HORIZONTAL, 6);
    gtk_widget_set_margin_top (custom, 6);

    GtkWidget *entry = self->merge_entry = gtk_entry_new ();
    gtk_entry_set_placeholder_text (GTK_ENTRY (entry), _("Custom separator"));
    gtk_widget_set_hexpand (entry, TRUE);
    g_signal_connect (entry, "activate", G_CALLBACK (on_custom_separator), self);

    GtkWidget *custom_merge = gtk_button_new_from_icon_name ("object-select-symbolic");
    g_paste_ui_set_icon_button_label (custom_merge, _("Merge With This Separator"));
    g_signal_connect (custom_merge, "clicked", G_CALLBACK (on_custom_separator), self);

    gtk_box_append (GTK_BOX (custom), entry);
    gtk_box_append (GTK_BOX (custom), custom_merge);
    gtk_box_append (GTK_BOX (box), custom);

    GtkWidget *popover = gtk_popover_new ();
    gtk_popover_set_child (GTK_POPOVER (popover), box);

    GtkWidget *merge_button = self->merge_button = gtk_menu_button_new ();
    gtk_menu_button_set_label (GTK_MENU_BUTTON (merge_button), _("Merge"));
    gtk_menu_button_set_popover (GTK_MENU_BUTTON (merge_button), popover);
    gtk_widget_add_css_class (merge_button, "suggested-action");
    gtk_widget_set_sensitive (merge_button, FALSE);

    GtkWidget *bar = gtk_action_bar_new ();
    self->merge_bar = GTK_ACTION_BAR (bar);
    gtk_action_bar_set_revealed (self->merge_bar, FALSE);
    gtk_action_bar_pack_end (self->merge_bar, merge_button);

    return bar;
}

static void
g_paste_ui_window_dispose (GObject *object)
{
    GPasteUiWindow *self = G_PASTE_UI_WINDOW (object);

    g_clear_object (&self->search_signals);
    g_clear_object (&self->client_signals);
    g_paste_clear_cancellable (&self->legacy_probe);
    /* The panel and the list hold the client too, until the widgets below go:
     * its wait for a daemon is ours to stop. */
    if (self->client)
        g_paste_client_unfollow_daemon (self->client);
    g_clear_handle_id (&self->shell_watch, g_bus_unwatch_name);
    g_clear_object (&self->client);
    g_clear_object (&self->settings);
    g_clear_handle_id (&self->shortcuts_source, g_source_remove);
    /* Registered on the dialogs, pointing at fields of ours: left in place they
     * would have GObject write into freed memory should one outlive us. */
    g_clear_weak_pointer (&self->shortcuts);
    g_clear_weak_pointer (&self->preferences);
    g_clear_weak_pointer (&self->about);
    g_clear_weak_pointer (&self->version_toast);
    g_clear_slist (&self->deferred, deferred_action_free);

    /* Chaining up unparents (and frees) every widget below, so every pointer to
     * one is dangling from here on. They are dropped together rather than as
     * each is found to be read after dispose: an asynchronous reply landing on a
     * closed window is the normal case here, not the exotic one, and a field
     * that is NULL is the test the rest of the file already makes. */
    self->header = NULL;
    self->history = NULL;
    self->panel = NULL;
    self->split_view = NULL;
    self->search_bar = NULL;
    self->search_entry = NULL;
    self->content_box = NULL;
    self->toast_overlay = NULL;
    self->banner = NULL;
    self->merge_bar = NULL;
    self->merge_button = NULL;
    self->merge_entry = NULL;

    G_OBJECT_CLASS (g_paste_ui_window_parent_class)->dispose (object);
}

static void
g_paste_ui_window_finalize (GObject *object)
{
    GPasteUiWindow *self = G_PASTE_UI_WINDOW (object);

    g_free (self->shell_owner);

    G_OBJECT_CLASS (g_paste_ui_window_parent_class)->finalize (object);
}

static void
g_paste_ui_window_class_init (GPasteUiWindowClass *klass)
{
    GObjectClass *object_class = G_OBJECT_CLASS (klass);

    object_class->dispose = g_paste_ui_window_dispose;
    object_class->finalize = g_paste_ui_window_finalize;
}

static void
g_paste_ui_window_init (GPasteUiWindow *self)
{
    GtkWidget *vbox = gtk_box_new (GTK_ORIENTATION_VERTICAL, 0);

    self->settings = g_paste_settings_new ();
    self->content_box = GTK_BOX (vbox);

    g_signal_connect_object (self->settings,
                             "notify::" G_PASTE_KEYBINDINGS_ENABLED_SETTING,
                             G_CALLBACK (on_shortcuts_enabled_changed),
                             self, G_CONNECT_SWAPPED);
    g_signal_connect_object (self->settings,
                             "rebind",
                             G_CALLBACK (on_shortcuts_obsolete),
                             self, G_CONNECT_SWAPPED);

    gtk_widget_set_hexpand (vbox, TRUE);
    gtk_widget_set_vexpand (vbox, TRUE);
    gtk_widget_set_halign (vbox, GTK_ALIGN_FILL);
    gtk_widget_set_valign (vbox, GTK_ALIGN_FILL);

    GtkWidget *banner = adw_banner_new ("");
    self->banner = ADW_BANNER (banner);
    /* As in g_paste_gtk_util_toast (): what it says is a translation. Said,
     * though libadwaita 1.10 starts a banner with markup off, against its
     * property's default of on, which a later release may honour: no case here
     * can tell the two apart. */
    adw_banner_set_use_markup (self->banner, FALSE);
    g_signal_connect_object (banner, "button-clicked", G_CALLBACK (on_banner_retry), self, 0);
    gtk_box_append (GTK_BOX (vbox), banner);

    /* The banner is the only thing above the split view, and the header bars,
     * the search bar and the merge bar all belong to one page of it or the
     * other -- which is what gives a collapsed window a header of its own to
     * carry the back button. So there is no window-level toolbar view. */
    GtkWidget *toast_overlay = adw_toast_overlay_new ();
    self->toast_overlay = ADW_TOAST_OVERLAY (toast_overlay);
    adw_toast_overlay_set_child (ADW_TOAST_OVERLAY (toast_overlay), vbox);

    adw_application_window_set_content (ADW_APPLICATION_WINDOW (self), toast_overlay);

    self->client_signals = g_signal_group_new (G_PASTE_TYPE_CLIENT);
    g_signal_group_connect (self->client_signals, "notify::history", G_CALLBACK (on_history_changed), self);
    g_signal_group_connect (self->client_signals, "notify::daemon-presence", G_CALLBACK (on_daemon_presence_changed), self);
    g_signal_group_connect (self->client_signals, "notify::g-name-owner", G_CALLBACK (on_daemon_owner_changed), self);
    g_signal_group_connect (self->client_signals, "tracking", G_CALLBACK (on_tracking_changed), self);

    add_shortcuts (self);

    gtk_window_set_default_size (GTK_WINDOW (self), 800, 600);
    /* Not the 360px the HIG asks of an application that means to fit a phone
     * held upright: GPaste is a desktop clipboard manager, its daemon needing
     * an X11 or GNOME Shell clipboard. What sets the width is the history
     * page's header -- New, the title, search, pinned, merge, the menu and the
     * window's own buttons -- which takes about 380px with GNOME's close-only
     * layout, 460px with minimize and maximize too (Ubuntu's, or a Tweaks
     * toggle), and 500px with the window's icon before them as well (KDE
     * Plasma's, "icon:minimize,maximize,close", which is also what GNOME's
     * settings daemon makes of a layout naming the window menu). The window
     * icon grows with the text scale, to about 520px at 1.5, past Large Text's
     * 1.25; 520 fits each layout up to there. Hiding the title below some
     * width instead would hide the selection count along with it. The height
     * is the HIG's: nothing needs more, and a short landscape screen still fits
     * the window. /ui/daemon-presence/minimum-width holds it to this. */
    gtk_widget_set_size_request (GTK_WIDGET (self), 520, 294);
}

/* Everything the window shows of a history, built once there is a proxy to
 * build it on -- whether or not a daemon is there yet, which the parts follow
 * on their own -- and so built from here rather than from init (), which runs
 * before there is one. A proxy that failed to build and was asked for again
 * reaches this with the window already presented, which is what @initialized
 * keeps straight. */
static void
g_paste_ui_window_setup (GPasteUiWindow *self,
                         GPasteClient   *client)
{
    GtkWindow *win = GTK_WINDOW (self);
    GPasteSettings *settings = self->settings;
    GtkWidget *header = g_paste_ui_header_new ();

    /* Built here rather than in init(): there is nothing to search through
     * without a proxy, and a window presented for a proxy that failed to build
     * would only be offering a search bar that could ignore whatever was typed
     * into it. With a proxy but no daemon yet, it is there and typing does not
     * reach it (g_paste_ui_window_update_key_capture ()). */
    GtkWidget *search_bar = gtk_search_bar_new ();
    GtkWidget *search_entry = gtk_search_entry_new ();

    self->search_bar = GTK_SEARCH_BAR (search_bar);
    self->search_entry = GTK_SEARCH_ENTRY (search_entry);
    gtk_search_bar_set_child (self->search_bar, search_entry);
    gtk_search_bar_connect_entry (self->search_bar, GTK_EDITABLE (search_entry));
    gtk_search_bar_set_key_capture_widget (self->search_bar, GTK_WIDGET (self));

    GSignalGroup *search_signals = self->search_signals = g_signal_group_new (GTK_TYPE_SEARCH_ENTRY);
    g_signal_group_connect (search_signals, "activate", G_CALLBACK (on_search_activate), self);
    g_signal_group_connect (search_signals, "search-changed", G_CALLBACK (on_search), self);
    g_signal_group_set_target (search_signals, self->search_entry);

    GtkWidget *panel = g_paste_ui_panel_new (client, settings, win, self->search_entry);
    GtkWidget *history = g_paste_ui_history_new (client, settings, G_PASTE_UI_PANEL (panel), win);

    self->header = ADW_HEADER_BAR (header);
    self->history = G_PASTE_UI_HISTORY (history);
    self->panel = panel;
    self->client = g_object_ref (client);

    add_window_actions (self);

    g_signal_connect_object (g_paste_ui_header_get_merge_button (self->header), "clicked",
                             G_CALLBACK (on_enter_selection_mode), self, 0);
    g_signal_connect_object (g_paste_ui_header_get_cancel_button (self->header), "clicked",
                             G_CALLBACK (on_cancel_selection_mode), self, 0);
    g_signal_connect_object (self->history, "selection-changed",
                             G_CALLBACK (on_selection_changed), self, 0);
    g_signal_connect_object (self->panel, "history-chosen",
                             G_CALLBACK (on_history_chosen), self, 0);

    /* A header bar apiece, which is what the pages need to stand on their own
     * once the split view collapses them into a navigation stack: the sidebar's
     * is bare, so it shows its page's title, and the content's carries ours. */
    GtkWidget *sidebar_view = adw_toolbar_view_new ();
    adw_toolbar_view_add_top_bar (ADW_TOOLBAR_VIEW (sidebar_view), adw_header_bar_new ());
    adw_toolbar_view_set_content (ADW_TOOLBAR_VIEW (sidebar_view), panel);

    GtkWidget *content_view = adw_toolbar_view_new ();
    adw_toolbar_view_add_top_bar (ADW_TOOLBAR_VIEW (content_view), header);
    adw_toolbar_view_add_top_bar (ADW_TOOLBAR_VIEW (content_view), search_bar);
    adw_toolbar_view_set_content (ADW_TOOLBAR_VIEW (content_view), history);
    adw_toolbar_view_add_bottom_bar (ADW_TOOLBAR_VIEW (content_view), build_merge_bar (self));

    AdwNavigationPage *sidebar_page = adw_navigation_page_new (sidebar_view, _("Histories"));
    AdwNavigationPage *content_page = adw_navigation_page_new (content_view, _("History"));

    GtkWidget *nav_split_view = adw_navigation_split_view_new ();
    self->split_view = ADW_NAVIGATION_SPLIT_VIEW (nav_split_view);
    adw_navigation_split_view_set_sidebar (self->split_view, sidebar_page);
    adw_navigation_split_view_set_content (self->split_view, content_page);
    adw_navigation_split_view_set_min_sidebar_width (self->split_view, 240);

    /* See G_PASTE_UI_WINDOW_COLLAPSE_WIDTH. */
    AdwBreakpointCondition *below_px = adw_breakpoint_condition_new_length (ADW_BREAKPOINT_CONDITION_MAX_WIDTH,
                                                                            G_PASTE_UI_WINDOW_COLLAPSE_WIDTH,
                                                                            ADW_LENGTH_UNIT_PX);
    AdwBreakpointCondition *below_sp = adw_breakpoint_condition_new_length (ADW_BREAKPOINT_CONDITION_MAX_WIDTH,
                                                                            G_PASTE_UI_WINDOW_COLLAPSE_WIDTH,
                                                                            ADW_LENGTH_UNIT_SP);
    AdwBreakpoint *breakpoint = adw_breakpoint_new (adw_breakpoint_condition_new_or (below_px, below_sp));
    adw_breakpoint_add_setters (breakpoint, G_OBJECT (nav_split_view), "collapsed", TRUE, NULL);
    adw_application_window_add_breakpoint (ADW_APPLICATION_WINDOW (self), breakpoint);

    /* The history is what the window is for, so it is the page a collapsed
     * window shows -- one opened narrow included, whose on_history_changed ()
     * ran before the breakpoint applied. Set here, where it does nothing until
     * the view collapses, and again whenever it uncollapses
     * (on_split_view_uncollapsed ()), the user having perhaps gone back to the
     * histories before. Never on collapsing: set then, it would push the
     * history page after the sidebar had been shown, and libadwaita would move
     * the focus into the pushed page's header, off the list
     * (/ui/daemon-presence/minimum-width and /ui/daemon-presence/resize). */
    adw_navigation_split_view_set_show_content (self->split_view, TRUE);
    g_signal_connect (nav_split_view, "notify::collapsed", G_CALLBACK (on_split_view_uncollapsed), NULL);

    gtk_widget_set_hexpand (nav_split_view, TRUE);
    gtk_widget_set_vexpand (nav_split_view, TRUE);
    gtk_widget_set_halign (nav_split_view, GTK_ALIGN_FILL);
    gtk_widget_set_valign (nav_split_view, GTK_ALIGN_FILL);

    gtk_box_append (self->content_box, nav_split_view);

    g_object_bind_property (g_paste_ui_header_get_search_button (self->header), "active",
                            self->search_bar, "search-mode-enabled",
                            G_BINDING_BIDIRECTIONAL);

    g_signal_connect_swapped (g_paste_ui_header_get_favourites_button (self->header), "toggled",
                              G_CALLBACK (on_favourites_toggled), self);

    g_signal_group_set_target (self->client_signals, self->client);

    /* On the client's own connection, the one the daemon's owner is read off
     * (g_paste_ui_window_restart_can_help ()). Set up again with a retried
     * client. */
    g_clear_handle_id (&self->shell_watch, g_bus_unwatch_name);
    g_clear_pointer (&self->shell_owner, g_free);
    self->shell_owner_known = FALSE;
    self->shell_watch = g_bus_watch_name_on_connection (g_dbus_proxy_get_connection (G_DBUS_PROXY (self->client)),
                                                        "org.gnome.Shell",
                                                        G_BUS_NAME_WATCHER_FLAGS_NONE,
                                                        on_shell_appeared,
                                                        on_shell_vanished,
                                                        self,
                                                        NULL);

    /* Opening the window is the user asking for a daemon, so one is asked for
     * outright if there is none rather than waited for, which is all the
     * client does on its own. Read after the handlers above are
     * watching, so a daemon moving in between is announced rather than
     * missed -- and read whatever it says, ready included: a retry
     * into a window presented for a failed connection has a banner up
     * that no change of presence would come to take down. */
    g_paste_client_follow_daemon (self->client, TRUE);
    on_daemon_presence_changed (self->client, NULL, self);
    on_history_changed (self->client, NULL, self);

    /* A retry into a window already presented for the banner: it is filling in
     * behind that banner, and the deferred actions ran the moment it went up. */
    if (self->initialized)
        return;

    gtk_window_present (win);
    self->initialized = TRUE;
    g_paste_ui_window_run_deferred_actions (self);
}

static void
on_client_ready (GObject      *source_object G_GNUC_UNUSED,
                 GAsyncResult *res,
                 gpointer      user_data)
{
    /* The window is not presented yet on a first connection -- that is done
     * below, by the setup or the failure alike -- so nothing else would keep it
     * alive if the application quit while we were connecting. */
    g_autoptr (GPasteUiWindow) self = user_data;
    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_finish (res, &error);

    /* The window was destroyed while we were connecting: nothing to set up, and
     * nothing to present. gtk_window_destroy () disposes nothing while our ref
     * stands, its widgets all still there, but it takes the window off GTK's
     * list of toplevels at once (/ui/daemon-presence/closed-while-connecting). */
    if (!g_paste_ui_window_is_toplevel (self))
        return;

    self->connecting = FALSE;

    if (error)
    {
        /* A warning, as in the panel's failed listing. No test builds a client
         * that fails: the bus the suite runs on is always there. */
        g_warning ("Couldn't connect to GPaste: %s", error->message);
        /* No wait here, unlike a daemon that merely went away: building the
         * proxy is what failed -- the session bus unreachable, or a daemon it
         * could not start -- so there is none to follow a daemon with. The
         * banner's button is the whole of the way back. */
        g_paste_ui_window_update_banner (self);

        if (self->initialized)
            return;

        add_daemonless_window_actions (self);
        /* Present anyway: the banner explaining what went wrong is the whole
         * point, and a window that is never shown leaves the application
         * running with nothing on screen at all. Before the deferred actions,
         * so the one that survives a failed connection has a presented window
         * to put its dialog over. */
        gtk_window_present (GTK_WINDOW (self));
        self->initialized = TRUE;
        g_paste_ui_window_run_deferred_actions (self);
        return;
    }

    g_paste_ui_window_setup (self, client);
}

/**
 * g_paste_ui_window_new:
 * @app: the #GtkApplication
 *
 * Create a new instance of #GPasteUiWindow
 *
 * Returns: (transfer none): a new #GPasteUiWindow, owned by GTK's list of
 *          toplevels as every #GtkWindow is: gtk_window_destroy () lets it go
 */
GtkWidget *
g_paste_ui_window_new (GtkApplication *app)
{
    g_return_val_if_fail (GTK_IS_APPLICATION (app), NULL);

    GtkWidget *self = g_object_new (G_PASTE_TYPE_UI_WINDOW,
                                      "application", app,
                                      "resizable",   TRUE,
                                      "title",       PACKAGE_NAME,
                                      "icon-name",   G_PASTE_ICON_NAME,
                                      NULL);

    G_PASTE_UI_WINDOW (self)->connecting = TRUE;
    /* The callback owns this ref (see on_client_ready). */
    g_paste_client_new (on_client_ready, g_object_ref (self));

    return self;
}
