// SPDX-FileCopyrightText: 2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com>
// SPDX-License-Identifier: BSD-2-Clause

/* posix_openpt () and its two companions, for the terminal a case writes to. */
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <gpaste-3/gpaste-error.h>
#include <gpaste-3/gpaste-settings.h>
#include <gpaste-3/gpaste-gsettings-keys.h>
#include <gpaste-3/gpaste-util.h>
#include <gpaste-test-env.h>
#include <glib-unix.h>
#include <glib/gstdio.h>
#include <fcntl.h>
#include <dlfcn.h>
#include <signal.h>
#include <termios.h>
#include <unistd.h>

static guint   signals_sent;
static GError *reexec_error;
static guint   reexecs;

/* How often isatty () was asked, and how many writes reached a stream holding
 * no buffer of its own -- one per stdio call, whichever it is: what printing
 * to a terminal costs. */
static guint terminal_asks;
static guint writes;

int
isatty (int fd)
{
    typedef int (*IsATty) (int);
    IsATty original = (IsATty) dlsym (RTLD_NEXT, "isatty");

    ++terminal_asks;

    return original (fd);
}

static ssize_t
count_write (void       *cookie G_GNUC_UNUSED,
             const char *data   G_GNUC_UNUSED,
             size_t      size)
{
    ++writes;

    return (ssize_t) size;
}

/* Whether nobody owns the name by the time the re-exec goes out, which fails
 * it as the bus does a call starting no daemon, worded as libgpaste hands it
 * out (/client/calls/reexecute-starts-nothing). */
static gboolean owner_gone;

/* The re-exec the CLI asks for, refused with whatever @reexec_error says: the
 * method is what the migration gate has to outlive, and reaching a daemon to
 * have it refuse for real would take one. */
static gboolean
fake_reexecute_daemon (GPasteClient *client G_GNUC_UNUSED,
                       GError      **error)
{
    ++reexecs;
    if (owner_gone)
    {
        g_set_error_literal (error, G_DBUS_ERROR, G_DBUS_ERROR_NAME_HAS_NO_OWNER, "No GPaste daemon is serving a history.");
        return FALSE;
    }

    if (!reexec_error)
        return TRUE;

    /* Guarded like the call it stands in for: @error is optional there. */
    if (error)
        *error = g_error_copy (reexec_error);

    return FALSE;
}

/* Whether a GPaste 45 or 50 owns the name, to be signalled: what makes that so
 * is libgpaste's to tell (/client/presence/legacy). */
static gboolean legacy_owner = TRUE;

static gboolean
fake_reexecute_legacy_daemon (GPasteClient *client G_GNUC_UNUSED,
                              GError      **error)
{
    if (!legacy_owner)
    {
        g_set_error_literal (error, G_PASTE_ERROR, G_PASTE_ERROR_FAILED, "not a legacy daemon");
        return FALSE;
    }

    ++signals_sent;
    return TRUE;
}

/* The presence the faked client reports, READY unless a case says otherwise,
 * and what a wait for the daemon turns it into: a daemon coming up, or none
 * coming -- or, with waited_on_legacy, a GPaste 45 or 50 told apart. What the
 * wait itself does is libgpaste's (/client/presence/wait-for-daemon). */
static GPasteDaemonPresence fake_presence = G_PASTE_DAEMON_PRESENCE_READY;
static GPasteDaemonPresence presence_after_follow = G_PASTE_DAEMON_PRESENCE_READY;
static gboolean             waited_on_legacy;
static guint                follows;

/* What the question about its owner below leaves it at: still starting, unless
 * the owner left (absent) or another came to serve (ready) before the answer
 * came. */
static GPasteDaemonPresence presence_after_question = G_PASTE_DAEMON_PRESENCE_STARTING;

/* Whether the daemon's path serves a GPaste 45 or 50's interface, which
 * libgpaste is asked when its presence reads as starting, or whether the
 * question fails, as on a bus error -- worded as libgpaste hands it out,
 * GDBus' prefix off (/client/presence/legacy-errors). */
static gboolean introspected_legacy;
static gboolean introspection_fails;

static void
fake_daemon_is_legacy (GPasteClient       *client G_GNUC_UNUSED,
                       GCancellable       *cancellable,
                       GAsyncReadyCallback callback,
                       gpointer            user_data)
{
    g_autoptr (GTask) task = g_task_new (NULL, cancellable, callback, user_data);

    fake_presence = presence_after_question;
    if (introspection_fails)
        g_task_return_new_error_literal (task, G_DBUS_ERROR, G_DBUS_ERROR_NO_REPLY, "unanswered");
    else
        g_task_return_boolean (task, introspected_legacy);
}

static gboolean
fake_daemon_is_legacy_finish (GAsyncResult *result,
                              GError      **error)
{
    return g_task_propagate_boolean (G_TASK (result), error);
}

static gchar *daemon_version;

/* The cached Version property, which is empty until the daemon has answered for
 * it and again once it leaves the bus. Faked rather than read off a real proxy,
 * so the empty case needs no daemon to go missing. */
static gchar *
fake_get_version (GPasteClient *client G_GNUC_UNUSED)
{
    return g_strdup (daemon_version);
}

static gchar *uploaded_and_copied;
static const gchar *uploaded_url = "https://paste.rs/x";

/* What `upload-and-copy` has the daemon do, recorded rather than sent: the
 * verb is a thin call, and what matters is that it is UploadAndCopy it makes,
 * not Upload, and with the item it was given. */
static gchar *
fake_upload_and_copy_sync (GPasteClient *client G_GNUC_UNUSED,
                           const gchar  *uuid,
                           GError      **error G_GNUC_UNUSED)
{
    g_set_str (&uploaded_and_copied, uuid);

    return g_strdup (uploaded_url);
}

/* Whether the daemon's name and GNOME Shell's are owned by one connection,
 * which is what the CLI asks the bus: answered here, the fake client being on
 * no bus. */
static gboolean daemon_in_shell_owner;

static GDBusConnection *
fake_proxy_get_connection (GDBusProxy *proxy G_GNUC_UNUSED)
{
    return (daemon_in_shell_owner) ? (GDBusConnection *) &daemon_in_shell_owner : NULL;
}

static gchar *
fake_proxy_get_name_owner (GDBusProxy *proxy G_GNUC_UNUSED)
{
    return (daemon_in_shell_owner) ? g_strdup (":1.42") : NULL;
}

static GVariant *
fake_connection_call_sync (GDBusConnection    *connection G_GNUC_UNUSED,
                           const gchar        *bus_name G_GNUC_UNUSED,
                           const gchar        *object_path G_GNUC_UNUSED,
                           const gchar        *interface_name G_GNUC_UNUSED,
                           const gchar        *method_name,
                           GVariant           *parameters,
                           const GVariantType *reply_type G_GNUC_UNUSED,
                           GDBusCallFlags      flags G_GNUC_UNUSED,
                           gint                timeout G_GNUC_UNUSED,
                           GCancellable       *cancellable G_GNUC_UNUSED,
                           GError            **error G_GNUC_UNUSED)
{
    g_autoptr (GVariant) owned = g_variant_ref_sink (parameters);
    const gchar *name = NULL;

    g_assert_cmpstr (method_name, ==, "GetNameOwner");
    g_variant_get (owned, "(&s)", &name);
    g_assert_cmpstr (name, ==, "org.gnome.Shell");

    return g_variant_ref_sink (g_variant_new ("(s)", ":1.42"));
}

/* The uuid of the faked daemon's item @n, a hex digit. */
#define FAKE_UUID(n) "00000000-0000-4000-8000-00000000000" #n

/* The history the faked daemon answers --use-index lookups from, newest
 * first, and the item a copy puts at its head right after each answer, when
 * @copied_after_answer names one -- the interleaving one command line's
 * lookups have to be safe from. */
static GPtrArray *fake_history;
static const gchar *copied_after_answer;
static guint clients_created;
static guint index_lookups;
static guint item_reads;
static guint history_reads;
static gchar *deleted_uuid;
static GStrv merged_uuids;
static gchar *added_text;
static gchar *search_pattern;

static void
set_fake_history (const gchar * const *uuids)
{
    g_clear_pointer (&fake_history, g_ptr_array_unref);
    fake_history = g_ptr_array_new_with_free_func (g_free);
    for (const gchar * const *uuid = uuids; *uuid; ++uuid)
        g_ptr_array_add (fake_history, g_strdup (*uuid));

    copied_after_answer = NULL;
    index_lookups = 0;
    history_reads = 0;
}

static void
fake_history_answered (void)
{
    if (copied_after_answer)
        g_ptr_array_insert (fake_history, 0, g_strdup (copied_after_answer));
}

/* What every item of the fake history holds. */
static const gchar *fake_value = "value";

static GPasteClientItem *
fake_item (guint index)
{
    return g_paste_client_item_new (g_ptr_array_index (fake_history, index), fake_value, G_PASTE_ITEM_KIND_TEXT, FALSE, NULL);
}

static GPasteClient *
fake_client_new_sync (GError **error G_GNUC_UNUSED)
{
    ++clients_created;
    return g_object_new (G_PASTE_TYPE_CLIENT, NULL);
}

static GPasteClientItem *
fake_get_item_at_index_sync (GPasteClient *client G_GNUC_UNUSED,
                             guint64       index,
                             GError      **error)
{
    ++index_lookups;

    if (index >= fake_history->len)
    {
        g_set_error_literal (error, G_PASTE_ERROR, G_PASTE_ERROR_INVALID_INDEX, "invalid index received");
        return NULL;
    }

    GPasteClientItem *item = fake_item (index);

    fake_history_answered ();
    return item;
}

static GList *
fake_get_history_sync (GPasteClient *client G_GNUC_UNUSED,
                       GError      **error G_GNUC_UNUSED)
{
    GList *history = NULL;

    ++history_reads;
    for (guint i = fake_history->len; i > 0; --i)
        history = g_list_prepend (history, fake_item (i - 1));

    fake_history_answered ();
    return history;
}

static GPasteClientItem *
fake_get_item_sync (GPasteClient *client G_GNUC_UNUSED,
                    const gchar  *uuid,
                    GError      **error G_GNUC_UNUSED)
{
    ++item_reads;
    return g_paste_client_item_new (uuid, fake_value, G_PASTE_ITEM_KIND_TEXT, FALSE, NULL);
}

static void
fake_delete_item_sync (GPasteClient *client G_GNUC_UNUSED,
                       const gchar  *uuid,
                       GError      **error G_GNUC_UNUSED)
{
    g_set_str (&deleted_uuid, uuid);
}

static gchar *
fake_merge_sync (GPasteClient        *client G_GNUC_UNUSED,
                 const gchar         *decoration G_GNUC_UNUSED,
                 const gchar         *separator G_GNUC_UNUSED,
                 const gchar * const *uuids,
                 GError             **error G_GNUC_UNUSED)
{
    g_set_strv (&merged_uuids, uuids);
    return g_strdup (FAKE_UUID (f));
}

static gchar *
fake_add_text_sync (GPasteClient *client G_GNUC_UNUSED,
                    const gchar  *text,
                    GError      **error G_GNUC_UNUSED)
{
    g_set_str (&added_text, text);
    return g_strdup (FAKE_UUID (f));
}

static gchar *added_password;
static guint  added_timeout;

static gchar *
fake_add_password_sync (GPasteClient *client G_GNUC_UNUSED,
                        const gchar  *name   G_GNUC_UNUSED,
                        const gchar  *password,
                        guint         timeout,
                        GError      **error  G_GNUC_UNUSED)
{
    g_set_str (&added_password, password);
    added_timeout = timeout;
    return g_strdup (FAKE_UUID (f));
}

/* The positions in the faked history of the items a search answers, in the
 * order it answers them, -1 ending the list; none when %NULL. */
static const gint *search_matches;

static GList *
fake_search_sync (GPasteClient *client G_GNUC_UNUSED,
                  const gchar  *pattern,
                  GError      **error G_GNUC_UNUSED)
{
    GList *items = NULL;

    g_set_str (&search_pattern, pattern);
    for (const gint *match = search_matches; match && *match >= 0; ++match)
        items = g_list_append (items, fake_item ((guint) *match));

    return items;
}

/* A third history the listing names, when set. */
static const gchar *fake_history_name;

static GList *
fake_list_histories_sync (GPasteClient *client G_GNUC_UNUSED,
                          GError      **error  G_GNUC_UNUSED)
{
    GList *histories = g_list_append (NULL, g_paste_client_history_new ("work", 1));

    histories = g_list_append (histories, g_paste_client_history_new ("two\nlines", 2));
    if (fake_history_name)
        histories = g_list_append (histories, g_paste_client_history_new (fake_history_name, 3));

    return histories;
}

static GPasteDaemonPresence
fake_get_daemon_presence (GPasteClient *client G_GNUC_UNUSED)
{
    return fake_presence;
}

static void
fake_wait_for_daemon (GPasteClient       *client G_GNUC_UNUSED,
                      GCancellable       *cancellable,
                      GAsyncReadyCallback callback,
                      gpointer            user_data)
{
    g_autoptr (GTask) task = g_task_new (NULL, cancellable, callback, user_data);

    if (fake_presence != G_PASTE_DAEMON_PRESENCE_READY)
    {
        ++follows;
        fake_presence = presence_after_follow;
    }

    if (waited_on_legacy)
        g_task_return_new_error (task, G_IO_ERROR, G_IO_ERROR_NOT_CONNECTED, "older: restart it with “gpaste-client daemon-reexec”");
    else if (fake_presence == G_PASTE_DAEMON_PRESENCE_READY)
        g_task_return_boolean (task, TRUE);
    else
        g_task_return_new_error (task, G_IO_ERROR, G_IO_ERROR_NOT_CONNECTED, "none serving");
}

static gboolean
fake_wait_for_daemon_finish (GAsyncResult *result,
                             GError      **error)
{
    return g_task_propagate_boolean (G_TASK (result), error);
}

/* What the check answers: its report and whether it left anything wrong, or
 * @doctor_error. */
static const gchar * const *doctor_report;
static gboolean             doctor_healthy;
static GError              *doctor_error;

static GStrv
fake_doctor_sync (GPasteClient *client G_GNUC_UNUSED,
                  gboolean     *healthy,
                  GError      **error)
{
    if (doctor_error)
    {
        g_propagate_error (error, g_error_copy (doctor_error));
        return NULL;
    }

    *healthy = doctor_healthy;

    return g_strdupv ((gchar **) doctor_report);
}

/* Exercise the CLI's actual fallback while keeping signals inside this test. */
#define main gpaste_client_main
#define g_paste_util_reexecute_legacy_daemon fake_reexecute_legacy_daemon
#define g_paste_util_reexecute_daemon fake_reexecute_daemon
#define g_paste_client_get_version fake_get_version
#define g_paste_client_upload_and_copy_sync fake_upload_and_copy_sync
#define g_paste_client_new_sync fake_client_new_sync
#define g_paste_client_get_item_at_index_sync fake_get_item_at_index_sync
#define g_paste_client_get_history_sync fake_get_history_sync
#define g_paste_client_get_item_sync fake_get_item_sync
#define g_paste_client_delete_item_sync fake_delete_item_sync
#define g_paste_client_merge_sync fake_merge_sync
#define g_paste_client_add_text_sync fake_add_text_sync
#define g_paste_client_search_sync fake_search_sync
#define g_paste_client_add_password_sync fake_add_password_sync
#define g_paste_client_list_histories_sync fake_list_histories_sync
#define g_paste_client_get_daemon_presence fake_get_daemon_presence
#define g_paste_client_doctor_sync fake_doctor_sync
#define g_paste_util_wait_for_daemon fake_wait_for_daemon
#define g_paste_util_wait_for_daemon_finish fake_wait_for_daemon_finish
#define g_paste_util_daemon_is_legacy fake_daemon_is_legacy
#define g_paste_util_daemon_is_legacy_finish fake_daemon_is_legacy_finish
#define g_dbus_proxy_get_connection fake_proxy_get_connection
#define g_dbus_proxy_get_name_owner fake_proxy_get_name_owner
#define g_dbus_connection_call_sync fake_connection_call_sync
#include "../../src/client/gpaste-client.c"
#undef g_dbus_connection_call_sync
#undef g_dbus_proxy_get_name_owner
#undef g_dbus_proxy_get_connection
#undef g_paste_util_wait_for_daemon_finish
#undef g_paste_util_wait_for_daemon
#undef g_paste_client_doctor_sync
#undef g_paste_client_get_daemon_presence
#undef g_paste_client_list_histories_sync
#undef g_paste_client_add_password_sync
#undef g_paste_client_search_sync
#undef g_paste_client_add_text_sync
#undef g_paste_client_merge_sync
#undef g_paste_client_delete_item_sync
#undef g_paste_client_get_item_sync
#undef g_paste_client_get_history_sync
#undef g_paste_client_get_item_at_index_sync
#undef g_paste_client_new_sync
#undef g_paste_client_upload_and_copy_sync
#undef g_paste_client_get_version
#undef g_paste_util_reexecute_daemon
#undef g_paste_util_reexecute_legacy_daemon
#undef main

/* `gpaste-client` @args as a shell would run it, getopt () rewound first: it
 * keeps its place across calls, and every case parses a command line anew. */
static gint
run_client (const gchar * const *args)
{
    g_autoptr (GStrvBuilder) builder = g_strv_builder_new ();

    g_strv_builder_add (builder, "gpaste-client");
    g_strv_builder_addv (builder, (const gchar **) args);

    g_auto (GStrv) argv = g_strv_builder_end (builder);

    optind = 0;
    return gpaste_client_main ((gint) g_strv_length (argv), argv);
}

/* An index names a place in the history, and a single one is looked up there
 * on its own. */
static void
test_item_index (void)
{
    set_fake_history ((const gchar *[]) { FAKE_UUID (a), FAKE_UUID (b), FAKE_UUID (c), NULL });

    g_assert_cmpint (run_client ((const gchar *[]) { "--use-index", "delete", "1", NULL }), ==, EXIT_SUCCESS);
    g_assert_cmpstr (deleted_uuid, ==, FAKE_UUID (b));
    g_assert_cmpuint (index_lookups, ==, 1);
    g_assert_cmpuint (history_reads, ==, 0);
    g_clear_pointer (&deleted_uuid, g_free);

    /* The item looked up is the one get prints, not read a second time. */
    g_assert_cmpint (run_client ((const gchar *[]) { "--use-index", "get", "1", NULL }), ==, EXIT_SUCCESS);
    g_assert_cmpuint (index_lookups, ==, 2);
    g_assert_cmpuint (item_reads, ==, 0);
}

/* A re-exec of a daemon GNOME Shell runs restarts nothing, the Shell keeping
 * the code it loaded, and says so rather than claim the updated daemon runs. */
static void
test_reexec_in_shell (void)
{
    if (!g_test_subprocess ())
    {
        g_test_trap_subprocess (NULL, 0, G_TEST_SUBPROCESS_DEFAULT);
        g_test_trap_assert_passed ();
        g_test_trap_assert_stdout ("*GNOME Shell runs the daemon*log out and back in*");
        g_test_trap_assert_stdout_unmatched ("*Successfully*");
        return;
    }

    daemon_in_shell_owner = TRUE;
    g_assert_cmpint (run_client ((const gchar *[]) { "daemon-reexec", NULL }), ==, EXIT_SUCCESS);
    daemon_in_shell_owner = FALSE;
}

/* Anything but a complete unsigned decimal number names no item, and is
 * refused before anything is looked up -- a vertical tab in front included,
 * which g_ascii_string_to_unsigned () alone lets through -- and before a
 * client is built: refusing it needs no daemon started. */
static void
test_malformed_index (void)
{
    const gchar *malformed[] = { "abc", "1x", "", "-1", "+1", " 1", "1 ", "0x1", "\v1", "\v-1", "18446744073709551616" };

    set_fake_history ((const gchar *[]) { FAKE_UUID (a), FAKE_UUID (b), FAKE_UUID (c), NULL });
    clients_created = 0;

    for (guint i = 0; i < G_N_ELEMENTS (malformed); ++i)
    {
        Context ctx = {
            .argc = 1,
            .args = (const gchar *[]) { malformed[i], NULL },
            .use_index = TRUE,
        };
        g_autoptr (GError) error = NULL;

        g_assert_cmpint (g_paste_dispatch (2, "delete", &ctx, &error), ==, EXIT_FAILURE);
        g_assert_error (error, G_PASTE_ERROR, G_PASTE_ERROR_INVALID_ARGUMENT);
        g_assert_null (deleted_uuid);
        g_assert_cmpuint (clients_created, ==, 0);
    }

    /* A merge's indexes are all checked before its one listing is read. */
    Context ctx = {
        .argc = 2,
        .args = (const gchar *[]) { "0", "abc", NULL },
        .use_index = TRUE,
    };
    g_autoptr (GError) error = NULL;

    g_assert_cmpint (g_paste_dispatch (3, "merge", &ctx, &error), ==, EXIT_FAILURE);
    g_assert_error (error, G_PASTE_ERROR, G_PASTE_ERROR_INVALID_ARGUMENT);
    g_assert_null (merged_uuids);
    g_assert_cmpuint (index_lookups, ==, 0);
    g_assert_cmpuint (history_reads, ==, 0);
    g_assert_cmpuint (clients_created, ==, 0);
}

/* A command that never talks to the daemon builds no client, which is what has
 * D-Bus start one -- and neither does a verb nobody knows, answered with the
 * help. */
static void
test_daemonless_commands (void)
{
    const gchar *lines[][2] = { { "version", NULL }, { "help", NULL }, { "--version", NULL }, { "--help", NULL } };

    clients_created = 0;

    for (guint i = 0; i < G_N_ELEMENTS (lines); ++i)
        g_assert_cmpint (run_client (lines[i]), ==, EXIT_SUCCESS);

    g_assert_cmpint (run_client ((const gchar *[]) { "no-such-verb", NULL }), ==, EXIT_FAILURE);
    g_assert_cmpuint (clients_created, ==, 0);
}

/* Every argument of merge names an item, and all of them are read off the same
 * listing: the copy landing after the first answer would otherwise have the
 * second index name the first item again. */
static void
test_merge_indexes (void)
{
    set_fake_history ((const gchar *[]) { FAKE_UUID (a), FAKE_UUID (b), FAKE_UUID (c), NULL });
    copied_after_answer = FAKE_UUID (d);

    g_assert_cmpint (run_client ((const gchar *[]) { "--use-index", "merge", "0", "1", NULL }), ==, EXIT_SUCCESS);
    g_assert_cmpstrv (merged_uuids, ((const gchar *[]) { FAKE_UUID (a), FAKE_UUID (b), NULL }));
    g_assert_cmpuint (history_reads, ==, 1);
    g_assert_cmpuint (index_lookups, ==, 0);
    g_clear_pointer (&merged_uuids, g_strfreev);
}

/* Past the end of the history, several indexes are refused the way a single
 * one is: nothing is merged. */
static void
test_merge_past_end (void)
{
    g_autoptr (GPasteClient) client = fake_client_new_sync (NULL);
    Context ctx = {
        .client = client,
        .argc = 2,
        .args = (const gchar *[]) { "0", "3", NULL },
        .use_index = TRUE,
    };
    g_autoptr (GError) error = NULL;

    set_fake_history ((const gchar *[]) { FAKE_UUID (a), FAKE_UUID (b), FAKE_UUID (c), NULL });

    g_assert_cmpint (g_paste_dispatch (3, "merge", &ctx, &error), ==, EXIT_FAILURE);
    g_assert_error (error, G_PASTE_ERROR, G_PASTE_ERROR_INVALID_INDEX);
    g_assert_null (merged_uuids);
}

/* Text, a pattern, a name or a path is no index, and an empty history has no
 * item to look any of them up as. */
static void
test_nonitem_arguments (void)
{
    set_fake_history ((const gchar *[]) { NULL });

    g_assert_cmpint (run_client ((const gchar *[]) { "--use-index", "add", "hello", NULL }), ==, EXIT_SUCCESS);
    g_assert_cmpint (run_client ((const gchar *[]) { "--use-index", "search", "hello", NULL }), ==, EXIT_SUCCESS);
    g_assert_cmpstr (added_text, ==, "hello");
    g_assert_cmpstr (search_pattern, ==, "hello");
    g_assert_cmpuint (index_lookups, ==, 0);
    g_assert_cmpuint (history_reads, ==, 0);
    g_clear_pointer (&added_text, g_free);
    g_clear_pointer (&search_pattern, g_free);
}

/* Every string a command could send the daemon has to be UTF-8, and is checked
 * before a client is even built: each argument of each verb that talks to the
 * daemon, the text piped in for one, and merge's decoration and separator. */
static void
test_utf8_refused (void)
{
    gchar invalid[] = { (gchar) 0xff, '\0' };
    Context piped = { .pipe_data = invalid };
    Context decorated = { .argc = 2, .args = (const gchar *[]) { "0", "1", NULL }, .decoration = invalid };
    Context separated = { .argc = 2, .args = (const gchar *[]) { "0", "1", NULL }, .separator = invalid };

    clients_created = 0;

    for (guint64 i = 0; i < G_N_ELEMENTS (commands); ++i)
    {
        const Command *c = &commands[i];
        gint count = c->argc - 1 + ((c->extra_args == G_MAXINT) ? 0 : c->extra_args);

        if (!c->verb || !c->needs_client)
            continue;

        /* Each argument in turn, the others valid, at the most arguments the
         * verb takes, and at the fewest with a pipe standing in for the last. */
        for (gint position = 0; position < count; ++position)
        {
            g_autoptr (GStrvBuilder) builder = g_strv_builder_new ();

            for (gint j = 0; j < count; ++j)
                g_strv_builder_add (builder, (j == position) ? invalid : "0");

            g_auto (GStrv) args = g_strv_builder_end (builder);
            Context ctx = { .argc = count, .args = (const gchar **) args };
            g_autoptr (GError) error = NULL;

            g_assert_cmpint (g_paste_dispatch (count + 1, c->verb, &ctx, &error), ==, EXIT_FAILURE);
            g_assert_error (error, G_PASTE_ERROR, G_PASTE_ERROR_INVALID_ARGUMENT);
        }

        if (c->reads_pipe)
        {
            Context ctx = { .argc = c->argc - 1, .args = (const gchar *[]) { "0", NULL }, .pipe_data = invalid };
            g_autoptr (GError) error = NULL;

            g_assert_cmpint (g_paste_dispatch (c->argc, c->verb, &ctx, &error), ==, EXIT_FAILURE);
            g_assert_error (error, G_PASTE_ERROR, G_PASTE_ERROR_INVALID_ARGUMENT);
        }
    }

    g_autoptr (GError) error = NULL;

    g_assert_cmpint (g_paste_dispatch (0, NULL, &piped, &error), ==, EXIT_FAILURE);
    g_assert_error (error, G_PASTE_ERROR, G_PASTE_ERROR_INVALID_ARGUMENT);
    g_clear_error (&error);

    g_assert_cmpint (g_paste_dispatch (3, "merge", &decorated, &error), ==, EXIT_FAILURE);
    g_assert_error (error, G_PASTE_ERROR, G_PASTE_ERROR_INVALID_ARGUMENT);
    g_clear_error (&error);

    g_assert_cmpint (g_paste_dispatch (3, "merge", &separated, &error), ==, EXIT_FAILURE);
    g_assert_error (error, G_PASTE_ERROR, G_PASTE_ERROR_INVALID_ARGUMENT);

    g_assert_cmpuint (clients_created, ==, 0);
}

/* What is UTF-8 goes through, from an argument or a pipe alike. */
static void
test_utf8_accepted (void)
{
    Context piped = { .pipe_data = (gchar *) "pipé" };
    g_autoptr (GError) error = NULL;

    g_assert_cmpint (run_client ((const gchar *[]) { "add", "héllo", NULL }), ==, EXIT_SUCCESS);
    g_assert_cmpstr (added_text, ==, "héllo");

    g_assert_cmpint (g_paste_dispatch (0, NULL, &piped, &error), ==, EXIT_SUCCESS);
    g_assert_no_error (error);
    g_assert_cmpstr (added_text, ==, "pipé");
    g_clear_object (&piped.client);
    g_clear_pointer (&added_text, g_free);
}

static void
test_upload_and_copy (void)
{
    Context ctx = { .argc = 1, .args = (const gchar *[]) { "item", NULL } };
    g_autoptr (GError) error = NULL;

    g_assert_cmpint (g_paste_upload_and_copy (&ctx, &error), ==, EXIT_SUCCESS);
    g_assert_no_error (error);
    g_assert_cmpstr (uploaded_and_copied, ==, "item");
    g_clear_pointer (&uploaded_and_copied, g_free);
}

static void
test_refusal (void)
{
    g_autoptr (GError) error = g_error_new_literal (G_PASTE_ERROR, G_PASTE_ERROR_FAILED, "Expiry deadline");

    signals_sent = 0;
    g_assert_false (reexec_fallback (NULL, FALSE, &error));
    g_assert_error (error, G_PASTE_ERROR, G_PASTE_ERROR_FAILED);
    g_assert_cmpuint (signals_sent, ==, 0);
}

static void
test_unsupported (void)
{
    g_autoptr (GError) error = g_error_new_literal (G_DBUS_ERROR, G_DBUS_ERROR_UNKNOWN_METHOD, "Unknown method");

    signals_sent = 0;
    g_assert_true (reexec_fallback (NULL, FALSE, &error));
    g_assert_no_error (error);
    g_assert_cmpuint (signals_sent, ==, 1);
}

/* An unknown method from a daemon libgpaste will not signal -- a pid file
 * naming another process than the name's owner -- leaves the error standing,
 * bar a current one settling its storage behind a prompt, which is said to be
 * starting. */
static void
test_unsupported_not_legacy (void)
{
    g_autoptr (GError) error = g_error_new_literal (G_DBUS_ERROR, G_DBUS_ERROR_UNKNOWN_METHOD, "Unknown method");

    signals_sent = 0;
    legacy_owner = FALSE;
    g_assert_false (reexec_fallback (NULL, FALSE, &error));
    g_assert_error (error, G_DBUS_ERROR, G_DBUS_ERROR_UNKNOWN_METHOD);
    g_assert_cmpuint (signals_sent, ==, 0);
    g_clear_error (&error);

    /* A daemon of this version still starting is said to be, rather than left
     * to GDBus' words for a path with no object. */
    error = g_error_new_literal (G_DBUS_ERROR, G_DBUS_ERROR_UNKNOWN_METHOD, "Unknown method");
    fake_presence = G_PASTE_DAEMON_PRESENCE_STARTING;
    g_assert_false (reexec_fallback (NULL, FALSE, &error));
    fake_presence = G_PASTE_DAEMON_PRESENCE_READY;
    g_assert_error (error, G_PASTE_ERROR, G_PASTE_ERROR_FAILED);
    g_assert_nonnull (strstr (error->message, "still starting"));
    g_assert_cmpuint (signals_sent, ==, 0);
    g_clear_error (&error);

    /* A GPaste 45 or 50 reads as starting too, never serving this interface:
     * its unknown method stands, there being nothing to wait for. */
    error = g_error_new_literal (G_DBUS_ERROR, G_DBUS_ERROR_UNKNOWN_METHOD, "Unknown method");
    fake_presence = G_PASTE_DAEMON_PRESENCE_STARTING;
    introspected_legacy = TRUE;
    g_assert_false (reexec_fallback (NULL, FALSE, &error));
    fake_presence = G_PASTE_DAEMON_PRESENCE_READY;
    introspected_legacy = FALSE;
    g_assert_error (error, G_DBUS_ERROR, G_DBUS_ERROR_UNKNOWN_METHOD);
    legacy_owner = TRUE;
}

/* migrate's handler, against a daemon of this version still starting -- one
 * starting again since the wait for it, a re-exec of its own say -- opens no
 * gate it would close again under it, and asks no re-exec, nor against an
 * owner that could not be told apart from one; against a GPaste 45 or 50,
 * which reads as starting too, the signal goes out. */
static void
test_migrate_starting (void)
{
    g_autoptr (GPasteSettings) settings = g_paste_settings_new ();
    Context ctx = { 0 };
    g_autoptr (GError) error = NULL;

    g_paste_settings_set_storage_backend_revision (settings, 37);
    fake_presence = G_PASTE_DAEMON_PRESENCE_STARTING;
    reexecs = 0;
    g_assert_cmpint (g_paste_migrate (&ctx, &error), ==, EXIT_FAILURE);
    g_assert_error (error, G_PASTE_ERROR, G_PASTE_ERROR_FAILED);
    g_assert_nonnull (strstr (error->message, "still starting"));
    g_assert_cmpuint (reexecs, ==, 0);
    g_assert_cmpuint (g_paste_settings_get_storage_backend_revision (settings), ==, 37);
    g_clear_error (&error);

    /* An owner the question could not reach, answering a re-exec as one still
     * starting would: refused before the gate opens, with the question's own
     * failure. */
    introspection_fails = TRUE;
    legacy_owner = FALSE;
    reexec_error = g_error_new_literal (G_DBUS_ERROR, G_DBUS_ERROR_UNKNOWN_METHOD, "Unknown method");
    g_assert_cmpint (g_paste_migrate (&ctx, &error), ==, EXIT_FAILURE);
    g_assert_error (error, G_DBUS_ERROR, G_DBUS_ERROR_NO_REPLY);
    g_assert_nonnull (strstr (error->message, "no migration was asked for: unanswered"));
    g_assert_cmpuint (reexecs, ==, 0);
    g_assert_cmpuint (g_paste_settings_get_storage_backend_revision (settings), ==, 37);
    g_clear_error (&error);
    g_clear_error (&reexec_error);
    legacy_owner = TRUE;
    introspection_fails = FALSE;

    introspected_legacy = TRUE;
    signals_sent = 0;
    reexec_error = g_error_new_literal (G_DBUS_ERROR, G_DBUS_ERROR_UNKNOWN_METHOD, "Unknown method");
    g_assert_cmpint (g_paste_migrate (&ctx, &error), ==, EXIT_SUCCESS);
    g_assert_no_error (error);
    g_assert_cmpuint (signals_sent, ==, 1);
    g_assert_cmpuint (g_paste_settings_get_storage_backend_revision (settings), ==, 0);

    introspected_legacy = FALSE;
    fake_presence = G_PASTE_DAEMON_PRESENCE_READY;
    g_clear_error (&reexec_error);
    g_paste_settings_reset (settings, G_PASTE_STORAGE_BACKEND_REVISION_SETTING);
}

/* `gpaste-client migrate` opens the migration gate, and what closes it again is
 * *both* routes to a re-exec having failed. A daemon too old for the method is
 * re-exec'd by signal instead, and the successor has to find the gate open: it
 * is the one that runs the migration the user asked for, and this prints a
 * success either way.
 *
 * @user_data says whether that fallback applies. A refusal the daemon made
 * itself has no second route, so the gate is closed and the revision the
 * migration was asked under is back.
 */
static void
test_migrate_gate (gconstpointer user_data)
{
    gboolean unsupported = GPOINTER_TO_INT (user_data);
    g_autoptr (GPasteSettings) settings = g_paste_settings_new ();
    Context ctx = { 0 };
    g_autoptr (GError) error = NULL;

    signals_sent = 0;
    reexec_error = (unsupported) ? g_error_new_literal (G_DBUS_ERROR, G_DBUS_ERROR_UNKNOWN_METHOD, "Unknown method")
                                 : g_error_new_literal (G_PASTE_ERROR, G_PASTE_ERROR_FAILED, "Expiry deadline");
    g_paste_settings_set_storage_backend_revision (settings, 37);

    g_assert_cmpint (g_paste_migrate (&ctx, &error), ==, (unsupported) ? EXIT_SUCCESS : EXIT_FAILURE);
    g_assert_cmpuint (signals_sent, ==, unsupported);
    g_assert_cmpuint (g_paste_settings_get_storage_backend_revision (settings), ==, (unsupported) ? 0 : 37);
    if (unsupported)
        g_assert_no_error (error);
    else
        g_assert_error (error, G_PASTE_ERROR, G_PASTE_ERROR_FAILED);

    g_clear_error (&reexec_error);
    g_paste_settings_reset (settings, G_PASTE_STORAGE_BACKEND_REVISION_SETTING);
}

/* A daemon that has not answered for its version yet, or that is not on the bus
 * at all, leaves the cached property empty, and the verb has to report that
 * rather than print it: gcc compiles its printf ("%s\n", ...) into a puts (),
 * which unlike printf () does not spell a %NULL out. */
static void
test_daemon_version (gconstpointer user_data)
{
    Context ctx = { 0 };
    g_autoptr (GError) error = NULL;

    daemon_version = (gchar *) user_data;

    g_assert_cmpint (g_paste_daemon_version (&ctx, &error), ==, (daemon_version) ? EXIT_SUCCESS : EXIT_FAILURE);
    if (daemon_version)
        g_assert_no_error (error);
    else
        g_assert_error (error, G_PASTE_ERROR, G_PASTE_ERROR_NOT_FOUND);
}

/* Which command lines go near stdin at all. extract_pipe_data () reads it to
 * its end, and a script that leaves its own stdin open never provides one, so a
 * verb answered without a pipe must never be waiting behind one -- the flag
 * actions above all, which are answered before any verb is looked at. */
static void
test_reads_stdin (void)
{
    Context ctx = { 0 };

    /* Nothing but a pipe, and the three verbs whose last argument it stands in
     * for when that argument is missing. */
    g_assert_true (dispatch_reads_stdin (0, NULL, &ctx));
    g_assert_true (dispatch_reads_stdin (1, "add", &ctx));
    g_assert_true (dispatch_reads_stdin (1, "a", &ctx));
    g_assert_true (dispatch_reads_stdin (2, "add-password", &ctx));
    g_assert_true (dispatch_reads_stdin (2, "replace", &ctx));

    /* The argument is there, so there is nothing to take from a pipe. */
    g_assert_false (dispatch_reads_stdin (2, "add", &ctx));
    g_assert_false (dispatch_reads_stdin (3, "add-password", &ctx));
    g_assert_false (dispatch_reads_stdin (3, "replace", &ctx));
    g_assert_false (dispatch_reads_stdin (1, "history", &ctx));
    g_assert_false (dispatch_reads_stdin (1, "version", &ctx));

    /* --help and --version carry no verb, which is the shape the verb-less add
     * has too -- and they are answered before it. */
    ctx.help = TRUE;
    g_assert_false (dispatch_reads_stdin (0, NULL, &ctx));

    ctx.help = FALSE;
    ctx.version = TRUE;
    g_assert_false (dispatch_reads_stdin (0, NULL, &ctx));

    /* Each option only the listing reads -- --favourites, --use-index,
     * --oneline, --raw, --reverse and --zero -- makes a verb-less line the
     * listing, and leaves a verb's own pipe alone, --use-index with replace
     * <index> above all. */
    ctx.version = FALSE;
    for (const gchar *letter = "fiorez"; *letter; ++letter)
    {
        ctx.given = option_bit (*letter);
        g_assert_false (dispatch_reads_stdin (0, NULL, &ctx));
        g_assert_true (dispatch_reads_stdin (1, "add", &ctx));
        g_assert_true (dispatch_reads_stdin (2, "replace", &ctx));
    }

    /* One the listing does not own leaves a verb-less line the pipe's. */
    for (const gchar *letter = "tds"; *letter; ++letter)
    {
        ctx.given = option_bit (*letter);
        g_assert_true (dispatch_reads_stdin (0, NULL, &ctx));
    }
}

/* @length bytes of @contents as the client's stdin, from a file of their own. */
static void
stdin_from (const gchar *contents,
            gsize        length)
{
    g_autofree gchar *path = NULL;
    gint fd = g_file_open_tmp ("gpaste-client-stdin-XXXXXX", &path, NULL);

    g_assert_cmpint (fd, >=, 0);
    g_assert_cmpint (write (fd, contents, length), ==, (gssize) length);
    g_assert_cmpint (lseek (fd, 0, SEEK_SET), ==, 0);
    g_assert_cmpint (dup2 (fd, STDIN_FILENO), ==, STDIN_FILENO);
    g_assert_true (g_close (fd, NULL));
    g_assert_cmpint (g_unlink (path), ==, 0);
    clearerr (stdin);
}

/* Piped input is read whole or refused: a NUL in it, which no D-Bus string can
 * carry, is not where it ends, and neither is a read that fails. */
static void
test_pipe_refusals (void)
{
    if (!g_test_subprocess ())
    {
        g_test_trap_subprocess (NULL, 0, G_TEST_SUBPROCESS_DEFAULT);
        g_test_trap_assert_passed ();
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autofree gchar *data = NULL;

    gboolean unreadable = FALSE;

    stdin_from ("a\0b", 3);
    g_assert_false (extract_pipe_data (&data, &unreadable, &error));
    g_assert_error (error, G_PASTE_ERROR, G_PASTE_ERROR_INVALID_ARGUMENT);
    g_assert_false (unreadable);
    g_assert_null (data);
    g_clear_error (&error);

    gint directory = g_open (g_get_tmp_dir (), O_RDONLY | O_DIRECTORY | O_CLOEXEC, 0);

    g_assert_cmpint (directory, >=, 0);
    g_assert_cmpint (dup2 (directory, STDIN_FILENO), ==, STDIN_FILENO);
    g_assert_true (g_close (directory, NULL));
    clearerr (stdin);
    g_assert_false (extract_pipe_data (&data, &unreadable, &error));
    g_assert_error (error, G_IO_ERROR, G_IO_ERROR_IS_DIRECTORY);
    g_assert_true (unreadable);
    g_assert_null (data);
    g_clear_error (&error);

    stdin_from ("piped", 5);
    g_assert_true (extract_pipe_data (&data, &unreadable, &error));
    g_assert_no_error (error);
    g_assert_cmpstr (data, ==, "piped");
}

/* The rest of the input, written and its pipe closed once the client is
 * waiting on it. */
static gpointer
write_rest (gpointer user_data)
{
    gint writer = GPOINTER_TO_INT (user_data);

    g_usleep (200 * G_TIME_SPAN_MILLISECOND);
    g_assert_cmpint (write (writer, "c", 1), ==, 1);
    g_assert_true (g_close (writer, NULL));

    return NULL;
}

/* A stdin its parent left non-blocking is read on as the input comes in, to
 * its end, where EAGAIN would cut it short: "ab" there before the read, the "c"
 * only once it is waiting. */
static void
test_pipe_nonblocking (void)
{
    if (!g_test_subprocess ())
    {
        g_test_trap_subprocess (NULL, 0, G_TEST_SUBPROCESS_DEFAULT);
        g_test_trap_assert_passed ();
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autofree gchar *data = NULL;
    gboolean unreadable = FALSE;
    gint fds[2];

    g_assert_true (g_unix_open_pipe (fds, O_CLOEXEC, &error));
    g_assert_true (g_unix_set_fd_nonblocking (fds[0], TRUE, &error));
    g_assert_no_error (error);
    g_assert_cmpint (write (fds[1], "ab", 2), ==, 2);
    g_assert_cmpint (dup2 (fds[0], STDIN_FILENO), ==, STDIN_FILENO);
    g_assert_true (g_close (fds[0], NULL));

    g_autoptr (GThread) rest = g_thread_new ("rest of the input", write_rest, GINT_TO_POINTER (fds[1]));

    g_assert_true (extract_pipe_data (&data, &unreadable, &error));
    g_assert_no_error (error);
    g_assert_cmpstr (data, ==, "abc");
    g_thread_join (g_steal_pointer (&rest));
}

/* A stdin nothing can be read from is nothing piped to a line with no verb,
 * which goes on to the listing, where a verb taking its text from there is
 * refused for it. */
static void
test_pipe_unreadable (void)
{
    if (!g_test_subprocess ())
    {
        g_test_trap_subprocess (NULL, 0, G_TEST_SUBPROCESS_DEFAULT);
        g_test_trap_assert_passed ();
        return;
    }

    g_assert_true (g_close (STDIN_FILENO, NULL) || errno == EBADF);

    Context ctx = { 0 };
    g_autoptr (GError) error = NULL;
    g_autofree gchar *data = NULL;

    g_assert_true (read_pipe_for (0, NULL, &ctx, &data, &error));
    g_assert_no_error (error);
    g_assert_null (data);

    const gchar *args[] = { NULL };

    ctx.args = args;
    g_assert_false (read_pipe_for (1, "add", &ctx, &data, &error));
    g_assert_error (error, G_IO_ERROR, G_IO_ERROR_FAILED);
    g_assert_null (data);
}

/* A command that fails tells the user why on stderr and exits 1 -- with no
 * critical, which is for a bug, and which G_DEBUG=fatal-criticals turns into
 * a crash. */
static void
test_failure_reported (void)
{
    if (!g_test_subprocess ())
    {
        g_test_trap_subprocess (NULL, 0, G_TEST_SUBPROCESS_DEFAULT);
        g_test_trap_assert_passed ();
        g_test_trap_assert_stderr ("Invalid item index: abc\n");
        return;
    }

    g_assert_cmpint (run_client ((const gchar *[]) { "--use-index", "delete", "abc", NULL }), ==, EXIT_FAILURE);
}

/* A timeout is a whole decimal number of seconds within the range: anything
 * else is refused and named -- "-0" above all, which a sign-skipping parse
 * reads as 0, a password never taken off the clipboard. */
static void
test_timeout_parsing (void)
{
    const gchar *malformed[] = { "-0", "+5", " 30", "\v1", "", "1x", "0x10", "65536", "-18446744073709486081" };

    for (guint i = 0; i < G_N_ELEMENTS (malformed); ++i)
    {
        g_autofree gchar *option = g_strdup_printf ("--timeout=%s", malformed[i]);
        g_autofree gchar *program = g_strdup ("gpaste-client");
        gchar *argv[] = { program, option, NULL };
        gchar **args = argv;
        gint argc = 2;
        Context ctx = { 0 };
        g_autoptr (GError) error = NULL;

        optind = 0;
        g_assert_false (parse_cmdline (&argc, &args, &ctx, &error));
        g_assert_error (error, G_PASTE_ERROR, G_PASTE_ERROR_INVALID_ARGUMENT);
        g_assert_false (options_given (&ctx, "t"));
    }

    g_autofree gchar *program = g_strdup ("gpaste-client");
    g_autofree gchar *option = g_strdup ("--timeout=30");
    gchar *argv[] = { program, option, NULL };
    gchar **args = argv;
    gint argc = 2;
    Context ctx = { 0 };
    g_autoptr (GError) error = NULL;

    optind = 0;
    g_assert_true (parse_cmdline (&argc, &args, &ctx, &error));
    g_assert_no_error (error);
    g_assert_true (options_given (&ctx, "t"));
    g_assert_cmpuint (ctx.timeout, ==, 30);
}

/* The help goes to stdout when asked for, and to stderr when the command line
 * was wrong, where a command substitution cannot take it for the output. */
static void
test_help_stream (gconstpointer user_data)
{
    gboolean asked = GPOINTER_TO_INT (user_data);

    if (!g_test_subprocess ())
    {
        g_test_trap_subprocess (NULL, 0, G_TEST_SUBPROCESS_DEFAULT);
        g_test_trap_assert_passed ();
        if (asked)
        {
            g_test_trap_assert_stdout ("*Usage*");
            g_test_trap_assert_stderr ("");
        }
        else
        {
            g_test_trap_assert_stdout ("");
            g_test_trap_assert_stderr ("*Usage*");
        }
        return;
    }

    if (asked)
        g_assert_cmpint (run_client ((const gchar *[]) { "help", NULL }), ==, EXIT_SUCCESS);
    else
        g_assert_cmpint (run_client ((const gchar *[]) { "get", NULL }), ==, EXIT_FAILURE);
    fflush (stdout);
}

/* The client sets the locale the environment names, which is what has gettext
 * look anything up: no GTK application, it has nothing else to set it. */
static void
test_locale_set (void)
{
    if (!g_test_subprocess ())
    {
        g_test_trap_subprocess (NULL, 0, G_TEST_SUBPROCESS_DEFAULT);
        g_test_trap_assert_passed ();
        return;
    }

    g_assert_true (g_setenv ("LC_ALL", "C.UTF-8", TRUE));
    setlocale (LC_ALL, "C");
    g_assert_cmpint (run_client ((const gchar *[]) { "version", NULL }), ==, EXIT_SUCCESS);
    g_assert_cmpstr (setlocale (LC_ALL, NULL), ==, "C.UTF-8");
}

/* A search prints its matches in the order --reverse asks for, and under
 * --use-index beside the place each sits in the history: the number
 * --use-index reads back, rather than the rank of the line. */
static void
test_search_output (gconstpointer user_data)
{
    gboolean reverse = GPOINTER_TO_INT (user_data);

    if (!g_test_subprocess ())
    {
        g_test_trap_subprocess (NULL, 0, G_TEST_SUBPROCESS_DEFAULT);
        g_test_trap_assert_passed ();
        g_test_trap_assert_stdout ((reverse) ? "0: value\n2: value\n" : "2: value\n0: value\n");
        return;
    }

    set_fake_history ((const gchar *[]) { FAKE_UUID (a), FAKE_UUID (b), FAKE_UUID (c), NULL });
    search_matches = (const gint[]) { 2, 0, -1 };
    g_assert_cmpint (run_client ((reverse) ? (const gchar *[]) { "--use-index", "--reverse", "search", "x", NULL }
                                           : (const gchar *[]) { "--use-index", "search", "x", NULL }), ==, EXIT_SUCCESS);
    fflush (stdout);
}

/* The history names end as the items do, NUL under --zero: one may hold a
 * line break of its own. */
static void
test_list_histories_zero (void)
{
    if (!g_test_subprocess ())
    {
        g_test_trap_subprocess (NULL, 0, G_TEST_SUBPROCESS_DEFAULT);
        g_test_trap_assert_passed ();
        g_test_trap_assert_stdout ("work\ntwo\nlines\n");
        return;
    }

    /* The NUL-ended run checked here, the newline-ended one by the parent:
     * the trap's own match stops at the first NUL. */
    g_autofree gchar *path = NULL;
    gint fd = g_file_open_tmp ("gpaste-client-stdout-XXXXXX", &path, NULL);
    gint saved = dup (STDOUT_FILENO);

    g_assert_cmpint (fd, >=, 0);
    fflush (stdout);
    g_assert_cmpint (dup2 (fd, STDOUT_FILENO), ==, STDOUT_FILENO);
    g_assert_cmpint (run_client ((const gchar *[]) { "--zero", "list-histories", NULL }), ==, EXIT_SUCCESS);
    fflush (stdout);
    g_assert_cmpint (dup2 (saved, STDOUT_FILENO), ==, STDOUT_FILENO);

    g_autofree gchar *contents = NULL;
    gsize length = 0;

    g_assert_true (g_file_get_contents (path, &contents, &length, NULL));
    g_assert_cmpmem (contents, length, "work\0two\nlines\0", 15);
    g_assert_cmpint (g_unlink (path), ==, 0);
    g_assert_true (g_close (fd, NULL));
    g_assert_true (g_close (saved, NULL));

    g_assert_cmpint (run_client ((const gchar *[]) { "list-histories", NULL }), ==, EXIT_SUCCESS);
    fflush (stdout);
}

/* The check's report is printed line for line, and the status says whether
 * anything is left wrong. */
static void
test_doctor_report (void)
{
    if (!g_test_subprocess ())
    {
        g_test_trap_subprocess (NULL, 0, G_TEST_SUBPROCESS_DEFAULT);
        g_test_trap_assert_passed ();
        g_test_trap_assert_stdout ("Restricted the folder\n“other” could not be read\n");
        return;
    }

    doctor_report = (const gchar * const []) { "Restricted the folder", "“other” could not be read", NULL };
    doctor_healthy = FALSE;
    g_assert_cmpint (run_client ((const gchar *[]) { "doctor", NULL }), ==, EXIT_FAILURE);
    fflush (stdout);
}

/* A check finding nothing says so, rather than print nothing at all. */
static void
test_doctor_nothing (void)
{
    if (!g_test_subprocess ())
    {
        g_test_trap_subprocess (NULL, 0, G_TEST_SUBPROCESS_DEFAULT);
        g_test_trap_assert_passed ();
        g_test_trap_assert_stdout ("Nothing to put right\n");
        return;
    }

    doctor_report = (const gchar * const []) { NULL };
    doctor_healthy = TRUE;
    g_assert_cmpint (run_client ((const gchar *[]) { "doctor", NULL }), ==, EXIT_SUCCESS);
    fflush (stdout);
}

/* A daemon older than the check is to be restarted, which is what the user is
 * told rather than GDBus' unknown method -- a new session for the one GNOME
 * Shell runs, which no re-exec reloads. */
static void
test_doctor_old_daemon (void)
{
    if (!g_test_subprocess ())
    {
        g_test_trap_subprocess (NULL, 0, G_TEST_SUBPROCESS_DEFAULT);
        g_test_trap_assert_passed ();
        g_test_trap_assert_stderr ("*gpaste-client daemon-reexec*log out and back in*");
        g_test_trap_assert_stdout ("");
        return;
    }

    doctor_error = g_error_new_literal (G_DBUS_ERROR, G_DBUS_ERROR_UNKNOWN_METHOD, "No such method “Doctor”");
    g_assert_cmpint (run_client ((const gchar *[]) { "doctor", NULL }), ==, EXIT_FAILURE);
    g_clear_error (&doctor_error);
}

/* Output that could not be written fails the command: a script trusting the
 * exit status of `gpaste-client get` into a full disk would lose the item. */
static void
test_output_failure (void)
{
    /* Decided before the trap: a child skipping exits 77, which the trap
     * takes for a failure, and the suite would end there. */
    if (!g_file_test ("/dev/full", G_FILE_TEST_EXISTS))
    {
        g_test_skip ("No /dev/full to write to");
        return;
    }

    if (!g_test_subprocess ())
    {
        g_test_trap_subprocess (NULL, 0, G_TEST_SUBPROCESS_DEFAULT);
        g_test_trap_assert_passed ();
        g_test_trap_assert_stderr ("Could not write the output: *");
        return;
    }

    gint full = g_open ("/dev/full", O_WRONLY | O_CLOEXEC, 0);

    g_assert_cmpint (full, >=, 0);
    g_assert_cmpint (dup2 (full, STDOUT_FILENO), ==, STDOUT_FILENO);
    g_assert_true (g_close (full, NULL));
    g_assert_cmpint (run_client ((const gchar *[]) { "version", NULL }), ==, EXIT_FAILURE);
    clearerr (stdout);
}

/* A write that failed earlier, which ferror () remembers, is said without a
 * reason: errno has been written over since, and a flush with nothing left to
 * write leaves it as it was. */
static void
test_output_failure_reason (void)
{
    if (!g_file_test ("/dev/full", G_FILE_TEST_EXISTS))
    {
        g_test_skip ("No /dev/full to write to");
        return;
    }

    if (!g_test_subprocess ())
    {
        g_test_trap_subprocess (NULL, 0, G_TEST_SUBPROCESS_DEFAULT);
        g_test_trap_assert_passed ();
        g_test_trap_assert_stderr ("Could not write the output\n");
        return;
    }

    FILE *full = fopen ("/dev/full", "we");

    g_assert_nonnull (full);
    g_assert_cmpint (setvbuf (full, NULL, _IONBF, 0), ==, 0);
    g_assert_cmpint (fputs ("lost", full), ==, EOF);
    errno = EINVAL;
    g_assert_false (output_written (full));
    fclose (full);
}

/* A command taking its last argument from a pipe that brought nothing is not
 * the command line's: the help answers it, and no client is built to start a
 * daemon for it. */
static void
test_nothing_piped (void)
{
    guint checked = 0;

    clients_created = 0;
    for (guint64 i = 0; i < G_N_ELEMENTS (commands); ++i)
    {
        const Command *c = &commands[i];

        /* The verb-less line falls to the listing, a daemon's to answer. */
        if (!c->verb || !c->reads_pipe)
            continue;

        /* The fewest arguments it takes, the pipe to bring the last. */
        gint argc = c->argc;
        g_autoptr (GStrvBuilder) builder = g_strv_builder_new ();

        for (gint j = 1; j < argc; ++j)
            g_strv_builder_add (builder, "name");

        g_auto (GStrv) args = g_strv_builder_end (builder);
        Context ctx = { .argc = argc - 1, .args = (const gchar **) args };
        g_autoptr (GError) error = NULL;

        g_assert_cmpint (g_paste_dispatch (argc, c->verb, &ctx, &error), ==, -1);
        g_assert_no_error (error);
        g_assert_null (ctx.client);
        ++checked;
    }
    g_assert_cmpuint (checked, >=, 3);
    g_assert_cmpuint (clients_created, ==, 0);
}

/* A piped password loses the newline ending the line that printed it, and that
 * one alone; one given as an argument is taken as it is. */
static void
test_piped_password (void)
{
    const struct
    {
        const gchar *piped;
        const gchar *argument;
        const gchar *added;
    } cases[] = {
        { "secret\n",   NULL,       "secret"   },
        { "secret\n\n", NULL,       "secret\n" },
        { "secret",     NULL,       "secret"   },
        { NULL,         "secret\n", "secret\n" },
    };

    for (guint i = 0; i < G_N_ELEMENTS (cases); ++i)
    {
        Context ctx = {
            .argc = (cases[i].argument) ? 2 : 1,
            .args = (const gchar *[]) { "bank", cases[i].argument, NULL },
            .pipe_data = (gchar *) cases[i].piped,
        };
        g_autoptr (GError) error = NULL;

        g_assert_cmpint (g_paste_dispatch (ctx.argc + 1, "add-password", &ctx, &error), ==, EXIT_SUCCESS);
        g_assert_no_error (error);
        g_assert_cmpstr (added_password, ==, cases[i].added);
        g_clear_pointer (&added_password, g_free);
        g_clear_object (&ctx.client);
    }
}

/* Without --timeout, AddPassword is sent the timeout the settings carry, which
 * a daemon of every version reads right, rather than asked for the default. */
static void
test_password_timeout (void)
{
    g_autoptr (GPasteSettings) settings = g_paste_settings_new ();
    Context ctx = { .argc = 2, .args = (const gchar *[]) { "bank", "secret", NULL } };
    g_autoptr (GError) error = NULL;

    g_paste_settings_set_password_timeout (settings, 30);
    g_assert_cmpint (g_paste_dispatch (3, "add-password", &ctx, &error), ==, EXIT_SUCCESS);
    g_assert_no_error (error);
    g_assert_cmpuint (added_timeout, ==, 30);
    g_clear_object (&ctx.client);

    ctx.given = option_bit ('t');
    ctx.timeout = 5;
    g_assert_cmpint (g_paste_dispatch (3, "add-password", &ctx, &error), ==, EXIT_SUCCESS);
    g_assert_no_error (error);
    g_assert_cmpuint (added_timeout, ==, 5);
    g_clear_object (&ctx.client);
    g_clear_pointer (&added_password, g_free);
    g_paste_settings_reset (settings, G_PASTE_PASSWORD_TIMEOUT_SETTING);
}

/* Read @terminal into @buffer, of @size bytes, until @last is in it: a
 * terminal hands what was written over in as many reads as it likes -- stdout,
 * line buffered there, leaving in a write per line -- and one read can wake on
 * the first write before the next has reached it. */
static void
read_terminal_until (gint         terminal,
                     gchar       *buffer,
                     gsize        size,
                     const gchar *last)
{
    gsize got = 0;

    memset (buffer, 0, size);
    while (!strstr (buffer, last) && got < size - 1)
    {
        gssize length = read (terminal, buffer + got, size - 1 - got);

        g_assert_cmpint (length, >, 0);
        got += (gsize) length;
    }
}

/* On a terminal, an item's control characters are shown rather than acted on:
 * an escape sequence copied off a web page neither retitles the window nor
 * writes the terminal's own clipboard -- line feeds, tabs and the carriage
 * return of a CRLF line ending aside, a lone one being shown. Asked once
 * whether it is one, and each run between two such characters written whole. */
static void
test_terminal_controls (void)
{
    if (!g_test_subprocess ())
    {
        g_test_trap_subprocess (NULL, 0, G_TEST_SUBPROCESS_DEFAULT);
        g_test_trap_assert_passed ();
        return;
    }

    gint terminal = posix_openpt (O_RDWR | O_NOCTTY);

    g_assert_cmpint (terminal, >=, 0);
    g_assert_cmpint (grantpt (terminal), ==, 0);
    g_assert_cmpint (unlockpt (terminal), ==, 0);

    gint client_side = g_open (ptsname (terminal), O_RDWR | O_NOCTTY | O_CLOEXEC, 0);
    struct termios raw;

    g_assert_cmpint (client_side, >=, 0);
    /* What is written reaches the other side as it is, no line feed made a
     * CRLF on the way. */
    g_assert_cmpint (tcgetattr (client_side, &raw), ==, 0);
    cfmakeraw (&raw);
    g_assert_cmpint (tcsetattr (client_side, TCSANOW, &raw), ==, 0);
    fflush (stdout);
    g_assert_cmpint (dup2 (client_side, STDOUT_FILENO), ==, STDOUT_FILENO);
    print_text ("a\x1b]52;c;eA==\x07" "b\x7f");
    print_text ("x\r\ny\rz\n");
    fflush (stdout);

    gchar buffer[64];

    read_terminal_until (terminal, buffer, sizeof (buffer), "z\n");
    g_assert_cmpstr (buffer, ==, "a\xef\xbf\xbd]52;c;eA==\xef\xbf\xbd" "b\xef\xbf\xbd" "x\r\ny\xef\xbf\xbdz\n");

    /* A text that is not UTF-8 -- a refusal echoing an option's value as typed
     * -- is not read past its end by a sequence cut short there, the bytes
     * beyond it holding a control character that would be found and written
     * out with them, nor has an escape character a lead byte comes before
     * stepped over. Written to memory, which keeps every byte, the terminal
     * having been found once already for stdout's. */
    static const gchar cut_short[] = { '5', '\xe2', '\0', 'X', '\x1b', '\0' };
    g_autofree gchar *shown = NULL;
    gsize shown_size = 0;
    FILE *memory = open_memstream (&shown, &shown_size);

    print_text_to (memory, cut_short);
    g_assert_cmpint (fclose (memory), ==, 0);
    g_assert_cmpmem (shown, shown_size, "5\xef\xbf\xbd", 4);
    g_clear_pointer (&shown, g_free);

    memory = open_memstream (&shown, &shown_size);
    print_text_to (memory, "\xe2\x1b]0;title\x07");
    g_assert_cmpint (fclose (memory), ==, 0);
    g_assert_cmpstr (shown, ==, "\xef\xbf\xbd\xef\xbf\xbd]0;title\xef\xbf\xbd");

    g_autofree gchar *clean = g_strnfill (1024, 'c');
    g_autofree gchar *echoed = g_malloc (2048);
    guint asked = terminal_asks;

    print_text (clean);
    print_text (clean);
    fflush (stdout);
    g_assert_cmpuint (terminal_asks, ==, asked);

    /* What lies between two control characters goes out in one write, a
     * character at a time costing one each. */
    FILE *counted = fopencookie (NULL, "w", (cookie_io_functions_t) { .write = count_write });

    g_assert_nonnull (counted);
    g_assert_cmpint (setvbuf (counted, NULL, _IONBF, 0), ==, 0);
    writes = 0;
    print_text_to (counted, clean);
    g_assert_cmpuint (writes, ==, 1);
    writes = 0;
    print_text_to (counted, "ab\x1b" "cd");
    g_assert_cmpuint (writes, ==, 3);
    g_assert_cmpint (fclose (counted), ==, 0);
    for (gssize got = 0; got < 2048;)
    {
        gssize read_now = read (terminal, echoed, 2048);

        g_assert_cmpint (read_now, >, 0);
        got += read_now;
    }

    /* And what the verbs printing an item write there, which is where the
     * escape sequences would be sent. */
    fake_value = "c\x1b]0;title\x07" "d";
    set_fake_history ((const gchar *[]) { FAKE_UUID (a), NULL });
    g_assert_cmpint (run_client ((const gchar *[]) { "history", NULL }), ==, EXIT_SUCCESS);
    g_assert_cmpint (run_client ((const gchar *[]) { "get", FAKE_UUID (a), NULL }), ==, EXIT_SUCCESS);
    fflush (stdout);

    gchar listed[256];

    read_terminal_until (terminal, listed, sizeof (listed), "c\xef\xbf\xbd]0;title\xef\xbf\xbd" "d");
    g_assert_null (strchr (listed, '\x1b'));
    g_assert_null (strchr (listed, '\x07'));

    /* Nor what names a file: a history's name, or the doctor's report of one
     * another user put in the history directory. */
    fake_history_name = "e\x1b]0;history\x07" "f";
    doctor_report = (const gchar *[]) { "g\x1b]0;doctor\x07" "h belongs to another user", NULL };
    doctor_healthy = TRUE;
    g_assert_cmpint (run_client ((const gchar *[]) { "list-histories", NULL }), ==, EXIT_SUCCESS);
    g_assert_cmpint (run_client ((const gchar *[]) { "doctor", NULL }), ==, EXIT_SUCCESS);
    fflush (stdout);
    fake_history_name = NULL;
    doctor_report = NULL;

    gchar named[512];

    read_terminal_until (terminal, named, sizeof (named), " belongs to another user");
    g_assert_nonnull (strstr (named, "e\xef\xbf\xbd]0;history\xef\xbf\xbd" "f"));
    g_assert_nonnull (strstr (named, "g\xef\xbf\xbd]0;doctor\xef\xbf\xbd" "h"));
    g_assert_null (strchr (named, '\x1b'));

    /* Nor what a daemon answers -- an older one checking none of it -- or
     * refuses with, on stderr: a version, an upload's url, an error quoting a
     * history's name. */
    g_autofree gchar *version = g_steal_pointer (&daemon_version);

    daemon_version = g_strdup ("v\x1b]0;version\x07" "w");
    uploaded_url = "u\x1b]0;url\x07" "x";
    reexec_error = g_error_new_literal (G_PASTE_ERROR, G_PASTE_ERROR_FAILED, "y\x1b]0;error\x07" "z refused");
    fflush (stderr);
    g_assert_cmpint (dup2 (client_side, STDERR_FILENO), ==, STDERR_FILENO);
    g_assert_cmpint (run_client ((const gchar *[]) { "daemon-version", NULL }), ==, EXIT_SUCCESS);
    g_assert_cmpint (run_client ((const gchar *[]) { "upload-and-copy", FAKE_UUID (a), NULL }), ==, EXIT_SUCCESS);
    g_assert_cmpint (run_client ((const gchar *[]) { "daemon-reexec", NULL }), ==, EXIT_FAILURE);
    fflush (stdout);
    fflush (stderr);
    g_clear_error (&reexec_error);
    g_set_str_take (&daemon_version, g_steal_pointer (&version));
    uploaded_url = "https://paste.rs/x";

    gchar answered[512];

    read_terminal_until (terminal, answered, sizeof (answered), "z refused");
    g_assert_nonnull (strstr (answered, "v\xef\xbf\xbd]0;version\xef\xbf\xbd" "w"));
    g_assert_nonnull (strstr (answered, "u\xef\xbf\xbd]0;url\xef\xbf\xbd" "x"));
    g_assert_nonnull (strstr (answered, "y\xef\xbf\xbd]0;error\xef\xbf\xbd" "z"));
    g_assert_null (strchr (answered, '\x1b'));
    g_assert_true (g_close (client_side, NULL));
    g_assert_true (g_close (terminal, NULL));
}

/* A merge takes two items at least: fewer is no merge, answered with the help
 * before any client is built. */
static void
test_merge_takes_two (void)
{
    clients_created = 0;
    for (gint argc = 1; argc < 3; ++argc)
    {
        Context ctx = {
            .argc = argc - 1,
            .args = (const gchar *[]) { FAKE_UUID (a), NULL },
        };
        g_autoptr (GError) error = NULL;

        g_assert_cmpint (g_paste_dispatch (argc, "merge", &ctx, &error), ==, -1);
        g_assert_no_error (error);
    }
    g_assert_cmpuint (clients_created, ==, 0);
    g_assert_null (merged_uuids);
}

/* A command talking to the daemon waits for one to serve: a daemon just
 * started, or re-executing, owns the name before it has anything to answer
 * with. One that never comes fails the command rather than have it call into
 * nothing -- bar daemon-reexec and migrate on a GPaste 45 or 50, which they
 * have to reach though it never serves this interface. */
static void
test_waits_for_daemon (void)
{
    set_fake_history ((const gchar *[]) { FAKE_UUID (a), NULL });
    follows = 0;

    fake_presence = G_PASTE_DAEMON_PRESENCE_ABSENT;
    presence_after_follow = G_PASTE_DAEMON_PRESENCE_READY;
    g_assert_cmpint (run_client ((const gchar *[]) { "delete", FAKE_UUID (a), NULL }), ==, EXIT_SUCCESS);
    g_assert_cmpstr (deleted_uuid, ==, FAKE_UUID (a));
    g_assert_cmpuint (follows, ==, 1);
    g_clear_pointer (&deleted_uuid, g_free);

    Context ctx = {
        .argc = 1,
        .args = (const gchar *[]) { FAKE_UUID (a), NULL },
    };
    g_autoptr (GError) error = NULL;

    fake_presence = G_PASTE_DAEMON_PRESENCE_ABSENT;
    presence_after_follow = G_PASTE_DAEMON_PRESENCE_ABSENT;
    g_assert_cmpint (g_paste_dispatch (2, "delete", &ctx, &error), ==, EXIT_FAILURE);
    g_assert_error (error, G_IO_ERROR, G_IO_ERROR_NOT_CONNECTED);
    g_assert_null (deleted_uuid);
    g_clear_error (&error);
    g_clear_object (&ctx.client);

    /* A GPaste 45 or 50 owning the name never serves: told apart at once, and
     * the command fails pointing at daemon-reexec rather than wait it out. */
    fake_presence = G_PASTE_DAEMON_PRESENCE_STARTING;
    presence_after_follow = G_PASTE_DAEMON_PRESENCE_STARTING;
    waited_on_legacy = TRUE;
    g_assert_cmpint (g_paste_dispatch (2, "delete", &ctx, &error), ==, EXIT_FAILURE);
    g_assert_error (error, G_IO_ERROR, G_IO_ERROR_NOT_CONNECTED);
    g_assert_nonnull (strstr (error->message, "daemon-reexec"));
    g_assert_null (deleted_uuid);
    waited_on_legacy = FALSE;
    g_clear_error (&error);
    g_clear_object (&ctx.client);

    /* Nor waited for by a re-exec, which reaches it by signal. */
    follows = 0;
    signals_sent = 0;
    introspected_legacy = TRUE;
    reexec_error = g_error_new_literal (G_DBUS_ERROR, G_DBUS_ERROR_UNKNOWN_METHOD, "Unknown method");
    g_assert_cmpint (run_client ((const gchar *[]) { "daemon-reexec", NULL }), ==, EXIT_SUCCESS);
    g_assert_cmpuint (follows, ==, 0);
    g_assert_cmpuint (signals_sent, ==, 1);
    g_clear_error (&reexec_error);
    introspected_legacy = FALSE;

    fake_presence = G_PASTE_DAEMON_PRESENCE_READY;
    presence_after_follow = G_PASTE_DAEMON_PRESENCE_READY;
}

/* An owner the question could not reach is not waited for either: the
 * re-exec's own route asks again, and signals a GPaste 45 or 50 there, where
 * the wait would fail on it, telling the user to run the very command that
 * failed. */
static void
test_unknown_owner_unwaited (void)
{
    follows = 0;
    signals_sent = 0;
    fake_presence = G_PASTE_DAEMON_PRESENCE_STARTING;
    presence_after_follow = G_PASTE_DAEMON_PRESENCE_STARTING;
    introspection_fails = TRUE;
    waited_on_legacy = TRUE;
    reexec_error = g_error_new_literal (G_DBUS_ERROR, G_DBUS_ERROR_UNKNOWN_METHOD, "Unknown method");
    g_assert_cmpint (run_client ((const gchar *[]) { "daemon-reexec", NULL }), ==, EXIT_SUCCESS);
    g_assert_cmpuint (follows, ==, 0);
    g_assert_cmpuint (signals_sent, ==, 1);

    /* migrate, whose gate opens before either route is taken, refuses it
     * instead, unwaited for: what it reports is the question's failure, not
     * the wait's. */
    g_autoptr (GPasteSettings) settings = g_paste_settings_new ();
    Context ctx = { 0 };
    g_autoptr (GError) error = NULL;

    g_paste_settings_set_storage_backend_revision (settings, 37);
    reexecs = 0;
    g_assert_cmpint (g_paste_dispatch (1, "migrate", &ctx, &error), ==, EXIT_FAILURE);
    g_assert_error (error, G_DBUS_ERROR, G_DBUS_ERROR_NO_REPLY);
    g_assert_cmpuint (follows, ==, 0);
    g_assert_cmpuint (reexecs, ==, 0);
    g_assert_cmpuint (signals_sent, ==, 1);
    g_assert_cmpuint (g_paste_settings_get_storage_backend_revision (settings), ==, 37);
    g_clear_object (&ctx.client);
    g_paste_settings_reset (settings, G_PASTE_STORAGE_BACKEND_REVISION_SETTING);

    g_clear_error (&reexec_error);
    waited_on_legacy = FALSE;
    introspection_fails = FALSE;
    fake_presence = G_PASTE_DAEMON_PRESENCE_READY;
    presence_after_follow = G_PASTE_DAEMON_PRESENCE_READY;
}

/* An owner leaving as the dispatch asks about it fails the question, and no
 * wait follows: migrate, finding nobody owning the name, refuses before it
 * opens the gate, as the wait refuses a daemon gone -- and so it does when a
 * GPaste 45 or 50 leaves as it answers migrate's own question. One leaving
 * once nothing is asked any more leaves the presence reading as it did,
 * ready: the re-exec then finds nobody owning the name, starting no daemon
 * for it, and migrate closes the gate it opened again, passing on the
 * re-exec's words, as daemon-reexec does. Another daemon come to serve
 * meanwhile is a daemon serving, which migrate re-executes as any. */
static void
test_unknown_owner_left (void)
{
    g_autoptr (GPasteSettings) settings = g_paste_settings_new ();
    Context ctx = { 0 };
    g_autoptr (GError) error = NULL;

    g_paste_settings_set_storage_backend_revision (settings, 37);
    follows = 0;
    reexecs = 0;
    signals_sent = 0;
    owner_gone = TRUE;
    fake_presence = G_PASTE_DAEMON_PRESENCE_STARTING;
    presence_after_question = G_PASTE_DAEMON_PRESENCE_ABSENT;
    introspection_fails = TRUE;
    g_assert_cmpint (g_paste_dispatch (1, "migrate", &ctx, &error), ==, EXIT_FAILURE);
    g_assert_error (error, G_IO_ERROR, G_IO_ERROR_NOT_CONNECTED);
    g_assert_cmpstr (error->message, ==, "No GPaste daemon is serving a history.");
    g_assert_cmpuint (follows, ==, 0);
    g_assert_cmpuint (reexecs, ==, 0);
    g_assert_cmpuint (signals_sent, ==, 0);
    g_assert_cmpuint (g_paste_settings_get_storage_backend_revision (settings), ==, 37);
    g_clear_error (&error);
    g_clear_object (&ctx.client);
    introspection_fails = FALSE;

    fake_presence = G_PASTE_DAEMON_PRESENCE_STARTING;
    introspected_legacy = TRUE;
    g_assert_cmpint (g_paste_migrate (&ctx, &error), ==, EXIT_FAILURE);
    g_assert_error (error, G_IO_ERROR, G_IO_ERROR_NOT_CONNECTED);
    g_assert_cmpuint (reexecs, ==, 0);
    g_assert_cmpuint (signals_sent, ==, 0);
    g_assert_cmpuint (g_paste_settings_get_storage_backend_revision (settings), ==, 37);
    g_clear_error (&error);
    introspected_legacy = FALSE;

    fake_presence = G_PASTE_DAEMON_PRESENCE_READY;
    presence_after_question = G_PASTE_DAEMON_PRESENCE_STARTING;
    g_assert_cmpint (g_paste_dispatch (1, "migrate", &ctx, &error), ==, EXIT_FAILURE);
    g_assert_error (error, G_DBUS_ERROR, G_DBUS_ERROR_NAME_HAS_NO_OWNER);
    g_assert_cmpstr (error->message, ==, "No GPaste daemon is serving a history.");
    g_assert_cmpuint (follows, ==, 0);
    g_assert_cmpuint (reexecs, ==, 1);
    g_assert_cmpuint (g_paste_settings_get_storage_backend_revision (settings), ==, 37);
    g_clear_error (&error);
    g_clear_object (&ctx.client);

    g_assert_cmpint (g_paste_dispatch (1, "daemon-reexec", &ctx, &error), ==, EXIT_FAILURE);
    g_assert_error (error, G_DBUS_ERROR, G_DBUS_ERROR_NAME_HAS_NO_OWNER);
    g_assert_cmpstr (error->message, ==, "No GPaste daemon is serving a history.");
    g_assert_cmpuint (reexecs, ==, 2);
    g_assert_cmpuint (signals_sent, ==, 0);
    g_clear_error (&error);
    g_clear_object (&ctx.client);
    owner_gone = FALSE;

    reexecs = 0;
    fake_presence = G_PASTE_DAEMON_PRESENCE_STARTING;
    presence_after_question = G_PASTE_DAEMON_PRESENCE_READY;
    introspection_fails = TRUE;
    g_assert_cmpint (g_paste_dispatch (1, "migrate", &ctx, &error), ==, EXIT_SUCCESS);
    g_assert_no_error (error);
    g_assert_cmpuint (follows, ==, 0);
    g_assert_cmpuint (reexecs, ==, 1);
    g_assert_cmpuint (g_paste_settings_get_storage_backend_revision (settings), ==, 0);
    g_clear_object (&ctx.client);

    introspection_fails = FALSE;
    presence_after_question = G_PASTE_DAEMON_PRESENCE_STARTING;
    fake_presence = G_PASTE_DAEMON_PRESENCE_READY;
    g_paste_settings_reset (settings, G_PASTE_STORAGE_BACKEND_REVISION_SETTING);
}

/* daemon-reexec and migrate wait for a daemon of this version still starting,
 * as every verb talking to the daemon does -- the one building the client
 * started, above all, which has nothing exported to re-exec yet -- and one
 * that never comes to serve has migrate open no gate. */
static void
test_starting_waited (void)
{
    g_autoptr (GPasteSettings) settings = g_paste_settings_new ();
    Context ctx = { 0 };
    g_autoptr (GError) error = NULL;

    g_paste_settings_set_storage_backend_revision (settings, 37);
    follows = 0;
    reexecs = 0;
    fake_presence = G_PASTE_DAEMON_PRESENCE_STARTING;
    presence_after_follow = G_PASTE_DAEMON_PRESENCE_READY;
    g_assert_cmpint (run_client ((const gchar *[]) { "daemon-reexec", NULL }), ==, EXIT_SUCCESS);
    g_assert_cmpuint (follows, ==, 1);
    g_assert_cmpuint (reexecs, ==, 1);

    fake_presence = G_PASTE_DAEMON_PRESENCE_STARTING;
    g_assert_cmpint (run_client ((const gchar *[]) { "migrate", NULL }), ==, EXIT_SUCCESS);
    g_assert_cmpuint (follows, ==, 2);
    g_assert_cmpuint (reexecs, ==, 2);
    g_assert_cmpuint (g_paste_settings_get_storage_backend_revision (settings), ==, 0);

    g_paste_settings_set_storage_backend_revision (settings, 37);
    fake_presence = G_PASTE_DAEMON_PRESENCE_STARTING;
    presence_after_follow = G_PASTE_DAEMON_PRESENCE_ABSENT;
    g_assert_cmpint (g_paste_dispatch (1, "migrate", &ctx, &error), ==, EXIT_FAILURE);
    g_assert_error (error, G_IO_ERROR, G_IO_ERROR_NOT_CONNECTED);
    g_assert_cmpuint (reexecs, ==, 2);
    g_assert_cmpuint (g_paste_settings_get_storage_backend_revision (settings), ==, 37);
    g_clear_object (&ctx.client);

    fake_presence = G_PASTE_DAEMON_PRESENCE_READY;
    presence_after_follow = G_PASTE_DAEMON_PRESENCE_READY;
    g_paste_settings_reset (settings, G_PASTE_STORAGE_BACKEND_REVISION_SETTING);
}

int
main (int argc, char **argv)
{
    g_paste_test_env_setup (G_PASTE_TEST_ENV_DEFAULT);
    g_test_init (&argc, &argv, NULL);
    g_test_add_func ("/client/reexec/refusal", test_refusal);
    g_test_add_func ("/client/reexec/in-shell", test_reexec_in_shell);
    g_test_add_func ("/client/upload-and-copy", test_upload_and_copy);
    g_test_add_func ("/client/dispatch/reads_stdin", test_reads_stdin);
    g_test_add_func ("/client/pipe/refusals", test_pipe_refusals);
    g_test_add_func ("/client/pipe/nonblocking", test_pipe_nonblocking);
    g_test_add_func ("/client/pipe/unreadable", test_pipe_unreadable);
    g_test_add_func ("/client/pipe/password", test_piped_password);
    g_test_add_func ("/client/password-timeout", test_password_timeout);
    g_test_add_func ("/client/pipe/nothing-piped", test_nothing_piped);
    g_test_add_func ("/client/failure-reported", test_failure_reported);
    g_test_add_func ("/client/options/timeout", test_timeout_parsing);
    g_test_add_data_func ("/client/help/asked", GINT_TO_POINTER (TRUE), test_help_stream);
    g_test_add_data_func ("/client/help/misuse", GINT_TO_POINTER (FALSE), test_help_stream);
    g_test_add_func ("/client/locale", test_locale_set);
    g_test_add_data_func ("/client/search/positions", GINT_TO_POINTER (FALSE), test_search_output);
    g_test_add_data_func ("/client/search/reverse", GINT_TO_POINTER (TRUE), test_search_output);
    g_test_add_func ("/client/list-histories/zero", test_list_histories_zero);
    g_test_add_func ("/client/output-failure", test_output_failure);
    g_test_add_func ("/client/output-failure/reason", test_output_failure_reason);
    g_test_add_func ("/client/terminal-controls", test_terminal_controls);
    g_test_add_func ("/client/merge-takes-two", test_merge_takes_two);
    g_test_add_func ("/client/doctor/report", test_doctor_report);
    g_test_add_func ("/client/doctor/nothing", test_doctor_nothing);
    g_test_add_func ("/client/doctor/old-daemon", test_doctor_old_daemon);
    g_test_add_func ("/client/waits-for-daemon", test_waits_for_daemon);
    g_test_add_func ("/client/reexec/starting-waited", test_starting_waited);
    g_test_add_func ("/client/reexec/unknown-owner", test_unknown_owner_unwaited);
    g_test_add_func ("/client/reexec/unknown-owner-left", test_unknown_owner_left);
    g_test_add_func ("/client/dispatch/daemonless", test_daemonless_commands);
    g_test_add_func ("/client/utf8/refused", test_utf8_refused);
    g_test_add_func ("/client/utf8/accepted", test_utf8_accepted);
    g_test_add_func ("/client/index/item", test_item_index);
    g_test_add_func ("/client/index/malformed", test_malformed_index);
    g_test_add_func ("/client/index/merge", test_merge_indexes);
    g_test_add_func ("/client/index/merge-past-end", test_merge_past_end);
    g_test_add_func ("/client/index/nonitem-arguments", test_nonitem_arguments);
    g_test_add_func ("/client/reexec/unsupported", test_unsupported);
    g_test_add_func ("/client/reexec/not-legacy", test_unsupported_not_legacy);
    g_test_add_func ("/client/reexec/migrate-starting", test_migrate_starting);
    g_test_add_data_func ("/client/daemon_version/answered", "51.1", test_daemon_version);
    g_test_add_data_func ("/client/daemon_version/unanswered", NULL, test_daemon_version);
    g_test_add_data_func ("/client/migrate/gate_survives_fallback", GINT_TO_POINTER (TRUE), test_migrate_gate);
    g_test_add_data_func ("/client/migrate/gate_closed_on_refusal", GINT_TO_POINTER (FALSE), test_migrate_gate);
    return g_paste_test_env_run ();
}
