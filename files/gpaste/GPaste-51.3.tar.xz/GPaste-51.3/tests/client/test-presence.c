// SPDX-FileCopyrightText: 2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com>
// SPDX-License-Identifier: BSD-2-Clause

#include <gpaste-3/gpaste-client.h>
#include <gpaste-3/gpaste-client-private.h>
#include <gpaste-3/gpaste-daemon3.h>
#include <gpaste-3/gpaste-error.h>
#include <gpaste-3/gpaste-gdbus-defines.h>
#include <gpaste-3/gpaste-util.h>
#include <gpaste-3/gpaste-util-private.h>
#include <gpaste-test-bus.h>
#include <gpaste-test-env.h>

#include <glib-unix.h>
#include <glib/gstdio.h>
#include <signal.h>
#include <sys/socket.h>
#include <sys/wait.h>

/* Local rather than in gpaste-test-bus, which knows no GPaste type: its
 * g_paste_test_bus_wait_for_enum () is the shared part, and what this adds is
 * the property's name and a presence typed as one.
 * tests/ui/test-daemon-presence.c has the same wrapper. */
static void
wait_for_presence (GPasteClient        *client,
                   GPasteDaemonPresence presence)
{
    g_paste_test_bus_wait_for_enum (client, "daemon-presence", presence);
}

/* As wait_for_presence (), for a client built in @context: the shared waits
 * run the default context alone. */
static void
wait_for_presence_on (GPasteClient        *client,
                      GMainContext        *context,
                      GPasteDaemonPresence presence)
{
    gint64 deadline = g_get_monotonic_time () + G_PASTE_TEST_BUS_WAIT_SECONDS * G_USEC_PER_SEC;

    while (g_paste_client_get_daemon_presence (client) != presence && g_get_monotonic_time () < deadline)
    {
        if (!g_main_context_iteration (context, FALSE))
            g_usleep (10000);
    }
    g_assert_cmpint (g_paste_client_get_daemon_presence (client), ==, presence);
}

/* What a real daemon owns the name with: replaceable, and not queued once
 * replaced, as it quits then -- a stand-in queued would get the name back when
 * its successor stops. */
#define REPLACEABLE (G_BUS_NAME_OWNER_FLAGS_ALLOW_REPLACEMENT | G_BUS_NAME_OWNER_FLAGS_DO_NOT_QUEUE)

/* A daemon stood in for on a connection of its own, owning the name before it
 * exports anything, as both real daemons do. */
static GDBusConnection *
stand_in_connect (GBusNameOwnerFlags flags,
                  guint             *owner)
{
    GDBusConnection *server = g_paste_test_bus_connect (g_getenv ("DBUS_SESSION_BUS_ADDRESS"));

    *owner = g_bus_own_name_on_connection (server, G_PASTE_BUS_NAME, flags, NULL, NULL, NULL, NULL);

    return server;
}

static void
test_follow (void)
{
    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);

    g_assert_no_error (error);

    /* Nobody owns the name and the bus has nothing to activate. */
    g_assert_cmpint (g_paste_client_get_daemon_presence (client), ==, G_PASTE_DAEMON_PRESENCE_ABSENT);

    /* Gone for less than the grace second is not yet missing. */
    g_paste_client_follow_daemon (client, FALSE);
    g_assert_cmpint (g_paste_client_get_daemon_presence (client), ==, G_PASTE_DAEMON_PRESENCE_STARTING);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_ABSENT);

    guint owner;
    g_autoptr (GDBusConnection) server = stand_in_connect (G_BUS_NAME_OWNER_FLAGS_NONE, &owner);

    /* The name without a history: starting. */
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_STARTING);

    g_autoptr (GPasteDaemon3) skeleton = g_paste_daemon3_skeleton_new ();

    g_dbus_interface_skeleton_export (G_DBUS_INTERFACE_SKELETON (skeleton), server, G_PASTE_DAEMON_OBJECT_PATH, &error);
    g_assert_no_error (error);
    g_paste_daemon3_set_history (skeleton, "history");

    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);

    g_dbus_interface_skeleton_unexport (G_DBUS_INTERFACE_SKELETON (skeleton));
    g_bus_unown_name (owner);

    /* Gone again: the grace second passes before it says so. */
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_STARTING);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_ABSENT);

    /* Asking goes to the bus, which has nothing to start. */
    g_paste_client_retry_daemon (client);
    g_assert_cmpint (g_paste_client_get_daemon_presence (client), ==, G_PASTE_DAEMON_PRESENCE_STARTING);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_ABSENT);

    g_paste_client_unfollow_daemon (client);
}

/* A stand-in that serves at once, its object exported before the bus has
 * handed it the name: its name, its object and its history --
 * all a client following a daemon reads, which is why it is not the UI
 * suite's FakeDaemon, made to answer what a window asks. */
typedef struct
{
    GDBusConnection *server;
    guint            owner;
    GPasteDaemon3   *skeleton;
} StandIn;

static void
stand_in_serve (StandIn           *stand_in,
                GBusNameOwnerFlags flags)
{
    g_autoptr (GError) error = NULL;

    stand_in->server = stand_in_connect (flags, &stand_in->owner);
    stand_in->skeleton = g_paste_daemon3_skeleton_new ();
    g_dbus_interface_skeleton_export (G_DBUS_INTERFACE_SKELETON (stand_in->skeleton), stand_in->server,
                                      G_PASTE_DAEMON_OBJECT_PATH, &error);
    g_assert_no_error (error);
    g_paste_daemon3_set_history (stand_in->skeleton, "history");
}

/* Gone as a real daemon goes, its connection closing first. */
static void
stand_in_stop (StandIn *stand_in)
{
    g_dbus_connection_close_sync (stand_in->server, NULL, NULL);
    g_dbus_interface_skeleton_unexport (G_DBUS_INTERFACE_SKELETON (stand_in->skeleton));
    g_clear_object (&stand_in->skeleton);
    g_clear_handle_id (&stand_in->owner, g_bus_unown_name);
    g_clear_object (&stand_in->server);
}

static void
on_init_ready (GObject      *source_object,
               GAsyncResult *res,
               gpointer      user_data)
{
    g_autoptr (GError) error = NULL;

    g_assert_true (g_async_initable_init_finish (G_ASYNC_INITABLE (source_object), res, &error));
    g_assert_no_error (error);
    *(gboolean *) user_data = TRUE;
}

static void
on_initable_ready (GObject      *source_object,
                   GAsyncResult *res,
                   gpointer      user_data)
{
    GObject **client = user_data;
    g_autoptr (GError) error = NULL;

    *client = g_async_initable_new_finish (G_ASYNC_INITABLE (source_object), res, &error);
    g_assert_no_error (error);
}

/* Each presence a client announces, and the owner its proxy addressed when it
 * announced it: what a consumer reading the daemon on that edge asks. */
typedef struct
{
    GPasteClient *client;
    GArray       *presences;
    GPtrArray    *owners;
} PresenceLog;

static void
on_presence_logged (GPasteClient *client,
                    GParamSpec   *pspec G_GNUC_UNUSED,
                    gpointer      user_data)
{
    PresenceLog *log = user_data;
    GPasteDaemonPresence presence = g_paste_client_get_daemon_presence (client);

    g_array_append_val (log->presences, presence);
    g_ptr_array_add (log->owners, g_dbus_proxy_get_name_owner (G_DBUS_PROXY (client)));
}

static void
presence_log_start (PresenceLog  *log,
                    GPasteClient *client)
{
    log->client = client;
    log->presences = g_array_new (FALSE, FALSE, sizeof (GPasteDaemonPresence));
    log->owners = g_ptr_array_new_with_free_func (g_free);
    g_signal_connect (client, "notify::daemon-presence", G_CALLBACK (on_presence_logged), log);
}

static void
presence_log_stop (PresenceLog *log)
{
    g_signal_handlers_disconnect_by_data (log->client, log);
    g_clear_pointer (&log->presences, g_array_unref);
    g_clear_pointer (&log->owners, g_ptr_array_unref);
}

static GPasteDaemonPresence
presence_log_at (PresenceLog *log,
                 guint        index)
{
    return g_array_index (log->presences, GPasteDaemonPresence, index);
}

/* A daemon taking the name over straight from another is a presence edge like
 * any other: not ready from the moment the bus hands the name over, however
 * soon the successor serves, and ready again only once the proxy addresses it
 * -- so what a consumer asks on that edge reaches the new daemon, not the one
 * standing down (on_name_owner_changed ()). */
static void
test_handoff (void)
{
    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    StandIn first = { 0 };
    StandIn second = { 0 };
    PresenceLog log = { 0 };

    g_assert_no_error (error);

    stand_in_serve (&first, REPLACEABLE);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    g_paste_test_bus_wait_for_owner (G_DBUS_PROXY (client), first.server);

    presence_log_start (&log, client);
    stand_in_serve (&second, G_BUS_NAME_OWNER_FLAGS_REPLACE);
    g_paste_test_bus_wait_for_owner (G_DBUS_PROXY (client), second.server);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);

    g_assert_cmpuint (log.presences->len, ==, 2);
    g_assert_cmpint (presence_log_at (&log, 0), ==, G_PASTE_DAEMON_PRESENCE_STARTING);
    g_assert_cmpint (presence_log_at (&log, 1), ==, G_PASTE_DAEMON_PRESENCE_READY);
    g_assert_cmpstr (g_ptr_array_index (log.owners, 1), ==, g_dbus_connection_get_unique_name (second.server));
    presence_log_stop (&log);

    stand_in_stop (&second);
    stand_in_stop (&first);
}

/* The same for a client built while a daemon already serves -- a window
 * opened, the Shell menu enabled, the usual case -- whose init found the
 * owner rather than being told of it: its watch of the name is what sees a
 * successor that serves at once, nothing else moving. And for a successor
 * that, as both real daemons do, owns the name before it serves anything, the
 * presence staying starting until it does. */
static void
test_handoff_after_init (void)
{
    StandIn first = { 0 };
    StandIn second = { 0 };
    StandIn third = { 0 };
    g_autoptr (GObject) client = NULL;
    PresenceLog log = { 0 };

    stand_in_serve (&first, REPLACEABLE);
    /* Asynchronously, for the reason test_initables () gives. */
    g_paste_client_new (on_initable_ready, &client);
    g_paste_test_bus_wait_until (g_paste_test_bus_is_set, &client, NULL);
    g_assert_nonnull (client);
    wait_for_presence (G_PASTE_CLIENT (client), G_PASTE_DAEMON_PRESENCE_READY);

    presence_log_start (&log, G_PASTE_CLIENT (client));
    stand_in_serve (&second, G_BUS_NAME_OWNER_FLAGS_REPLACE | REPLACEABLE);
    g_paste_test_bus_wait_for_owner (G_DBUS_PROXY (client), second.server);
    wait_for_presence (G_PASTE_CLIENT (client), G_PASTE_DAEMON_PRESENCE_READY);
    g_assert_cmpuint (log.presences->len, ==, 2);
    g_assert_cmpint (presence_log_at (&log, 0), ==, G_PASTE_DAEMON_PRESENCE_STARTING);
    g_assert_cmpint (presence_log_at (&log, 1), ==, G_PASTE_DAEMON_PRESENCE_READY);
    g_assert_cmpstr (g_ptr_array_index (log.owners, 1), ==, g_dbus_connection_get_unique_name (second.server));
    presence_log_stop (&log);

    guint silent_owner;
    g_autoptr (GDBusConnection) silent = stand_in_connect (G_BUS_NAME_OWNER_FLAGS_REPLACE | REPLACEABLE, &silent_owner);

    wait_for_presence (G_PASTE_CLIENT (client), G_PASTE_DAEMON_PRESENCE_STARTING);
    g_paste_test_bus_wait_for_owner (G_DBUS_PROXY (client), silent);
    g_assert_cmpint (g_paste_client_get_daemon_presence (G_PASTE_CLIENT (client)), ==, G_PASTE_DAEMON_PRESENCE_STARTING);

    /* That one replaced in turn by one that serves: ready, once. */
    presence_log_start (&log, G_PASTE_CLIENT (client));
    stand_in_serve (&third, G_BUS_NAME_OWNER_FLAGS_REPLACE);
    g_paste_test_bus_wait_for_owner (G_DBUS_PROXY (client), third.server);
    wait_for_presence (G_PASTE_CLIENT (client), G_PASTE_DAEMON_PRESENCE_READY);
    g_assert_cmpuint (log.presences->len, ==, 1);
    g_assert_cmpstr (g_ptr_array_index (log.owners, 0), ==, g_dbus_connection_get_unique_name (third.server));
    presence_log_stop (&log);

    stand_in_stop (&third);
    g_dbus_connection_close_sync (silent, NULL, NULL);
    g_bus_unown_name (silent_owner);
    stand_in_stop (&second);
    stand_in_stop (&first);
}

/* A client built through the initables for a name of its own follows that
 * name's handoffs, and only those: one of GPaste's leaves it as it was. */
static void
test_handoff_other_name (void)
{
    static const gchar *other_name = "org.gnome.GPaste.Test.Other";
    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteDaemon3) skeleton = g_paste_daemon3_skeleton_new ();
    g_autoptr (GDBusConnection) other = g_paste_test_bus_connect (g_getenv ("DBUS_SESSION_BUS_ADDRESS"));

    g_dbus_interface_skeleton_export (G_DBUS_INTERFACE_SKELETON (skeleton), other, G_PASTE_DAEMON_OBJECT_PATH, &error);
    g_assert_no_error (error);
    g_paste_daemon3_set_history (skeleton, "history");

    guint other_owner = g_bus_own_name_on_connection (other, other_name, G_BUS_NAME_OWNER_FLAGS_NONE, NULL, NULL, NULL, NULL);
    g_autoptr (GObject) client = NULL;

    /* Asynchronously, for the reason test_initables () gives. */
    g_async_initable_new_async (G_PASTE_TYPE_CLIENT, G_PRIORITY_DEFAULT, NULL, on_initable_ready, &client,
                                "g-bus-type",       G_BUS_TYPE_SESSION,
                                "g-name",           other_name,
                                "g-object-path",    G_PASTE_DAEMON_OBJECT_PATH,
                                "g-interface-name", G_PASTE_DAEMON_INTERFACE_NAME,
                                NULL);
    g_paste_test_bus_wait_until (g_paste_test_bus_is_set, &client, NULL);
    g_assert_nonnull (client);
    wait_for_presence (G_PASTE_CLIENT (client), G_PASTE_DAEMON_PRESENCE_READY);

    /* GPaste's own name changing hands, watched through a client of its own. */
    g_autoptr (GPasteClient) watcher = g_paste_client_new_sync (&error);
    StandIn first = { 0 };
    StandIn second = { 0 };

    g_assert_no_error (error);
    stand_in_serve (&first, REPLACEABLE);
    g_paste_test_bus_wait_for_owner (G_DBUS_PROXY (watcher), first.server);
    stand_in_serve (&second, G_BUS_NAME_OWNER_FLAGS_REPLACE);
    g_paste_test_bus_wait_for_owner (G_DBUS_PROXY (watcher), second.server);
    g_paste_test_bus_round_trip (g_dbus_proxy_get_connection (G_DBUS_PROXY (client)), other);
    g_assert_cmpint (g_paste_client_get_daemon_presence (G_PASTE_CLIENT (client)), ==, G_PASTE_DAEMON_PRESENCE_READY);

    stand_in_stop (&second);
    stand_in_stop (&first);
    g_dbus_connection_close_sync (other, NULL, NULL);
    g_bus_unown_name (other_owner);
}

/* A call carrying a string that is not UTF-8, which is all D-Bus carries, is
 * refused before it is sent -- whichever front end makes it, and however it
 * waits for the answer: sent, it would reach the daemon as "[Invalid UTF-8]",
 * a history created under that name. A relative file name is checked as it
 * goes out, joined to a working directory named in another encoding. */
static void
test_invalid_utf8_refused (void)
{
    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    const gchar *latin1 = "caf\xe9";
    const gchar * const uuids[] = { latin1, NULL };
    const gchar * const valid[] = { "uuid", NULL };

    g_assert_no_error (error);

    g_paste_client_switch_history_sync (client, latin1, &error);
    g_assert_error (error, G_IO_ERROR, G_IO_ERROR_INVALID_DATA);
    g_clear_error (&error);
    g_assert_null (g_paste_client_add_password_sync (client, "name", latin1, 0, &error));
    g_assert_error (error, G_IO_ERROR, G_IO_ERROR_INVALID_DATA);
    g_clear_error (&error);
    g_assert_null (g_paste_client_get_items_sync (client, uuids, &error));
    g_assert_error (error, G_IO_ERROR, G_IO_ERROR_INVALID_DATA);
    g_clear_error (&error);
    g_assert_null (g_paste_client_merge_sync (client, latin1, NULL, valid, &error));
    g_assert_error (error, G_IO_ERROR, G_IO_ERROR_INVALID_DATA);
    g_clear_error (&error);

    {
        g_autoptr (GAsyncResult) result = NULL;

        g_paste_client_backup_history (client, "history", latin1, NULL, g_paste_test_env_keep_result, &result);
        g_paste_test_env_wait_result_within (&result, G_PASTE_TEST_BUS_WAIT_SECONDS);
        g_paste_client_backup_history_finish (client, result, &error);
        g_assert_error (error, G_IO_ERROR, G_IO_ERROR_INVALID_DATA);
        g_clear_error (&error);
    }

    {
        g_autoptr (GAsyncResult) result = NULL;

        g_paste_client_get_item (client, latin1, NULL, g_paste_test_env_keep_result, &result);
        g_paste_test_env_wait_result_within (&result, G_PASTE_TEST_BUS_WAIT_SECONDS);
        g_assert_null (g_paste_client_get_item_finish (client, result, &error));
        g_assert_error (error, G_IO_ERROR, G_IO_ERROR_INVALID_DATA);
        g_clear_error (&error);
    }

    g_autofree gchar *cwd = g_get_current_dir ();
    g_autofree gchar *base = g_dir_make_tmp (NULL, NULL);
    g_autofree gchar *directory = g_build_filename (base, latin1, NULL);

    g_assert_cmpint (g_mkdir (directory, 0700), ==, 0);
    g_assert_cmpint (g_chdir (directory), ==, 0);

    {
        g_autoptr (GAsyncResult) result = NULL;

        g_assert_null (g_paste_client_add_file_sync (client, "file", &error));
        g_assert_error (error, G_IO_ERROR, G_IO_ERROR_INVALID_DATA);
        g_clear_error (&error);
        g_paste_client_add_file (client, "file", NULL, g_paste_test_env_keep_result, &result);
        g_paste_test_env_wait_result_within (&result, G_PASTE_TEST_BUS_WAIT_SECONDS);
        g_assert_null (g_paste_client_add_file_finish (client, result, &error));
        g_assert_error (error, G_IO_ERROR, G_IO_ERROR_INVALID_DATA);
    }

    g_assert_cmpint (g_chdir (cwd), ==, 0);
    g_assert_cmpint (g_rmdir (directory), ==, 0);
    g_assert_cmpint (g_rmdir (base), ==, 0);
}

/* A call failing because its daemon left the bus, rather than refusing it. An
 * unknown method is not one: a handoff moves the presence before the daemon
 * standing down can answer one (test_handoff ()), and otherwise it is a daemon
 * older than the method. GDBus, which both daemons use, answers an unexported
 * object or interface with UnknownMethod too. */
static void
test_daemon_gone_error (void)
{
    g_autoptr (GError) no_reply = g_error_new_literal (G_DBUS_ERROR, G_DBUS_ERROR_NO_REPLY, "gone");
    g_autoptr (GError) unknown = g_error_new_literal (G_DBUS_ERROR, G_DBUS_ERROR_SERVICE_UNKNOWN, "gone");
    g_autoptr (GError) no_owner = g_error_new_literal (G_DBUS_ERROR, G_DBUS_ERROR_NAME_HAS_NO_OWNER, "gone");
    g_autoptr (GError) refused = g_error_new_literal (G_PASTE_ERROR, G_PASTE_ERROR_NOT_FOUND, "no such item");
    g_autoptr (GError) timed_out = g_error_new_literal (G_IO_ERROR, G_IO_ERROR_TIMED_OUT, "slow");
    g_autoptr (GError) unknown_method = g_error_new_literal (G_DBUS_ERROR, G_DBUS_ERROR_UNKNOWN_METHOD, "older");

    g_assert_true (g_paste_client_is_daemon_gone_error (no_reply));
    g_assert_true (g_paste_client_is_daemon_gone_error (unknown));
    g_assert_true (g_paste_client_is_daemon_gone_error (no_owner));
    g_assert_false (g_paste_client_is_daemon_gone_error (unknown_method));
    g_assert_false (g_paste_client_is_daemon_gone_error (refused));
    g_assert_false (g_paste_client_is_daemon_gone_error (timed_out));
    g_assert_false (g_paste_client_is_daemon_gone_error (NULL));
}

/* A new owner starting the wait afresh once the two minutes ran out
 * (g_paste_client_notify ()) is test-give-up's, which shortens them. */

/* Without following, there is no wait: absent is absent at once. */
static void
test_unfollowed (void)
{
    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);

    g_assert_no_error (error);
    g_paste_client_follow_daemon (client, FALSE);
    g_paste_client_unfollow_daemon (client);
    g_assert_cmpint (g_paste_client_get_daemon_presence (client), ==, G_PASTE_DAEMON_PRESENCE_ABSENT);
}

/* A client built the way a binding builds one, through the initables rather
 * than g_paste_client_new*(), starts out knowing the daemon is there. */
static void
test_initables (void)
{
    g_autoptr (GError) error = NULL;
    guint owner;
    g_autoptr (GDBusConnection) server = stand_in_connect (G_BUS_NAME_OWNER_FLAGS_NONE, &owner);
    g_autoptr (GPasteDaemon3) skeleton = g_paste_daemon3_skeleton_new ();

    g_dbus_interface_skeleton_export (G_DBUS_INTERFACE_SKELETON (skeleton), server, G_PASTE_DAEMON_OBJECT_PATH, &error);
    g_assert_no_error (error);
    g_paste_daemon3_set_history (skeleton, "history");

    /* Asynchronously first: the stand-in answers the proxy's GetAll on this
     * thread's main context, which a synchronous initialisation would block
     * until it timed out. */
    g_autoptr (GObject) async_client = NULL;

    g_async_initable_new_async (G_PASTE_TYPE_CLIENT, G_PRIORITY_DEFAULT, NULL, on_initable_ready, &async_client,
                                "g-bus-type",       G_BUS_TYPE_SESSION,
                                "g-name",           G_PASTE_BUS_NAME,
                                "g-object-path",    G_PASTE_DAEMON_OBJECT_PATH,
                                "g-interface-name", G_PASTE_DAEMON_INTERFACE_NAME,
                                NULL);
    g_paste_test_bus_wait_until (g_paste_test_bus_is_set, &async_client, NULL);
    g_assert_nonnull (async_client);
    g_assert_cmpint (g_paste_client_get_daemon_presence (G_PASTE_CLIENT (async_client)), ==, G_PASTE_DAEMON_PRESENCE_READY);

    /* Built in two steps, with a handler watching before the init: it hears of
     * the daemon being there, once. */
    g_autoptr (GObject) watched = g_object_new (G_PASTE_TYPE_CLIENT,
                                                "g-bus-type",       G_BUS_TYPE_SESSION,
                                                "g-name",           G_PASTE_BUS_NAME,
                                                "g-object-path",    G_PASTE_DAEMON_OBJECT_PATH,
                                                "g-interface-name", G_PASTE_DAEMON_INTERFACE_NAME,
                                                NULL);
    guint notified = 0;
    gboolean initialised = FALSE;

    g_signal_connect_swapped (watched, "notify::daemon-presence", G_CALLBACK (g_paste_test_bus_count_emission), &notified);
    g_async_initable_init_async (G_ASYNC_INITABLE (watched), G_PRIORITY_DEFAULT, NULL, on_init_ready, &initialised);
    g_paste_test_bus_wait_until (g_paste_test_bus_is_true, &initialised, NULL);
    g_assert_true (initialised);
    g_assert_cmpint (g_paste_client_get_daemon_presence (G_PASTE_CLIENT (watched)), ==, G_PASTE_DAEMON_PRESENCE_READY);
    g_assert_cmpuint (notified, ==, 1);

    g_dbus_interface_skeleton_unexport (G_DBUS_INTERFACE_SKELETON (skeleton));
    g_bus_unown_name (owner);
    wait_for_presence (G_PASTE_CLIENT (async_client), G_PASTE_DAEMON_PRESENCE_ABSENT);

    /* With the daemon gone, the synchronous one has nothing to wait on. */
    g_autoptr (GPasteClient) sync_client = G_PASTE_CLIENT (g_initable_new (G_PASTE_TYPE_CLIENT, NULL, &error,
                                                                           "g-bus-type",       G_BUS_TYPE_SESSION,
                                                                           "g-name",           G_PASTE_BUS_NAME,
                                                                           "g-object-path",    G_PASTE_DAEMON_OBJECT_PATH,
                                                                           "g-interface-name", G_PASTE_DAEMON_INTERFACE_NAME,
                                                                           NULL));

    g_assert_no_error (error);
    g_assert_cmpint (g_paste_client_get_daemon_presence (sync_client), ==, G_PASTE_DAEMON_PRESENCE_ABSENT);
}

/* With no get_property () in the vtable, GDBus hands the proxy's GetAll here
 * too: that one is answered with nothing, a daemon still starting having no
 * history to give, and everything else is sat on -- the invocation, which a
 * reply consumes, kept for the test to answer. */
static void
on_method_call (GDBusConnection       *connection     G_GNUC_UNUSED,
                const gchar           *sender         G_GNUC_UNUSED,
                const gchar           *object_path    G_GNUC_UNUSED,
                const gchar           *interface_name,
                const gchar           *method_name    G_GNUC_UNUSED,
                GVariant              *parameters     G_GNUC_UNUSED,
                GDBusMethodInvocation *invocation,
                gpointer               user_data)
{
    GDBusMethodInvocation **held = user_data;

    if (g_paste_str_equal (interface_name, "org.freedesktop.DBus.Properties"))
        g_dbus_method_invocation_return_value (invocation, g_variant_new_parsed ("(@a{sv} {},)"));
    else
        *held = invocation;
}

/* A request for a daemon still out to one that never answers holds nothing
 * that would keep the client alive: dropping the last reference is what runs
 * the dispose () that cancels it. */
static void
test_probe_released (void)
{
    g_autoptr (GError) error = NULL;
    /* Built before the stand-in is there, for the reason test_initables ()
     * gives. */
    GPasteClient *client = g_paste_client_new_sync (&error);

    g_assert_no_error (error);

    /* Registered by hand rather than through the skeleton, which would serve
     * the History property, empty as it is, and read as a daemon ready: this
     * one is still starting, and sits on whatever it is asked. */
    static const GDBusInterfaceVTable vtable = { on_method_call, NULL, NULL, { 0 } };
    GDBusMethodInvocation *held = NULL;
    guint owner;
    g_autoptr (GDBusConnection) server = stand_in_connect (G_BUS_NAME_OWNER_FLAGS_NONE, &owner);
    guint registration = g_dbus_connection_register_object (server, G_PASTE_DAEMON_OBJECT_PATH,
                                                            g_paste_daemon3_interface_info (),
                                                            &vtable, &held, NULL, &error);

    g_assert_no_error (error);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_STARTING);

    g_paste_client_follow_daemon (client, TRUE);

    g_paste_test_bus_wait_until (g_paste_test_bus_is_set, &held, NULL);
    g_assert_nonnull (held);

    g_object_add_weak_pointer (G_OBJECT (client), (gpointer *) &client);
    g_object_unref (client);
    g_assert_null (client);

    g_dbus_method_invocation_return_value (g_steal_pointer (&held), g_variant_new ("(t)", (guint64) 0));
    g_dbus_connection_unregister_object (server, registration);
    g_bus_unown_name (owner);
}

/* A two-step init against an owner that serves nothing yet: GetAll fills no
 * history, so nothing in GDBusProxy's init moves the presence, and the seed
 * alone tells a handler watching from before the init that a daemon is on its
 * way. (Against a serving daemon, as in test_initables (), the GetAll reply
 * has already said so.) */
static void
test_seed_announced (void)
{
    g_autoptr (GError) error = NULL;
    static const GDBusInterfaceVTable vtable = { on_method_call, NULL, NULL, { 0 } };
    GDBusMethodInvocation *held = NULL;
    guint owner;
    g_autoptr (GDBusConnection) server = stand_in_connect (G_BUS_NAME_OWNER_FLAGS_NONE, &owner);
    guint registration = g_dbus_connection_register_object (server, G_PASTE_DAEMON_OBJECT_PATH,
                                                            g_paste_daemon3_interface_info (),
                                                            &vtable, &held, NULL, &error);

    g_assert_no_error (error);

    g_autoptr (GObject) watched = g_object_new (G_PASTE_TYPE_CLIENT,
                                                "g-bus-type",       G_BUS_TYPE_SESSION,
                                                "g-name",           G_PASTE_BUS_NAME,
                                                "g-object-path",    G_PASTE_DAEMON_OBJECT_PATH,
                                                "g-interface-name", G_PASTE_DAEMON_INTERFACE_NAME,
                                                NULL);
    guint notified = 0;
    gboolean initialised = FALSE;

    g_signal_connect_swapped (watched, "notify::daemon-presence", G_CALLBACK (g_paste_test_bus_count_emission), &notified);
    g_async_initable_init_async (G_ASYNC_INITABLE (watched), G_PRIORITY_DEFAULT, NULL, on_init_ready, &initialised);
    g_paste_test_bus_wait_until (g_paste_test_bus_is_true, &initialised, NULL);
    g_assert_true (initialised);
    g_assert_cmpint (g_paste_client_get_daemon_presence (G_PASTE_CLIENT (watched)), ==, G_PASTE_DAEMON_PRESENCE_STARTING);
    g_assert_cmpuint (notified, ==, 1);

    g_assert_null (held);
    g_dbus_connection_unregister_object (server, registration);
    g_bus_unown_name (owner);
}

/* A GPaste 45 or 50 stood in for: the name, and its own interface on the
 * daemon's path, which knows nothing of this one. */
static guint
legacy_export (GDBusConnection *server)
{
    static const GDBusInterfaceVTable vtable = { 0 };
    g_autoptr (GDBusNodeInfo) node = g_dbus_node_info_new_for_xml ("<node><interface name='org.gnome.GPaste2'/></node>", NULL);
    g_autoptr (GError) error = NULL;
    guint id = g_dbus_connection_register_object (server, G_PASTE_DAEMON_OBJECT_PATH, node->interfaces[0], &vtable, NULL, NULL, &error);

    g_assert_no_error (error);

    return id;
}

typedef struct
{
    gboolean done;
    gboolean legacy;
    GError  *error;
} LegacyAnswer;

static void
on_legacy_answered (GObject      *source_object G_GNUC_UNUSED,
                    GAsyncResult *res,
                    gpointer      user_data)
{
    LegacyAnswer *answer = user_data;

    answer->legacy = g_paste_util_daemon_is_legacy_finish (res, &answer->error);
    answer->done = TRUE;
}

static gboolean
legacy_asked (GPasteClient *client,
              GError      **error)
{
    LegacyAnswer answer = { 0 };

    g_paste_util_daemon_is_legacy (client, NULL, on_legacy_answered, &answer);
    g_paste_test_bus_wait_until (g_paste_test_bus_is_true, &answer.done, NULL);
    /* An answer still out would also land in a frame gone by then. */
    g_assert_true (answer.done);
    if (answer.error)
        g_propagate_error (error, answer.error);

    return answer.legacy;
}

static gboolean
on_sigusr1 (gpointer user_data)
{
    ++*(guint *) user_data;

    return G_SOURCE_CONTINUE;
}

static gboolean
signalled (gconstpointer count,
           gconstpointer arg G_GNUC_UNUSED)
{
    return *(const guint *) count > 0;
}

/* Whom the re-execution asks what it is, and whose pid it asks the bus for.
 * Shared with the filter noting it, which GIO may still be running on its
 * worker once removed, so the filter holds a reference of its own, dropped by
 * its destroy notify. */
typedef struct
{
    GMutex mutex;
    gchar *introspected;
    gchar *pid_of;
} Asked;

static void
asked_clear (gpointer data)
{
    Asked *asked = data;

    g_mutex_clear (&asked->mutex);
    g_free (asked->introspected);
    g_free (asked->pid_of);
}

static void
asked_release (gpointer data)
{
    g_atomic_rc_box_release_full (data, asked_clear);
}

static GDBusMessage *
note_asked (GDBusConnection *connection G_GNUC_UNUSED,
            GDBusMessage    *message,
            gboolean         incoming,
            gpointer         user_data)
{
    Asked *asked = user_data;
    const gchar *member = g_dbus_message_get_member (message);

    if (incoming || g_dbus_message_get_message_type (message) != G_DBUS_MESSAGE_TYPE_METHOD_CALL)
        return message;

    g_autoptr (GMutexLocker) locker = g_mutex_locker_new (&asked->mutex);

    if (g_paste_str_equal (member, "Introspect"))
        g_set_str (&asked->introspected, g_dbus_message_get_destination (message));
    else if (g_paste_str_equal (member, "GetConnectionUnixProcessID"))
        g_variant_get (g_dbus_message_get_body (message), "(s)", &asked->pid_of);

    return message;
}

/* A daemon serving only the interface of a GPaste 45 or 50 is told apart from
 * one serving this interface, and from one that exports nothing yet -- GDBus
 * answering an unknown method alike for all three. It is the one re-executed by
 * signal, the pid file naming the process owning the name; a pid file naming
 * another process, or a daemon of this version, is signalled nothing. */
static void
test_legacy (void)
{
    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    guint signals = 0;
    guint source = g_unix_signal_add (SIGUSR1, on_sigusr1, &signals);
    guint owner;

    g_source_set_name_by_id (source, "[GPaste] test SIGUSR1 counter");
    g_assert_no_error (error);

    g_autoptr (GDBusConnection) server = stand_in_connect (G_BUS_NAME_OWNER_FLAGS_NONE, &owner);

    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_STARTING);
    /* Nothing exported yet: not one of those. */
    g_assert_false (legacy_asked (client, &error));
    g_assert_no_error (error);
    g_assert_false (g_paste_util_reexecute_legacy_daemon (client, &error));
    g_assert_error (error, G_PASTE_ERROR, G_PASTE_ERROR_FAILED);
    g_clear_error (&error);

    guint registration = legacy_export (server);

    g_assert_true (legacy_asked (client, &error));
    g_assert_no_error (error);

    /* The stand-in is this very process, so is the name's owner. Both
     * questions go to that one owner by its unique name, as
     * g_paste_util_reexecute_legacy_daemon () says why, and that is what is
     * checked: two owners racing for the name here would share this pid. */
    Asked *asked = g_atomic_rc_box_new0 (Asked);
    GDBusConnection *connection = g_dbus_proxy_get_connection (G_DBUS_PROXY (client));

    g_mutex_init (&asked->mutex);

    guint filter = g_dbus_connection_add_filter (connection, note_asked, g_atomic_rc_box_acquire (asked), asked_release);

    g_paste_util_write_pid_file ("Daemon");
    g_assert_true (g_paste_util_reexecute_legacy_daemon (client, &error));
    g_assert_no_error (error);
    g_paste_test_bus_wait_until (signalled, &signals, NULL);
    g_assert_cmpuint (signals, ==, 1);
    g_dbus_connection_remove_filter (connection, filter);
    g_mutex_lock (&asked->mutex);
    g_assert_cmpstr (asked->introspected, ==, g_dbus_connection_get_unique_name (server));
    g_assert_cmpstr (asked->pid_of, ==, g_dbus_connection_get_unique_name (server));
    g_mutex_unlock (&asked->mutex);
    asked_release (asked);

    /* Where g_paste_util_write_pid_file () put it, as
     * g_paste_util_get_runtime_dir () spells the directory. */
    g_autofree gchar *pid_file = g_build_filename (g_get_user_runtime_dir (), PACKAGE_NAME, "Daemon", "pid", NULL);

    /* A process of the test's own, which SIGUSR1 would end: what a pid file
     * left stale names can be anything, and nothing outside the test is to be
     * signalled should the check fail. */
    const gchar *sleeper[] = { "sleep", "60", NULL };
    GPid stale;

    g_assert_true (g_spawn_async (NULL, (gchar **) sleeper, NULL, G_SPAWN_SEARCH_PATH | G_SPAWN_DO_NOT_REAP_CHILD,
                                  NULL, NULL, &stale, &error));
    g_assert_no_error (error);

    g_autofree gchar *stale_pid = g_strdup_printf ("%" G_PID_FORMAT, stale);

    signals = 0;
    g_assert_true (g_file_set_contents (pid_file, stale_pid, -1, NULL));
    g_assert_false (g_paste_util_reexecute_legacy_daemon (client, &error));
    g_assert_error (error, G_PASTE_ERROR, G_PASTE_ERROR_FAILED);
    g_clear_error (&error);
    g_paste_test_bus_pump (100);
    g_assert_cmpuint (signals, ==, 0);
    g_assert_cmpint (waitpid (stale, NULL, WNOHANG), ==, 0);
    kill (stale, SIGTERM);
    g_assert_cmpint (waitpid (stale, NULL, 0), ==, stale);
    g_spawn_close_pid (stale);

    g_dbus_connection_unregister_object (server, registration);

    g_autoptr (GPasteDaemon3) skeleton = g_paste_daemon3_skeleton_new ();

    g_dbus_interface_skeleton_export (G_DBUS_INTERFACE_SKELETON (skeleton), server, G_PASTE_DAEMON_OBJECT_PATH, &error);
    g_assert_no_error (error);
    g_paste_util_write_pid_file ("Daemon");
    g_assert_false (legacy_asked (client, &error));
    g_assert_no_error (error);
    g_assert_false (g_paste_util_reexecute_legacy_daemon (client, &error));
    g_assert_error (error, G_PASTE_ERROR, G_PASTE_ERROR_FAILED);
    g_clear_error (&error);
    g_paste_test_bus_pump (100);
    g_assert_cmpuint (signals, ==, 0);

    g_dbus_interface_skeleton_unexport (G_DBUS_INTERFACE_SKELETON (skeleton));
    g_unlink (pid_file);
    g_source_remove (source);
    g_bus_unown_name (owner);
    g_dbus_connection_close_sync (server, NULL, NULL);
}

/* The daemon path's Introspect answered with an error GLib maps to no domain,
 * as an owner of the name that is no GPaste daemon could. */
static GDBusMessage *
refuse_introspect (GDBusConnection *connection,
                   GDBusMessage    *message,
                   gboolean         incoming,
                   gpointer         user_data G_GNUC_UNUSED)
{
    if (!incoming || g_dbus_message_get_message_type (message) != G_DBUS_MESSAGE_TYPE_METHOD_CALL ||
        g_strcmp0 (g_dbus_message_get_member (message), "Introspect"))
        return message;

    g_autoptr (GDBusMessage) owned = message;
    g_autoptr (GDBusMessage) reply = g_dbus_message_new_method_error_literal (owned, "org.example.Foo", "not telling");

    g_dbus_connection_send_message (connection, reply, G_DBUS_SEND_MESSAGE_FLAGS_NONE, NULL, NULL);

    return NULL;
}

/* The question failing hands its error out as the client's calls do
 * (g_paste_client_strip_remote_error ()), domain and code kept. */
static void
test_legacy_errors (void)
{
    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    guint owner;

    g_assert_no_error (error);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_ABSENT);
    g_assert_false (legacy_asked (client, &error));
    g_assert_error (error, G_DBUS_ERROR, G_DBUS_ERROR_NAME_HAS_NO_OWNER);
    g_assert_false (g_str_has_prefix (error->message, "GDBus.Error:"));
    g_clear_error (&error);

    g_autoptr (GDBusConnection) server = stand_in_connect (G_BUS_NAME_OWNER_FLAGS_NONE, &owner);
    guint filter = g_dbus_connection_add_filter (server, refuse_introspect, NULL, NULL);

    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_STARTING);
    g_assert_false (legacy_asked (client, &error));
    g_assert_error (error, G_IO_ERROR, G_IO_ERROR_DBUS_ERROR);
    g_assert_cmpstr (error->message, ==, "GDBus.Error:org.example.Foo: not telling");

    g_dbus_connection_remove_filter (server, filter);
    g_bus_unown_name (owner);
    g_dbus_connection_close_sync (server, NULL, NULL);
}

/* A client @stand_in serves. A call reaching the stand-in is made
 * asynchronously, its answer waited for (g_paste_test_env_wait_result_within ()):
 * the stand-in answers from this very main loop, so a synchronous call would
 * wait on itself. */
static GPasteClient *
ready_client (StandIn *stand_in)
{
    g_autoptr (GError) error = NULL;
    GPasteClient *client = g_paste_client_new_sync (&error);

    g_assert_no_error (error);
    stand_in_serve (stand_in, REPLACEABLE);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);

    return client;
}

static gboolean
refuse_backup (GPasteDaemon3         *skeleton G_GNUC_UNUSED,
               GDBusMethodInvocation *invocation,
               const gchar           *history G_GNUC_UNUSED,
               const gchar           *backup G_GNUC_UNUSED,
               gpointer               user_data G_GNUC_UNUSED)
{
    g_dbus_method_invocation_return_error_literal (invocation, G_PASTE_ERROR, G_PASTE_ERROR_NOT_FOUND, "no history goes by that name");

    return TRUE;
}

static gboolean
refuse_item (GPasteDaemon3         *skeleton G_GNUC_UNUSED,
             GDBusMethodInvocation *invocation,
             const gchar           *uuid G_GNUC_UNUSED,
             gpointer               user_data G_GNUC_UNUSED)
{
    g_dbus_method_invocation_return_error_literal (invocation, G_PASTE_ERROR, G_PASTE_ERROR_NOT_FOUND, "no item goes by that uuid");

    return TRUE;
}

static gboolean
refuse_doctor (GPasteDaemon3         *skeleton G_GNUC_UNUSED,
               GDBusMethodInvocation *invocation,
               gpointer               user_data G_GNUC_UNUSED)
{
    g_dbus_method_invocation_return_error_literal (invocation, G_PASTE_ERROR, G_PASTE_ERROR_FAILED, "nothing hosts the check");

    return TRUE;
}

/* A refusal comes with its domain and code and the daemon's own words, not
 * GDBus' "GDBus.Error:<name>: " in front of them -- a method answering
 * nothing, one answering something, and hand-written ones alike. */
static void
test_errors_stripped (void)
{
    StandIn stand_in = { 0 };
    g_autoptr (GPasteClient) client = ready_client (&stand_in);
    g_autoptr (GError) error = NULL;
    g_autoptr (GAsyncResult) backup = NULL;
    g_autoptr (GAsyncResult) item = NULL;
    g_autoptr (GAsyncResult) items = NULL;
    g_autoptr (GAsyncResult) doctor = NULL;

    g_signal_connect (stand_in.skeleton, "handle-backup-history", G_CALLBACK (refuse_backup), NULL);
    g_signal_connect (stand_in.skeleton, "handle-get-item", G_CALLBACK (refuse_item), NULL);
    g_signal_connect (stand_in.skeleton, "handle-get-items", G_CALLBACK (refuse_item), NULL);
    g_signal_connect (stand_in.skeleton, "handle-doctor", G_CALLBACK (refuse_doctor), NULL);

    g_paste_client_backup_history (client, "history", "backup", NULL, g_paste_test_env_keep_result, &backup);
    g_paste_test_env_wait_result_within (&backup, G_PASTE_TEST_BUS_WAIT_SECONDS);
    g_paste_client_backup_history_finish (client, backup, &error);
    g_assert_error (error, G_PASTE_ERROR, G_PASTE_ERROR_NOT_FOUND);
    g_assert_cmpstr (error->message, ==, "no history goes by that name");
    g_clear_error (&error);

    g_paste_client_get_item (client, "00000000-0000-4000-8000-000000000001", NULL, g_paste_test_env_keep_result, &item);
    g_paste_test_env_wait_result_within (&item, G_PASTE_TEST_BUS_WAIT_SECONDS);
    g_assert_null (g_paste_client_get_item_finish (client, item, &error));
    g_assert_error (error, G_PASTE_ERROR, G_PASTE_ERROR_NOT_FOUND);
    g_assert_cmpstr (error->message, ==, "no item goes by that uuid");
    g_clear_error (&error);

    const gchar *uuids[] = { "00000000-0000-4000-8000-000000000001", NULL };

    g_paste_client_get_items (client, uuids, NULL, g_paste_test_env_keep_result, &items);
    g_paste_test_env_wait_result_within (&items, G_PASTE_TEST_BUS_WAIT_SECONDS);
    g_assert_null (g_paste_client_get_items_finish (client, items, &error));
    g_assert_error (error, G_PASTE_ERROR, G_PASTE_ERROR_NOT_FOUND);
    g_assert_cmpstr (error->message, ==, "no item goes by that uuid");
    g_clear_error (&error);

    gboolean healthy = TRUE;

    g_paste_client_doctor (client, NULL, g_paste_test_env_keep_result, &doctor);
    g_paste_test_env_wait_result_within (&doctor, G_PASTE_TEST_BUS_WAIT_SECONDS);
    g_assert_null (g_paste_client_doctor_finish (client, doctor, &healthy, &error));
    g_assert_error (error, G_PASTE_ERROR, G_PASTE_ERROR_FAILED);
    g_assert_cmpstr (error->message, ==, "nothing hosts the check");
    g_assert_false (healthy);

    stand_in_stop (&stand_in);
}

static gboolean
serve_doctor (GPasteDaemon3         *skeleton,
              GDBusMethodInvocation *invocation,
              gpointer               user_data G_GNUC_UNUSED)
{
    static const gchar * const report[] = { "Restricted the folder", "“other” could not be read", NULL };

    g_paste_daemon3_complete_doctor (skeleton, invocation, report, FALSE);

    return TRUE;
}

/* What the check found reaches the caller line for line, a store it leaves
 * unhealthy said to be. */
static void
test_doctor_answers (void)
{
    StandIn stand_in = { 0 };
    g_autoptr (GPasteClient) client = ready_client (&stand_in);
    g_autoptr (GError) error = NULL;
    g_autoptr (GAsyncResult) result = NULL;
    gboolean healthy = TRUE;

    g_signal_connect (stand_in.skeleton, "handle-doctor", G_CALLBACK (serve_doctor), NULL);
    g_paste_client_doctor (client, NULL, g_paste_test_env_keep_result, &result);
    g_paste_test_env_wait_result_within (&result, G_PASTE_TEST_BUS_WAIT_SECONDS);

    g_auto (GStrv) report = g_paste_client_doctor_finish (client, result, &healthy, &error);

    g_assert_no_error (error);
    g_assert_cmpstrv (report, ((const gchar * const []) { "Restricted the folder", "“other” could not be read", NULL }));
    g_assert_false (healthy);

    stand_in_stop (&stand_in);
}

/* Past the proxy's default timeout, which the test cuts to a fifth of a
 * second: the stand-in answering, as the daemon does, once a worker has been
 * through the store. */
#define STORE_ANSWER_MS 600

static gboolean
answer_store_call (gpointer user_data)
{
    GDBusMethodInvocation *invocation = user_data;
    const gchar *method = g_dbus_method_invocation_get_method_name (invocation);

    if (g_paste_str_equal (method, "ListHistories"))
        g_dbus_method_invocation_return_value (invocation, g_variant_new_parsed ("(@a(st) [('history', 0)],)"));
    else
        g_dbus_method_invocation_return_value (invocation, NULL);

    return G_SOURCE_REMOVE;
}

/* Connected swapped, so that one handler serves the three methods: the
 * arguments past the invocation are not read. */
static gboolean
store_call_later (gpointer               data G_GNUC_UNUSED,
                  GDBusMethodInvocation *invocation)
{
    g_source_set_name_by_id (g_timeout_add (STORE_ANSWER_MS, answer_store_call, invocation), "[GPaste] test store answer");

    return TRUE;
}

/* BackupHistory, EmptyHistory and ListHistories wait for their answer past the
 * proxy's default timeout: the daemon answers each once a worker has written
 * or counted a store, which slow storage or a long queue of writes can take
 * longer than that over, and a backup reported failed is one still written. */
static void
test_store_calls_wait (void)
{
    StandIn stand_in = { 0 };
    g_autoptr (GPasteClient) client = ready_client (&stand_in);

    g_signal_connect_swapped (stand_in.skeleton, "handle-backup-history", G_CALLBACK (store_call_later), NULL);
    g_signal_connect_swapped (stand_in.skeleton, "handle-empty-history", G_CALLBACK (store_call_later), NULL);
    g_signal_connect_swapped (stand_in.skeleton, "handle-list-histories", G_CALLBACK (store_call_later), NULL);
    g_dbus_proxy_set_default_timeout (G_DBUS_PROXY (client), STORE_ANSWER_MS / 3);

    /* All three out at once, each answered on a timer of its own. */
    g_autoptr (GAsyncResult) backed_up = NULL;
    g_autoptr (GAsyncResult) emptied = NULL;
    g_autoptr (GAsyncResult) listed = NULL;

    g_paste_client_backup_history (client, "history", "backup", NULL, g_paste_test_env_keep_result, &backed_up);
    g_paste_client_empty_history (client, "other", NULL, g_paste_test_env_keep_result, &emptied);
    g_paste_client_list_histories (client, NULL, g_paste_test_env_keep_result, &listed);

    {
        g_autoptr (GError) error = NULL;

        g_paste_test_env_wait_result_within (&backed_up, G_PASTE_TEST_BUS_WAIT_SECONDS);
        g_paste_client_backup_history_finish (client, backed_up, &error);
        g_assert_no_error (error);
    }
    {
        g_autoptr (GError) error = NULL;

        g_paste_test_env_wait_result_within (&emptied, G_PASTE_TEST_BUS_WAIT_SECONDS);
        g_paste_client_empty_history_finish (client, emptied, &error);
        g_assert_no_error (error);
    }
    {
        g_autoptr (GError) error = NULL;

        g_paste_test_env_wait_result_within (&listed, G_PASTE_TEST_BUS_WAIT_SECONDS);

        g_autolist (GPasteClientHistory) histories = g_paste_client_list_histories_finish (client, listed, &error);

        g_assert_no_error (error);
        g_assert_cmpuint (g_list_length (histories), ==, 1);
    }

    stand_in_stop (&stand_in);
}

/* What the stand-in answers GetItem and GetHistory with. */
static const gchar *served_uuid;
static guint32      served_kind;

static GVariant *
served_item (const gchar *uuid)
{
    static const gchar *notes[] = { NULL };

    return g_variant_new (G_PASTE_ITEM_VARIANT_FORMAT, uuid, "value", served_kind, FALSE, notes);
}

static gboolean
serve_item (GPasteDaemon3         *skeleton,
            GDBusMethodInvocation *invocation,
            const gchar           *uuid G_GNUC_UNUSED,
            gpointer               user_data G_GNUC_UNUSED)
{
    g_paste_daemon3_complete_get_item (skeleton, invocation, served_item (served_uuid));

    return TRUE;
}

static gboolean
serve_history (GPasteDaemon3         *skeleton,
               GDBusMethodInvocation *invocation,
               gpointer               user_data G_GNUC_UNUSED)
{
    g_auto (GVariantBuilder) builder = G_VARIANT_BUILDER_INIT (G_VARIANT_TYPE (G_PASTE_ITEMS_VARIANT_STRING));

    g_variant_builder_add_value (&builder, served_item ("00000000-0000-4000-8000-000000000001"));
    g_variant_builder_add_value (&builder, served_item (served_uuid));
    g_paste_daemon3_complete_get_history (skeleton, invocation, g_variant_builder_end (&builder));

    return TRUE;
}

/* A kind this library does not know is read as text, rather than stored as an
 * enumeration value no binding can hand out; an item with no valid uuid is no
 * item -- an error for a single one, left out of a list. */
static void
test_items_read (void)
{
    StandIn stand_in = { 0 };
    g_autoptr (GPasteClient) client = ready_client (&stand_in);

    g_signal_connect (stand_in.skeleton, "handle-get-item", G_CALLBACK (serve_item), NULL);
    g_signal_connect (stand_in.skeleton, "handle-get-history", G_CALLBACK (serve_history), NULL);

    served_uuid = "00000000-0000-4000-8000-000000000002";
    for (guint i = 0; i < 2; ++i)
    {
        g_autoptr (GError) error = NULL;
        g_autoptr (GAsyncResult) result = NULL;

        served_kind = (i) ? 99 : G_PASTE_ITEM_KIND_INVALID;
        g_paste_client_get_item (client, served_uuid, NULL, g_paste_test_env_keep_result, &result);
        g_paste_test_env_wait_result_within (&result, G_PASTE_TEST_BUS_WAIT_SECONDS);

        g_autoptr (GPasteClientItem) item = g_paste_client_get_item_finish (client, result, &error);

        g_assert_no_error (error);
        g_assert_cmpint (g_paste_client_item_get_kind (item), ==, G_PASTE_ITEM_KIND_TEXT);
        g_assert_cmpstr (g_paste_client_item_get_value (item), ==, "value");
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GAsyncResult) invalid = NULL;
    g_autoptr (GAsyncResult) history = NULL;

    served_uuid = "not-a-uuid";
    served_kind = G_PASTE_ITEM_KIND_TEXT;
    g_paste_client_get_item (client, "00000000-0000-4000-8000-000000000002", NULL, g_paste_test_env_keep_result, &invalid);
    g_paste_test_env_wait_result_within (&invalid, G_PASTE_TEST_BUS_WAIT_SECONDS);
    g_assert_null (g_paste_client_get_item_finish (client, invalid, &error));
    g_assert_error (error, G_IO_ERROR, G_IO_ERROR_INVALID_DATA);

    g_paste_client_get_history (client, NULL, g_paste_test_env_keep_result, &history);
    g_paste_test_env_wait_result_within (&history, G_PASTE_TEST_BUS_WAIT_SECONDS);
    g_autolist (GPasteClientItem) items = g_paste_client_get_history_finish (client, history, NULL);

    g_assert_cmpuint (g_list_length (items), ==, 1);

    stand_in_stop (&stand_in);
}

static guint files_asked;

static gboolean
count_add_file (GPasteDaemon3         *skeleton,
                GDBusMethodInvocation *invocation,
                const gchar           *file G_GNUC_UNUSED,
                gpointer               user_data G_GNUC_UNUSED)
{
    ++files_asked;
    g_paste_daemon3_complete_add_file (skeleton, invocation, "00000000-0000-4000-8000-000000000001");

    return TRUE;
}

/* A path that is not UTF-8 -- a relative one in a working directory named in
 * another encoding included -- is refused before anything is sent, rather
 * than sent as "[Invalid UTF-8]". So is a relative one in a working directory
 * that has gone, rather than sent as a path under "/". */
static void
test_add_file_not_utf8 (void)
{
    StandIn stand_in = { 0 };
    g_autoptr (GPasteClient) client = ready_client (&stand_in);
    g_autoptr (GError) error = NULL;
    g_autoptr (GAsyncResult) result = NULL;
    g_autoptr (GAsyncResult) sent = NULL;

    files_asked = 0;
    g_signal_connect (stand_in.skeleton, "handle-add-file", G_CALLBACK (count_add_file), NULL);

    g_assert_null (g_paste_client_add_file_sync (client, "/tmp/caf\xe9", &error));
    g_assert_error (error, G_IO_ERROR, G_IO_ERROR_INVALID_DATA);
    g_clear_error (&error);

    g_autofree gchar *here = g_get_current_dir ();
    g_autofree gchar *dir = g_dir_make_tmp ("gpaste-\xe9-XXXXXX", &error);

    g_assert_no_error (error);
    g_assert_cmpint (g_chdir (dir), ==, 0);
    g_paste_client_add_file (client, "notes.txt", NULL, g_paste_test_env_keep_result, &result);
    g_assert_cmpint (g_chdir (here), ==, 0);
    g_assert_cmpint (g_rmdir (dir), ==, 0);
    g_paste_test_env_wait_result_within (&result, G_PASTE_TEST_BUS_WAIT_SECONDS);

    g_assert_null (g_paste_client_add_file_finish (client, result, &error));
    g_assert_error (error, G_IO_ERROR, G_IO_ERROR_INVALID_DATA);
    g_assert_cmpuint (files_asked, ==, 0);
    g_clear_error (&error);

    g_autofree gchar *gone = g_dir_make_tmp ("gpaste-gone-XXXXXX", &error);

    g_assert_no_error (error);
    g_assert_cmpint (g_chdir (gone), ==, 0);
    g_assert_cmpint (g_rmdir (gone), ==, 0);
    g_assert_null (g_paste_client_add_file_sync (client, "notes.txt", &error));
    g_assert_cmpint (g_chdir (here), ==, 0);
    g_assert_error (error, G_FILE_ERROR, G_FILE_ERROR_NOENT);
    g_assert_cmpuint (files_asked, ==, 0);

    g_paste_client_add_file (client, "/tmp/notes.txt", NULL, g_paste_test_env_keep_result, &sent);
    g_paste_test_env_wait_result_within (&sent, G_PASTE_TEST_BUS_WAIT_SECONDS);
    g_autofree gchar *uuid = g_paste_client_add_file_finish (client, sent, NULL);

    g_assert_nonnull (uuid);
    g_assert_cmpuint (files_asked, ==, 1);

    stand_in_stop (&stand_in);
}

/* A NULL @file is refused rather than sent as the working directory. Run in a
 * subprocess, the critical being fatal under g_test. */
static void
test_add_file_null (void)
{
    if (!g_test_subprocess ())
    {
        g_test_trap_subprocess (NULL, 0, G_TEST_SUBPROCESS_DEFAULT);
        g_test_trap_assert_failed ();
        g_test_trap_assert_stderr ("*assertion 'file' failed*");
        return;
    }

    g_autoptr (GPasteClient) client = g_paste_client_new_sync (NULL);

    g_paste_client_add_file_sync (client, NULL, NULL);
}

static gboolean
reexecute_unanswered (GPasteDaemon3         *skeleton G_GNUC_UNUSED,
                      GDBusMethodInvocation *invocation G_GNUC_UNUSED,
                      gpointer               user_data)
{
    /* As a re-exec goes: the connection closes, the call never answered. */
    g_dbus_connection_close_sync (user_data, NULL, NULL);

    return TRUE;
}

static gboolean
reexecute_refused (GPasteDaemon3         *skeleton G_GNUC_UNUSED,
                   GDBusMethodInvocation *invocation,
                   gpointer               user_data G_GNUC_UNUSED)
{
    g_dbus_method_invocation_return_error_literal (invocation, G_IO_ERROR, G_IO_ERROR_NOT_DIRECTORY, "not a directory");

    return TRUE;
}

/* A Reexecute left unanswered by a daemon going away is the success it is; a
 * refusal sharing the code of that NoReply in another domain is not. */
static void
test_reexecute_answers (void)
{
    for (guint i = 0; i < 2; ++i)
    {
        StandIn stand_in = { 0 };
        g_autoptr (GPasteClient) client = ready_client (&stand_in);
        g_autoptr (GError) error = NULL;
        g_autoptr (GAsyncResult) result = NULL;

        if (i)
            g_signal_connect (stand_in.skeleton, "handle-reexecute", G_CALLBACK (reexecute_refused), NULL);
        else
            g_signal_connect (stand_in.skeleton, "handle-reexecute", G_CALLBACK (reexecute_unanswered), stand_in.server);

        g_paste_client_reexecute (client, NULL, g_paste_test_env_keep_result, &result);
        g_paste_test_env_wait_result_within (&result, G_PASTE_TEST_BUS_WAIT_SECONDS);
        g_paste_client_reexecute_finish (client, result, &error);
        if (i)
            g_assert_error (error, G_IO_ERROR, G_IO_ERROR_NOT_DIRECTORY);
        else
            g_assert_no_error (error);

        stand_in_stop (&stand_in);
    }
}

/* Whether nobody owns the name, asked of the bus on @connection synchronously:
 * on a context of the call's own, so the default one, where a proxy hears of
 * its owner leaving, is not run for it. */
static gboolean
name_unowned (GDBusConnection *connection)
{
    g_autoptr (GError) error = NULL;
    g_autoptr (GVariant) owner = g_dbus_connection_call_sync (connection, "org.freedesktop.DBus", "/org/freedesktop/DBus",
                                                              "org.freedesktop.DBus", "GetNameOwner",
                                                              g_variant_new ("(s)", G_PASTE_BUS_NAME), G_VARIANT_TYPE ("(s)"),
                                                              G_DBUS_CALL_FLAGS_NONE, -1, NULL, &error);

    return g_error_matches (error, G_DBUS_ERROR, G_DBUS_ERROR_NAME_HAS_NO_OWNER);
}

/* A Reexecute starts no daemon: one sent to a name nobody owns fails with
 * NameHasNoOwner, where a call the bus may start a daemon for fails with
 * ServiceUnknown on this bus, which has none to start -- and so does one sent
 * once the owner has gone but before the client hears of it, the presence
 * still reading ready, which is what a caller opening the migration gate
 * would have read last. Either says so in GPaste's words, as the wait for a
 * daemon does, and is still a daemon gone. */
static void
test_reexecute_starts_nothing (void)
{
    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    g_autoptr (GAsyncResult) result = NULL;

    g_assert_no_error (error);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_ABSENT);
    g_paste_client_reexecute (client, NULL, g_paste_test_env_keep_result, &result);
    g_paste_test_env_wait_result_within (&result, G_PASTE_TEST_BUS_WAIT_SECONDS);
    g_paste_client_reexecute_finish (client, result, &error);
    g_assert_error (error, G_DBUS_ERROR, G_DBUS_ERROR_NAME_HAS_NO_OWNER);
    g_assert_cmpstr (error->message, ==, g_paste_util_no_daemon_message ());
    g_assert_true (g_paste_client_is_daemon_gone_error (error));
    g_clear_error (&error);

    StandIn stand_in = { 0 };
    g_autoptr (GPasteClient) served = ready_client (&stand_in);
    GDBusConnection *connection = g_dbus_proxy_get_connection (G_DBUS_PROXY (served));
    gint64 deadline = g_get_monotonic_time () + G_PASTE_TEST_BUS_WAIT_SECONDS * G_USEC_PER_SEC;

    stand_in_stop (&stand_in);
    while (!name_unowned (connection) && g_get_monotonic_time () < deadline)
        g_usleep (10000);
    g_assert_true (name_unowned (connection));
    g_assert_cmpint (g_paste_client_get_daemon_presence (served), ==, G_PASTE_DAEMON_PRESENCE_READY);

    g_paste_client_reexecute_sync (served, &error);
    g_assert_error (error, G_DBUS_ERROR, G_DBUS_ERROR_NAME_HAS_NO_OWNER);
    g_assert_cmpstr (error->message, ==, "No GPaste daemon is serving a history.");
    g_assert_true (g_paste_client_is_daemon_gone_error (error));
}

static void
record_presence (GPasteClient *client,
                 GParamSpec   *pspec G_GNUC_UNUSED,
                 gpointer      user_data)
{
    *(GPasteDaemonPresence *) user_data = g_paste_client_get_daemon_presence (client);
}

/* An owner that leaves before it ever served gets the grace second any daemon
 * leaving does, rather than reading as absent the moment it goes -- its own
 * grace from arriving having long run out by then. */
static void
test_starting_owner_leaves (void)
{
    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    GPasteDaemonPresence at_gone = G_PASTE_DAEMON_PRESENCE_READY;
    guint owner;

    g_assert_no_error (error);
    g_paste_client_follow_daemon (client, FALSE);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_ABSENT);

    g_autoptr (GDBusConnection) server = stand_in_connect (G_BUS_NAME_OWNER_FLAGS_NONE, &owner);

    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_STARTING);
    /* Past the arrival's grace second, so that only the leave can keep the
     * presence starting: a seconds timer fires on GLib's per-process second
     * mark, up to 1.75 s after it is armed. */
    g_paste_test_bus_pump (2000);
    g_assert_cmpint (g_paste_client_get_daemon_presence (client), ==, G_PASTE_DAEMON_PRESENCE_STARTING);

    g_signal_connect (client, "notify::g-name-owner", G_CALLBACK (record_presence), &at_gone);
    g_bus_unown_name (owner);
    g_paste_test_bus_wait_for_owner (G_DBUS_PROXY (client), NULL);
    g_assert_cmpint (at_gone, ==, G_PASTE_DAEMON_PRESENCE_STARTING);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_ABSENT);

    g_paste_client_unfollow_daemon (client);
    g_dbus_connection_close_sync (server, NULL, NULL);
}

/* The wait runs on the context the client was built in, as its D-Bus callbacks
 * do: one built under a thread-default context of its own sees its presence
 * move as that context runs, and only then. */
static void
test_own_context (void)
{
    g_autoptr (GError) error = NULL;
    g_autoptr (GMainContext) context = g_main_context_new ();

    g_main_context_push_thread_default (context);

    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);

    g_assert_no_error (error);
    g_paste_client_follow_daemon (client, FALSE);
    g_main_context_pop_thread_default (context);
    g_assert_cmpint (g_paste_client_get_daemon_presence (client), ==, G_PASTE_DAEMON_PRESENCE_STARTING);

    wait_for_presence_on (client, context, G_PASTE_DAEMON_PRESENCE_ABSENT);

    g_paste_client_unfollow_daemon (client);
}

/* So does the request for a daemon, asked for while another context is the
 * thread's default: its reply lands on the client's own, and the wait it
 * starts with it, where on that other context, never run, it would keep the
 * presence starting for good. */
static void
test_own_context_probe (void)
{
    g_autoptr (GError) error = NULL;
    g_autoptr (GMainContext) context = g_main_context_new ();

    g_main_context_push_thread_default (context);

    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);

    g_main_context_pop_thread_default (context);
    g_assert_no_error (error);
    g_paste_client_follow_daemon (client, TRUE);
    g_assert_cmpint (g_paste_client_get_daemon_presence (client), ==, G_PASTE_DAEMON_PRESENCE_STARTING);

    wait_for_presence_on (client, context, G_PASTE_DAEMON_PRESENCE_ABSENT);

    g_paste_client_unfollow_daemon (client);
}

static void
on_peer_ready (GObject      *source_object G_GNUC_UNUSED,
               GAsyncResult *res,
               gpointer      user_data)
{
    g_autoptr (GError) error = NULL;

    *(GDBusConnection **) user_data = g_dbus_connection_new_finish (res, &error);
    g_assert_no_error (error);
}

static GIOStream *
peer_stream (gint fd)
{
    g_autoptr (GError) error = NULL;
    g_autoptr (GSocket) socket = g_socket_new_from_fd (fd, &error);

    g_assert_no_error (error);

    return G_IO_STREAM (g_socket_connection_factory_create_connection (socket));
}

/* The calls sent to a message bus -- an owner asked for, a match added --
 * counted on GDBus's worker thread. */
static guint bus_calls;

static GDBusMessage *
count_bus_calls (GDBusConnection *connection G_GNUC_UNUSED,
                 GDBusMessage    *message,
                 gboolean         incoming,
                 gpointer         user_data G_GNUC_UNUSED)
{
    if (!incoming && g_dbus_message_get_message_type (message) == G_DBUS_MESSAGE_TYPE_METHOD_CALL &&
        g_paste_str_equal (g_dbus_message_get_destination (message), "org.freedesktop.DBus"))
        g_atomic_int_inc (&bus_calls);

    return message;
}

/* A client on a peer-to-peer connection, built through the initables with no
 * name, as GDBusProxy allows, has no bus to hear of owners from and does not
 * ask one: the peer would refuse such a call, which would leave the presence
 * absent all the same. */
static void
test_peer_to_peer (void)
{
    g_autoptr (GError) error = NULL;
    gint fds[2];

    g_assert_cmpint (socketpair (AF_UNIX, SOCK_STREAM, 0, fds), ==, 0);

    g_autofree gchar *guid = g_dbus_generate_guid ();
    g_autoptr (GIOStream) server_stream = peer_stream (fds[0]);
    g_autoptr (GIOStream) client_stream = peer_stream (fds[1]);
    g_autoptr (GDBusConnection) server = NULL;

    g_dbus_connection_new (server_stream, guid, G_DBUS_CONNECTION_FLAGS_AUTHENTICATION_SERVER | G_DBUS_CONNECTION_FLAGS_AUTHENTICATION_ALLOW_ANONYMOUS,
                           NULL, NULL, on_peer_ready, &server);

    g_autoptr (GDBusConnection) connection = g_dbus_connection_new_sync (client_stream, NULL, G_DBUS_CONNECTION_FLAGS_AUTHENTICATION_CLIENT, NULL, NULL, &error);

    g_assert_no_error (error);
    g_paste_test_bus_wait_until (g_paste_test_bus_is_set, &server, NULL);
    g_assert_nonnull (server);
    bus_calls = 0;
    g_dbus_connection_add_filter (connection, count_bus_calls, NULL, NULL);

    g_autoptr (GPasteClient) client = g_initable_new (G_PASTE_TYPE_CLIENT, NULL, &error,
                                                      "g-connection", connection,
                                                      "g-object-path", G_PASTE_DAEMON_OBJECT_PATH,
                                                      "g-interface-name", G_PASTE_DAEMON_INTERFACE_NAME,
                                                      "g-flags", G_DBUS_PROXY_FLAGS_DO_NOT_LOAD_PROPERTIES,
                                                      NULL);

    g_assert_no_error (error);
    g_assert_cmpint (g_paste_client_get_daemon_presence (client), ==, G_PASTE_DAEMON_PRESENCE_ABSENT);
    /* Whatever the client sent has been through the filter once written. */
    g_assert_true (g_dbus_connection_flush_sync (connection, NULL, &error));
    g_assert_no_error (error);
    g_assert_cmpuint (g_atomic_int_get (&bus_calls), ==, 0);
    g_dbus_connection_close_sync (connection, NULL, NULL);
}

typedef struct
{
    gboolean done;
    gboolean serving;
    GError  *error;
} Waited;

static void
on_waited (GObject      *source_object G_GNUC_UNUSED,
           GAsyncResult *res,
           gpointer      user_data)
{
    Waited *waited = user_data;

    waited->serving = g_paste_util_wait_for_daemon_finish (res, &waited->error);
    waited->done = TRUE;
}

/* Waiting for a daemon to serve goes on while one owns the name before it
 * exports anything, answering once it serves; one serving only a GPaste 45 or
 * 50's interface fails it at once, saying how to restart it. */
static void
test_wait_for_daemon (void)
{
    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    guint owner;

    g_assert_no_error (error);

    g_autoptr (GDBusConnection) server = stand_in_connect (G_BUS_NAME_OWNER_FLAGS_NONE, &owner);
    Waited waited = { 0 };

    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_STARTING);
    g_paste_util_wait_for_daemon (client, NULL, on_waited, &waited);
    g_paste_test_bus_pump (100);
    g_assert_false (waited.done);

    g_autoptr (GPasteDaemon3) skeleton = g_paste_daemon3_skeleton_new ();

    g_dbus_interface_skeleton_export (G_DBUS_INTERFACE_SKELETON (skeleton), server, G_PASTE_DAEMON_OBJECT_PATH, &error);
    g_assert_no_error (error);
    g_paste_daemon3_set_history (skeleton, "history");
    g_paste_test_bus_wait_until (g_paste_test_bus_is_true, &waited.done, NULL);
    g_assert_true (waited.serving);
    g_assert_no_error (waited.error);
    g_dbus_interface_skeleton_unexport (G_DBUS_INTERFACE_SKELETON (skeleton));
    g_bus_unown_name (owner);
    g_dbus_connection_close_sync (server, NULL, NULL);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_ABSENT);

    g_autoptr (GDBusConnection) legacy = stand_in_connect (G_BUS_NAME_OWNER_FLAGS_NONE, &owner);
    guint registration = legacy_export (legacy);
    Waited refused = { 0 };

    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_STARTING);
    g_paste_util_wait_for_daemon (client, NULL, on_waited, &refused);
    g_paste_test_bus_wait_until (g_paste_test_bus_is_true, &refused.done, NULL);
    g_assert_false (refused.serving);
    g_assert_error (refused.error, G_IO_ERROR, G_IO_ERROR_NOT_CONNECTED);
    g_assert_nonnull (strstr (refused.error->message, "daemon-reexec"));
    g_clear_error (&refused.error);

    g_dbus_connection_unregister_object (legacy, registration);
    g_bus_unown_name (owner);
    g_dbus_connection_close_sync (legacy, NULL, NULL);
}

/* A wait over leaves the client as it found it: followed when its caller had
 * it so, and holding no reference of the wait's once a GPaste 45 or 50 has
 * answered it. Cancelled, it answers at once, with the cancellation. */
static void
test_wait_for_daemon_cleanup (void)
{
    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    guint owner;

    g_assert_no_error (error);

    g_autoptr (GDBusConnection) legacy = stand_in_connect (G_BUS_NAME_OWNER_FLAGS_NONE, &owner);
    guint registration = legacy_export (legacy);
    Waited refused = { 0 };

    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_STARTING);

    guint refs = G_OBJECT (client)->ref_count;

    g_paste_util_wait_for_daemon (client, NULL, on_waited, &refused);
    g_paste_test_bus_wait_until (g_paste_test_bus_is_true, &refused.done, NULL);
    g_assert_error (refused.error, G_IO_ERROR, G_IO_ERROR_NOT_CONNECTED);
    g_clear_error (&refused.error);
    g_paste_test_bus_pump (100);
    g_assert_cmpuint (G_OBJECT (client)->ref_count, ==, refs);

    g_autoptr (GCancellable) cancellable = g_cancellable_new ();
    Waited cancelled = { 0 };

    g_paste_client_follow_daemon (client, FALSE);
    g_paste_util_wait_for_daemon (client, cancellable, on_waited, &cancelled);
    g_cancellable_cancel (cancellable);
    g_paste_test_bus_pump (100);
    g_assert_true (cancelled.done);
    g_assert_error (cancelled.error, G_IO_ERROR, G_IO_ERROR_CANCELLED);
    g_clear_error (&cancelled.error);
    g_assert_true (g_paste_client_is_following (client));
    g_paste_client_unfollow_daemon (client);

    g_dbus_connection_unregister_object (legacy, registration);
    g_bus_unown_name (owner);
    g_dbus_connection_close_sync (legacy, NULL, NULL);
}

static void
on_shell_done (GObject      *source_object,
               GAsyncResult *res,
               gpointer      user_data)
{
    g_subprocess_wait_finish (G_SUBPROCESS (source_object), res, NULL);
    *(gboolean *) user_data = TRUE;
}

/* Whether the bash completion takes the daemon for one to list items from,
 * the main loop left running for whatever the shell asks of it meanwhile. */
static gboolean
bash_completion_sees_daemon (void)
{
    g_autofree gchar *command = g_strdup_printf ("source '%s' && _gpaste_client_daemon_running", G_PASTE_TEST_BASH_COMPLETION);
    g_autoptr (GError) error = NULL;
    g_autoptr (GSubprocess) shell = g_subprocess_new (G_SUBPROCESS_FLAGS_NONE, &error, "bash", "-c", command, NULL);
    gboolean done = FALSE;

    g_assert_no_error (error);
    g_subprocess_wait_async (shell, NULL, on_shell_done, &done);
    g_paste_test_bus_wait_until (g_paste_test_bus_is_true, &done, NULL);
    g_assert_true (done);

    return g_subprocess_get_successful (shell);
}

/* The completions list items only from a daemon that serves: one owning the
 * name before it does -- settling its storage -- or a GPaste 45 or 50 an update
 * left running would have gpaste-client wait on it, and the shell with it. */
static void
test_completion_serving_daemon (void)
{
    g_assert_false (bash_completion_sees_daemon ());

    g_autoptr (GDBusConnection) server = g_paste_test_bus_connect (g_getenv ("DBUS_SESSION_BUS_ADDRESS"));

    g_assert_cmpuint (g_paste_test_bus_name_call (server, "RequestName", g_variant_new ("(su)", G_PASTE_BUS_NAME, 0u)), ==, 1);
    g_assert_false (bash_completion_sees_daemon ());

    guint registration = legacy_export (server);

    g_assert_false (bash_completion_sees_daemon ());
    g_dbus_connection_unregister_object (server, registration);

    g_autoptr (GPasteDaemon3) skeleton = g_paste_daemon3_skeleton_new ();
    g_autoptr (GError) error = NULL;

    g_dbus_interface_skeleton_export (G_DBUS_INTERFACE_SKELETON (skeleton), server, G_PASTE_DAEMON_OBJECT_PATH, &error);
    g_assert_no_error (error);
    g_assert_true (bash_completion_sees_daemon ());

    g_dbus_interface_skeleton_unexport (G_DBUS_INTERFACE_SKELETON (skeleton));
    g_dbus_connection_close_sync (server, NULL, NULL);
}

int
main (int argc, char **argv)
{
    g_paste_test_env_setup (G_PASTE_TEST_ENV_DEFAULT);
    g_test_init (&argc, &argv, NULL);
    g_test_add_func ("/client/presence/follow", test_follow);
    g_test_add_func ("/client/presence/unfollowed", test_unfollowed);
    g_test_add_func ("/client/presence/initables", test_initables);
    g_test_add_func ("/client/presence/probe-released", test_probe_released);
    g_test_add_func ("/client/presence/seed-announced", test_seed_announced);
    g_test_add_func ("/client/presence/handoff", test_handoff);
    g_test_add_func ("/client/presence/handoff-after-init", test_handoff_after_init);
    g_test_add_func ("/client/presence/handoff-other-name", test_handoff_other_name);
    g_test_add_func ("/client/presence/daemon-gone-error", test_daemon_gone_error);
    g_test_add_func ("/client/invalid-utf8-refused", test_invalid_utf8_refused);
    g_test_add_func ("/client/presence/legacy", test_legacy);
    g_test_add_func ("/client/presence/legacy-errors", test_legacy_errors);
    g_test_add_func ("/client/presence/wait-for-daemon", test_wait_for_daemon);
    g_test_add_func ("/client/presence/wait-for-daemon-cleanup", test_wait_for_daemon_cleanup);
    g_test_add_func ("/client/presence/completion-serving-daemon", test_completion_serving_daemon);
    g_test_add_func ("/client/presence/starting-owner-leaves", test_starting_owner_leaves);
    g_test_add_func ("/client/presence/own-context", test_own_context);
    g_test_add_func ("/client/presence/own-context-probe", test_own_context_probe);
    g_test_add_func ("/client/presence/peer-to-peer", test_peer_to_peer);
    g_test_add_func ("/client/calls/errors-stripped", test_errors_stripped);
    g_test_add_func ("/client/calls/items-read", test_items_read);
    g_test_add_func ("/client/calls/add-file-not-utf8", test_add_file_not_utf8);
    g_test_add_func ("/client/calls/add-file-null", test_add_file_null);
    g_test_add_func ("/client/calls/reexecute-answers", test_reexecute_answers);
    g_test_add_func ("/client/calls/reexecute-starts-nothing", test_reexecute_starts_nothing);
    g_test_add_func ("/client/calls/doctor-answers", test_doctor_answers);
    g_test_add_func ("/client/calls/store-calls-wait", test_store_calls_wait);
    return g_paste_test_env_run ();
}
