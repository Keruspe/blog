// SPDX-FileCopyrightText: 2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com>
// SPDX-License-Identifier: BSD-2-Clause

#include "gpaste-test-history.h"

#include <gpaste-test-bus.h>
#include <gpaste-test-env.h>
#include <gpaste-3/gpaste-gsettings-keys.h>
#include <gpaste-daemon/gpaste-daemon-methods.h>
#include <gpaste-daemon/gpaste-daemon-util.h>
#include <gpaste-daemon/gpaste-file-backend.h>
#include <gpaste-daemon/gpaste-history-private.h>
#include <gpaste-daemon/gpaste-history.h>
#include <gpaste-daemon/gpaste-image-item.h>
#include <gpaste-daemon/gpaste-password-item.h>
#include <gpaste-daemon/gpaste-storage-backend.h>
#include <gpaste-daemon/gpaste-text-item.h>

#include <dlfcn.h>
#include <glib/gstdio.h>
#include <sys/file.h>
#include <fcntl.h>

/* Where the storage writes of the history named @name are held: a worker
 * writing it waits at the backend boundary until the case releases it, so the
 * case can act while that write is still out. The model and the saver stay the
 * shipped ones, their threads and completion callbacks included. A static
 * GMutex and GCond need no initialisation.
 *
 * With @require_written, a worker reading that history asserts the held write
 * has landed first. @password_name and @password_timeout are what the held
 * write found on the first password it was handed, once released. */
typedef struct
{
    GMutex       mutex;
    GCond        cond;
    GThread     *main_thread;
    const gchar *name;
    gboolean     hold_write;
    gboolean     started;
    gboolean     released;
    gboolean     require_written;
    gboolean     written;
    gchar       *password_name;
    guint        password_timeout;
} Barrier;

static Barrier barrier;
static gboolean (*real_write) (GPasteStorageBackend *, const gchar *, const GList *);
static gboolean (*real_read) (GPasteStorageBackend *, const gchar *, GCancellable *, GList **, gsize *);
static void (*real_add_item) (GPasteStorageBackend *, const gchar *, GPasteItem *, const GList *);
static void (*real_clear) (GPasteStorageBackend *, const gchar *, const GList *);

/* Holds the worker writing @name, when the case asked for that, until the case
 * releases it; answers whether it did. */
static gboolean
hold_write (const gchar *name,
            const GList *items)
{
    gboolean held = FALSE;

    /* The main thread is never held: a drain applying writes there is what the
     * held worker is being raced against. */
    if (g_thread_self () != barrier.main_thread)
    {
        g_mutex_lock (&barrier.mutex);
        held = barrier.hold_write && g_paste_str_equal (name, barrier.name);
        if (held)
        {
            barrier.started = TRUE;
            g_cond_broadcast (&barrier.cond);
            while (!barrier.released)
                g_cond_wait (&barrier.cond, &barrier.mutex);

            for (const GList *item = items; item; item = item->next)
            {
                if (G_PASTE_IS_PASSWORD_ITEM (item->data))
                {
                    g_set_str (&barrier.password_name, g_paste_password_item_get_name (item->data));
                    barrier.password_timeout = g_paste_password_item_get_timeout (item->data);
                    break;
                }
            }
        }
        g_mutex_unlock (&barrier.mutex);
    }

    return held;
}

static void
mark_written (gboolean held)
{
    if (!held)
        return;

    g_mutex_lock (&barrier.mutex);
    barrier.written = TRUE;
    g_mutex_unlock (&barrier.mutex);
}

/* A history whose writes have to come after the held one has landed, when
 * set: a backup queued behind it. */
static const gchar *written_after_held;

gboolean
g_paste_storage_backend_write_history (GPasteStorageBackend *backend,
                                       const gchar          *name,
                                       const GList          *items)
{
    if (written_after_held && g_paste_str_equal (name, written_after_held))
    {
        g_mutex_lock (&barrier.mutex);
        g_assert_true (barrier.written);
        g_mutex_unlock (&barrier.mutex);
    }

    gboolean held = hold_write (name, items);
    gboolean written = real_write (backend, name, items);

    mark_written (held);

    return written;
}

/* How many incremental adds carried a snapshot of the history to reconcile. */
static guint adds_with_snapshot;

/* What an incremental backend is handed for an add, held the same way. */
void
g_paste_storage_backend_add_item (GPasteStorageBackend *backend,
                                  const gchar          *name,
                                  GPasteItem           *item,
                                  const GList          *history)
{
    gboolean held = hold_write (name, history);

    if (history)
        ++adds_with_snapshot;

    real_add_item (backend, name, item, history);
    mark_written (held);
}

/* What an incremental backend is handed for an emptying, held the same way. */
void
g_paste_storage_backend_clear_history (GPasteStorageBackend *backend,
                                       const gchar          *name,
                                       const GList          *history)
{
    gboolean held = hold_write (name, history);

    real_clear (backend, name, history);
    mark_written (held);
}

gboolean
g_paste_storage_backend_read_history (GPasteStorageBackend *backend,
                                      const gchar          *name,
                                      GCancellable         *cancellable,
                                      GList               **items,
                                      gsize                *size)
{
    if (g_thread_self () != barrier.main_thread)
    {
        g_mutex_lock (&barrier.mutex);
        if (barrier.require_written && g_paste_str_equal (name, barrier.name))
            g_assert_true (barrier.written);
        g_mutex_unlock (&barrier.mutex);
    }

    return real_read (backend, name, cancellable, items, size);
}

/* Until the worker writing the held history has started, the main context
 * iterated meanwhile, as the daemon's loop would be: a write recorded while
 * the saver still waits for an earlier one's completion -- which the worker
 * posts after it lets go of the drain -- only starts from that completion,
 * dispatched there. */
static void
wait_worker (void)
{
    gint64 deadline = g_get_monotonic_time () + 10 * G_USEC_PER_SEC;

    g_mutex_lock (&barrier.mutex);
    while (!barrier.started)
    {
        g_mutex_unlock (&barrier.mutex);
        g_assert_cmpint (g_get_monotonic_time (), <, deadline);
        g_main_context_iteration (NULL, FALSE);
        g_mutex_lock (&barrier.mutex);
        g_cond_wait_until (&barrier.cond, &barrier.mutex, g_get_monotonic_time () + 10 * G_TIME_SPAN_MILLISECOND);
    }
    g_mutex_unlock (&barrier.mutex);
}

static void
release_worker (void)
{
    g_mutex_lock (&barrier.mutex);
    barrier.released = TRUE;
    g_cond_broadcast (&barrier.cond);
    g_mutex_unlock (&barrier.mutex);
}

/* For a call that has to wait for the held write: it blocks the main thread
 * until then, so the release comes from elsewhere. */
static gpointer
release_later (gpointer data G_GNUC_UNUSED)
{
    g_usleep (100 * 1000);
    release_worker ();
    return NULL;
}

/* For a call that must not wait for the held write: one that does gets it
 * released five seconds on, and comes back to find it released -- a failure
 * rather than a hang. */
static gpointer
release_eventually (gpointer data G_GNUC_UNUSED)
{
    gint64 deadline = g_get_monotonic_time () + 5 * G_USEC_PER_SEC;

    g_mutex_lock (&barrier.mutex);
    while (!barrier.released && g_cond_wait_until (&barrier.cond, &barrier.mutex, deadline))
        ;
    g_mutex_unlock (&barrier.mutex);
    release_worker ();
    return NULL;
}

static gboolean
is_released (void)
{
    g_mutex_lock (&barrier.mutex);
    gboolean released = barrier.released;
    g_mutex_unlock (&barrier.mutex);

    return released;
}

static void
finish_history (GPasteHistory *history)
{
    g_paste_history_flush (history);
    g_paste_test_bus_drain ();
}

/* A history called @name holding one stored item in @storage, loaded, with
 * nothing held. */
static void
fixture_in (GPasteSettings       **settings,
            GPasteStorageBackend **backend,
            GPasteHistory        **history,
            const gchar           *name,
            GPasteStorage          storage)
{
    /* Every case starts from the schema's defaults. */
    g_paste_test_env_reset_settings (G_PASTE_SETTINGS_NAME);
    *settings = g_paste_settings_new ();
    g_paste_settings_set_growing_lines (*settings, FALSE);
    g_paste_settings_set_storage_backend (*settings, storage);
    *backend = g_paste_storage_backend_new (storage, *settings);

    g_autolist (GPasteItem) old = g_list_prepend (NULL, g_paste_text_item_new ("old stored item"));

    real_write (*backend, name, old);
    *history = g_paste_history_new (*settings);
    g_paste_history_load (*history, name);

    g_mutex_lock (&barrier.mutex);
    barrier.name = name;
    barrier.hold_write = FALSE;
    barrier.started = FALSE;
    barrier.released = FALSE;
    barrier.require_written = FALSE;
    barrier.written = FALSE;
    g_clear_pointer (&barrier.password_name, g_free);
    barrier.password_timeout = 0;
    g_mutex_unlock (&barrier.mutex);
}

static void
fixture (GPasteSettings       **settings,
         GPasteStorageBackend **backend,
         GPasteHistory        **history,
         const gchar           *name)
{
    fixture_in (settings, backend, history, name, G_PASTE_STORAGE_FILE);
}

/* What @name holds on disk, as test-history's read_history_ok () reads it: a
 * test binary keeps the few storage helpers it needs to itself. */
static GList *
read_items (GPasteStorageBackend *backend,
            const gchar          *name)
{
    g_autolist (GPasteItem) items = NULL;
    gsize size = 0;

    g_assert_true (g_paste_storage_backend_read_history (backend, name, NULL, &items, &size));
    return g_steal_pointer (&items);
}

/* A history switched away from with its writes still out, one in flight and
 * one queued, then deleted: neither may land after the unlink. */
static void
test_delete_pending (void)
{
    g_autoptr (GPasteSettings) settings = NULL;
    g_autoptr (GPasteStorageBackend) backend = NULL;
    g_autoptr (GPasteHistory) history = NULL;

    fixture (&settings, &backend, &history, "deleted-source");
    barrier.hold_write = TRUE;
    g_paste_history_add (history, g_paste_text_item_new ("first pending"));
    wait_worker ();
    g_paste_history_add (history, g_paste_text_item_new ("second pending"));
    g_paste_history_load (history, "other-current");

    g_autoptr (GError) error = NULL;
    g_autoptr (GThread) release = g_thread_new ("release-delete-write", release_later, NULL);

    g_assert_true (g_paste_history_delete (history, "deleted-source", &error));
    g_thread_join (g_steal_pointer (&release));
    g_assert_no_error (error);
    finish_history (history);

    g_autofree gchar *path = g_paste_storage_backend_get_history_file_path (backend, "deleted-source");

    g_assert_false (g_file_test (path, G_FILE_TEST_EXISTS));
}

/* Deleting another history has nothing to wait for in the current one's
 * writes, which carry on and land. */
static void
test_delete_other (void)
{
    g_autoptr (GPasteSettings) settings = NULL;
    g_autoptr (GPasteStorageBackend) backend = NULL;
    g_autoptr (GPasteHistory) history = NULL;

    fixture (&settings, &backend, &history, "kept-current");

    g_autolist (GPasteItem) other = g_list_prepend (NULL, g_paste_text_item_new ("other stored item"));

    real_write (backend, "deleted-other", other);
    barrier.hold_write = TRUE;
    g_paste_history_add (history, g_paste_text_item_new ("pending"));
    wait_worker ();

    g_autoptr (GError) error = NULL;
    g_autoptr (GThread) release = g_thread_new ("release-current-write", release_eventually, NULL);

    g_assert_true (g_paste_history_delete (history, "deleted-other", &error));
    g_assert_no_error (error);
    g_assert_false (is_released ());
    release_worker ();
    g_thread_join (g_steal_pointer (&release));
    finish_history (history);

    g_autofree gchar *path = g_paste_storage_backend_get_history_file_path (backend, "deleted-other");
    g_autolist (GPasteItem) items = read_items (backend, "kept-current");

    g_assert_false (g_file_test (path, G_FILE_TEST_EXISTS));
    g_assert_cmpuint (g_list_length (items), ==, 2);
    g_assert_cmpstr (g_paste_item_get_real_value (items->data), ==, "pending");
}

/* A history switched away from and straight back to while its writes are out
 * is read once they have landed: read earlier, it would be installed without
 * them and saved over them by the switch's own full write. */
static void
test_switch_pending (void)
{
    g_autoptr (GPasteSettings) settings = NULL;
    g_autoptr (GPasteStorageBackend) backend = NULL;
    g_autoptr (GPasteHistory) history = NULL;

    fixture (&settings, &backend, &history, "switch-source");
    barrier.hold_write = TRUE;
    g_paste_history_add (history, g_paste_text_item_new ("first pending"));
    wait_worker ();
    g_paste_history_add (history, g_paste_text_item_new ("second pending"));
    g_mutex_lock (&barrier.mutex);
    barrier.require_written = TRUE;
    g_mutex_unlock (&barrier.mutex);

    g_paste_history_switch (history, "other-switch");
    g_paste_history_switch (history, "switch-source");

    g_autoptr (GThread) release = g_thread_new ("release-switch-write", release_later, NULL);

    wait_load (history);
    g_thread_join (g_steal_pointer (&release));
    g_assert_cmpuint (g_paste_history_get_length (history), ==, 3);
    g_assert_cmpstr (g_paste_item_get_real_value (g_paste_history_get (history, 0)), ==, "second pending");
    finish_history (history);

    g_autolist (GPasteItem) items = read_items (backend, "switch-source");

    g_assert_cmpuint (g_list_length (items), ==, 3);
    g_assert_cmpstr (g_paste_item_get_real_value (items->data), ==, "second pending");
}

/* Another history is read whatever the one left still has out: with the file
 * backend each is a store of its own. And the writes it has out still land,
 * the one queued included, although the history switched to saves itself as
 * soon as it is loaded. */
static void
test_switch_other (void)
{
    g_autoptr (GPasteSettings) settings = NULL;
    g_autoptr (GPasteStorageBackend) backend = NULL;
    g_autoptr (GPasteHistory) history = NULL;

    fixture (&settings, &backend, &history, "switch-left");
    barrier.hold_write = TRUE;
    g_paste_history_add (history, g_paste_text_item_new ("first pending"));
    wait_worker ();
    g_paste_history_add (history, g_paste_text_item_new ("second pending"));

    g_autoptr (GThread) release = g_thread_new ("release-left-write", release_eventually, NULL);

    g_paste_history_switch (history, "switch-reached");
    wait_load (history);
    g_assert_false (is_released ());
    g_assert_cmpstr (g_paste_history_get_current (history), ==, "switch-reached");
    release_worker ();
    g_thread_join (g_steal_pointer (&release));
    finish_history (history);

    g_autolist (GPasteItem) items = read_items (backend, "switch-left");

    g_assert_cmpuint (g_list_length (items), ==, 3);
    g_assert_cmpstr (g_paste_item_get_real_value (items->data), ==, "second pending");
}

/* A history left with its writes out, switched to another one which loads and
 * saves itself meanwhile: what the switch leaves the case to act on. */
static void
leave_with_write_out (GPasteHistory *history,
                      const gchar   *next)
{
    barrier.hold_write = TRUE;
    g_paste_history_add (history, g_paste_text_item_new ("accepted"));
    wait_worker ();
    g_paste_history_switch (history, next);
    wait_load (history);
}

/* The current history is backed up from its model, which holds what is still
 * on its way to the store, in the background: the call holds the main thread
 * for none of the writes out, and the copy lands behind them, its write coming
 * once the one held has landed. */
static void
test_backup_current (void)
{
    g_autoptr (GPasteSettings) settings = NULL;
    g_autoptr (GPasteStorageBackend) backend = NULL;
    g_autoptr (GPasteHistory) history = NULL;

    fixture (&settings, &backend, &history, "backup-current");
    barrier.hold_write = TRUE;
    g_paste_history_add (history, g_paste_text_item_new ("accepted"));
    wait_worker ();

    g_autoptr (GPasteDaemon3) skeleton = g_paste_daemon3_skeleton_new ();
    const GPasteDaemonMethods methods = { .history = history, .settings = settings, .skeleton = skeleton };
    g_autoptr (GAsyncResult) result = NULL;
    g_autoptr (GError) error = NULL;
    g_autoptr (GThread) release = g_thread_new ("release-current-write", release_eventually, NULL);

    written_after_held = "backup-current-copy";
    g_paste_daemon_methods_backup_history_async (&methods, "backup-current", "backup-current-copy", g_paste_test_env_keep_result, &result);
    g_assert_false (is_released ());
    g_paste_test_bus_drain ();
    g_assert_null (result);
    release_worker ();
    g_thread_join (g_steal_pointer (&release));
    g_paste_test_env_wait_result (&result);
    written_after_held = NULL;
    g_assert_true (g_paste_daemon_methods_backup_history_finish (result, &error));
    g_assert_no_error (error);
    finish_history (history);

    g_autolist (GPasteItem) items = read_items (backend, "backup-current-copy");

    g_assert_cmpuint (g_list_length (items), ==, 2);
    g_assert_cmpstr (g_paste_item_get_real_value (items->data), ==, "accepted");
}

typedef struct
{
    GPasteHistory *history;
    GAsyncResult **result;
    gboolean       answered_inside;
    gboolean       flushed;
} DrainedFlush;

/* A flush from a source dispatch of a later iteration than the backup's, as
 * the daemon's come: where GTask runs a callback from inside its return. */
static void
flush_from_source (gpointer user_data)
{
    DrainedFlush *flush = user_data;

    g_paste_history_flush (flush->history);
    flush->answered_inside = (*flush->result != NULL);
    flush->flushed = TRUE;
}

static gboolean
is_flushed (gconstpointer data,
            gconstpointer arg G_GNUC_UNUSED)
{
    return ((const DrainedFlush *) data)->flushed;
}

/* A backup a flush lands on the main thread is answered from an idle, not
 * from inside the flush: that holds the history's lock, and the backup's
 * callback -- the D-Bus reply, HistoriesChanged, whatever a caller of
 * g_paste_history_copy_async () reads of the history -- would run under it,
 * the lock not being recursive. */
static void
test_backup_drained (void)
{
    g_autoptr (GPasteSettings) settings = NULL;
    g_autoptr (GPasteStorageBackend) backend = NULL;
    g_autoptr (GPasteHistory) history = NULL;

    fixture (&settings, &backend, &history, "backup-drained");
    barrier.hold_write = TRUE;
    g_paste_history_add (history, g_paste_text_item_new ("accepted"));
    wait_worker ();

    g_autoptr (GPasteDaemon3) skeleton = g_paste_daemon3_skeleton_new ();
    const GPasteDaemonMethods methods = { .history = history, .settings = settings, .skeleton = skeleton };
    g_autoptr (GAsyncResult) result = NULL;
    g_autoptr (GError) error = NULL;
    g_autoptr (GThread) release = g_thread_new ("release-current-write", release_later, NULL);

    DrainedFlush flush = { .history = history, .result = &result };

    g_paste_daemon_methods_backup_history_async (&methods, "backup-drained", "backup-drained-copy", g_paste_test_env_keep_result, &result);
    g_usleep (2000);
    g_idle_add_once (flush_from_source, &flush);
    g_paste_test_bus_wait_until (is_flushed, &flush, NULL);
    g_thread_join (g_steal_pointer (&release));
    g_assert_false (flush.answered_inside);
    g_paste_test_env_wait_result (&result);
    g_assert_true (g_paste_daemon_methods_backup_history_finish (result, &error));
    g_assert_no_error (error);
    finish_history (history);

    g_autolist (GPasteItem) items = read_items (backend, "backup-drained-copy");

    g_assert_cmpuint (g_list_length (items), ==, 2);
}

#ifdef G_PASTE_ENABLE_SQLITE
/* On the SQLite flavours, where a load waits for every write out, it waits for
 * no backup: a copy reads and writes through a backend of its own, never the
 * connection the wait keeps the queue's writes on, and a switch made while a
 * large history is backed up would show the history switched to empty, and
 * still loading, until the backup has landed. */
static void
test_backup_switch_sqlite (void)
{
    g_autoptr (GPasteSettings) settings = NULL;
    g_autoptr (GPasteStorageBackend) backend = NULL;
    g_autoptr (GPasteHistory) history = NULL;

    fixture_in (&settings, &backend, &history, "backup-switch", G_PASTE_STORAGE_SQLITE);
    finish_history (history);
    g_paste_history_resume (history);
    barrier.name = "backup-switch-copy";
    barrier.hold_write = TRUE;

    g_autoptr (GPasteDaemon3) skeleton = g_paste_daemon3_skeleton_new ();
    const GPasteDaemonMethods methods = { .history = history, .settings = settings, .skeleton = skeleton };
    g_autoptr (GAsyncResult) result = NULL;
    g_autoptr (GError) error = NULL;

    g_paste_daemon_methods_backup_history_async (&methods, "backup-switch", "backup-switch-copy", g_paste_test_env_keep_result, &result);
    wait_worker ();
    g_paste_history_load_async (history, "backup-switch-other");

    g_autoptr (GThread) release = g_thread_new ("release-copy", release_eventually, NULL);

    wait_load (history);
    g_assert_false (is_released ());
    release_worker ();
    g_thread_join (g_steal_pointer (&release));
    g_paste_test_env_wait_result (&result);
    g_assert_true (g_paste_daemon_methods_backup_history_finish (result, &error));
    g_assert_no_error (error);
    finish_history (history);
}
#endif

/* A second backup under a name the first is still writing is refused as the
 * store already holding it would be, rather than written over it. */
static void
test_backup_twice (void)
{
    g_autoptr (GPasteSettings) settings = NULL;
    g_autoptr (GPasteStorageBackend) backend = NULL;
    g_autoptr (GPasteHistory) history = NULL;

    fixture (&settings, &backend, &history, "backup-twice");
    barrier.hold_write = TRUE;
    g_paste_history_add (history, g_paste_text_item_new ("accepted"));
    wait_worker ();

    g_autoptr (GPasteDaemon3) skeleton = g_paste_daemon3_skeleton_new ();
    const GPasteDaemonMethods methods = { .history = history, .settings = settings, .skeleton = skeleton };
    g_autoptr (GAsyncResult) first = NULL;
    g_autoptr (GAsyncResult) second = NULL;
    g_autoptr (GError) error = NULL;

    g_paste_daemon_methods_backup_history_async (&methods, "backup-twice", "backup-twice-copy", g_paste_test_env_keep_result, &first);
    g_paste_daemon_methods_backup_history_async (&methods, "backup-twice", "backup-twice-copy", g_paste_test_env_keep_result, &second);
    g_paste_test_env_wait_result (&second);
    g_assert_false (g_paste_daemon_methods_backup_history_finish (second, &error));
    g_assert_error (error, G_PASTE_ERROR, G_PASTE_ERROR_ALREADY_EXISTS);
    g_clear_error (&error);
    release_worker ();
    g_paste_test_env_wait_result (&first);
    g_assert_true (g_paste_daemon_methods_backup_history_finish (first, &error));
    g_assert_no_error (error);
    finish_history (history);
}

/* Another history is backed up from its store, once its writes still out have
 * landed there. */
static void
test_backup_other (void)
{
    g_autoptr (GPasteSettings) settings = NULL;
    g_autoptr (GPasteStorageBackend) backend = NULL;
    g_autoptr (GPasteHistory) history = NULL;

    fixture (&settings, &backend, &history, "backup-left");
    leave_with_write_out (history, "backup-reached");

    g_autoptr (GPasteDaemon3) skeleton = g_paste_daemon3_skeleton_new ();
    const GPasteDaemonMethods methods = { .history = history, .settings = settings, .skeleton = skeleton };
    g_autoptr (GError) error = NULL;
    g_autoptr (GThread) release = g_thread_new ("release-left-write", release_later, NULL);

    backup_history (&methods, "backup-left", "backup-left-copy", &error);
    g_thread_join (g_steal_pointer (&release));
    g_assert_no_error (error);
    finish_history (history);

    g_autolist (GPasteItem) items = read_items (backend, "backup-left-copy");

    g_assert_cmpuint (g_list_length (items), ==, 2);
    g_assert_cmpstr (g_paste_item_get_real_value (items->data), ==, "accepted");
}

/* A history a backup still queued reads is not deleted, nor the one it writes
 * emptied, until the copy has landed: drained first, the copy would run on the
 * main thread, and left behind the unlink it would read a store that is gone
 * and answer for an empty copy. Refused, they can be asked again once the
 * backup is answered. */
static void
test_backup_then_delete (void)
{
    g_autoptr (GPasteSettings) settings = NULL;
    g_autoptr (GPasteStorageBackend) backend = NULL;
    g_autoptr (GPasteHistory) history = NULL;

    fixture (&settings, &backend, &history, "backup-deleted");
    leave_with_write_out (history, "backup-deleted-next");

    g_autoptr (GPasteDaemon3) skeleton = g_paste_daemon3_skeleton_new ();
    const GPasteDaemonMethods methods = { .history = history, .settings = settings, .skeleton = skeleton };
    g_autoptr (GAsyncResult) result = NULL;
    g_autoptr (GError) error = NULL;

    g_paste_daemon_methods_backup_history_async (&methods, "backup-deleted", "backup-deleted-copy", g_paste_test_env_keep_result, &result);

    g_assert_false (g_paste_history_delete (history, "backup-deleted", &error));
    g_assert_error (error, G_IO_ERROR, G_IO_ERROR_BUSY);
    g_clear_error (&error);
    empty_history (&methods, "backup-deleted-copy", &error);
    g_assert_error (error, G_IO_ERROR, G_IO_ERROR_BUSY);
    g_clear_error (&error);
    g_assert_false (is_released ());

    release_worker ();
    g_paste_test_env_wait_result (&result);
    g_assert_true (g_paste_daemon_methods_backup_history_finish (result, &error));
    g_assert_no_error (error);
    g_assert_true (g_paste_history_delete (history, "backup-deleted", &error));
    g_assert_no_error (error);
    finish_history (history);

    g_autofree gchar *path = g_paste_storage_backend_get_history_file_path (backend, "backup-deleted");
    g_autolist (GPasteItem) items = read_items (backend, "backup-deleted-copy");

    g_assert_false (g_file_test (path, G_FILE_TEST_EXISTS));
    g_assert_cmpuint (g_list_length (items), ==, 2);
    g_assert_cmpstr (g_paste_item_get_real_value (items->data), ==, "accepted");
}

/* The current history has no model to back up from while it loads -- here
 * waiting for its own write to land, having been switched away from and back. */
static void
test_backup_loading (void)
{
    g_autoptr (GPasteSettings) settings = NULL;
    g_autoptr (GPasteStorageBackend) backend = NULL;
    g_autoptr (GPasteHistory) history = NULL;

    fixture (&settings, &backend, &history, "backup-loading");
    leave_with_write_out (history, "backup-loading-elsewhere");
    g_paste_history_switch (history, "backup-loading");
    g_assert_true (g_paste_history_is_loading (history));

    g_autoptr (GPasteDaemon3) skeleton = g_paste_daemon3_skeleton_new ();
    const GPasteDaemonMethods methods = { .history = history, .settings = settings, .skeleton = skeleton };
    g_autoptr (GError) error = NULL;

    backup_history (&methods, "backup-loading", "backup-loading-copy", &error);
    g_assert_error (error, G_IO_ERROR, G_IO_ERROR_BUSY);
    release_worker ();
    wait_load (history);
    finish_history (history);

    g_autofree gchar *path = g_paste_storage_backend_get_history_file_path (backend, "backup-loading-copy");

    g_assert_false (g_file_test (path, G_FILE_TEST_EXISTS));
}

/* An emptied current history is backed up empty, from its model like any
 * current one: the emptying write it queued can be coalesced away by the next
 * change before it lands, and a copy reading the store would then back up what
 * the user had just emptied. */
static void
test_backup_emptied (void)
{
    g_autoptr (GPasteSettings) settings = NULL;
    g_autoptr (GPasteStorageBackend) backend = NULL;
    g_autoptr (GPasteHistory) history = NULL;

    fixture (&settings, &backend, &history, "backup-emptied");
    barrier.hold_write = TRUE;
    g_paste_history_add (history, g_paste_text_item_new ("emptied"));
    wait_worker ();

    g_autoptr (GPasteDaemon3) skeleton = g_paste_daemon3_skeleton_new ();
    const GPasteDaemonMethods methods = { .history = history, .settings = settings, .skeleton = skeleton };
    g_autoptr (GAsyncResult) result = NULL;
    g_autoptr (GError) error = NULL;

    empty_history (&methods, "backup-emptied", &error);
    g_assert_no_error (error);
    g_paste_daemon_methods_backup_history_async (&methods, "backup-emptied", "backup-emptied-copy", g_paste_test_env_keep_result, &result);
    g_paste_history_add (history, g_paste_text_item_new ("copied after"));
    release_worker ();
    g_paste_test_env_wait_result (&result);
    g_assert_true (g_paste_daemon_methods_backup_history_finish (result, &error));
    g_assert_no_error (error);
    finish_history (history);

    g_autolist (GPasteItem) items = read_items (backend, "backup-emptied-copy");

    g_assert_null (items);
}

/* Emptying the current history goes through its model, its write queued behind
 * the one out: nothing to wait for. */
static void
test_empty_current (void)
{
    g_autoptr (GPasteSettings) settings = NULL;
    g_autoptr (GPasteStorageBackend) backend = NULL;
    g_autoptr (GPasteHistory) history = NULL;

    fixture (&settings, &backend, &history, "empty-current");
    barrier.hold_write = TRUE;
    g_paste_history_add (history, g_paste_text_item_new ("accepted"));
    wait_worker ();

    g_autoptr (GPasteDaemon3) skeleton = g_paste_daemon3_skeleton_new ();
    const GPasteDaemonMethods methods = { .history = history, .settings = settings, .skeleton = skeleton };
    g_autoptr (GError) error = NULL;
    g_autoptr (GThread) release = g_thread_new ("release-current-write", release_eventually, NULL);

    empty_history (&methods, "empty-current", &error);
    g_assert_no_error (error);
    g_assert_false (is_released ());
    release_worker ();
    g_thread_join (g_steal_pointer (&release));
    finish_history (history);

    g_autolist (GPasteItem) items = read_items (backend, "empty-current");

    g_assert_null (items);
}

/* Writing another history over empty happens on the saver's worker, the call
 * answered once it has landed: on the main loop -- gnome-shell's compositor,
 * for the daemon hosted there -- a key derivation, a sync and a sweep of its
 * images would stall it for as long. */
static void
test_empty_other_off_main_loop (void)
{
    g_autoptr (GPasteSettings) settings = NULL;
    g_autoptr (GPasteStorageBackend) backend = NULL;
    g_autoptr (GPasteHistory) history = NULL;

    fixture (&settings, &backend, &history, "empty-stays-current");

    g_autolist (GPasteItem) other = g_list_prepend (NULL, g_paste_text_item_new ("other stored item"));

    real_write (backend, "emptied-elsewhere", other);
    g_mutex_lock (&barrier.mutex);
    barrier.name = "emptied-elsewhere";
    barrier.hold_write = TRUE;
    g_mutex_unlock (&barrier.mutex);

    g_autoptr (GPasteDaemon3) skeleton = g_paste_daemon3_skeleton_new ();
    const GPasteDaemonMethods methods = { .history = history, .settings = settings, .skeleton = skeleton };
    g_autoptr (GAsyncResult) result = NULL;
    g_autoptr (GError) error = NULL;

    g_paste_daemon_methods_empty_history_async (&methods, "emptied-elsewhere", g_paste_test_env_keep_result, &result);
    wait_worker ();
    g_assert_null (result);
    release_worker ();
    g_paste_test_env_wait_result (&result);
    g_assert_true (g_paste_daemon_methods_empty_history_finish (result, &error));
    g_assert_no_error (error);
    finish_history (history);

    g_autolist (GPasteItem) items = read_items (backend, "emptied-elsewhere");

    g_assert_null (items);
}

/* Another history's emptying is a write in the saver's turn: a switch to it
 * made while the emptying is still out reads it once that has landed, not the
 * items it held, which the next save would then write back. */
static void
test_empty_other_then_switch (void)
{
    g_autoptr (GPasteSettings) settings = NULL;
    g_autoptr (GPasteStorageBackend) backend = NULL;
    g_autoptr (GPasteHistory) history = NULL;

    fixture (&settings, &backend, &history, "empty-then-switch-from");

    g_autolist (GPasteItem) other = g_list_prepend (NULL, g_paste_text_item_new ("other stored item"));

    real_write (backend, "empty-then-switch-to", other);
    g_mutex_lock (&barrier.mutex);
    barrier.name = "empty-then-switch-to";
    barrier.hold_write = TRUE;
    g_mutex_unlock (&barrier.mutex);

    g_autoptr (GPasteDaemon3) skeleton = g_paste_daemon3_skeleton_new ();
    const GPasteDaemonMethods methods = { .history = history, .settings = settings, .skeleton = skeleton };
    g_autoptr (GAsyncResult) result = NULL;
    g_autoptr (GError) error = NULL;

    g_paste_daemon_methods_empty_history_async (&methods, "empty-then-switch-to", g_paste_test_env_keep_result, &result);
    wait_worker ();
    g_paste_history_switch (history, "empty-then-switch-to");

    g_autoptr (GThread) release = g_thread_new ("release-emptying", release_later, NULL);

    wait_load (history);
    g_thread_join (g_steal_pointer (&release));
    g_paste_test_env_wait_result (&result);
    g_assert_true (g_paste_daemon_methods_empty_history_finish (result, &error));
    g_assert_no_error (error);
    g_assert_cmpuint (g_paste_history_get_length (history), ==, 0);
    finish_history (history);
}

/* A flush lands another history's emptying with the rest, the way out of the
 * process -- a stop, a takeover, a re-exec -- waiting for it as for any write:
 * cut short, the history would come back with the items emptied. */
static void
test_empty_other_flushed (void)
{
    g_autoptr (GPasteSettings) settings = NULL;
    g_autoptr (GPasteStorageBackend) backend = NULL;
    g_autoptr (GPasteHistory) history = NULL;

    fixture (&settings, &backend, &history, "empty-flushed-current");

    g_autolist (GPasteItem) other = g_list_prepend (NULL, g_paste_text_item_new ("other stored item"));

    real_write (backend, "empty-flushed", other);
    g_mutex_lock (&barrier.mutex);
    barrier.name = "empty-flushed";
    barrier.hold_write = TRUE;
    g_mutex_unlock (&barrier.mutex);

    g_autoptr (GPasteDaemon3) skeleton = g_paste_daemon3_skeleton_new ();
    const GPasteDaemonMethods methods = { .history = history, .settings = settings, .skeleton = skeleton };
    g_autoptr (GAsyncResult) result = NULL;

    g_paste_daemon_methods_empty_history_async (&methods, "empty-flushed", g_paste_test_env_keep_result, &result);
    wait_worker ();

    g_autoptr (GThread) release = g_thread_new ("release-emptying", release_later, NULL);

    g_paste_history_flush (history);
    g_thread_join (g_steal_pointer (&release));

    g_autolist (GPasteItem) items = read_items (backend, "empty-flushed");

    g_assert_null (items);
    g_paste_test_env_wait_result (&result);
}

/* Another history is emptied in the flavour the history runs on, as it is
 * listed, counted and backed up in: the storage-backend setting moved under a
 * running daemon names a store it does not read. */
static void
test_empty_other_backend_in_use (void)
{
    g_autoptr (GPasteSettings) settings = NULL;
    g_autoptr (GPasteStorageBackend) backend = NULL;
    g_autoptr (GPasteHistory) history = NULL;

    fixture (&settings, &backend, &history, "empty-in-use-current");

    g_autolist (GPasteItem) other = g_list_prepend (NULL, g_paste_text_item_new ("other stored item"));

    real_write (backend, "empty-in-use", other);
    g_paste_settings_set_storage_backend (settings, G_PASTE_STORAGE_SQLITE);

    g_autoptr (GPasteDaemon3) skeleton = g_paste_daemon3_skeleton_new ();
    const GPasteDaemonMethods methods = { .history = history, .settings = settings, .skeleton = skeleton };
    g_autoptr (GError) error = NULL;

    empty_history (&methods, "empty-in-use", &error);
    g_assert_no_error (error);
    g_paste_settings_set_storage_backend (settings, G_PASTE_STORAGE_FILE);
    finish_history (history);

    g_autolist (GPasteItem) items = read_items (backend, "empty-in-use");

    g_assert_null (items);
}

/* Another history is written over empty once its writes still out have landed:
 * landing afterwards, they would bring back what was emptied. */
static void
test_empty_other (void)
{
    g_autoptr (GPasteSettings) settings = NULL;
    g_autoptr (GPasteStorageBackend) backend = NULL;
    g_autoptr (GPasteHistory) history = NULL;

    fixture (&settings, &backend, &history, "empty-left");
    leave_with_write_out (history, "empty-reached");

    g_autoptr (GPasteDaemon3) skeleton = g_paste_daemon3_skeleton_new ();
    const GPasteDaemonMethods methods = { .history = history, .settings = settings, .skeleton = skeleton };
    g_autoptr (GError) error = NULL;
    g_autoptr (GThread) release = g_thread_new ("release-left-write", release_later, NULL);

    empty_history (&methods, "empty-left", &error);
    g_thread_join (g_steal_pointer (&release));
    g_assert_no_error (error);
    finish_history (history);

    g_autolist (GPasteItem) items = read_items (backend, "empty-left");

    g_assert_null (items);
}

/* Once the store has been handed over, neither a backup nor an emptying
 * touches it. */
static void
test_stopped (void)
{
    g_autoptr (GPasteSettings) settings = NULL;
    g_autoptr (GPasteStorageBackend) backend = NULL;
    g_autoptr (GPasteHistory) history = NULL;

    fixture (&settings, &backend, &history, "stopped-target");
    g_paste_history_load (history, "stopped-current");
    finish_history (history);

    g_autoptr (GPasteDaemon3) skeleton = g_paste_daemon3_skeleton_new ();
    const GPasteDaemonMethods methods = { .history = history, .settings = settings, .skeleton = skeleton };

    {
        g_autoptr (GError) error = NULL;

        empty_history (&methods, "stopped-target", &error);
        g_assert_error (error, G_IO_ERROR, G_IO_ERROR_BUSY);
    }

    {
        g_autoptr (GError) error = NULL;

        backup_history (&methods, "stopped-target", "stopped-copy", &error);
        g_assert_error (error, G_IO_ERROR, G_IO_ERROR_BUSY);
    }

    /* A change to an entry is refused as much: recorded nowhere, the reload
     * that ends the handover would undo it -- and a switch, which would drop
     * what was copied meanwhile. An add, which the reload keeps, is not
     * (/clipboard/add_handed_over). */
    {
        g_autoptr (GError) error = NULL;

        g_paste_daemon_methods_switch_history (&methods, "switched-while-handed-over", &error);
        g_assert_error (error, G_IO_ERROR, G_IO_ERROR_BUSY);
        g_assert_cmpstr (g_paste_history_get_current (history), ==, "stopped-current");
        g_clear_error (&error);

        g_paste_daemon_methods_delete_item (&methods, "00000000-0000-4000-8000-000000000000", &error);
        g_assert_error (error, G_IO_ERROR, G_IO_ERROR_BUSY);
        g_clear_error (&error);

        g_paste_daemon_methods_delete_password (&methods, "stopped password", &error);
        g_assert_error (error, G_IO_ERROR, G_IO_ERROR_BUSY);
        g_clear_error (&error);

        g_paste_daemon_methods_set_favourite (&methods, "00000000-0000-4000-8000-000000000000", TRUE, &error);
        g_assert_error (error, G_IO_ERROR, G_IO_ERROR_BUSY);
        g_clear_error (&error);

        g_paste_daemon_methods_select (&methods, "00000000-0000-4000-8000-000000000000", &error);
        g_assert_error (error, G_IO_ERROR, G_IO_ERROR_BUSY);
        g_clear_error (&error);

        g_autofree gchar *replaced = g_paste_daemon_methods_replace (&methods, "00000000-0000-4000-8000-000000000000", "contents", &error);

        g_assert_error (error, G_IO_ERROR, G_IO_ERROR_BUSY);
        g_clear_error (&error);

        g_paste_daemon_methods_strip_rich_text (&methods, "00000000-0000-4000-8000-000000000000", &error);
        g_assert_error (error, G_IO_ERROR, G_IO_ERROR_BUSY);
        g_clear_error (&error);

        g_autofree gchar *made = g_paste_daemon_methods_make_password (&methods, "00000000-0000-4000-8000-000000000000", "name", 0, &error);

        g_assert_error (error, G_IO_ERROR, G_IO_ERROR_BUSY);
        g_assert_cmpuint (g_paste_history_get_length (history), ==, 0);
    }

    g_autofree gchar *path = g_paste_storage_backend_get_history_file_path (backend, "stopped-copy");
    g_autolist (GPasteItem) items = read_items (backend, "stopped-target");

    g_assert_false (g_file_test (path, G_FILE_TEST_EXISTS));
    g_assert_cmpuint (g_list_length (items), ==, 1);
    g_assert_cmpstr (g_paste_item_get_real_value (items->data), ==, "old stored item");
}

/* A history just left counts what its writes still out are about to store,
 * not what its store holds yet. */
static void
test_count_pending (void)
{
    g_autoptr (GPasteSettings) settings = NULL;
    g_autoptr (GPasteStorageBackend) backend = NULL;
    g_autoptr (GPasteHistory) history = NULL;

    fixture (&settings, &backend, &history, "count-left");
    leave_with_write_out (history, "count-reached");

    g_assert_cmpuint (g_paste_history_get_size (history, "count-left"), ==, 2);
    release_worker ();
    finish_history (history);
    g_assert_cmpuint (g_paste_history_get_size (history, "count-left"), ==, 2);
}

/* What the store answers for of a history just left is what it is counted by
 * from settings changed since the snapshot was taken, too: no image with
 * images-support off, and no more than max-history-size items. So it is on an
 * incremental store, whose write out carries no snapshot: counted by what the
 * history held as it left. */
#define COUNT_IMAGES      (1 << 0)
#define COUNT_INCREMENTAL (1 << 1)

static void
test_count_pending_settings (gconstpointer data)
{
    gboolean images = GPOINTER_TO_INT (data) & COUNT_IMAGES;
    gboolean incremental = GPOINTER_TO_INT (data) & COUNT_INCREMENTAL;
    const gchar *name = (incremental) ? ((images) ? "count-incremental-images" : "count-incremental-capped")
                                      : ((images) ? "count-images" : "count-capped");
    g_autoptr (GPasteSettings) settings = NULL;
    g_autoptr (GPasteStorageBackend) backend = NULL;
    g_autoptr (GPasteHistory) history = NULL;

    fixture_in (&settings, &backend, &history, name, (incremental) ? G_PASTE_STORAGE_SQLITE : G_PASTE_STORAGE_FILE);
    g_paste_settings_set_images_support (settings, TRUE);
    if (images)
    {
        const guchar pixel[] = { 50, 51, 52, 255 };
        g_autoptr (GBytes) bytes = g_bytes_new (pixel, sizeof (pixel));
        g_autoptr (GdkTexture) texture = gdk_memory_texture_new (1, 1, GDK_MEMORY_R8G8B8A8, bytes, 4);

        g_paste_history_add (history, g_paste_image_item_new (texture));
    }
    else
    {
        for (guint i = 0; i < 6; ++i)
        {
            g_autofree gchar *text = g_strdup_printf ("text %u", i);

            g_paste_history_add (history, g_paste_text_item_new (text));
        }
    }
    finish_history (history);
    g_paste_history_resume (history);
    g_autofree gchar *next = g_strconcat (name, "-reached", NULL);

    /* An incremental store's history switched to is read once the writes out
     * have landed: left, not yet loaded. */
    if (incremental)
    {
        barrier.hold_write = TRUE;
        g_paste_history_add (history, g_paste_text_item_new ("accepted"));
        wait_worker ();
        g_paste_history_switch (history, next);
    }
    else
        leave_with_write_out (history, next);

    /* 3 items, the image left out; 8, capped at 5. */
    if (images)
        g_paste_settings_set_images_support (settings, FALSE);
    else
        g_paste_settings_set_max_history_size (settings, 5);

    guint64 expected = (images) ? 2 : 5;

    g_assert_cmpuint (g_paste_history_get_size (history, name), ==, expected);
    release_worker ();
    if (incremental)
        wait_load (history);
    finish_history (history);
    g_assert_cmpuint (g_paste_history_get_size (history, name), ==, expected);
}

/* What a plain store keeps of a history just left is what it is counted by: its
 * passwords, which that store's write leaves out, are not counted. */
static void
test_count_pending_passwords (void)
{
    g_autoptr (GPasteSettings) settings = NULL;
    g_autoptr (GPasteStorageBackend) backend = NULL;
    g_autoptr (GPasteHistory) history = NULL;

    fixture (&settings, &backend, &history, "count-passwords");
    g_paste_history_add (history, g_paste_password_item_new ("left out", "secret", 0));
    /* Landed before the write held next is queued: queued behind one still in
     * flight, it would start only from the main loop, which nothing iterates
     * while the case waits for it. */
    finish_history (history);
    g_paste_history_resume (history);
    leave_with_write_out (history, "count-passwords-reached");

    g_assert_cmpuint (g_paste_history_get_size (history, "count-passwords"), ==, 2);
    release_worker ();
    finish_history (history);
    g_assert_cmpuint (g_paste_history_get_size (history, "count-passwords"), ==, 2);
}

#ifdef G_PASTE_ENABLE_SQLITE
/* The passwords a write carrying no snapshot is counted without follow the
 * history as it changes: one an item was made, one deleted, one added. */
static void
test_count_pending_password_changes (void)
{
    g_autoptr (GPasteSettings) settings = NULL;
    g_autoptr (GPasteStorageBackend) backend = NULL;
    g_autoptr (GPasteHistory) history = NULL;

    fixture_in (&settings, &backend, &history, "count-changes", G_PASTE_STORAGE_SQLITE);
    barrier.hold_write = TRUE;
    g_paste_history_add (history, g_paste_password_item_new ("deleted", "secret", 0));
    wait_worker ();
    g_paste_history_add (history, g_paste_text_item_new ("made"));

    g_autofree gchar *made = g_strdup (g_paste_item_get_uuid (g_paste_history_get (history, 0)));
    g_autofree gchar *password = g_paste_history_make_password (history, made, "made", 0);

    g_assert_nonnull (password);
    g_assert_true (g_paste_history_delete_password (history, "deleted"));
    g_paste_history_add (history, g_paste_password_item_new ("added", "secret", 0));
    g_paste_history_add (history, g_paste_text_item_new ("last"));
    g_paste_history_switch (history, "count-changes-next");

    /* "last" and the stored item, of four. */
    g_assert_cmpuint (g_paste_history_get_size (history, "count-changes"), ==, 2);
    release_worker ();
    wait_load (history);
    finish_history (history);
}

/* An incremental store's add carries no snapshot, and a history just left is
 * still counted by what its writes still out leave it holding. */
static void
test_count_pending_incremental (void)
{
    g_autoptr (GPasteSettings) settings = NULL;
    g_autoptr (GPasteStorageBackend) backend = NULL;
    g_autoptr (GPasteHistory) history = NULL;

    fixture_in (&settings, &backend, &history, "count-incremental", G_PASTE_STORAGE_SQLITE);
    barrier.hold_write = TRUE;
    g_paste_history_add (history, g_paste_text_item_new ("accepted"));
    wait_worker ();
    g_paste_history_switch (history, "count-incremental-next");

    g_assert_cmpuint (g_paste_history_get_size (history, "count-incremental"), ==, 2);
    release_worker ();
    wait_load (history);
    finish_history (history);
    g_assert_cmpuint (g_paste_history_get_size (history, "count-incremental"), ==, 2);
}
#endif

#ifdef G_PASTE_ENABLE_SQLITE
/* Another history emptied is counted as empty while its emptying is still
 * out: the daemon has answered it as emptied, and a listing counting the store
 * would paint the old count back over the 0. */
static void
test_count_pending_emptied_other (void)
{
    g_autoptr (GPasteSettings) settings = NULL;
    g_autoptr (GPasteStorageBackend) backend = NULL;
    g_autoptr (GPasteHistory) history = NULL;

    fixture (&settings, &backend, &history, "count-stays-current");

    g_autolist (GPasteItem) other = g_list_prepend (NULL, g_paste_text_item_new ("other stored item"));

    real_write (backend, "count-emptied-elsewhere", other);
    g_assert_cmpuint (g_paste_history_get_size (history, "count-emptied-elsewhere"), ==, 1);
    g_mutex_lock (&barrier.mutex);
    barrier.name = "count-emptied-elsewhere";
    barrier.hold_write = TRUE;
    g_mutex_unlock (&barrier.mutex);

    g_autoptr (GPasteDaemon3) skeleton = g_paste_daemon3_skeleton_new ();
    const GPasteDaemonMethods methods = { .history = history, .settings = settings, .skeleton = skeleton };
    g_autoptr (GAsyncResult) result = NULL;
    g_autoptr (GError) error = NULL;

    g_paste_daemon_methods_empty_history_async (&methods, "count-emptied-elsewhere", g_paste_test_env_keep_result, &result);
    wait_worker ();
    g_assert_cmpuint (g_paste_history_get_size (history, "count-emptied-elsewhere"), ==, 0);
    release_worker ();
    g_paste_test_env_wait_result (&result);
    g_assert_true (g_paste_daemon_methods_empty_history_finish (result, &error));
    g_assert_no_error (error);
    finish_history (history);
    g_assert_cmpuint (g_paste_history_get_size (history, "count-emptied-elsewhere"), ==, 0);
}

/* An incremental store's emptying carries no snapshot either, and a history
 * emptied and left before it lands holds nothing all the same, whatever its
 * store still holds. */
static void
test_count_pending_emptied (void)
{
    g_autoptr (GPasteSettings) settings = NULL;
    g_autoptr (GPasteStorageBackend) backend = NULL;
    g_autoptr (GPasteHistory) history = NULL;
    g_autoptr (GError) error = NULL;

    fixture_in (&settings, &backend, &history, "count-emptied", G_PASTE_STORAGE_SQLITE);
    g_paste_history_add (history, g_paste_text_item_new ("first"));
    g_paste_history_add (history, g_paste_text_item_new ("second"));
    finish_history (history);
    g_paste_history_resume (history);

    barrier.hold_write = TRUE;
    g_assert_true (g_paste_history_empty (history, &error));
    g_assert_no_error (error);
    wait_worker ();
    g_paste_history_switch (history, "count-emptied-next");

    g_assert_cmpuint (g_paste_history_get_size (history, "count-emptied"), ==, 0);
    release_worker ();
    wait_load (history);
    finish_history (history);
    g_assert_cmpuint (g_paste_history_get_size (history, "count-emptied"), ==, 0);
}

/* Selecting an item moves it and displaces nothing: its write carries no copy
 * of the whole history to reconcile, which nothing could be dropped by. */
static void
test_select_carries_no_snapshot (void)
{
    g_autoptr (GPasteSettings) settings = NULL;
    g_autoptr (GPasteStorageBackend) backend = NULL;
    g_autoptr (GPasteHistory) history = NULL;

    fixture_in (&settings, &backend, &history, "select-no-snapshot", G_PASTE_STORAGE_SQLITE);
    g_paste_history_add (history, g_paste_text_item_new ("first"));
    g_paste_history_add (history, g_paste_text_item_new ("second"));
    finish_history (history);
    g_paste_history_resume (history);

    g_autofree gchar *uuid = g_strdup (g_paste_item_get_uuid (g_paste_history_get (history, 2)));

    adds_with_snapshot = 0;
    g_assert_true (g_paste_history_select (history, uuid));
    finish_history (history);
    g_assert_cmpuint (adds_with_snapshot, ==, 0);
}
#endif

/* A password renamed while a write holding it is out: the write stores the
 * name and timeout it was recorded with, the rename putting a new item in its
 * place rather than writing over the one a worker reads. */
static void
test_rename_during_write (void)
{
    g_autoptr (GPasteSettings) settings = NULL;
    g_autoptr (GPasteStorageBackend) backend = NULL;
    g_autoptr (GPasteHistory) history = NULL;

    fixture (&settings, &backend, &history, "rename-during-write");

    GPasteItem *password = g_paste_password_item_new ("original", "secret", 42);
    g_autofree gchar *uuid = g_strdup (g_paste_item_get_uuid (password));

    barrier.hold_write = TRUE;
    g_paste_history_add (history, password);
    wait_worker ();

    g_autofree gchar *renamed = g_paste_history_make_password (history, uuid, "renamed", 7);

    g_assert_cmpstr (renamed, ==, uuid);
    release_worker ();
    finish_history (history);

    g_assert_cmpstr (barrier.password_name, ==, "original");
    g_assert_cmpuint (barrier.password_timeout, ==, 42);

    GPasteItem *kept = g_paste_history_get_by_uuid (history, uuid);

    g_assert_cmpstr (g_paste_password_item_get_name (G_PASTE_PASSWORD_ITEM (kept)), ==, "renamed");
    g_assert_cmpuint (g_paste_password_item_get_timeout (G_PASTE_PASSWORD_ITEM (kept)), ==, 7);
}

/* An image deleted while a write still holding it is out leaves no file once
 * the write its deletion records has landed. Deleted when the item left the
 * model, the file would come back with the write that was out, and the next
 * one, no longer referencing it, would never take it again. */
static void
test_remove_image_during_write (void)
{
    g_autoptr (GPasteSettings) settings = NULL;
    g_autoptr (GPasteStorageBackend) backend = NULL;
    g_autoptr (GPasteHistory) history = NULL;

    fixture (&settings, &backend, &history, "image-removed-during-write");
    g_paste_settings_set_images_support (settings, TRUE);

    const guchar pixel[] = { 40, 41, 42, 255 };
    g_autoptr (GBytes) bytes = g_bytes_new (pixel, sizeof (pixel));
    g_autoptr (GdkTexture) texture = gdk_memory_texture_new (1, 1, GDK_MEMORY_R8G8B8A8, bytes, 4);
    GPasteItem *image = g_paste_image_item_new (texture);
    g_autofree gchar *path = g_paste_file_backend_image_path ("image-removed-during-write",
                                                              g_paste_image_item_get_checksum (G_PASTE_IMAGE_ITEM (image)));

    barrier.hold_write = TRUE;
    g_paste_history_add (history, image);
    wait_worker ();
    g_paste_history_remove (history, 0);
    release_worker ();
    finish_history (history);

    g_autolist (GPasteItem) items = read_items (backend, "image-removed-during-write");

    g_assert_cmpuint (g_list_length (items), ==, 1);
    g_assert_false (g_file_test (path, G_FILE_TEST_EXISTS));
}

/* A load left pending behind a write when the history is handed over waits for
 * the handover to end: started as that write lands, it would take back the
 * storage lock the host has just let go of. */
static void
test_flush_holds_pending_load (void)
{
    if (!g_test_subprocess ())
    {
        g_test_trap_subprocess (NULL, 0, G_TEST_SUBPROCESS_DEFAULT);
        g_test_trap_assert_passed ();
        return;
    }

    g_autoptr (GPasteSettings) settings = NULL;
    g_autoptr (GPasteStorageBackend) backend = NULL;
    g_autoptr (GPasteHistory) history = NULL;

    fixture (&settings, &backend, &history, "flush-pending");
    leave_with_write_out (history, "flush-pending-elsewhere");
    g_paste_history_switch (history, "flush-pending");
    g_assert_true (g_paste_history_is_loading (history));

    g_autoptr (GThread) release = g_thread_new ("release-flush-write", release_later, NULL);

    g_paste_history_flush (history);
    g_thread_join (g_steal_pointer (&release));
    g_paste_storage_backend_unlock ();
    g_paste_test_bus_pump (500);

    /* Another open file, which flock () tells apart even in this process. */
    g_autofree gchar *dir = g_paste_util_get_history_dir_path ();
    g_autofree gchar *lock = g_build_filename (dir, "lock", NULL);
    gint fd = g_open (lock, O_RDWR | O_CREAT | O_CLOEXEC, 0600);

    g_assert_cmpint (fd, >=, 0);
    g_assert_cmpint (flock (fd, LOCK_EX | LOCK_NB), ==, 0);
    g_close (fd, NULL);
}

int
main (int    argc,
      char **argv)
{
    g_paste_test_env_setup (G_PASTE_TEST_ENV_DEFAULT);
    g_test_init (&argc, &argv, NULL);

    barrier.main_thread = g_thread_self ();
    real_write = dlsym (RTLD_NEXT, "g_paste_storage_backend_write_history");
    real_read = dlsym (RTLD_NEXT, "g_paste_storage_backend_read_history");
    real_add_item = dlsym (RTLD_NEXT, "g_paste_storage_backend_add_item");
    real_clear = dlsym (RTLD_NEXT, "g_paste_storage_backend_clear_history");
    g_assert_nonnull (real_write);
    g_assert_nonnull (real_read);
    g_assert_nonnull (real_clear);
    g_assert_nonnull (real_add_item);

    g_test_add_func ("/history-ordering/delete-pending", test_delete_pending);
    g_test_add_func ("/history-ordering/delete-other", test_delete_other);
    g_test_add_func ("/history-ordering/switch-pending", test_switch_pending);
    g_test_add_func ("/history-ordering/switch-other", test_switch_other);
    g_test_add_func ("/history-ordering/backup-current", test_backup_current);
#ifdef G_PASTE_ENABLE_SQLITE
    g_test_add_func ("/history-ordering/backup-switch-sqlite", test_backup_switch_sqlite);
#endif
    g_test_add_func ("/history-ordering/backup-drained", test_backup_drained);
    g_test_add_func ("/history-ordering/backup-twice", test_backup_twice);
    g_test_add_func ("/history-ordering/backup-other", test_backup_other);
    g_test_add_func ("/history-ordering/backup-then-delete", test_backup_then_delete);
    g_test_add_func ("/history-ordering/backup-loading", test_backup_loading);
    g_test_add_func ("/history-ordering/empty-current", test_empty_current);
    g_test_add_func ("/history-ordering/backup-emptied", test_backup_emptied);
    g_test_add_func ("/history-ordering/empty-other", test_empty_other);
    g_test_add_func ("/history-ordering/empty-other-then-switch", test_empty_other_then_switch);
    g_test_add_func ("/history-ordering/empty-other-flushed", test_empty_other_flushed);
    g_test_add_func ("/history-ordering/empty-other-backend-in-use", test_empty_other_backend_in_use);
    g_test_add_func ("/history-ordering/empty-other-off-main-loop", test_empty_other_off_main_loop);
    g_test_add_func ("/history-ordering/stopped", test_stopped);
    g_test_add_func ("/history-ordering/count-pending", test_count_pending);
    g_test_add_func ("/history-ordering/count-pending-passwords", test_count_pending_passwords);
    g_test_add_data_func ("/history-ordering/count-pending-images-off", GINT_TO_POINTER (COUNT_IMAGES), test_count_pending_settings);
    g_test_add_data_func ("/history-ordering/count-pending-capped", GINT_TO_POINTER (0), test_count_pending_settings);
#ifdef G_PASTE_ENABLE_SQLITE
    g_test_add_func ("/history-ordering/count-pending-password-changes", test_count_pending_password_changes);
    g_test_add_func ("/history-ordering/count-pending-incremental", test_count_pending_incremental);
    g_test_add_func ("/history-ordering/count-pending-emptied", test_count_pending_emptied);
    g_test_add_func ("/history-ordering/count-pending-emptied-other", test_count_pending_emptied_other);
    g_test_add_func ("/history-ordering/select-no-snapshot", test_select_carries_no_snapshot);
    g_test_add_data_func ("/history-ordering/count-pending-incremental-images-off", GINT_TO_POINTER (COUNT_INCREMENTAL | COUNT_IMAGES), test_count_pending_settings);
    g_test_add_data_func ("/history-ordering/count-pending-incremental-capped", GINT_TO_POINTER (COUNT_INCREMENTAL), test_count_pending_settings);
#endif
    g_test_add_func ("/history-ordering/rename-during-write", test_rename_during_write);
    g_test_add_func ("/history-ordering/remove-image-during-write", test_remove_image_during_write);
    g_test_add_func ("/history-ordering/flush-holds-pending-load", test_flush_holds_pending_load);

    return g_paste_test_env_run ();
}
