// SPDX-FileCopyrightText: 2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com>
// SPDX-License-Identifier: BSD-2-Clause

#include <gpaste-test-bus.h>
#include <gpaste-test-env.h>
#include <gpaste-test-gtk.h>

#include <gpaste-3/gpaste-util.h>

#include <dlfcn.h>
#include <glib-unix.h>
#include <signal.h>

/* The translations the suite has, each holding an &, which a label read as
 * markup would leave blank: the empty history's description and the
 * sidebar's entry. Interposed by the suite itself, as test-preferences.c's
 * are: gpaste-test-gtk, linked into every GTK suite, would translate for them
 * all, and a lookup shared there would be no shorter than this one. */
#define EMPTY_DESCRIPTION_TRANSLATED "Copy & paste to start your history"
#define SWITCH_ENTRY_TRANSLATED      "Switch & create"

const gchar *
g_dgettext (const gchar *domain,
            const gchar *msgid)
{
    typedef const gchar *(*Dgettext) (const gchar *, const gchar *);
    Dgettext original = (Dgettext) dlsym (RTLD_NEXT, "g_dgettext");

    if (!g_strcmp0 (msgid, "Copy something to start building your history."))
        return EMPTY_DESCRIPTION_TRANSLATED;
    if (!g_strcmp0 (msgid, "Switch or Create"))
        return SWITCH_ENTRY_TRANSLATED;

    return original (domain, msgid);
}

/* Every restart the window asks of a GPaste 45 or 50, before handing it on:
 * two signals sent together are as good as one. */
static gint legacy_restarts;

static gboolean
counted_reexecute_legacy_daemon (GPasteClient *client,
                                 GError      **error)
{
    g_atomic_int_inc (&legacy_restarts);

    return g_paste_util_reexecute_legacy_daemon (client, error);
}

/* Set to have the window's client fail to build, as with the session bus out
 * of reach: the suite's bus is always there. */
static gboolean fail_client_builds;

static GPasteClient *
failing_client_new_finish (GAsyncResult *result,
                           GError      **error)
{
    if (!fail_client_builds)
        return g_paste_client_new_finish (result, error);

    g_autoptr (GPasteClient) built = g_paste_client_new_finish (result, NULL);

    g_set_error_literal (error, G_IO_ERROR, G_IO_ERROR_FAILED, "no bus");
    return NULL;
}

/* Reach the window's banner, actions and setup. */
#define g_paste_util_reexecute_legacy_daemon counted_reexecute_legacy_daemon
#define g_paste_client_new_finish failing_client_new_finish
#include <gpaste-ui-window.c>
#undef g_paste_client_new_finish
#undef g_paste_util_reexecute_legacy_daemon
#include <gpaste-ui-item.h>

/* And the application's actions, its main () put out of the way. */
#define main gpaste_ui_main
#include <gpaste-ui.c>
#undef main

#include <gpaste-3/gpaste-daemon3.h>
#include <gpaste-3/gpaste-gdbus-defines.h>

/* One for the whole binary: an application stays exported on the bus for as
 * long as anything holds it, which a closed window may still do. */
static GtkApplication *app;

/* How many holds on it are out, the window's and GTK's alike: what a merge
 * outliving its window holds is told by the count moving. */
static gint app_holds;

void
g_application_hold (GApplication *application)
{
    typedef void (*Hold) (GApplication *);
    Hold original = (Hold) dlsym (RTLD_NEXT, "g_application_hold");

    if (app && application == G_APPLICATION (app))
        ++app_holds;
    original (application);
}

void
g_application_release (GApplication *application)
{
    typedef void (*Release) (GApplication *);
    Release original = (Release) dlsym (RTLD_NEXT, "g_application_release");

    if (app && application == G_APPLICATION (app))
        --app_holds;
    original (application);
}

static gboolean have_display;

/* A daemon stood in for by the generated skeleton on a connection of its own,
 * owning the name before it exports anything, as both real daemons do. It
 * lists what @listing says, holds @size items of text, and is of @version, or
 * of the window's own when that is %NULL. With @in_shell, it owns the Shell's
 * name too, on the same connection, as the in-shell daemon does. */
typedef struct
{
    GDBusConnection       *connection;
    GPasteDaemon3         *skeleton;
    guint                  owner;
    const gchar           *listing;
    guint64                size;
    const gchar           *version;
    gboolean               in_shell;
    /* Answer the pinned items and searches as a daemon gone would: unlike the
     * holds below, there is no invocation the test could answer later, a
     * search going out each time the filter changes. */
    gboolean               filters_gone;
    gboolean               allow_replacement;
    gboolean               replace;
    guint                  shell_owner;
    guint                  listings;
    guint                  sizings;
    guint                  filters;
    /* Set to hold these calls rather than answer them, the invocation kept
     * for the test to answer: its reference is the handler's to keep. */
    gboolean               hold_sizes;
    GDBusMethodInvocation *held_size;
    gboolean               hold_listings;
    GDBusMethodInvocation *held_listing;
    gboolean               hold_upload;
    GDBusMethodInvocation *held_upload;
    guint                  uploads;
    /* Serve image items, whose image cannot be read. */
    gboolean               images;
    guint                  image_reads;
    /* What a search matches: one text item of this uuid, or nothing. */
    const gchar           *match;
    gboolean               hold_filters;
    GDBusMethodInvocation *held_filter;
    /* Items read by index, held for the test to answer (release_items ()). */
    gboolean               hold_items;
    GPtrArray             *held_items;
    guint                  selects;
    gchar                 *selected;
    /* Announce an update ahead of answering a Select, as a daemon publishing
     * the item it selects does. */
    gboolean               announce_selects;
    /* The lowest index read since the test last set it. */
    guint64                lowest_read;
    /* Appended to every item's value, as an edit would. */
    const gchar           *edited;
    /* How many items went in above the ones the indexes named so far, which
     * their uuids follow. */
    guint64                shift;
    GStrv                  merged;
    guint                  switches;
    gboolean               listing_fails;
    gchar                 *query;
} FakeDaemon;

#define LISTING_TWO "[('" G_PASTE_DEFAULT_HISTORY "', uint64 0), ('work', 2)]"
#define LISTING_ONE "[('" G_PASTE_DEFAULT_HISTORY "', uint64 0)]"
#define LISTING_THREE "[('" G_PASTE_DEFAULT_HISTORY "', uint64 0), ('work', 2), ('other', 1)]"

static const gchar * const no_notes[] = { NULL };

static gboolean
on_list_histories (GPasteDaemon3         *skeleton,
                   GDBusMethodInvocation *invocation,
                   gpointer               user_data)
{
    FakeDaemon *daemon = user_data;

    ++daemon->listings;

    if (daemon->listing_fails)
        g_dbus_method_invocation_return_error_literal (invocation, G_PASTE_ERROR, G_PASTE_ERROR_FAILED, "unreadable");
    else if (daemon->hold_listings)
        daemon->held_listing = invocation;
    else
        g_paste_daemon3_complete_list_histories (skeleton, invocation, g_variant_new_parsed (daemon->listing));

    return TRUE;
}

static gboolean
on_get_history_size (GPasteDaemon3         *skeleton,
                     GDBusMethodInvocation *invocation,
                     gpointer               user_data)
{
    FakeDaemon *daemon = user_data;

    ++daemon->sizings;

    if (daemon->hold_sizes)
        daemon->held_size = invocation;
    else
        g_paste_daemon3_complete_get_history_size (skeleton, invocation, daemon->size);

    return TRUE;
}

/* What the bus answers a call whose recipient disconnected: a call answered
 * this way is one its daemon left without answering. */
static void
return_gone (GDBusMethodInvocation *invocation)
{
    g_dbus_method_invocation_return_error_literal (invocation, G_DBUS_ERROR, G_DBUS_ERROR_NO_REPLY, "gone");
}

/* A search and the pinned items alike: nothing matches, nothing is pinned --
 * or, with filters_gone, the daemon gone without answering. */
static gboolean
on_get_favourites (GPasteDaemon3         *skeleton G_GNUC_UNUSED,
                   GDBusMethodInvocation *invocation,
                   gpointer               user_data)
{
    FakeDaemon *daemon = user_data;

    ++daemon->filters;
    if (daemon->filters_gone)
        return_gone (invocation);
    else if (daemon->hold_filters)
    {
        /* One held at a time: the listing it replaces, which the client gave
         * up asking for that one, is answered with nothing. */
        if (daemon->held_filter)
        {
            g_dbus_method_invocation_return_value (g_steal_pointer (&daemon->held_filter),
                                                   g_variant_new_parsed ("(@" G_PASTE_ITEMS_VARIANT_STRING " [],)"));
        }
        daemon->held_filter = invocation;
    }
    else
        g_dbus_method_invocation_return_value (invocation, g_variant_new_parsed ("(@" G_PASTE_ITEMS_VARIANT_STRING " [],)"));

    return TRUE;
}

/* The held search answered with @daemon's match. */
static void
answer_filter (FakeDaemon *daemon)
{
    g_auto (GVariantBuilder) items = G_VARIANT_BUILDER_INIT (G_PASTE_ITEMS_VARIANT_TYPE);

    g_variant_builder_add (&items, G_PASTE_ITEM_VARIANT_FORMAT, daemon->match, "match", G_PASTE_ITEM_KIND_TEXT, FALSE, no_notes);
    g_dbus_method_invocation_return_value (g_steal_pointer (&daemon->held_filter),
                                           g_variant_new ("(@" G_PASTE_ITEMS_VARIANT_STRING ")", g_variant_builder_end (&items)));
}

static gboolean
on_merge (GPasteDaemon3         *skeleton,
          GDBusMethodInvocation *invocation,
          const gchar           *decoration G_GNUC_UNUSED,
          const gchar           *separator G_GNUC_UNUSED,
          const gchar * const   *uuids,
          gpointer               user_data)
{
    FakeDaemon *daemon = user_data;

    g_set_strv (&daemon->merged, uuids);
    g_paste_daemon3_complete_merge (skeleton, invocation, "00000000-0000-4000-8000-0000000000ee");

    return TRUE;
}

static gboolean
on_switch_history (GPasteDaemon3         *skeleton,
                   GDBusMethodInvocation *invocation,
                   const gchar           *name G_GNUC_UNUSED,
                   gpointer               user_data)
{
    FakeDaemon *daemon = user_data;

    ++daemon->switches;
    g_paste_daemon3_complete_switch_history (skeleton, invocation);

    return TRUE;
}

static gboolean
on_select (GPasteDaemon3         *skeleton,
           GDBusMethodInvocation *invocation,
           const gchar           *uuid,
           gpointer               user_data)
{
    FakeDaemon *daemon = user_data;

    g_set_str (&daemon->selected, uuid);
    ++daemon->selects;
    if (daemon->announce_selects)
        g_paste_daemon3_emit_raw_update (skeleton, G_PASTE_UPDATE_ACTION_REPLACE, G_PASTE_UPDATE_TARGET_ALL, "", 0);
    g_paste_daemon3_complete_select (skeleton, invocation);

    return TRUE;
}

static gboolean
on_fake_search (GPasteDaemon3         *skeleton,
                GDBusMethodInvocation *invocation,
                const gchar           *query,
                gpointer               user_data)
{
    g_set_str (&((FakeDaemon *) user_data)->query, query);

    return on_get_favourites (skeleton, invocation, user_data);
}

#define UPLOADED_URL "https://paste.rs/x"

/* What the daemon keeps of the address -- the history, or the clipboard alone --
 * is its own business (g_paste_daemon_methods_copy_uploaded ()), which nothing
 * here stands in for: the window only reports how the upload went. */
static gboolean
on_upload_and_copy (GPasteDaemon3         *skeleton,
                    GDBusMethodInvocation *invocation,
                    const gchar           *uuid G_GNUC_UNUSED,
                    gpointer               user_data)
{
    FakeDaemon *daemon = user_data;

    ++daemon->uploads;

    if (daemon->hold_upload)
        daemon->held_upload = invocation;
    else
        g_paste_daemon3_complete_upload_and_copy (skeleton, invocation, UPLOADED_URL);

    return TRUE;
}

static void
complete_item (FakeDaemon            *daemon,
               GDBusMethodInvocation *invocation,
               guint64                index)
{
    daemon->lowest_read = MIN (daemon->lowest_read, index);

    g_autofree gchar *uuid = g_strdup_printf ("00000000-0000-4000-8000-%012" G_GUINT64_FORMAT, index + daemon->shift);
    g_autofree gchar *value = g_strdup_printf ("value %" G_GUINT64_FORMAT "%s", index, (daemon->edited) ? daemon->edited : "");
    GPasteItemKind kind = (daemon->images) ? G_PASTE_ITEM_KIND_IMAGE : G_PASTE_ITEM_KIND_TEXT;

    g_paste_daemon3_complete_get_item_at_index (daemon->skeleton, invocation,
                                                g_variant_new (G_PASTE_ITEM_VARIANT_FORMAT, uuid, value, kind, FALSE, no_notes));
}

static gboolean
on_get_item_at_index (GPasteDaemon3         *skeleton G_GNUC_UNUSED,
                      GDBusMethodInvocation *invocation,
                      guint64                index,
                      gpointer               user_data)
{
    FakeDaemon *daemon = user_data;

    if (daemon->hold_items)
        g_ptr_array_add (daemon->held_items, invocation);
    else
        complete_item (daemon, invocation, index);

    return TRUE;
}

/* Every item read held so far answered, and the reads after it too. */
static void
release_items (FakeDaemon *daemon)
{
    daemon->hold_items = FALSE;

    for (guint i = 0; i < daemon->held_items->len; ++i)
    {
        GDBusMethodInvocation *invocation = daemon->held_items->pdata[i];
        guint64 index;

        g_variant_get (g_dbus_method_invocation_get_parameters (invocation), "(t)", &index);
        complete_item (daemon, invocation, index);
    }

    g_ptr_array_set_size (daemon->held_items, 0);
}

/* An image the daemon cannot read back, as one whose cache file went. */
static gboolean
on_get_image (GPasteDaemon3         *skeleton G_GNUC_UNUSED,
              GDBusMethodInvocation *invocation,
              const gchar           *uuid G_GNUC_UNUSED,
              gpointer               user_data)
{
    FakeDaemon *daemon = user_data;

    ++daemon->image_reads;
    g_dbus_method_invocation_return_error_literal (invocation, G_PASTE_ERROR, G_PASTE_ERROR_NOT_FOUND, "no image");

    return TRUE;
}

static void
fake_daemon_start (FakeDaemon *daemon)
{
    g_autoptr (GError) error = NULL;

    if (!daemon->listing)
        daemon->listing = LISTING_TWO;

    daemon->connection = g_paste_test_bus_connect (g_getenv ("DBUS_SESSION_BUS_ADDRESS"));
    if (daemon->in_shell)
    {
        daemon->shell_owner = g_bus_own_name_on_connection (daemon->connection, "org.gnome.Shell", G_BUS_NAME_OWNER_FLAGS_NONE,
                                                            NULL, NULL, NULL, NULL);
    }
    /* Not queued for the name once replaced: a real daemon quits then
     * (on_name_lost () in src/daemon/gpaste-daemon.c), so it never gets the
     * name back from its successor going. */
    GBusNameOwnerFlags flags = (daemon->allow_replacement ? G_BUS_NAME_OWNER_FLAGS_ALLOW_REPLACEMENT | G_BUS_NAME_OWNER_FLAGS_DO_NOT_QUEUE : G_BUS_NAME_OWNER_FLAGS_NONE) |
                              (daemon->replace ? G_BUS_NAME_OWNER_FLAGS_REPLACE : G_BUS_NAME_OWNER_FLAGS_NONE);

    daemon->owner = g_bus_own_name_on_connection (daemon->connection, G_PASTE_BUS_NAME, flags,
                                                  NULL, NULL, NULL, NULL);

    daemon->skeleton = g_paste_daemon3_skeleton_new ();
    g_signal_connect (daemon->skeleton, "handle-list-histories", G_CALLBACK (on_list_histories), daemon);
    g_signal_connect (daemon->skeleton, "handle-get-history-size", G_CALLBACK (on_get_history_size), daemon);
    g_signal_connect (daemon->skeleton, "handle-get-item-at-index", G_CALLBACK (on_get_item_at_index), daemon);
    g_signal_connect (daemon->skeleton, "handle-get-image", G_CALLBACK (on_get_image), daemon);
    g_signal_connect (daemon->skeleton, "handle-search", G_CALLBACK (on_fake_search), daemon);
    g_signal_connect (daemon->skeleton, "handle-upload-and-copy", G_CALLBACK (on_upload_and_copy), daemon);
    g_signal_connect (daemon->skeleton, "handle-get-favourites", G_CALLBACK (on_get_favourites), daemon);
    g_signal_connect (daemon->skeleton, "handle-select", G_CALLBACK (on_select), daemon);
    g_signal_connect (daemon->skeleton, "handle-merge", G_CALLBACK (on_merge), daemon);
    g_signal_connect (daemon->skeleton, "handle-switch-history", G_CALLBACK (on_switch_history), daemon);
    daemon->held_items = g_ptr_array_new ();
    g_dbus_interface_skeleton_export (G_DBUS_INTERFACE_SKELETON (daemon->skeleton), daemon->connection,
                                      G_PASTE_DAEMON_OBJECT_PATH, &error);
    g_assert_no_error (error);
    /* After the export, as g_paste_daemon_register_on_connection () sets it:
     * only a set made then reaches a client that watched the daemon start. */
    g_paste_daemon3_set_version (daemon->skeleton, (daemon->version) ? daemon->version : PACKAGE_VERSION);
    g_paste_daemon3_set_history (daemon->skeleton, G_PASTE_DEFAULT_HISTORY);
}

/* Gone as a real daemon goes, its names and its object off the bus at once:
 * the connection closed first, once what it answered has gone out, as a
 * daemon flushes its replies before it exits. A close finding writes still
 * queued drops them, and a call answered would fail as one its daemon left
 * without answering, in whichever case runs when that failure comes back
 * (/ui/daemon-presence/stand-in-answers-first). Unexported first, it would
 * still own the name for a moment, and a call landing then would read an
 * error no real daemon gives -- no object at the path -- which the window
 * reports as a failure. */
static void
fake_daemon_stop (FakeDaemon *daemon)
{
    g_dbus_connection_flush_sync (daemon->connection, NULL, NULL);
    g_dbus_connection_close_sync (daemon->connection, NULL, NULL);
    g_dbus_interface_skeleton_unexport (G_DBUS_INTERFACE_SKELETON (daemon->skeleton));
    g_clear_object (&daemon->skeleton);
    g_clear_handle_id (&daemon->owner, g_bus_unown_name);
    g_clear_handle_id (&daemon->shell_owner, g_bus_unown_name);
    g_clear_object (&daemon->connection);
    g_clear_pointer (&daemon->held_items, g_ptr_array_unref);
    g_clear_pointer (&daemon->selected, g_free);
    g_clear_pointer (&daemon->merged, g_strfreev);
    g_clear_pointer (&daemon->query, g_free);
}

/* The calls the window sends the daemon's name that are its own to make -- a
 * search, the pinned items -- counted as they leave, which is the one place to
 * see them while nobody owns the name. The filter runs on GDBus' worker
 * thread. */
typedef struct
{
    gint searches;
    gint favourites;
    gint others;
} Outgoing;

static GDBusMessage *
count_outgoing (GDBusConnection *connection G_GNUC_UNUSED,
                GDBusMessage    *message,
                gboolean         incoming,
                gpointer         user_data)
{
    Outgoing *outgoing = user_data;

    if (incoming ||
        g_dbus_message_get_message_type (message) != G_DBUS_MESSAGE_TYPE_METHOD_CALL ||
        !g_paste_str_equal (g_dbus_message_get_destination (message), G_PASTE_BUS_NAME))
        return message;

    const gchar *member = g_dbus_message_get_member (message);

    if (g_paste_str_equal (member, "Search"))
        g_atomic_int_inc (&outgoing->searches);
    else if (g_paste_str_equal (member, "GetFavourites"))
        g_atomic_int_inc (&outgoing->favourites);
    else
        g_atomic_int_inc (&outgoing->others);

    return message;
}

/* As in tests/client/test-presence.c: local, gpaste-test-bus knowing no GPaste
 * type. */
static void
wait_for_presence (GPasteClient        *client,
                   GPasteDaemonPresence presence)
{
    g_paste_test_bus_wait_for_enum (client, "daemon-presence", presence);
}

/* The Pinned filter's star is drawn as the rows' are: empty while the filter
 * is off, full while it shows only the pinned items. */
static void
test_pinned_filter_star (void)
{
    g_autoptr (GtkWidget) header = g_object_ref_sink (g_paste_ui_header_new ());
    GtkToggleButton *button = g_paste_ui_header_get_favourites_button (ADW_HEADER_BAR (header));
    GtkImage *star = GTK_IMAGE (gtk_button_get_child (GTK_BUTTON (button)));

    g_assert_cmpstr (gtk_image_get_icon_name (star), ==, "non-starred-symbolic");
    gtk_toggle_button_set_active (button, TRUE);
    g_assert_cmpstr (gtk_image_get_icon_name (star), ==, "starred-symbolic");
    gtk_toggle_button_set_active (button, FALSE);
    g_assert_cmpstr (gtk_image_get_icon_name (star), ==, "non-starred-symbolic");
}

static AdwStatusPage *
find_status_page (GtkWidget *widget)
{
    return ADW_STATUS_PAGE (g_paste_test_gtk_find_widget (widget, ADW_TYPE_STATUS_PAGE));
}

/* The sidebar's row for @history, borrowed from the sidebar's model. */
static AdwSidebarItem *
sidebar_item (GPasteUiWindow *window,
              const gchar    *history)
{
    g_autoptr (GtkSelectionModel) items = adw_sidebar_get_items (ADW_SIDEBAR (g_paste_test_gtk_find_widget (window->panel, ADW_TYPE_SIDEBAR)));

    for (guint i = 0; i < g_list_model_get_n_items (G_LIST_MODEL (items)); ++i)
    {
        g_autoptr (AdwSidebarItem) item = g_list_model_get_item (G_LIST_MODEL (items), i);

        if (g_paste_str_equal (adw_sidebar_item_get_title (item), history))
            return item;
    }

    return NULL;
}

static gboolean
sidebar_lists (GPasteUiWindow *window,
               const gchar    *history)
{
    return sidebar_item (window, history) != NULL;
}

static gboolean
action_enabled (GPasteUiWindow *window,
                const gchar    *name)
{
    return g_action_group_get_action_enabled (G_ACTION_GROUP (window), name);
}

static gboolean
history_has_focus (GPasteUiWindow *window)
{
    GtkWidget *focus = gtk_root_get_focus (GTK_ROOT (window));

    return focus && gtk_widget_is_ancestor (focus, GTK_WIDGET (window->history));
}

static gboolean
history_list_has_focus (GPasteUiWindow *window)
{
    GtkWidget *focus = gtk_root_get_focus (GTK_ROOT (window));
    GtkWidget *list = g_paste_test_gtk_find_widget (GTK_WIDGET (window->history), GTK_TYPE_LIST_VIEW);

    return focus && (focus == list || gtk_widget_is_ancestor (focus, list));
}

static gboolean
sidebar_dropped (gconstpointer window,
                 gconstpointer history)
{
    return !sidebar_lists ((GPasteUiWindow *) window, history);
}

static gboolean
sidebar_has_history (gconstpointer window,
                     gconstpointer history)
{
    return sidebar_lists ((GPasteUiWindow *) window, history);
}

static gboolean
history_rows_are (gconstpointer window,
                  gconstpointer count)
{
    GtkWidget *view = g_paste_test_gtk_find_widget (GTK_WIDGET (((GPasteUiWindow *) window)->history), GTK_TYPE_LIST_VIEW);

    return g_list_model_get_n_items (G_LIST_MODEL (gtk_list_view_get_model (GTK_LIST_VIEW (view)))) == GPOINTER_TO_UINT (count);
}

/* GTK lets go of a row that went away on a later frame, not at once: until it
 * does, the window still names that row, rows standing in for it later getting
 * the focus back on their own. */
static gboolean
focus_moved_away (gconstpointer window,
                  gconstpointer arg G_GNUC_UNUSED)
{
    return !history_has_focus ((GPasteUiWindow *) window);
}

static gboolean
focus_returned (gconstpointer window,
                gconstpointer arg G_GNUC_UNUSED)
{
    return history_has_focus ((GPasteUiWindow *) window);
}

static gboolean
history_is_work (gconstpointer client,
                 gconstpointer arg G_GNUC_UNUSED)
{
    g_autofree gchar *history = g_paste_client_get_history_name ((GPasteClient *) client);

    return g_paste_str_equal (history, "work");
}

/* The rows are back once the list is shown in place of the status page. */
static gboolean
list_shown (gconstpointer window,
            gconstpointer arg G_GNUC_UNUSED)
{
    return gtk_widget_get_mapped (g_paste_test_gtk_find_widget (GTK_WIDGET (((GPasteUiWindow *) window)->history), GTK_TYPE_LIST_VIEW));
}

static GPasteUiWindow *
test_window (void)
{
    return g_object_ref_sink (g_object_new (G_PASTE_TYPE_UI_WINDOW, "application", app, NULL));
}

/* What the window showed the moment the daemon was said to be starting, read
 * from inside that notify -- after the window's own handler, connected first --
 * so that the end of the client's grace second, which a loaded machine can
 * reach before the test does, cannot have moved it on. */
typedef struct
{
    gboolean     seen;
    gboolean     revealed;
    const gchar *title;
    gboolean     new_item;
    gboolean     panel;
    gboolean     search_mode;
    const gchar *search_text;
} StartingSnapshot;

static void
on_presence_snapshot (GPasteClient *client,
                      GParamSpec   *pspec G_GNUC_UNUSED,
                      gpointer      user_data)
{
    GPasteUiWindow *window = user_data;
    StartingSnapshot *snapshot = g_object_get_data (G_OBJECT (window), "starting-snapshot");

    if (snapshot->seen || g_paste_client_get_daemon_presence (client) != G_PASTE_DAEMON_PRESENCE_STARTING)
        return;

    snapshot->seen = TRUE;
    snapshot->revealed = adw_banner_get_revealed (window->banner);
    snapshot->title = g_intern_string (adw_banner_get_title (window->banner));
    snapshot->new_item = action_enabled (window, "new-item");
    snapshot->panel = gtk_widget_get_sensitive (window->panel);
    snapshot->search_mode = gtk_search_bar_get_search_mode (window->search_bar);
    snapshot->search_text = g_intern_string (gtk_editable_get_text (GTK_EDITABLE (window->search_entry)));
}

/* The window, the list and the sidebar across a daemon that is not there, turns
 * up, and goes away again. */
static void
test_follow (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteUiWindow) window = test_window ();
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { 0 };

    g_assert_no_error (error);

    /* Opening the window asks for a daemon, which the bus has none of. */
    g_paste_ui_window_setup (window, client);
    g_assert_true (adw_banner_get_revealed (window->banner));
    g_assert_false (adw_banner_get_use_markup (window->banner));
    g_assert_cmpstr (adw_banner_get_title (window->banner), ==, _("Connecting to GPaste…"));
    g_assert_null (adw_banner_get_button_label (window->banner));
    g_assert_nonnull (adw_status_page_get_paintable (find_status_page (GTK_WIDGET (window->history))));

    /* Nothing that would act on a daemon is on offer without one. */
    g_assert_false (action_enabled (window, "new-item"));
    g_assert_false (action_enabled (window, "track-changes"));
    g_assert_true (action_enabled (window, "preferences"));
    g_assert_false (gtk_widget_get_sensitive (window->panel));
    g_assert_false (gtk_widget_get_sensitive (GTK_WIDGET (window->history)));

    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_ABSENT);
    g_assert_cmpstr (adw_banner_get_title (window->banner), ==, _("Couldn’t connect to GPaste"));
    g_assert_cmpstr (adw_banner_get_button_label (window->banner), ==, _("Retry"));
    g_assert_cmpstr (adw_status_page_get_title (find_status_page (GTK_WIDGET (window->history))), ==, _("History Unavailable"));
    g_assert_null (adw_status_page_get_paintable (find_status_page (GTK_WIDGET (window->history))));

    /* A daemon turning up lists the histories and the history both, and the
     * banner slides away still saying what it said. */
    fake_daemon_start (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    g_paste_test_bus_wait_for_count (&daemon.listings, 1);
    g_paste_test_bus_wait_for_count (&daemon.sizings, 1);
    g_assert_false (adw_banner_get_revealed (window->banner));
    g_assert_cmpstr (adw_banner_get_title (window->banner), ==, _("Couldn’t connect to GPaste"));
    g_assert_true (action_enabled (window, "new-item"));
    g_assert_true (gtk_widget_get_sensitive (window->panel));
    g_assert_true (gtk_widget_get_sensitive (GTK_WIDGET (window->history)));

    /* One going away takes the offers back, but not the search the user
     * typed: a daemon away for a moment would otherwise throw it away. */
    StartingSnapshot snapshot = { 0 };

    g_object_set_data (G_OBJECT (window), "starting-snapshot", &snapshot);
    g_signal_connect_object (client, "notify::daemon-presence", G_CALLBACK (on_presence_snapshot), window, 0);
    gtk_search_bar_set_search_mode (window->search_bar, TRUE);
    gtk_editable_set_text (GTK_EDITABLE (window->search_entry), "value");
    g_paste_test_bus_wait_for_count (&daemon.filters, 1);
    fake_daemon_stop (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_STARTING);
    g_assert_true (snapshot.seen);
    g_assert_true (snapshot.revealed);
    g_assert_cmpstr (snapshot.title, ==, _("Connecting to GPaste…"));
    g_assert_false (snapshot.new_item);
    g_assert_false (snapshot.panel);
    g_assert_true (snapshot.search_mode);
    g_assert_cmpstr (snapshot.search_text, ==, "value");

    /* The next daemon is asked the same search, once: the list asks it as
     * the presence reaches ready, and nothing asks again after. */
    daemon.filters = 0;
    fake_daemon_start (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    g_paste_test_bus_wait_for_count (&daemon.filters, 1);
    g_paste_test_bus_pump (200);
    g_assert_cmpuint (daemon.filters, ==, 1);
    g_assert_true (gtk_search_bar_get_search_mode (window->search_bar));
    g_assert_cmpstr (gtk_editable_get_text (GTK_EDITABLE (window->search_entry)), ==, "value");

    gtk_window_destroy (GTK_WINDOW (window));
    g_paste_test_bus_drain ();
    fake_daemon_stop (&daemon);
}

/* A window presented for a proxy that could not be built, then retried into a
 * daemon that is already there: the banner has nothing left to say. */
static void
test_retried_client (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GPasteUiWindow) window = test_window ();
    FakeDaemon daemon = { 0 };

    /* What on_banner_retry () leaves: a new client on its way, over a window
     * on_client_ready () already presented for the failure. */
    window->connecting = TRUE;
    window->initialized = TRUE;
    g_paste_ui_window_update_banner (window);
    g_assert_cmpstr (adw_banner_get_title (window->banner), ==, _("Connecting to GPaste…"));

    /* Built before the daemon is there: the stand-in answers on this thread's
     * main context, which a synchronous call made to it would block. */
    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);

    g_assert_no_error (error);
    fake_daemon_start (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);

    window->connecting = FALSE;
    g_paste_ui_window_setup (window, client);
    g_assert_false (adw_banner_get_revealed (window->banner));

    gtk_window_destroy (GTK_WINDOW (window));
    g_paste_test_bus_drain ();
    fake_daemon_stop (&daemon);
}

/* Escape with the search bar open and no daemon closes the bar, the focus
 * being on none of what is insensitive: the search is not kept for a daemon
 * that is not there, and emptying the entry asks nothing of anyone, the next
 * daemon included (on_escape ()). */
static void
test_search_closed_away (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteUiWindow) window = test_window ();
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { 0 };
    Outgoing outgoing = { 0 };

    g_assert_no_error (error);
    fake_daemon_start (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    g_paste_ui_window_setup (window, client);
    gtk_search_bar_set_search_mode (window->search_bar, TRUE);
    gtk_editable_set_text (GTK_EDITABLE (window->search_entry), "value");
    g_paste_test_bus_wait_for_count (&daemon.filters, 1);
    g_paste_test_bus_drain ();

    GDBusConnection *connection = g_dbus_proxy_get_connection (G_DBUS_PROXY (client));
    guint filter = g_dbus_connection_add_filter (connection, count_outgoing, &outgoing, NULL);

    fake_daemon_stop (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_STARTING);
    g_assert_true (gtk_search_bar_get_search_mode (window->search_bar));

    g_assert_true (on_escape (GTK_WIDGET (window), NULL, NULL));
    g_assert_false (gtk_search_bar_get_search_mode (window->search_bar));
    g_assert_cmpstr (gtk_editable_get_text (GTK_EDITABLE (window->search_entry)), ==, "");
    g_paste_test_bus_drain ();

    daemon.filters = 0;
    fake_daemon_start (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    g_paste_test_bus_wait_for_count (&daemon.listings, 1);
    g_paste_test_bus_pump (200);
    g_dbus_connection_flush_sync (connection, NULL, &error);
    g_assert_no_error (error);
    g_assert_cmpint (g_atomic_int_get (&outgoing.searches), ==, 0);
    g_assert_cmpuint (daemon.filters, ==, 0);
    g_dbus_connection_remove_filter (connection, filter);

    gtk_window_destroy (GTK_WINDOW (window));
    g_paste_test_bus_drain ();
    fake_daemon_stop (&daemon);
}

/* With no daemon, nothing the window does asks for one: not typing, not a
 * search reaching the list. */
static void
test_nothing_asked (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteUiWindow) window = test_window ();
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { 0 };
    Outgoing outgoing = { 0 };

    /* Built before the daemon is there, as in test_retried_client (). */
    g_assert_no_error (error);
    fake_daemon_start (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    g_paste_ui_window_setup (window, client);
    g_assert_true (gtk_search_bar_get_key_capture_widget (window->search_bar) == GTK_WIDGET (window));

    /* The Pinned filter on and a search typed: the search bar stays open
     * while the daemon is away, though emptying its entry is a search of its
     * own (/ui/daemon-presence/search-closed-away). */
    gtk_toggle_button_set_active (g_paste_ui_header_get_favourites_button (window->header), TRUE);
    gtk_search_bar_set_search_mode (window->search_bar, TRUE);
    gtk_editable_set_text (GTK_EDITABLE (window->search_entry), "value");
    g_paste_test_bus_wait_for_count (&daemon.filters, 2);
    g_paste_test_bus_drain ();

    GDBusConnection *connection = g_dbus_proxy_get_connection (G_DBUS_PROXY (client));
    guint filter = g_dbus_connection_add_filter (connection, count_outgoing, &outgoing, NULL);

    fake_daemon_stop (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_STARTING);
    g_paste_test_bus_drain ();

    /* With the daemon gone, typing does not open the search, and a search
     * asked for all the same stops at the list. */
    g_assert_null (gtk_search_bar_get_key_capture_widget (window->search_bar));
    g_paste_ui_history_search (window->history, "value");
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_ABSENT);
    g_paste_ui_history_search (window->history, "");
    g_paste_test_bus_drain ();

    g_dbus_connection_flush_sync (connection, NULL, &error);
    g_assert_no_error (error);
    g_assert_cmpint (g_atomic_int_get (&outgoing.favourites), ==, 0);
    g_assert_cmpint (g_atomic_int_get (&outgoing.searches), ==, 0);
    g_assert_cmpstr (adw_status_page_get_title (find_status_page (GTK_WIDGET (window->history))), ==, _("History Unavailable"));
    g_dbus_connection_remove_filter (connection, filter);

    /* A daemon back gives typing back its search. */
    fake_daemon_start (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    g_assert_true (gtk_search_bar_get_key_capture_widget (window->search_bar) == GTK_WIDGET (window));

    gtk_window_destroy (GTK_WINDOW (window));
    g_paste_test_bus_drain ();
    fake_daemon_stop (&daemon);
}

/* The sidebar's entry holding the focus when the daemon goes: it is taken off
 * the entry before the sidebar goes insensitive, or GTK would leave the entry
 * believing it still has it -- and warn, which a test aborts on. */
static void
test_entry_focus_released (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteUiWindow) window = test_window ();
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { 0 };

    g_assert_no_error (error);
    fake_daemon_start (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    g_paste_ui_window_setup (window, client);
    g_paste_test_bus_wait_for_count (&daemon.listings, 1);
    g_paste_test_bus_drain ();

    GtkWidget *entry = g_paste_test_gtk_find_widget (window->panel, GTK_TYPE_TEXT);

    g_assert_true (gtk_widget_grab_focus (entry));

    fake_daemon_stop (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_STARTING);
    /* Past the frame GTK would warn on. */
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_ABSENT);
    g_assert_false (gtk_widget_has_focus (entry));

    gtk_window_destroy (GTK_WINDOW (window));
    g_paste_test_bus_drain ();
}

/* What the entry's own focus controller believes, which is what GTK leaves
 * stale when it drops the focus of an insensitive widget. */
static gboolean
entry_believes_focused (GtkWidget *text)
{
    g_autoptr (GListModel) controllers = gtk_widget_observe_controllers (text);

    for (guint i = 0; i < g_list_model_get_n_items (controllers); ++i)
    {
        g_autoptr (GObject) controller = g_list_model_get_item (controllers, i);

        if (GTK_IS_EVENT_CONTROLLER_FOCUS (controller) && gtk_event_controller_focus_is_focus (GTK_EVENT_CONTROLLER_FOCUS (controller)))
            return TRUE;
    }

    return FALSE;
}

static gboolean
entry_let_go (gconstpointer text,
              gconstpointer arg G_GNUC_UNUSED)
{
    return !entry_believes_focused ((GtkWidget *) text);
}

/* The Merge popover's entry holding the focus when the picks drop below two --
 * the daemon going, which empties the list, or a history change: it is let go
 * of before the button goes insensitive, or its own focus controller goes on
 * believing it has the focus -- which GTK warns about when the popover is next
 * opened. */
static void
test_merge_entry_focus_released (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteUiWindow) window = test_window ();
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { 0 };

    g_assert_no_error (error);
    fake_daemon_start (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    g_paste_ui_window_setup (window, client);
    g_paste_test_bus_drain ();

    GtkMenuButton *merge = GTK_MENU_BUTTON (window->merge_button);

    /* A popover on Xvfb, which has no compositor, gets GDK warning about its
     * frame timings -- nothing the window does, and nothing this test is about,
     * which asserts on the entry's controller rather than on a warning. So
     * warnings are not fatal while the popover is up; the structured log GTK
     * uses ignores g_test_log_set_fatal_handler (). */
    GLogLevelFlags fatal = g_log_set_always_fatal (G_LOG_FATAL_MASK | G_LOG_LEVEL_CRITICAL);

    /* In selection mode, as the Merge button is only shown there. */
    on_enter_selection_mode (NULL, window);
    g_signal_emit_by_name (window->history, "selection-changed", 2);
    gtk_menu_button_popup (merge);
    g_paste_test_bus_wait_until (g_paste_test_gtk_widget_mapped, window->merge_entry, NULL);
    g_assert_true (gtk_widget_get_mapped (window->merge_entry));
    g_assert_true (gtk_widget_grab_focus (window->merge_entry));

    GtkWidget *text = g_paste_test_gtk_find_widget (window->merge_entry, GTK_TYPE_TEXT);

    g_assert_true (entry_believes_focused (text));

    g_signal_emit_by_name (window->history, "selection-changed", 0);
    g_paste_test_bus_wait_until (entry_let_go, text, NULL);
    g_assert_false (entry_believes_focused (text));
    g_log_set_always_fatal (fatal);

    gtk_window_destroy (GTK_WINDOW (window));
    g_paste_test_bus_drain ();
    fake_daemon_stop (&daemon);
}

/* A window closed while the list's size request is out: the list outlives the
 * sidebar, the reply holding it until it lands, and the reply must not reach
 * for the sidebar gone with the window (see the panel field of
 * GPasteUiHistory). */
static void
test_reply_after_close (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteUiWindow) window = test_window ();
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { 0 };

    g_assert_no_error (error);
    fake_daemon_start (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    g_paste_ui_window_setup (window, client);
    g_paste_test_bus_wait_for_count (&daemon.sizings, 1);
    g_paste_test_bus_drain ();

    daemon.hold_sizes = TRUE;
    daemon.sizings = 0;
    g_paste_ui_history_search (window->history, "");
    g_paste_test_bus_wait_for_count (&daemon.sizings, 1);

    /* Destroyed and let go of, as the application does: the list stands on,
     * held by the reply, and the sidebar does not. */
    GtkWidget *panel = window->panel;
    GPasteUiHistory *history = window->history;

    g_object_add_weak_pointer (G_OBJECT (panel), (gpointer *) &panel);
    g_object_add_weak_pointer (G_OBJECT (history), (gpointer *) &history);
    gtk_window_destroy (GTK_WINDOW (window));
    g_clear_object (&window);
    g_paste_test_bus_drain ();
    g_assert_null (panel);
    g_assert_nonnull (history);

    g_paste_daemon3_complete_get_history_size (daemon.skeleton, g_steal_pointer (&daemon.held_size), 3);
    g_dbus_connection_flush_sync (daemon.connection, NULL, &error);
    g_assert_no_error (error);
    g_paste_test_bus_round_trip (g_dbus_proxy_get_connection (G_DBUS_PROXY (client)), daemon.connection);
    g_assert_null (history);

    fake_daemon_stop (&daemon);
}

/* A window over @daemon, started, its rows shown, that pastes without
 * closing. */
static GPasteUiWindow *
activation_window (GPasteClient *client,
                   FakeDaemon   *daemon)
{
    GPasteUiWindow *window = test_window ();

    fake_daemon_start (daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    g_paste_ui_window_setup (window, client);
    g_paste_settings_set_close_on_select (window->settings, FALSE);
    g_paste_test_bus_wait_for_count (&daemon->sizings, 1);
    g_paste_test_bus_wait_until (list_shown, window, NULL);
    g_assert_true (list_shown (window, NULL));

    return window;
}

static gboolean
count_tick (GtkWidget     *widget G_GNUC_UNUSED,
            GdkFrameClock *clock  G_GNUC_UNUSED,
            gpointer       user_data)
{
    ++*(guint *) user_data;

    return G_SOURCE_CONTINUE;
}

/* Until @widget has been through a frame since now, which is what lays out
 * what its model changed: draining the main context does not wait for one. */
static void
wait_for_layout (GtkWidget *widget)
{
    guint ticks = 0;
    guint id = gtk_widget_add_tick_callback (widget, count_tick, &ticks, NULL);

    g_paste_test_bus_wait_for_count (&ticks, 2);
    gtk_widget_remove_tick_callback (widget, id);
}

/* Rows past what the window shows, loaded as scrolling to the bottom does,
 * @times batches of them. */
static void
grow_list (GPasteUiWindow *window,
           GPasteClient   *client,
           FakeDaemon     *daemon,
           guint           times)
{
    GtkWidget *list_view = g_paste_test_gtk_find_widget (GTK_WIDGET (window->history), GTK_TYPE_LIST_VIEW);
    GtkWidget *scroll = gtk_widget_get_ancestor (list_view, GTK_TYPE_SCROLLED_WINDOW);

    for (guint i = 0; i < times; ++i)
    {
        guint sized = daemon->sizings;

        g_signal_emit_by_name (scroll, "edge-reached", GTK_POS_BOTTOM);
        g_paste_test_bus_wait_for_count (&daemon->sizings, sized + 1);
        g_paste_test_bus_round_trip (g_dbus_proxy_get_connection (G_DBUS_PROXY (client)), daemon->connection);
        wait_for_layout (list_view);
    }
}

static void
close_activation_window (GPasteUiWindow *window,
                         FakeDaemon     *daemon)
{
    g_paste_settings_reset (window->settings, G_PASTE_CLOSE_ON_SELECT_SETTING);
    gtk_window_destroy (GTK_WINDOW (window));
    g_paste_test_bus_drain ();
    fake_daemon_stop (daemon);
}

static gboolean
has_held_items (gconstpointer daemon,
                gconstpointer arg G_GNUC_UNUSED)
{
    return ((FakeDaemon *) daemon)->held_items->len > 0;
}

static gboolean
selected (gconstpointer daemon,
          gconstpointer arg G_GNUC_UNUSED)
{
    return ((FakeDaemon *) daemon)->selects > 0;
}

/* Enter in the search selects the first match of what was typed, once that is
 * listed -- not the first row of whatever the list showed when it was pressed,
 * the entry's delay having applied nothing yet. */
static void
test_search_enter_waits (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .size = 5, .match = "00000000-0000-4000-8000-0000000000ff" };

    g_assert_no_error (error);

    g_autoptr (GPasteUiWindow) window = activation_window (client, &daemon);

    daemon.hold_filters = TRUE;
    gtk_search_bar_set_search_mode (window->search_bar, TRUE);
    gtk_editable_set_text (GTK_EDITABLE (window->search_entry), "match");
    g_signal_emit_by_name (window->search_entry, "activate");
    g_paste_test_bus_wait_for_count (&daemon.filters, 1);
    g_paste_test_bus_round_trip (g_dbus_proxy_get_connection (G_DBUS_PROXY (client)), daemon.connection);
    g_assert_cmpuint (daemon.selects, ==, 0);

    /* Past the entry's delay, which says the same search again. */
    g_paste_test_bus_pump (300);
    g_assert_cmpuint (daemon.filters, ==, 1);
    answer_filter (&daemon);
    g_paste_test_bus_wait_until (selected, &daemon, NULL);
    g_assert_cmpstr (daemon.selected, ==, daemon.match);
    close_activation_window (window, &daemon);
}

/* An Enter waiting on a search the daemon has not answered goes with that
 * daemon: the next one lists the search again, and is not told to select its
 * first match -- which would replace the clipboard, and close the window by
 * default, a daemon's restart after the key was pressed. */
static void
test_search_enter_restart (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon old = { .size = 5, .match = "00000000-0000-4000-8000-0000000000ff" };
    FakeDaemon successor = { .size = 5, .match = "00000000-0000-4000-8000-0000000000ff" };

    g_assert_no_error (error);

    g_autoptr (GPasteUiWindow) window = activation_window (client, &old);

    old.hold_filters = TRUE;
    gtk_search_bar_set_search_mode (window->search_bar, TRUE);
    gtk_editable_set_text (GTK_EDITABLE (window->search_entry), "match");
    g_signal_emit_by_name (window->search_entry, "activate");
    g_paste_test_bus_wait_for_count (&old.filters, 1);

    /* Gone with the search unanswered, which the next daemon lists again:
     * the presence edge, cancelling it, comes before the call's failure. */
    fake_daemon_stop (&old);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_ABSENT);
    g_clear_object (&old.held_filter);
    fake_daemon_start (&successor);
    g_paste_test_bus_wait_for_count (&successor.filters, 1);
    g_paste_test_bus_round_trip (g_dbus_proxy_get_connection (G_DBUS_PROXY (client)), successor.connection);
    g_paste_test_bus_pump (300);
    g_assert_cmpuint (successor.selects, ==, 0);
    g_assert_cmpuint (old.selects, ==, 0);

    close_activation_window (window, &successor);
}

/* Set to hold the next Update a stand-in sends on GDBus' worker thread, which
 * every connection of the process shares, a quarter of a second: what it
 * writes after it waits the while in its queue. stall_over is set once the
 * quarter is over. */
static gint stall_update;
static gint stall_over;

static GDBusMessage *
stall_update_filter (GDBusConnection *connection G_GNUC_UNUSED,
                     GDBusMessage    *message,
                     gboolean         incoming,
                     gpointer         user_data G_GNUC_UNUSED)
{
    if (!incoming && g_dbus_message_get_message_type (message) == G_DBUS_MESSAGE_TYPE_SIGNAL &&
        g_paste_str_equal (g_dbus_message_get_member (message), "Update") &&
        g_atomic_int_compare_and_exchange (&stall_update, TRUE, FALSE))
    {
        g_usleep (G_USEC_PER_SEC / 4);
        g_atomic_int_set (&stall_over, TRUE);
    }

    return message;
}

/* As fake_daemon_stop () says: a Select the stand-in answered right before it
 * goes, its answer queued behind an announcement, is answered. */
static void
test_stand_in_answers_first (void)
{
    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    g_autoptr (GAsyncResult) result = NULL;
    FakeDaemon daemon = { .size = 1, .announce_selects = TRUE };

    g_assert_no_error (error);
    fake_daemon_start (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    g_dbus_connection_add_filter (daemon.connection, stall_update_filter, NULL, NULL);
    g_atomic_int_set (&stall_over, FALSE);
    g_atomic_int_set (&stall_update, TRUE);

    g_paste_client_select (client, "00000000-0000-4000-8000-000000000000", NULL, g_paste_test_env_keep_result, &result);
    g_paste_test_bus_wait_until (selected, &daemon, NULL);
    g_assert_cmpuint (daemon.selects, ==, 1);
    /* A stall already over let the answer out before the stop began -- this
     * thread held off the processor for as long -- leaving the stop nothing
     * queued to drop. */
    if (g_atomic_int_get (&stall_over))
        g_test_skip ("The answer went out before the stand-in began to go");
    fake_daemon_stop (&daemon);
    g_paste_test_env_wait_result (&result);
    g_paste_client_select_finish (client, result, &error);
    g_assert_no_error (error);
}

/* Nor does an update listing the same search again while Enter waits on it --
 * a new copy, a removal -- lose the key: the listing replacing the one Enter
 * was asked of answers it. */
static void
test_search_enter_survives_update (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .size = 5, .match = "00000000-0000-4000-8000-0000000000ff" };

    g_assert_no_error (error);

    g_autoptr (GPasteUiWindow) window = activation_window (client, &daemon);

    daemon.hold_filters = TRUE;
    gtk_search_bar_set_search_mode (window->search_bar, TRUE);
    gtk_editable_set_text (GTK_EDITABLE (window->search_entry), "match");
    g_signal_emit_by_name (window->search_entry, "activate");
    g_paste_test_bus_wait_for_count (&daemon.filters, 1);

    g_paste_daemon3_emit_raw_update (daemon.skeleton, G_PASTE_UPDATE_ACTION_REPLACE, G_PASTE_UPDATE_TARGET_ALL, "", 0);
    g_paste_test_bus_wait_for_count (&daemon.filters, 2);
    g_paste_test_bus_round_trip (g_dbus_proxy_get_connection (G_DBUS_PROXY (client)), daemon.connection);
    g_assert_cmpuint (daemon.selects, ==, 0);

    answer_filter (&daemon);
    g_paste_test_bus_wait_until (selected, &daemon, NULL);
    g_assert_cmpstr (daemon.selected, ==, daemon.match);
    close_activation_window (window, &daemon);
}

/* A status page's description is a translation shown as written, an & in it
 * included, rather than nothing below the title; so is the sidebar's entry's
 * title. */
static void
test_status_plain (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .size = 0 };

    g_assert_no_error (error);

    GPasteUiWindow *window = test_window ();

    fake_daemon_start (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    g_paste_ui_window_setup (window, client);
    g_paste_test_bus_wait_for_count (&daemon.sizings, 1);
    g_paste_test_bus_round_trip (g_dbus_proxy_get_connection (G_DBUS_PROXY (client)), daemon.connection);

    AdwStatusPage *status = find_status_page (GTK_WIDGET (window->history));

    g_assert_cmpstr (adw_status_page_get_title (status), ==, _("No Items"));
    g_assert_true (g_paste_test_gtk_shows_label (GTK_WIDGET (status), EMPTY_DESCRIPTION_TRANSLATED));
    g_assert_true (g_paste_test_gtk_shows_label (window->panel, SWITCH_ENTRY_TRANSLATED));
    close_activation_window (window, &daemon);
}

/* Leaving a search whose history then cannot be sized leaves no search result
 * on screen as if it were the history, Ctrl+0 pasting it: the rows go, under
 * an error and a way to retry. */
static void
test_size_fails_leaving_search (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .size = 5, .match = "00000000-0000-4000-8000-0000000000ff" };

    g_assert_no_error (error);

    g_autoptr (GPasteUiWindow) window = activation_window (client, &daemon);

    daemon.hold_filters = TRUE;
    g_paste_ui_history_search (window->history, "match");
    g_paste_test_bus_wait_for_count (&daemon.filters, 1);
    answer_filter (&daemon);
    g_paste_test_bus_round_trip (g_dbus_proxy_get_connection (G_DBUS_PROXY (client)), daemon.connection);
    g_assert_true (list_shown (window, NULL));

    guint sized = daemon.sizings;

    daemon.hold_sizes = TRUE;
    g_paste_ui_history_search (window->history, "");
    g_paste_test_bus_wait_for_count (&daemon.sizings, sized + 1);
    g_test_expect_message ("GPaste", G_LOG_LEVEL_WARNING, "Could not get the size of history*size failed");
    g_dbus_method_invocation_return_dbus_error (g_steal_pointer (&daemon.held_size), "org.gnome.GPaste.Test.Size", "size failed");
    g_paste_test_bus_round_trip (g_dbus_proxy_get_connection (G_DBUS_PROXY (client)), daemon.connection);
    g_test_assert_expected_messages ();

    AdwStatusPage *status = find_status_page (GTK_WIDGET (window->history));

    g_assert_false (list_shown (window, NULL));
    g_assert_cmpstr (adw_status_page_get_title (status), ==, _("Could Not Load History"));

    /* Ctrl+0 is the history's first item, read by its index. */
    daemon.hold_sizes = FALSE;
    g_assert_true (g_paste_ui_history_activate_index (window->history, 0));
    g_paste_test_bus_wait_until (selected, &daemon, NULL);
    g_assert_cmpstr (daemon.selected, !=, daemon.match);
    close_activation_window (window, &daemon);
}

/* A search or the pinned items the daemon fails to list is no answer that
 * nothing matched or nothing is pinned: it is warned about, and the page says
 * the history could not be loaded, with a way to retry. */
static void
test_filter_fails (gconstpointer data)
{
    gboolean searched = GPOINTER_TO_INT (data);

    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .size = 5, .match = "00000000-0000-4000-8000-0000000000ff" };

    g_assert_no_error (error);

    g_autoptr (GPasteUiWindow) window = activation_window (client, &daemon);

    daemon.hold_filters = TRUE;
    if (searched)
        g_paste_ui_history_search (window->history, "match");
    else
        g_paste_ui_history_set_favourites (window->history, TRUE);
    g_paste_test_bus_wait_for_count (&daemon.filters, 1);
    g_test_expect_message ("GPaste", G_LOG_LEVEL_WARNING, (searched) ? "Could not search the history*filter failed" : "Could not list the pinned items*filter failed");
    g_dbus_method_invocation_return_dbus_error (g_steal_pointer (&daemon.held_filter), "org.gnome.GPaste.Test.Filter", "filter failed");
    g_paste_test_bus_round_trip (g_dbus_proxy_get_connection (G_DBUS_PROXY (client)), daemon.connection);
    g_test_assert_expected_messages ();

    AdwStatusPage *status = find_status_page (GTK_WIDGET (window->history));

    g_assert_false (list_shown (window, NULL));
    g_assert_cmpstr (adw_status_page_get_title (status), ==, _("Could Not Load History"));
    g_assert_true (gtk_widget_get_visible (adw_status_page_get_child (status)));
    daemon.hold_filters = FALSE;
    close_activation_window (window, &daemon);
}

/* The sidebar's count of the current history follows a copy or a deletion
 * made with a search up, which lists the history again by its matches. */
static void
test_filtered_count (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .size = 5, .match = "00000000-0000-4000-8000-0000000000ff" };

    g_assert_no_error (error);

    g_autoptr (GPasteUiWindow) window = activation_window (client, &daemon);

    g_paste_test_bus_wait_until (sidebar_has_history, window, G_PASTE_DEFAULT_HISTORY);
    g_assert_true (sidebar_has_history (window, G_PASTE_DEFAULT_HISTORY));
    daemon.hold_filters = TRUE;
    g_paste_ui_history_search (window->history, "match");
    g_paste_test_bus_wait_for_count (&daemon.filters, 1);
    answer_filter (&daemon);
    g_paste_test_bus_round_trip (g_dbus_proxy_get_connection (G_DBUS_PROXY (client)), daemon.connection);
    g_assert_cmpstr (adw_sidebar_item_get_subtitle (sidebar_item (window, G_PASTE_DEFAULT_HISTORY)), ==, "5");

    daemon.size = 3;
    g_paste_daemon3_emit_raw_update (daemon.skeleton, G_PASTE_UPDATE_ACTION_REMOVE, G_PASTE_UPDATE_TARGET_ITEM, "", 0);
    g_paste_test_bus_wait_for_count (&daemon.filters, 2);
    answer_filter (&daemon);
    g_paste_test_bus_round_trip (g_dbus_proxy_get_connection (G_DBUS_PROXY (client)), daemon.connection);
    g_assert_cmpstr (adw_sidebar_item_get_subtitle (sidebar_item (window, G_PASTE_DEFAULT_HISTORY)), ==, "3");
    daemon.hold_filters = FALSE;
    close_activation_window (window, &daemon);
}

/* A row bound before its item has been read activates all the same, read by its
 * index, as is one past the rows loaded so far, as far as the history goes. */
static void
test_activate_unread_rows (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .size = 500, .hold_items = TRUE };

    g_assert_no_error (error);

    g_autoptr (GPasteUiWindow) window = activation_window (client, &daemon);

    g_paste_test_bus_wait_until (has_held_items, &daemon, NULL);
    g_assert_true (has_held_items (&daemon, NULL));
    g_assert_true (g_paste_ui_history_activate_index (window->history, 0));
    release_items (&daemon);
    g_paste_test_bus_wait_until (selected, &daemon, NULL);
    g_assert_cmpstr (daemon.selected, ==, "00000000-0000-4000-8000-000000000000");

    daemon.selects = 0;
    g_assert_true (g_paste_ui_history_activate_index (window->history, 400));
    g_paste_test_bus_wait_until (selected, &daemon, NULL);
    g_assert_cmpstr (daemon.selected, ==, "00000000-0000-4000-8000-000000000400");
    g_assert_false (g_paste_ui_history_activate_index (window->history, 500));
    close_activation_window (window, &daemon);
}

static void
count_picks (GPasteUiHistory *history G_GNUC_UNUSED,
             guint            count,
             gpointer         user_data)
{
    *(guint *) user_data = count;
}

/* While items are being picked, Ctrl+1 picks the second row as a click would,
 * an arrow key moving the cursor leaves the picks as they were, picking every
 * row adds those not picked yet, and Ctrl+F
 * opens no search over the picks. A search asked for from outside leaves
 * selection mode first. */
static void
test_selection_mode_keys (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .size = 3 };
    guint picks = 0;

    g_assert_no_error (error);

    g_autoptr (GPasteUiWindow) window = activation_window (client, &daemon);

    g_signal_connect (window->history, "selection-changed", G_CALLBACK (count_picks), &picks);
    g_assert_true (action_enabled (window, "toggle-search"));
    on_enter_selection_mode (NULL, window);
    g_assert_false (action_enabled (window, "toggle-search"));

    g_assert_true (g_paste_ui_history_activate_index (window->history, 1));
    g_paste_test_bus_round_trip (g_dbus_proxy_get_connection (G_DBUS_PROXY (client)), daemon.connection);
    g_assert_cmpuint (picks, ==, 1);
    g_assert_cmpuint (daemon.selects, ==, 0);

    /* What the list view's own arrow keys do as they move to a row. */
    GtkWidget *list_view = g_paste_test_gtk_find_widget (GTK_WIDGET (window->history), GTK_TYPE_LIST_VIEW);
    GtkSelectionModel *model = gtk_list_view_get_model (GTK_LIST_VIEW (list_view));

    g_assert_true (g_paste_ui_history_activate_index (window->history, 0));
    g_assert_cmpuint (picks, ==, 2);
    g_assert_true (gtk_widget_activate_action (list_view, "list.select-item", "(ubb)", 2, FALSE, FALSE));
    g_assert_cmpuint (picks, ==, 2);
    g_assert_true (gtk_selection_model_is_selected (model, 0));
    g_assert_true (gtk_selection_model_is_selected (model, 1));
    g_assert_false (gtk_selection_model_is_selected (model, 2));

    /* Picking every row adds those left, each pick once: the first given up so
     * that what changes spans the second, still picked. */
    g_assert_true (g_paste_ui_history_activate_index (window->history, 0));
    g_assert_cmpuint (picks, ==, 1);
    g_assert_true (gtk_widget_activate_action (list_view, "list.select-all", NULL));
    g_assert_cmpuint (picks, ==, 3);

    g_paste_ui_window_search (window, "value");
    g_assert_false (g_paste_ui_history_get_selection_mode (window->history));
    g_assert_true (gtk_search_bar_get_search_mode (window->search_bar));
    g_assert_true (action_enabled (window, "toggle-search"));
    close_activation_window (window, &daemon);
}

/* The click gesture of a row, @position's among the rows built. */
static GtkGesture *
row_press_gesture (GtkListView *list_view,
                   guint        position)
{
    guint seen = 0;

    for (GtkWidget *child = gtk_widget_get_first_child (GTK_WIDGET (list_view)); child; child = gtk_widget_get_next_sibling (child))
    {
        GtkWidget *item = gtk_widget_get_first_child (child);

        if (!item || !G_PASTE_IS_UI_ITEM (item) || seen++ != position)
            continue;

        g_autoptr (GListModel) controllers = gtk_widget_observe_controllers (item);

        for (guint i = 0; i < g_list_model_get_n_items (controllers); ++i)
        {
            g_autoptr (GtkEventController) controller = g_list_model_get_item (controllers, i);

            if (GTK_IS_GESTURE_CLICK (controller))
                return GTK_GESTURE (controller);
        }
    }

    return NULL;
}

/* While items are being picked, a row clicked takes the keyboard too, as one
 * clicked outside selection mode does: the pick claims the press before the
 * list's own gesture, which is what gives the focus, and Enter would then pick
 * whichever row the keyboard was left on rather than the one clicked. */
static void
test_selection_click_focuses (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .size = 3 };

    g_assert_no_error (error);

    g_autoptr (GPasteUiWindow) window = activation_window (client, &daemon);
    GtkListView *list_view = GTK_LIST_VIEW (g_paste_test_gtk_find_widget (GTK_WIDGET (window->history), GTK_TYPE_LIST_VIEW));

    on_enter_selection_mode (NULL, window);
    wait_for_layout (GTK_WIDGET (list_view));

    GtkGesture *gesture = row_press_gesture (list_view, 2);

    g_assert_nonnull (gesture);
    g_signal_emit_by_name (gesture, "pressed", 1, 1.0, 1.0);
    g_paste_test_bus_drain ();

    GtkWidget *focus = gtk_root_get_focus (GTK_ROOT (window));
    GtkWidget *clicked = gtk_widget_get_parent (gtk_event_controller_get_widget (GTK_EVENT_CONTROLLER (gesture)));

    g_assert_nonnull (focus);
    g_assert_true (focus == clicked || gtk_widget_is_ancestor (focus, clicked));
    close_activation_window (window, &daemon);
}

/* A positional refresh superseded by another before its size came back would
 * have refetched from its own row on; the one that supersedes it does so from
 * the earlier of the two rows, its reply alone landing. */
static void
test_superseded_refresh (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .size = 10 };

    g_assert_no_error (error);

    g_autoptr (GPasteUiWindow) window = activation_window (client, &daemon);

    g_paste_test_bus_drain ();
    daemon.hold_sizes = TRUE;
    daemon.sizings = 0;
    g_signal_emit_by_name (client, "update", G_PASTE_UPDATE_ACTION_REMOVE, G_PASTE_UPDATE_TARGET_ITEM, "", (guint64) 2);
    g_paste_test_bus_wait_for_count (&daemon.sizings, 1);

    GDBusMethodInvocation *superseded = g_steal_pointer (&daemon.held_size);

    g_signal_emit_by_name (client, "update", G_PASTE_UPDATE_ACTION_REMOVE, G_PASTE_UPDATE_TARGET_ITEM, "", (guint64) 5);
    g_paste_test_bus_wait_for_count (&daemon.sizings, 2);

    daemon.lowest_read = G_MAXUINT64;
    daemon.size = 8;
    g_paste_daemon3_complete_get_history_size (daemon.skeleton, superseded, daemon.size);
    g_paste_daemon3_complete_get_history_size (daemon.skeleton, g_steal_pointer (&daemon.held_size), daemon.size);
    g_paste_test_bus_round_trip (g_dbus_proxy_get_connection (G_DBUS_PROXY (client)), daemon.connection);
    g_paste_test_bus_round_trip (g_dbus_proxy_get_connection (G_DBUS_PROXY (client)), daemon.connection);
    g_assert_cmpuint (daemon.lowest_read, ==, 2);
    close_activation_window (window, &daemon);
}

/* A row whose item changed where it stands is read again in place: the widget
 * stays, with the keyboard focus and what it shows until the read lands, rather
 * than being unbound and blanked as a recycled row is. A pick on it goes, what
 * it shows no longer being what was picked. */
static void
test_row_read_in_place (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .size = 6 };
    guint picks = 0;

    g_assert_no_error (error);

    g_autoptr (GPasteUiWindow) window = activation_window (client, &daemon);
    GtkListView *list_view = GTK_LIST_VIEW (g_paste_test_gtk_find_widget (GTK_WIDGET (window->history), GTK_TYPE_LIST_VIEW));

    g_paste_test_bus_drain ();
    gtk_list_view_scroll_to (list_view, 3, GTK_LIST_SCROLL_FOCUS, NULL);
    g_paste_test_bus_drain ();

    GtkWidget *focus = gtk_root_get_focus (GTK_ROOT (window));

    g_assert_nonnull (focus);

    GtkInscription *label = GTK_INSCRIPTION (g_paste_test_gtk_find_widget (focus, GTK_TYPE_INSCRIPTION));

    g_assert_cmpstr (gtk_inscription_get_text (label), ==, "value 3");

    /* Until its read lands, the row goes on showing what it showed. */
    daemon.hold_items = TRUE;
    daemon.edited = " edited";
    g_signal_emit_by_name (client, "update", G_PASTE_UPDATE_ACTION_REPLACE, G_PASTE_UPDATE_TARGET_ITEM, "", (guint64) 3);
    g_paste_test_bus_wait_until (has_held_items, &daemon, NULL);
    g_assert_cmpstr (gtk_inscription_get_text (label), ==, "value 3");

    daemon.lowest_read = G_MAXUINT64;
    release_items (&daemon);
    g_paste_test_bus_round_trip (g_dbus_proxy_get_connection (G_DBUS_PROXY (client)), daemon.connection);
    g_assert_cmpuint (daemon.lowest_read, ==, 3);
    g_assert_true (gtk_root_get_focus (GTK_ROOT (window)) == focus);
    g_assert_cmpstr (gtk_inscription_get_text (label), ==, "value 3 edited");

    g_signal_connect (window->history, "selection-changed", G_CALLBACK (count_picks), &picks);
    on_enter_selection_mode (NULL, window);
    g_assert_true (g_paste_ui_history_activate_index (window->history, 2));
    g_assert_cmpuint (picks, ==, 1);
    g_signal_emit_by_name (client, "update", G_PASTE_UPDATE_ACTION_REPLACE, G_PASTE_UPDATE_TARGET_ITEM, "", (guint64) 2);
    g_assert_cmpuint (picks, ==, 0);
    close_activation_window (window, &daemon);
}

/* Answer the search held with five matches, the same every time. */
static void
answer_five_matches (FakeDaemon   *daemon,
                     GPasteClient *client)
{
    g_auto (GVariantBuilder) items = G_VARIANT_BUILDER_INIT (G_PASTE_ITEMS_VARIANT_TYPE);

    for (guint i = 0; i < 5; ++i)
    {
        g_autofree gchar *uuid = g_strdup_printf ("00000000-0000-4000-8000-0000000000%02u", i + 10);
        g_autofree gchar *value = g_strdup_printf ("match %u", i);

        g_variant_builder_add (&items, G_PASTE_ITEM_VARIANT_FORMAT, uuid, value, G_PASTE_ITEM_KIND_TEXT, FALSE, no_notes);
    }
    g_dbus_method_invocation_return_value (g_steal_pointer (&daemon->held_filter),
                                           g_variant_new ("(@" G_PASTE_ITEMS_VARIANT_STRING ")", g_variant_builder_end (&items)));
    g_paste_test_bus_round_trip (g_dbus_proxy_get_connection (G_DBUS_PROXY (client)), daemon->connection);
}

/* A search is listed again on every change of the history, and one answered
 * with the results it already lists keeps their rows: the keyboard stays on
 * the result it was on, rather than GTK moving it to the first one once the
 * row it was on is rebuilt -- where Enter would then paste another item. */
static void
test_search_relist_keeps_focus (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .size = 6, .match = "00000000-0000-4000-8000-0000000000ff" };

    g_assert_no_error (error);

    g_autoptr (GPasteUiWindow) window = activation_window (client, &daemon);
    GtkListView *list_view = GTK_LIST_VIEW (g_paste_test_gtk_find_widget (GTK_WIDGET (window->history), GTK_TYPE_LIST_VIEW));

    daemon.hold_filters = TRUE;
    g_paste_ui_history_search (window->history, "match");
    g_paste_test_bus_wait_for_count (&daemon.filters, 1);
    answer_five_matches (&daemon, client);
    wait_for_layout (GTK_WIDGET (list_view));
    gtk_widget_grab_focus (GTK_WIDGET (list_view));
    g_paste_test_bus_drain ();
    gtk_list_view_scroll_to (list_view, 3, GTK_LIST_SCROLL_FOCUS, NULL);
    g_paste_test_bus_drain ();
    wait_for_layout (GTK_WIDGET (list_view));

    GtkWidget *focus = gtk_root_get_focus (GTK_ROOT (window));

    g_assert_nonnull (focus);

    g_signal_emit_by_name (client, "update", G_PASTE_UPDATE_ACTION_REPLACE, G_PASTE_UPDATE_TARGET_ALL, "", (guint64) 0);
    g_paste_test_bus_wait_for_count (&daemon.filters, 2);
    answer_five_matches (&daemon, client);
    wait_for_layout (GTK_WIDGET (list_view));
    g_paste_test_bus_pump (100);
    g_paste_test_bus_drain ();

    g_assert_true (gtk_root_get_focus (GTK_ROOT (window)) == focus);
    g_assert_nonnull (gtk_widget_get_parent (focus));
    close_activation_window (window, &daemon);
}

/* Entering selection mode and leaving it leave the list where it was scrolled
 * to, the focus on the row it was on, rather than back at the top with every
 * row built anew. */
static void
test_selection_mode_keeps_place (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .size = 100 };

    g_assert_no_error (error);

    g_autoptr (GPasteUiWindow) window = activation_window (client, &daemon);
    GtkListView *list_view = GTK_LIST_VIEW (g_paste_test_gtk_find_widget (GTK_WIDGET (window->history), GTK_TYPE_LIST_VIEW));
    GtkAdjustment *vadjustment = gtk_scrollable_get_vadjustment (GTK_SCROLLABLE (list_view));
    /* The merge bar sliding in and out would leave the list's height to when
     * a check happens to run. */
    GtkSettings *gtk_settings = gtk_widget_get_settings (GTK_WIDGET (window));

    g_object_set (gtk_settings, "gtk-enable-animations", FALSE, NULL);
    g_paste_test_bus_drain ();

    grow_list (window, client, &daemon, 3);

    /* The last row loaded, which is past what the window shows. */
    guint last = g_list_model_get_n_items (G_LIST_MODEL (gtk_list_view_get_model (list_view))) - 1;
    g_autofree gchar *shown = g_strdup_printf ("value %u", last);

    gtk_list_view_scroll_to (list_view, last, GTK_LIST_SCROLL_FOCUS, NULL);
    g_paste_test_bus_round_trip (g_dbus_proxy_get_connection (G_DBUS_PROXY (client)), daemon.connection);
    wait_for_layout (GTK_WIDGET (list_view));

    GtkWidget *focus = gtk_root_get_focus (GTK_ROOT (window));
    GtkInscription *label = GTK_INSCRIPTION (g_paste_test_gtk_find_widget (focus, GTK_TYPE_INSCRIPTION));
    graphene_rect_t bounds;

    /* On screen before selection mode, which is what it has to keep. */
    g_assert_cmpfloat (gtk_adjustment_get_value (vadjustment), >, 0);
    g_assert_cmpstr (gtk_inscription_get_text (label), ==, shown);
    g_assert_true (gtk_widget_compute_bounds (focus, GTK_WIDGET (list_view), &bounds));
    g_assert_cmpfloat (bounds.origin.y, <, gtk_widget_get_height (GTK_WIDGET (list_view)));

    for (guint i = 0; i < 2; ++i)
    {
        if (i)
            exit_selection_mode (window);
        else
            on_enter_selection_mode (NULL, window);
        g_paste_test_bus_round_trip (g_dbus_proxy_get_connection (G_DBUS_PROXY (client)), daemon.connection);
        wait_for_layout (GTK_WIDGET (list_view));

        /* Not back at the top, and the very row that had the focus still has
         * it, on screen -- in part, the merge bar coming up over the bottom of
         * the list. */
        g_assert_cmpfloat (gtk_adjustment_get_value (vadjustment), >, 0);
        g_assert_true (gtk_root_get_focus (GTK_ROOT (window)) == focus);
        g_assert_cmpstr (gtk_inscription_get_text (label), ==, shown);
        g_assert_true (gtk_widget_compute_bounds (focus, GTK_WIDGET (list_view), &bounds));
        g_assert_cmpfloat (bounds.origin.y, <, gtk_widget_get_height (GTK_WIDGET (list_view)));
    }
    gtk_settings_reset_property (gtk_settings, "gtk-enable-animations");
    close_activation_window (window, &daemon);
}

static gboolean
merged (gconstpointer daemon,
        gconstpointer arg G_GNUC_UNUSED)
{
    return ((FakeDaemon *) daemon)->merged != NULL;
}

/* A merge joins what the user picked, in the order picked, each row as it
 * showed when it was picked: the history moved under the picks before the
 * refresh that would drop them came back. */
static void
test_merge_picks_shown (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .size = 10 };

    g_assert_no_error (error);

    g_autoptr (GPasteUiWindow) window = activation_window (client, &daemon);

    g_paste_test_bus_drain ();
    on_enter_selection_mode (NULL, window);
    g_assert_true (g_paste_ui_history_activate_index (window->history, 2));
    g_assert_true (g_paste_ui_history_activate_index (window->history, 1));

    /* A new item above them all, its refresh not back yet. */
    daemon.shift = 1;
    daemon.hold_sizes = TRUE;
    g_signal_emit_by_name (client, "update", G_PASTE_UPDATE_ACTION_REPLACE, G_PASTE_UPDATE_TARGET_ALL, "", (guint64) 0);

    const gchar *expected[] = { "00000000-0000-4000-8000-000000000002", "00000000-0000-4000-8000-000000000001", NULL };

    do_merge (window, gtk_widget_get_next_sibling (window->merge_entry), ",");
    g_paste_test_bus_wait_until (merged, &daemon, NULL);
    g_assert_cmpstrv (daemon.merged, expected);
    g_assert_false (g_paste_ui_history_get_selection_mode (window->history));

    g_paste_daemon3_complete_get_history_size (daemon.skeleton, g_steal_pointer (&daemon.held_size), daemon.size);
    close_activation_window (window, &daemon);
}

/* A row picked before it showed anything is read by its position as the merge
 * goes out, alone, rather than the whole history being read to find it. */
static void
test_merge_picks_unread (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .size = 10, .hold_items = TRUE };

    g_assert_no_error (error);

    g_autoptr (GPasteUiWindow) window = activation_window (client, &daemon);

    g_paste_test_bus_wait_until (has_held_items, &daemon, NULL);
    g_assert_cmpuint (daemon.held_items->len, >, 0);
    g_paste_test_bus_drain ();
    on_enter_selection_mode (NULL, window);
    g_assert_true (g_paste_ui_history_activate_index (window->history, 3));
    g_assert_true (g_paste_ui_history_activate_index (window->history, 0));

    guint held = daemon.held_items->len;
    const gchar *expected[] = { "00000000-0000-4000-8000-000000000003", "00000000-0000-4000-8000-000000000000", NULL };

    /* One read out at a time: the second goes once the first has landed. */
    do_merge (window, gtk_widget_get_next_sibling (window->merge_entry), ",");
    g_paste_test_bus_wait_for_count (&daemon.held_items->len, held + 1);
    g_paste_test_bus_pump (100);
    g_assert_cmpuint (daemon.held_items->len, ==, held + 1);
    release_items (&daemon);
    g_paste_test_bus_wait_until (merged, &daemon, NULL);
    g_assert_cmpstrv (daemon.merged, expected);
    close_activation_window (window, &daemon);
}

/* A merge whose picks are still being read when the window closes goes out
 * once they are, the merge holding the window that merges, and the
 * application until it goes. */
static void
test_merge_after_close (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .size = 10, .hold_items = TRUE };

    g_assert_no_error (error);

    g_autoptr (GPasteUiWindow) window = activation_window (client, &daemon);

    g_paste_test_bus_wait_until (has_held_items, &daemon, NULL);
    g_paste_test_bus_drain ();
    on_enter_selection_mode (NULL, window);
    g_assert_true (g_paste_ui_history_activate_index (window->history, 3));
    g_assert_true (g_paste_ui_history_activate_index (window->history, 0));

    guint held = daemon.held_items->len;
    const gchar *expected[] = { "00000000-0000-4000-8000-000000000003", "00000000-0000-4000-8000-000000000000", NULL };

    do_merge (window, gtk_widget_get_next_sibling (window->merge_entry), ",");
    g_paste_test_bus_wait_for_count (&daemon.held_items->len, held + 1);
    g_paste_settings_reset (window->settings, G_PASTE_CLOSE_ON_SELECT_SETTING);
    gtk_window_destroy (GTK_WINDOW (window));
    g_clear_object (&window);
    g_paste_test_bus_drain ();

    gint holds = app_holds;

    release_items (&daemon);
    g_paste_test_bus_wait_until (merged, &daemon, NULL);
    g_assert_cmpstrv (daemon.merged, expected);
    g_paste_test_bus_round_trip (g_dbus_proxy_get_connection (G_DBUS_PROXY (client)), daemon.connection);
    g_assert_cmpint (app_holds, ==, holds - 1);
    fake_daemon_stop (&daemon);
}

/* A row picked while it is read again where it stands is about to show what
 * its position holds then, and is merged as that, not as the item it showed
 * before the history moved under it. */
static void
test_merge_pick_during_reread (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .size = 10 };

    g_assert_no_error (error);

    g_autoptr (GPasteUiWindow) window = activation_window (client, &daemon);
    GtkWidget *list_view = g_paste_test_gtk_find_widget (GTK_WIDGET (window->history), GTK_TYPE_LIST_VIEW);

    g_paste_test_bus_drain ();
    wait_for_layout (list_view);
    on_enter_selection_mode (NULL, window);

    /* A new item above them all: the rows are read again where they stand,
     * those reads held. */
    daemon.shift = 1;
    daemon.hold_items = TRUE;
    g_signal_emit_by_name (client, "update", G_PASTE_UPDATE_ACTION_REPLACE, G_PASTE_UPDATE_TARGET_ALL, "", (guint64) 0);
    g_paste_test_bus_wait_until (has_held_items, &daemon, NULL);
    g_assert_true (g_paste_ui_history_activate_index (window->history, 2));
    release_items (&daemon);
    g_paste_test_bus_round_trip (g_dbus_proxy_get_connection (G_DBUS_PROXY (client)), daemon.connection);
    g_assert_true (g_paste_ui_history_activate_index (window->history, 5));

    const gchar *expected[] = { "00000000-0000-4000-8000-000000000003", "00000000-0000-4000-8000-000000000006", NULL };

    do_merge (window, gtk_widget_get_next_sibling (window->merge_entry), ",");
    g_paste_test_bus_wait_until (merged, &daemon, NULL);
    g_assert_cmpstrv (daemon.merged, expected);
    close_activation_window (window, &daemon);
}

/* An image row reads its thumbnail only while previews are on, and reads it as
 * they are turned on. */
static void
test_image_preview_off (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    g_autoptr (GPasteSettings) settings = g_paste_settings_new ();
    FakeDaemon daemon = { .size = 3, .images = TRUE };

    g_assert_no_error (error);
    g_paste_settings_set_images_preview (settings, FALSE);

    g_autoptr (GPasteUiWindow) window = activation_window (client, &daemon);

    g_paste_test_bus_drain ();
    g_paste_test_bus_round_trip (g_dbus_proxy_get_connection (G_DBUS_PROXY (client)), daemon.connection);
    g_assert_cmpuint (daemon.image_reads, ==, 0);

    g_paste_settings_set_images_preview (settings, TRUE);
    g_paste_test_bus_wait_for_count (&daemon.image_reads, 3);
    g_paste_settings_reset (settings, G_PASTE_IMAGES_PREVIEW_SETTING);
    close_activation_window (window, &daemon);
}

/* A history filled one item at a time shows every item while they fit the
 * window: the row's height is not read off a viewport the rows do not fill,
 * which would make it the whole page and hold the list at two rows. */
static void
test_short_history_grows (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .size = 1 };

    g_assert_no_error (error);

    g_autoptr (GPasteUiWindow) window = activation_window (client, &daemon);
    GListModel *rows = G_LIST_MODEL (gtk_list_view_get_model (GTK_LIST_VIEW (g_paste_test_gtk_find_widget (GTK_WIDGET (window->history), GTK_TYPE_LIST_VIEW))));

    /* Copied one at a time. */
    for (daemon.size = 2; daemon.size <= 12; ++daemon.size)
    {
        guint sized = daemon.sizings;

        g_paste_test_bus_pump (100);
        g_signal_emit_by_name (client, "update", G_PASTE_UPDATE_ACTION_REPLACE, G_PASTE_UPDATE_TARGET_ALL, "", (guint64) 0);
        g_paste_test_bus_wait_for_count (&daemon.sizings, sized + 1);
        g_paste_test_bus_round_trip (g_dbus_proxy_get_connection (G_DBUS_PROXY (client)), daemon.connection);
        g_paste_test_bus_pump (100);
        g_assert_cmpuint (g_list_model_get_n_items (rows), ==, daemon.size);
    }
    close_activation_window (window, &daemon);
}

static gboolean
switched (gconstpointer daemon,
          gconstpointer arg G_GNUC_UNUSED)
{
    return ((FakeDaemon *) daemon)->switches > 0;
}

/* Moving through the sidebar switches nothing: the selection stays on the
 * history in use, and only activating a row switches to its history. In a
 * collapsed window, activating the history in use shows it, switching nothing. */
static void
test_sidebar_choice (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .size = 3 };

    g_assert_no_error (error);

    g_autoptr (GPasteUiWindow) window = activation_window (client, &daemon);
    AdwSidebar *sidebar = ADW_SIDEBAR (g_paste_test_gtk_find_widget (window->panel, ADW_TYPE_SIDEBAR));

    g_paste_test_bus_wait_until (sidebar_has_history, window, "work");
    g_assert_true (sidebar_has_history (window, "work"));

    guint current = adw_sidebar_get_selected (sidebar);
    guint work = adw_sidebar_item_get_index (sidebar_item (window, "work"));

    /* What the arrow keys do. */
    adw_sidebar_set_selected (sidebar, work);
    g_paste_test_bus_round_trip (g_dbus_proxy_get_connection (G_DBUS_PROXY (client)), daemon.connection);
    g_assert_cmpuint (daemon.switches, ==, 0);
    g_assert_cmpuint (adw_sidebar_get_selected (sidebar), ==, current);

    adw_navigation_split_view_set_collapsed (window->split_view, TRUE);
    adw_navigation_split_view_set_show_content (window->split_view, FALSE);
    g_signal_emit_by_name (sidebar, "activated", current);
    g_assert_true (adw_navigation_split_view_get_show_content (window->split_view));
    g_paste_test_bus_round_trip (g_dbus_proxy_get_connection (G_DBUS_PROXY (client)), daemon.connection);
    g_assert_cmpuint (daemon.switches, ==, 0);

    g_signal_emit_by_name (sidebar, "activated", work);
    g_paste_test_bus_wait_until (switched, &daemon, NULL);
    g_assert_cmpuint (daemon.switches, ==, 1);
    close_activation_window (window, &daemon);
}

/* The application's actions bring the window to the front, and do nothing once
 * it is gone rather than reach for it. */
static void
test_app_actions (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .size = 1 };

    g_assert_no_error (error);
    g_assert_null (gtk_application_get_windows (app));
    about_activated (NULL, NULL, app);
    prefs_activated (NULL, NULL, app);
    search_activated (NULL, g_variant_new_string ("value"), app);

    g_autoptr (GPasteUiWindow) window = activation_window (client, &daemon);

    gtk_widget_set_visible (GTK_WIDGET (window), FALSE);
    search_activated (NULL, g_variant_new_string ("value"), app);
    g_assert_true (gtk_widget_get_visible (GTK_WIDGET (window)));
    gtk_widget_set_visible (GTK_WIDGET (window), FALSE);
    about_activated (NULL, NULL, app);
    g_assert_true (gtk_widget_get_visible (GTK_WIDGET (window)));
    adw_dialog_force_close (adw_application_window_get_visible_dialog (ADW_APPLICATION_WINDOW (window)));
    gtk_widget_set_visible (GTK_WIDGET (window), FALSE);
    prefs_activated (NULL, NULL, app);
    g_assert_true (gtk_widget_get_visible (GTK_WIDGET (window)));
    close_activation_window (window, &daemon);
}

/* A search asked for from outside a collapsed window shows the page it is on,
 * and About asked for twice raises the one up rather than stack another. */
static void
test_outside_asks (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .size = 1 };

    g_assert_no_error (error);

    g_autoptr (GPasteUiWindow) window = activation_window (client, &daemon);

    adw_navigation_split_view_set_collapsed (window->split_view, TRUE);
    adw_navigation_split_view_set_show_content (window->split_view, FALSE);
    g_paste_ui_window_search (window, "value");
    g_paste_test_bus_drain ();
    g_assert_true (adw_navigation_split_view_get_show_content (window->split_view));
    adw_navigation_split_view_set_collapsed (window->split_view, FALSE);

    g_paste_ui_window_show_about (window);
    g_paste_test_bus_drain ();

    AdwDialog *about = adw_application_window_get_visible_dialog (ADW_APPLICATION_WINDOW (window));

    g_assert_true (ADW_IS_ABOUT_DIALOG (about));
    g_paste_ui_window_show_about (window);
    g_paste_test_bus_drain ();
    g_assert_true (adw_application_window_get_visible_dialog (ADW_APPLICATION_WINDOW (window)) == about);
    adw_dialog_force_close (about);
    g_paste_test_bus_drain ();
    close_activation_window (window, &daemon);
}

/* Restarting the daemon, or stopping the tracking, confirmed once the daemon
 * left with the question up sends nothing: the call would be what the bus
 * starts one on. */
static void
test_confirmed_without_daemon (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .size = 1 };

    g_assert_no_error (error);

    g_autoptr (GPasteUiWindow) window = activation_window (client, &daemon);

    fake_daemon_stop (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_ABSENT);

    GDBusConnection *connection = g_dbus_proxy_get_connection (G_DBUS_PROXY (client));
    Outgoing outgoing = { 0 };
    guint filter = g_dbus_connection_add_filter (connection, count_outgoing, &outgoing, NULL);

    on_reexec_confirmed (TRUE, g_paste_weak_ref_new (window));
    on_track_confirmed (TRUE, g_paste_weak_ref_new (window));
    g_paste_test_bus_pump (300);
    g_dbus_connection_remove_filter (connection, filter);
    g_assert_cmpint (g_atomic_int_get (&outgoing.others), ==, 0);
    g_paste_settings_reset (window->settings, G_PASTE_CLOSE_ON_SELECT_SETTING);
    gtk_window_destroy (GTK_WINDOW (window));
    g_paste_test_bus_drain ();
}

/* A window closed with Restart Daemon's or Stop Tracking's question up goes,
 * and the question with it, answered as refused: nothing is sent. */
static void
test_closed_with_question_up (gconstpointer data)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    const gchar *action = data;
    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .size = 1 };

    g_assert_no_error (error);

    GPasteUiWindow *window = activation_window (client, &daemon);

    g_simple_action_set_state (G_SIMPLE_ACTION (g_action_map_lookup_action (G_ACTION_MAP (window), "track-changes")),
                               g_variant_new_boolean (TRUE));
    g_action_group_activate_action (G_ACTION_GROUP (window), action, NULL);
    g_paste_test_bus_drain ();

    AdwDialog *dialog = adw_application_window_get_visible_dialog (ADW_APPLICATION_WINDOW (window));

    g_assert_true (ADW_IS_ALERT_DIALOG (dialog));
    g_object_add_weak_pointer (G_OBJECT (window), (gpointer *) &window);
    g_object_add_weak_pointer (G_OBJECT (dialog), (gpointer *) &dialog);

    GDBusConnection *connection = g_dbus_proxy_get_connection (G_DBUS_PROXY (client));
    Outgoing outgoing = { 0 };
    guint filter = g_dbus_connection_add_filter (connection, count_outgoing, &outgoing, NULL);

    g_paste_settings_reset (window->settings, G_PASTE_CLOSE_ON_SELECT_SETTING);
    gtk_window_destroy (GTK_WINDOW (window));
    g_object_unref (window);
    g_paste_test_bus_drain ();
    g_paste_test_bus_pump (100);
    g_dbus_connection_remove_filter (connection, filter);
    g_assert_null (window);
    g_assert_null (dialog);
    g_assert_cmpint (g_atomic_int_get (&outgoing.others), ==, 0);
    fake_daemon_stop (&daemon);
}

static gboolean
connection_done (gconstpointer window,
                 gconstpointer arg G_GNUC_UNUSED)
{
    GPasteUiWindow *self = (GPasteUiWindow *) window;

    /* Either our reference is the last, the connection's let go, or the window
     * was set up all the same. */
    return G_OBJECT (self)->ref_count == 1 || self->client;
}

/* A window closed while it is still connecting is not set up, nor presented,
 * once the connection is: gtk_window_destroy () disposed nothing while the
 * connection held it. */
static void
test_closed_while_connecting (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GPasteUiWindow) window = g_object_ref (G_PASTE_UI_WINDOW (g_paste_ui_window_new (app)));

    gtk_window_destroy (GTK_WINDOW (window));
    g_paste_test_bus_wait_until (connection_done, window, NULL);
    g_assert_cmpuint (G_OBJECT (window)->ref_count, ==, 1);
    g_assert_null (window->client);
    g_assert_false (gtk_widget_get_visible (GTK_WIDGET (window)));
}

static gboolean
connection_answered (gconstpointer window,
                     gconstpointer arg G_GNUC_UNUSED)
{
    return !((GPasteUiWindow *) window)->connecting;
}

/* A window whose client could not be built has a header bar to close it by,
 * every other one belonging to a page setup builds, until a retry gets as far
 * as setup, whose pages bring their own. */
static void
test_client_fails (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    fail_client_builds = TRUE;
    g_test_expect_message ("GPaste", G_LOG_LEVEL_WARNING, "Couldn't connect to GPaste: no bus");

    g_autoptr (GPasteUiWindow) window = g_object_ref (G_PASTE_UI_WINDOW (g_paste_ui_window_new (app)));

    g_paste_test_bus_wait_until (connection_answered, window, NULL);
    g_assert_true (connection_answered (window, NULL));
    g_test_assert_expected_messages ();
    fail_client_builds = FALSE;
    g_assert_true (gtk_widget_get_visible (GTK_WIDGET (window)));

    GtkWidget *header = g_paste_test_gtk_find_widget (GTK_WIDGET (window), ADW_TYPE_HEADER_BAR);

    g_assert_nonnull (header);
    g_assert_true (adw_header_bar_get_show_end_title_buttons (ADW_HEADER_BAR (header)));

    FakeDaemon daemon = { .size = 1 };

    fake_daemon_start (&daemon);
    g_signal_emit_by_name (window->banner, "button-clicked");
    g_paste_test_bus_wait_until (connection_answered, window, NULL);
    g_assert_nonnull (window->client);
    g_assert_null (window->daemonless_header);
    g_assert_true (gtk_widget_get_first_child (GTK_WIDGET (window->content_box)) == GTK_WIDGET (window->banner));

    gtk_window_destroy (GTK_WINDOW (window));
    g_paste_test_bus_drain ();
    fake_daemon_stop (&daemon);
}

/* A daemon that could not list its histories is warned about -- a failure of
 * the session's, not a bug of the program's -- and leaves the rows usable. */
static void
test_listing_fails (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    g_autoptr (GPasteUiWindow) window = test_window ();
    FakeDaemon daemon = { .size = 1, .listing_fails = TRUE };

    g_assert_no_error (error);
    fake_daemon_start (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    g_test_expect_message ("GPaste", G_LOG_LEVEL_WARNING, "Error while listing available histories: *unreadable");
    g_paste_ui_window_setup (window, client);
    g_paste_test_bus_wait_for_count (&daemon.listings, 1);
    g_paste_test_bus_round_trip (g_dbus_proxy_get_connection (G_DBUS_PROXY (client)), daemon.connection);
    g_test_assert_expected_messages ();
    g_assert_true (adw_sidebar_item_get_enabled (sidebar_item (window, G_PASTE_DEFAULT_HISTORY)));

    gtk_window_destroy (GTK_WINDOW (window));
    g_paste_test_bus_drain ();
    fake_daemon_stop (&daemon);
}

static gboolean
on_sigusr1 (gpointer user_data)
{
    ++*(guint *) user_data;

    return G_SOURCE_CONTINUE;
}

static gboolean
banner_says (gconstpointer window,
             gconstpointer title)
{
    return g_paste_str_equal (adw_banner_get_title (((GPasteUiWindow *) window)->banner), title);
}

/* A GPaste 45 or 50 stood in for, on a connection of its own: the object the
 * window's probe looks for (g_paste_util_daemon_is_legacy ()), registered
 * before the name is asked for, so that the probe finds it whenever the name
 * comes, queued behind another daemon or not. */
typedef struct
{
    GDBusConnection *connection;
    guint            registration;
    guint            owner;
} LegacyDaemon;

static void
legacy_daemon_start (LegacyDaemon *legacy)
{
    g_autoptr (GDBusNodeInfo) node = g_dbus_node_info_new_for_xml ("<node><interface name='org.gnome.GPaste2'/></node>", NULL);
    static const GDBusInterfaceVTable vtable = { 0 };
    g_autoptr (GError) error = NULL;

    legacy->connection = g_paste_test_bus_connect (g_getenv ("DBUS_SESSION_BUS_ADDRESS"));
    legacy->registration = g_dbus_connection_register_object (legacy->connection, G_PASTE_DAEMON_OBJECT_PATH, node->interfaces[0],
                                                              &vtable, NULL, NULL, &error);
    g_assert_no_error (error);
    legacy->owner = g_bus_own_name_on_connection (legacy->connection, G_PASTE_BUS_NAME, G_BUS_NAME_OWNER_FLAGS_NONE,
                                                  NULL, NULL, NULL, NULL);
}

/* Gone as fake_daemon_stop () has a FakeDaemon go. */
static void
legacy_daemon_stop (LegacyDaemon *legacy)
{
    g_dbus_connection_flush_sync (legacy->connection, NULL, NULL);
    g_dbus_connection_close_sync (legacy->connection, NULL, NULL);
    g_dbus_connection_unregister_object (legacy->connection, legacy->registration);
    g_clear_handle_id (&legacy->owner, g_bus_unown_name);
    g_clear_object (&legacy->connection);
}

/* @window set up while a GPaste 45 or 50 owns the name: the banner offers to
 * restart it. */
static void
legacy_window_setup (GPasteUiWindow *window,
                     GPasteClient   *client)
{
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_STARTING);
    g_paste_ui_window_setup (window, client);
    g_paste_test_bus_wait_until (banner_says, window, _("An older GPaste daemon is still running"));
    g_assert_cmpstr (adw_banner_get_title (window->banner), ==, _("An older GPaste daemon is still running"));
    g_assert_cmpstr (adw_banner_get_button_label (window->banner), ==, _("Restart"));
}

/* A GPaste 45 or 50 owning the name, as a package update leaves it until the
 * session ends: the banner says so and offers to restart it, which signals it
 * once however often it is pressed, the pid file naming this very process as
 * its owner here. What comes back is this version's daemon. */
static void
test_legacy_daemon (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    g_autoptr (GPasteUiWindow) window = test_window ();
    LegacyDaemon legacy = { 0 };
    FakeDaemon daemon = { .size = 1 };
    guint signals = 0;
    guint source = g_unix_signal_add (SIGUSR1, on_sigusr1, &signals);

    g_source_set_name_by_id (source, "[GPaste] test SIGUSR1 counter");
    g_assert_no_error (error);
    legacy_daemon_start (&legacy);
    legacy_window_setup (window, client);

    g_paste_util_write_pid_file ("Daemon");
    /* Pressed twice, as an impatient user would: restarted once. */
    g_signal_emit_by_name (window->banner, "button-clicked");
    g_signal_emit_by_name (window->banner, "button-clicked");
    g_paste_test_bus_wait_for_count (&signals, 1);
    g_paste_test_bus_pump (100);
    g_assert_cmpuint (signals, ==, 1);
    g_assert_cmpint (g_atomic_int_get (&legacy_restarts), ==, 1);
    g_paste_test_bus_wait_until (banner_says, window, _("Connecting to GPaste…"));
    g_assert_cmpstr (adw_banner_get_title (window->banner), ==, _("Connecting to GPaste…"));

    /* The daemon re-executed, as this version's. */
    legacy_daemon_stop (&legacy);
    fake_daemon_start (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    g_paste_test_bus_drain ();
    g_assert_false (adw_banner_get_revealed (window->banner));

    g_source_remove (source);
    gtk_window_destroy (GTK_WINDOW (window));
    g_paste_test_bus_drain ();
    fake_daemon_stop (&daemon);
}

/* An older daemon replaced by this version's other than through the banner --
 * the command line's daemon-reexec, a service restart -- hands the name over
 * with the presence starting on both sides: the banner stops saying an older
 * daemon runs, with a Restart that could only fail, once the name has changed
 * hands and its new owner been asked. */
static void
test_legacy_replaced (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    g_autoptr (GPasteUiWindow) window = test_window ();
    LegacyDaemon legacy = { 0 };
    g_autoptr (GDBusConnection) current = g_paste_test_bus_connect (g_getenv ("DBUS_SESSION_BUS_ADDRESS"));

    g_assert_no_error (error);
    legacy_daemon_start (&legacy);
    legacy_window_setup (window, client);

    /* Queued behind the older one, the new daemon gets the name the moment it
     * is let go of, and serves nothing yet. */
    guint replacement = g_bus_own_name_on_connection (current, G_PASTE_BUS_NAME, G_BUS_NAME_OWNER_FLAGS_NONE, NULL, NULL, NULL, NULL);

    g_paste_test_bus_round_trip (current, legacy.connection);
    legacy_daemon_stop (&legacy);
    g_paste_test_bus_wait_until (banner_says, window, _("Connecting to GPaste…"));
    g_assert_cmpint (g_paste_client_get_daemon_presence (client), ==, G_PASTE_DAEMON_PRESENCE_STARTING);
    g_assert_cmpstr (adw_banner_get_title (window->banner), ==, _("Connecting to GPaste…"));

    g_bus_unown_name (replacement);
    gtk_window_destroy (GTK_WINDOW (window));
    g_paste_test_bus_drain ();
    g_dbus_connection_close_sync (current, NULL, NULL);
}

static void
record_title (AdwBanner  *banner,
              GParamSpec *pspec G_GNUC_UNUSED,
              gpointer    user_data)
{
    g_ptr_array_add (user_data, g_strdup (adw_banner_get_title (banner)));
}

static gboolean
legacy_answered (gconstpointer window,
                 gconstpointer arg G_GNUC_UNUSED)
{
    return !((GPasteUiWindow *) window)->legacy_probe;
}

/* A GPaste 45 or 50 owning the name is still said to run while the window asks
 * again whether one does: the presence moving, or the name passing to another
 * such daemon, has the banner go on offering a restart rather than a retry,
 * which cannot help there, until the answer is in. */
static void
test_legacy_kept (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    g_autoptr (GPasteUiWindow) window = test_window ();
    LegacyDaemon legacy = { 0 };
    LegacyDaemon successor = { 0 };
    g_autoptr (GPtrArray) titles = g_ptr_array_new_with_free_func (g_free);

    g_assert_no_error (error);
    legacy_daemon_start (&legacy);
    legacy_window_setup (window, client);

    /* As the window hears of a presence moving: asked again, the verdict still
     * stands as the question goes out, and once it is answered. */
    on_daemon_presence_changed (client, NULL, window);
    g_assert_nonnull (window->legacy_probe);
    g_assert_cmpstr (adw_banner_get_title (window->banner), ==, _("An older GPaste daemon is still running"));
    g_assert_cmpstr (adw_banner_get_button_label (window->banner), ==, _("Restart"));
    g_paste_test_bus_wait_until (legacy_answered, window, NULL);
    g_assert_true (legacy_answered (window, NULL));
    g_assert_true (banner_says (window, _("An older GPaste daemon is still running")));

    /* Another such daemon queued behind it gets the name as it is let go of. */
    legacy_daemon_start (&successor);
    g_paste_test_bus_round_trip (successor.connection, legacy.connection);
    g_signal_connect (window->banner, "notify::title", G_CALLBACK (record_title), titles);
    legacy_daemon_stop (&legacy);
    g_paste_test_bus_wait_for_owner (G_DBUS_PROXY (client), successor.connection);
    g_paste_test_bus_wait_until (legacy_answered, window, NULL);
    g_assert_true (legacy_answered (window, NULL));
    g_signal_handlers_disconnect_by_func (window->banner, record_title, titles);
    for (guint i = 0; i < titles->len; ++i)
        g_assert_cmpstr (g_ptr_array_index (titles, i), ==, _("An older GPaste daemon is still running"));
    g_assert_true (banner_says (window, _("An older GPaste daemon is still running")));
    g_assert_cmpstr (adw_banner_get_button_label (window->banner), ==, _("Restart"));

    legacy_daemon_stop (&successor);
    gtk_window_destroy (GTK_WINDOW (window));
    g_paste_test_bus_drain ();
}

static gboolean
legacy_restart_settled (gconstpointer window,
                        gconstpointer arg G_GNUC_UNUSED)
{
    return !((GPasteUiWindow *) window)->legacy_restarting && legacy_answered (window, NULL);
}

/* Restart pressed as the name passes on, the window's question about the new
 * owner just gone out -- pressed from a handler of the name changing hands,
 * connected after the window's -- with the banner still offering it. */
static void
press_restart (GPasteClient *client G_GNUC_UNUSED,
               GParamSpec   *pspec  G_GNUC_UNUSED,
               gpointer      user_data)
{
    GPasteUiWindow *window = user_data;

    g_assert_true (window->legacy);
    g_assert_nonnull (window->legacy_probe);
    g_signal_emit_by_name (window->banner, "button-clicked");
}

/* A Restart pressed while the window asks whether the daemon that just took
 * the name is a GPaste 45 or 50 waits for the answer: carried out for one,
 * signalling it, and dropped for this version's, which a restart could only
 * fail on, warning and toasting that it had. @user_data says which the
 * successor is. */
static void
test_legacy_restart_asked (gconstpointer user_data)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    gboolean legacy_successor = GPOINTER_TO_INT (user_data);
    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    g_autoptr (GPasteUiWindow) window = test_window ();
    LegacyDaemon legacy = { 0 };
    LegacyDaemon successor = { 0 };
    g_autoptr (GDBusConnection) current = NULL;
    guint current_owner = 0;
    guint signals = 0;
    guint source = g_unix_signal_add (SIGUSR1, on_sigusr1, &signals);

    g_source_set_name_by_id (source, "[GPaste] test SIGUSR1 counter");
    g_assert_no_error (error);
    legacy_daemon_start (&legacy);
    legacy_window_setup (window, client);

    /* Queued behind the older one, the successor gets the name as it is let
     * go of: another such daemon, or this version's, serving nothing yet. */
    if (legacy_successor)
        legacy_daemon_start (&successor);
    else
    {
        current = g_paste_test_bus_connect (g_getenv ("DBUS_SESSION_BUS_ADDRESS"));
        current_owner = g_bus_own_name_on_connection (current, G_PASTE_BUS_NAME, G_BUS_NAME_OWNER_FLAGS_NONE, NULL, NULL, NULL, NULL);
    }

    GDBusConnection *queued = (legacy_successor) ? successor.connection : current;

    g_paste_test_bus_round_trip (queued, legacy.connection);
    g_paste_util_write_pid_file ("Daemon");
    g_atomic_int_set (&legacy_restarts, 0);

    gulong pressed = g_signal_connect (client, "notify::g-name-owner", G_CALLBACK (press_restart), window);

    legacy_daemon_stop (&legacy);
    g_paste_test_bus_wait_for_owner (G_DBUS_PROXY (client), queued);
    g_signal_handler_disconnect (client, pressed);
    g_paste_test_bus_wait_until (legacy_restart_settled, window, NULL);
    g_assert_true (legacy_restart_settled (window, NULL));

    if (legacy_successor)
    {
        g_paste_test_bus_wait_for_count (&signals, 1);
        g_assert_cmpuint (signals, ==, 1);
        g_assert_cmpint (g_atomic_int_get (&legacy_restarts), ==, 1);
    }
    else
    {
        g_assert_cmpint (g_atomic_int_get (&legacy_restarts), ==, 0);
        g_assert_cmpuint (signals, ==, 0);
    }
    g_assert_true (banner_says (window, _("Connecting to GPaste…")));

    if (legacy_successor)
        legacy_daemon_stop (&successor);
    else
        g_bus_unown_name (current_owner);
    g_source_remove (source);
    gtk_window_destroy (GTK_WINDOW (window));
    g_paste_test_bus_drain ();
    if (current)
        g_dbus_connection_close_sync (current, NULL, NULL);
}

/* What is typed in the search is searched for as text: Search takes a regular
 * expression, which would not compile it, or would match what was not typed. */
static void
test_search_escaped (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .size = 1 };

    g_assert_no_error (error);

    g_autoptr (GPasteUiWindow) window = activation_window (client, &daemon);

    g_paste_ui_history_search (window->history, "c++ (gcc");
    g_paste_test_bus_wait_for_count (&daemon.filters, 1);
    g_assert_cmpstr (daemon.query, ==, "c\\+\\+ \\(gcc");
    close_activation_window (window, &daemon);
}

/* A listing asked for under one history and answered after a switch to
 * another: the sidebar keeps the row of the history current now selected. */
static void
test_listing_after_switch (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteUiWindow) window = test_window ();
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .listing = LISTING_TWO };

    g_assert_no_error (error);
    fake_daemon_start (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    g_paste_ui_window_setup (window, client);
    g_paste_test_bus_wait_for_count (&daemon.listings, 1);
    g_paste_test_bus_round_trip (g_dbus_proxy_get_connection (G_DBUS_PROXY (client)), daemon.connection);

    daemon.hold_listings = TRUE;
    daemon.listings = 0;
    g_paste_daemon3_emit_raw_histories_changed (daemon.skeleton);
    g_paste_test_bus_wait_for_count (&daemon.listings, 1);

    g_paste_daemon3_set_history (daemon.skeleton, "work");
    g_paste_test_bus_wait_until (history_is_work, client, NULL);
    g_assert_true (history_is_work (client, NULL));
    g_paste_test_bus_drain ();

    g_paste_daemon3_complete_list_histories (daemon.skeleton, g_steal_pointer (&daemon.held_listing), g_variant_new_parsed (LISTING_TWO));
    g_paste_test_bus_round_trip (g_dbus_proxy_get_connection (G_DBUS_PROXY (client)), daemon.connection);

    AdwSidebarItem *selected = adw_sidebar_get_selected_item (ADW_SIDEBAR (g_paste_test_gtk_find_widget (window->panel, ADW_TYPE_SIDEBAR)));

    g_assert_nonnull (selected);
    g_assert_cmpstr (adw_sidebar_item_get_title (selected), ==, "work");

    gtk_window_destroy (GTK_WINDOW (window));
    g_paste_test_bus_drain ();
    fake_daemon_stop (&daemon);
}

/* A delayed older listing cannot undo the rows installed by a later one. */
static void
test_listing_overtaken (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteUiWindow) window = test_window ();
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .listing = LISTING_TWO };

    g_assert_no_error (error);
    fake_daemon_start (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    g_paste_ui_window_setup (window, client);
    g_paste_test_bus_wait_for_count (&daemon.listings, 1);
    g_paste_test_bus_wait_until (sidebar_has_history, window, "work");
    g_assert_true (sidebar_has_history (window, "work"));

    daemon.hold_listings = TRUE;
    daemon.listings = 0;
    g_paste_daemon3_emit_raw_histories_changed (daemon.skeleton);
    g_paste_test_bus_wait_for_count (&daemon.listings, 1);

    daemon.hold_listings = FALSE;
    g_paste_daemon3_emit_raw_histories_changed (daemon.skeleton);
    g_paste_test_bus_wait_for_count (&daemon.listings, 2);
    g_paste_test_bus_round_trip (g_dbus_proxy_get_connection (G_DBUS_PROXY (client)), daemon.connection);
    g_assert_true (sidebar_lists (window, "work"));

    g_paste_daemon3_complete_list_histories (daemon.skeleton, g_steal_pointer (&daemon.held_listing), g_variant_new_parsed (LISTING_ONE));
    g_paste_test_bus_round_trip (g_dbus_proxy_get_connection (G_DBUS_PROXY (client)), daemon.connection);
    g_assert_true (sidebar_lists (window, "work"));

    gtk_window_destroy (GTK_WINDOW (window));
    g_paste_test_bus_drain ();
    fake_daemon_stop (&daemon);
}

/* A listing still out when its daemon goes ends without a word: given up on by
 * the presence edge, or, were it still standing, answered by the bus with an
 * error of a daemon gone, which on_histories_ready () drops -- either way no
 * warning, which would be fatal in a test. Which of the two ends it is
 * listing-handoff's to pin, the cancellation being what keeps a late listing
 * off the next daemon's rows; this one pins the silence. Nothing announces a
 * report not coming, hence the pump. */
static void
test_listing_abandoned (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteUiWindow) window = test_window ();
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .listing = LISTING_TWO };

    g_assert_no_error (error);
    fake_daemon_start (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    g_paste_ui_window_setup (window, client);
    g_paste_test_bus_wait_for_count (&daemon.listings, 1);
    g_paste_test_bus_drain ();

    daemon.hold_listings = TRUE;
    daemon.listings = 0;
    g_paste_daemon3_emit_raw_histories_changed (daemon.skeleton);
    g_paste_test_bus_wait_for_count (&daemon.listings, 1);

    /* Dropped unanswered, the connection going with it. */
    g_clear_object (&daemon.held_listing);
    fake_daemon_stop (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_ABSENT);
    g_paste_test_bus_pump (300);

    gtk_window_destroy (GTK_WINDOW (window));
    g_paste_test_bus_drain ();
}

/* A window closed while the sidebar's listing is out takes the sidebar with
 * it: the listing holds it weakly, so nothing keeps the panel past the window,
 * and its dispose () gives the listing up (g_paste_ui_panel_refresh ()). The
 * answer the stand-in sends after goes to a call already given up on. */
static void
test_listing_after_close (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteUiWindow) window = test_window ();
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .listing = LISTING_TWO, .hold_listings = TRUE };
    GtkWidget *panel = NULL;

    g_assert_no_error (error);
    fake_daemon_start (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    g_paste_ui_window_setup (window, client);
    g_paste_test_bus_wait_for_count (&daemon.listings, 1);
    g_set_weak_pointer (&panel, window->panel);

    gtk_window_destroy (GTK_WINDOW (window));
    g_clear_object (&window);
    g_paste_test_bus_drain ();
    g_assert_null (panel);

    g_paste_daemon3_complete_list_histories (daemon.skeleton, g_steal_pointer (&daemon.held_listing), g_variant_new_parsed (LISTING_TWO));
    g_paste_test_bus_round_trip (g_dbus_proxy_get_connection (G_DBUS_PROXY (client)), daemon.connection);
    fake_daemon_stop (&daemon);
}

/* A daemon coming back with fewer histories than it left with: the sidebar
 * drops the ones it no longer lists. */
static void
test_listing_pruned (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteUiWindow) window = test_window ();
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .listing = LISTING_TWO };

    /* Built before the daemon is there, as in test_retried_client (). */
    g_assert_no_error (error);
    fake_daemon_start (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    g_paste_ui_window_setup (window, client);
    g_paste_test_bus_wait_for_count (&daemon.listings, 1);
    g_paste_test_bus_wait_until (sidebar_has_history, window, "work");
    g_assert_true (sidebar_has_history (window, "work"));

    fake_daemon_stop (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_STARTING);
    daemon.listing = LISTING_ONE;
    daemon.listings = 0;
    fake_daemon_start (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    g_paste_test_bus_wait_until (sidebar_dropped, window, "work");
    g_assert_false (sidebar_lists (window, "work"));
    g_assert_true (sidebar_lists (window, G_PASTE_DEFAULT_HISTORY));

    gtk_window_destroy (GTK_WINDOW (window));
    g_paste_test_bus_drain ();
    fake_daemon_stop (&daemon);
}

/* GDBus answers the proxy's GetAll with the method call itself when the vtable
 * has no get_property (), which is what lets this successor sit on it: until
 * it answers, the proxy goes on addressing the daemon standing down. */
static void
on_held_get_all (GDBusConnection       *connection     G_GNUC_UNUSED,
                 const gchar           *sender         G_GNUC_UNUSED,
                 const gchar           *object_path    G_GNUC_UNUSED,
                 const gchar           *interface_name G_GNUC_UNUSED,
                 const gchar           *method_name    G_GNUC_UNUSED,
                 GVariant              *parameters     G_GNUC_UNUSED,
                 GDBusMethodInvocation *invocation,
                 gpointer               user_data)
{
    *(GDBusMethodInvocation **) user_data = invocation;
}

static gboolean
sidebar_enabled (GPasteUiWindow *window,
                 const gchar    *history)
{
    return adw_sidebar_item_get_enabled (sidebar_item (window, history));
}

static gboolean
sidebar_row_enabled (gconstpointer window,
                     gconstpointer history)
{
    return sidebar_enabled ((GPasteUiWindow *) window, history);
}

/* A daemon taking the name over straight from another is a presence edge like
 * any other (/client/presence/handoff), and the window treats it as one.
 *
 * While the proxy still addresses the daemon standing down, nothing is asked
 * of it, and the listing it had out says nothing once answered, the edge
 * having given it up. The sidebar's rows stay, but none the new
 * daemon has not named can be clicked, a click on one it lacks creating that
 * history there; the listing naming it gives it back, the same row in the
 * same place, and the new daemon is listed and sized once. */
static void
test_listing_handoff (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteUiWindow) window = test_window ();
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon old = { .listing = LISTING_TWO, .size = 2, .allow_replacement = TRUE };
    FakeDaemon successor = { .listing = LISTING_THREE, .size = 1, .replace = TRUE, .hold_sizes = TRUE, .hold_listings = TRUE };
    GDBusConnection *bus = NULL;

    g_assert_no_error (error);
    bus = g_dbus_proxy_get_connection (G_DBUS_PROXY (client));
    fake_daemon_start (&old);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    g_paste_test_bus_wait_for_owner (G_DBUS_PROXY (client), old.connection);
    g_paste_ui_window_setup (window, client);
    g_paste_test_bus_wait_for_count (&old.listings, 1);
    g_paste_test_bus_wait_until (sidebar_has_history, window, "work");
    g_assert_true (sidebar_has_history (window, "work"));
    g_paste_test_bus_wait_until (history_rows_are, window, GUINT_TO_POINTER (2));
    g_assert_true (history_rows_are (window, GUINT_TO_POINTER (2)));

    /* Held, so that a row dropped and added again could not come back at the
     * same address and pass for the one kept. */
    g_autoptr (AdwSidebarItem) work = g_object_ref (sidebar_item (window, "work"));

    old.hold_listings = TRUE;
    old.listings = 0;
    g_signal_emit_by_name (client, "histories-changed");
    g_paste_test_bus_wait_for_count (&old.listings, 1);
    g_assert_nonnull (old.held_listing);

    /* A successor owning the name and sitting on the proxy's GetAll. */
    static const GDBusInterfaceVTable vtable = { on_held_get_all, NULL, NULL, { 0 } };
    GDBusMethodInvocation *get_all = NULL;
    g_autoptr (GDBusConnection) holder = g_paste_test_bus_connect (g_getenv ("DBUS_SESSION_BUS_ADDRESS"));
    guint registration = g_dbus_connection_register_object (holder, G_PASTE_DAEMON_OBJECT_PATH,
                                                            g_paste_daemon3_interface_info (),
                                                            &vtable, &get_all, NULL, &error);

    g_assert_no_error (error);

    guint holder_owner = g_bus_own_name_on_connection (holder, G_PASTE_BUS_NAME,
                                                       G_BUS_NAME_OWNER_FLAGS_REPLACE | G_BUS_NAME_OWNER_FLAGS_ALLOW_REPLACEMENT | G_BUS_NAME_OWNER_FLAGS_DO_NOT_QUEUE,
                                                       NULL, NULL, NULL, NULL);

    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_STARTING);
    g_paste_test_bus_wait_until (g_paste_test_bus_is_set, &get_all, NULL);
    g_assert_false (sidebar_enabled (window, "work"));
    g_assert_true (adw_sidebar_item_get_enabled (sidebar_item (window, G_PASTE_DEFAULT_HISTORY)));

    /* The old listing answering now, as a daemon that kept nothing: given
     * up on, it prunes nothing. */
    g_paste_daemon3_complete_list_histories (old.skeleton, g_steal_pointer (&old.held_listing), g_variant_new_parsed (LISTING_ONE));
    g_paste_test_bus_round_trip (bus, old.connection);
    g_assert_true (sidebar_item (window, "work") == work);

    /* What the old daemon says meanwhile reaches nobody
     * (g_paste_client_g_signal ()); nor would anything ask it if it did, which
     * the client announcing the changes itself shows. */
    old.listings = 0;
    old.sizings = 0;
    g_paste_daemon3_emit_raw_histories_changed (old.skeleton);
    g_paste_daemon3_emit_raw_update (old.skeleton, G_PASTE_UPDATE_ACTION_REPLACE, G_PASTE_UPDATE_TARGET_ALL, "", 0);
    g_signal_emit_by_name (client, "histories-changed");
    g_signal_emit_by_name (client, "update", G_PASTE_UPDATE_ACTION_REPLACE, G_PASTE_UPDATE_TARGET_ALL, "", (guint64) 0);
    g_paste_test_bus_round_trip (bus, old.connection);
    g_assert_cmpuint (old.listings, ==, 0);
    g_assert_cmpuint (old.sizings, ==, 0);

    /* A context menu left up on the row that was just disabled acts on
     * nothing (g_paste_ui_panel_get_menu_history ()): a backup would open
     * its dialog. */
    AdwSidebar *sidebar = ADW_SIDEBAR (g_paste_test_gtk_find_widget (window->panel, ADW_TYPE_SIDEBAR));

    g_signal_emit_by_name (sidebar, "setup-menu", sidebar_item (window, "work"));
    g_assert_true (gtk_widget_activate_action (window->panel, "panel.backup-history", NULL));
    g_paste_test_bus_drain ();
    g_assert_null (adw_application_window_get_visible_dialog (ADW_APPLICATION_WINDOW (window)));

    /* A serving successor takes the name over from the one that held. */
    g_dbus_method_invocation_return_value (g_steal_pointer (&get_all), g_variant_new_parsed ("(@a{sv} {},)"));
    fake_daemon_start (&successor);
    g_paste_test_bus_wait_for_owner (G_DBUS_PROXY (client), successor.connection);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    g_paste_test_bus_wait_for_count (&successor.listings, 1);
    g_paste_test_bus_wait_for_count (&successor.sizings, 1);
    g_assert_false (sidebar_enabled (window, "work"));
    g_assert_true (history_rows_are (window, GUINT_TO_POINTER (0)));

    /* The size answered for the history it was asked of: the switch below would
     * make it another history's, and one the refresh a real switch announces
     * would ask again. */
    g_paste_daemon3_complete_get_history_size (successor.skeleton, g_steal_pointer (&successor.held_size), successor.size);
    g_paste_test_bus_wait_until (history_rows_are, window, GUINT_TO_POINTER (1));
    g_assert_true (history_rows_are (window, GUINT_TO_POINTER (1)));

    /* The successor's current history is named by the daemon there now, listed
     * or not (on_history_changed ()): its row can be clicked before the
     * listing says so. */
    g_paste_daemon3_set_history (successor.skeleton, "work");
    g_paste_test_bus_wait_until (sidebar_row_enabled, window, "work");
    g_assert_true (sidebar_enabled (window, "work"));

    g_paste_daemon3_complete_list_histories (successor.skeleton, g_steal_pointer (&successor.held_listing), g_variant_new_parsed (LISTING_THREE));
    g_paste_test_bus_wait_until (sidebar_has_history, window, "other");
    g_assert_true (sidebar_has_history (window, "other"));
    g_paste_test_bus_round_trip (bus, successor.connection);
    g_assert_true (sidebar_item (window, "work") == work);
    g_assert_true (sidebar_enabled (window, "work"));
    g_assert_cmpuint (successor.listings, ==, 1);
    g_assert_cmpuint (successor.sizings, ==, 1);

    /* The same menu acts on the row once it can be clicked. */
    g_assert_true (gtk_widget_activate_action (window->panel, "panel.backup-history", NULL));
    g_paste_test_bus_drain ();
    g_assert_nonnull (adw_application_window_get_visible_dialog (ADW_APPLICATION_WINDOW (window)));
    adw_dialog_force_close (adw_application_window_get_visible_dialog (ADW_APPLICATION_WINDOW (window)));

    gtk_window_destroy (GTK_WINDOW (window));
    g_paste_test_bus_drain ();
    fake_daemon_stop (&successor);
    g_dbus_connection_close_sync (holder, NULL, NULL);
    g_dbus_connection_unregister_object (holder, registration);
    g_bus_unown_name (holder_owner);
    fake_daemon_stop (&old);
}

/* An image preview that cannot be read is a read the user did not ask for,
 * made again each time its row is bound: it says nothing, warning or toast,
 * however often that is (g_paste_ui_item_on_image_ready ()). Warnings being
 * fatal, one would abort the case. */
static void
test_image_preview_unreadable (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteUiWindow) window = test_window ();
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .size = 1, .images = TRUE };

    g_assert_no_error (error);
    fake_daemon_start (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    g_paste_ui_window_setup (window, client);
    g_paste_test_bus_wait_for_count (&daemon.image_reads, 1);

    /* The row bound afresh, its item having changed in place. */
    g_paste_daemon3_emit_raw_update (daemon.skeleton, G_PASTE_UPDATE_ACTION_REPLACE, G_PASTE_UPDATE_TARGET_ITEM,
                                     "00000000-0000-4000-8000-000000000000", 0);
    g_paste_test_bus_wait_for_count (&daemon.image_reads, 2);
    g_paste_test_bus_round_trip (g_dbus_proxy_get_connection (G_DBUS_PROXY (client)), daemon.connection);

    gtk_window_destroy (GTK_WINDOW (window));
    g_paste_test_bus_drain ();
    fake_daemon_stop (&daemon);
}

/* A read failing because its daemon left without answering -- a crash with
 * the call out -- is no failure to report: no warning, no "Could Not Load
 * History", no "No Pinned Items", no critical from the sidebar, the presence
 * saying what comes next (g_paste_client_is_daemon_gone_error ()). Warnings
 * and criticals being fatal, either report would abort the case. */
static void
test_listing_daemon_gone (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteUiWindow) window = test_window ();
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .size = 1, .hold_sizes = TRUE, .hold_listings = TRUE };

    g_assert_no_error (error);
    fake_daemon_start (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    g_paste_ui_window_setup (window, client);
    g_paste_test_bus_wait_for_count (&daemon.sizings, 1);
    g_paste_test_bus_wait_for_count (&daemon.listings, 1);

    AdwStatusPage *status = find_status_page (GTK_WIDGET (window->history));
    g_autofree gchar *title = g_strdup (adw_status_page_get_title (status));
    GdkPaintable *paintable = adw_status_page_get_paintable (status);

    return_gone (g_steal_pointer (&daemon.held_size));
    return_gone (g_steal_pointer (&daemon.held_listing));
    g_paste_test_bus_round_trip (g_dbus_proxy_get_connection (G_DBUS_PROXY (client)), daemon.connection);
    /* The page waiting for rows stays as it was. */
    g_assert_cmpstr (adw_status_page_get_title (status), ==, title);
    g_assert_true (adw_status_page_get_paintable (status) == paintable);

    /* Nor is a filter read failing so an answer that nothing is pinned. */
    daemon.filters_gone = TRUE;
    g_paste_ui_history_set_favourites (window->history, TRUE);
    g_paste_test_bus_wait_for_count (&daemon.filters, 1);
    g_paste_test_bus_round_trip (g_dbus_proxy_get_connection (G_DBUS_PROXY (client)), daemon.connection);
    g_assert_cmpstr (adw_status_page_get_title (status), !=, _("No Pinned Items"));

    gtk_window_destroy (GTK_WINDOW (window));
    g_paste_test_bus_drain ();
    fake_daemon_stop (&daemon);
}

/* The proxy can say a daemon is ready, its history cached, before it has
 * learnt who owns the name: learning it is no handoff, so the sidebar and the
 * list ask that daemon once, not again when its owner turns up (the bus
 * announced no owner straight to another: on_name_owner_changed ()). */
static void
test_owner_learned (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteUiWindow) window = test_window ();
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .size = 1 };

    g_assert_no_error (error);
    fake_daemon_start (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    g_paste_ui_window_setup (window, client);
    g_paste_test_bus_wait_for_owner (G_DBUS_PROXY (client), daemon.connection);
    g_paste_test_bus_wait_until (list_shown, window, NULL);
    g_assert_true (list_shown (window, NULL));
    g_paste_test_bus_round_trip (g_dbus_proxy_get_connection (G_DBUS_PROXY (client)), daemon.connection);
    g_assert_cmpuint (daemon.listings, ==, 1);
    g_assert_cmpuint (daemon.sizings, ==, 1);

    gtk_window_destroy (GTK_WINDOW (window));
    g_paste_test_bus_drain ();
    fake_daemon_stop (&daemon);
}

/* A successor whose history size cannot be read leaves no rows to keep
 * showing: the list says so, with Retry, rather than a spinner forever, and a
 * retry that succeeds brings the rows and the list's focus back. */
static void
test_listing_owner_size_error (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteUiWindow) window = test_window ();
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon old = { .size = 2, .allow_replacement = TRUE };
    FakeDaemon successor = { .size = 1, .replace = TRUE, .hold_sizes = TRUE };

    g_assert_no_error (error);
    fake_daemon_start (&old);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    g_paste_ui_window_setup (window, client);
    g_paste_test_bus_wait_until (history_rows_are, window, GUINT_TO_POINTER (2));
    g_assert_true (history_rows_are (window, GUINT_TO_POINTER (2)));
    gtk_widget_grab_focus (g_paste_test_gtk_find_widget (GTK_WIDGET (window->history), GTK_TYPE_LIST_VIEW));
    g_assert_true (history_has_focus (window));

    fake_daemon_start (&successor);
    g_paste_test_bus_wait_for_owner (G_DBUS_PROXY (client), successor.connection);
    g_paste_test_bus_wait_for_count (&successor.sizings, 1);
    g_assert_true (history_rows_are (window, GUINT_TO_POINTER (0)));

    AdwStatusPage *status = find_status_page (GTK_WIDGET (window->history));

    /* The size failure's warning is expected at each attempt, and nothing else
     * the error page or Retry might say. */
    for (guint attempt = 0; attempt < 2; ++attempt)
    {
        g_assert_nonnull (successor.held_size);
        g_test_expect_message ("GPaste", G_LOG_LEVEL_WARNING, "Could not get the size of history*size failed");
        g_dbus_method_invocation_return_dbus_error (g_steal_pointer (&successor.held_size),
                                                     "org.gnome.GPaste.Test.Size", "size failed");
        g_paste_test_bus_round_trip (g_dbus_proxy_get_connection (G_DBUS_PROXY (client)), successor.connection);
        g_test_assert_expected_messages ();
        g_assert_cmpint (g_paste_client_get_daemon_presence (client), ==, G_PASTE_DAEMON_PRESENCE_READY);
        g_assert_true (history_rows_are (window, GUINT_TO_POINTER (0)));
        g_assert_cmpstr (adw_status_page_get_title (status), ==, _("Could Not Load History"));
        g_assert_null (adw_status_page_get_paintable (status));

        GtkWidget *retry = adw_status_page_get_child (status);

        g_assert_nonnull (retry);
        g_assert_true (gtk_widget_get_visible (retry));
        g_assert_true (gtk_widget_grab_focus (retry));
        g_signal_emit_by_name (retry, "clicked");
        g_paste_test_bus_wait_for_count (&successor.sizings, attempt + 2);
        g_assert_nonnull (adw_status_page_get_paintable (status));
    }

    successor.hold_sizes = FALSE;
    g_paste_daemon3_complete_get_history_size (successor.skeleton, g_steal_pointer (&successor.held_size), successor.size);
    g_paste_test_bus_wait_until (history_rows_are, window, GUINT_TO_POINTER (1));
    g_assert_false (gtk_widget_get_visible (GTK_WIDGET (status)));
    g_paste_test_bus_wait_until (focus_returned, window, NULL);
    g_assert_true (history_list_has_focus (window));

    gtk_window_destroy (GTK_WINDOW (window));
    g_paste_test_bus_drain ();
    fake_daemon_stop (&successor);
    fake_daemon_stop (&old);
}

/* The list that had the focus when the daemon went has it again once the
 * daemon is back and its rows are. */
static void
test_focus_restored (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteUiWindow) window = test_window ();
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .size = 2 };

    /* Built before the daemon is there, as in test_retried_client (). */
    g_assert_no_error (error);
    fake_daemon_start (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    g_paste_ui_window_setup (window, client);
    g_paste_test_bus_wait_for_count (&daemon.sizings, 1);
    g_paste_test_bus_drain ();
    gtk_widget_grab_focus (g_paste_test_gtk_find_widget (GTK_WIDGET (window->history), GTK_TYPE_LIST_VIEW));
    g_assert_true (history_has_focus (window));
    g_assert_false (focus_moved_away (window, NULL));

    fake_daemon_stop (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_STARTING);
    g_paste_test_bus_wait_until (focus_moved_away, window, NULL);
    g_assert_false (history_has_focus (window));

    daemon.sizings = 0;
    fake_daemon_start (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    g_paste_test_bus_wait_until (focus_returned, window, NULL);
    g_assert_true (history_has_focus (window));

    /* But not from where the user put it while the daemon was away. */
    GtkWidget *elsewhere = GTK_WIDGET (g_paste_ui_header_get_favourites_button (window->header));

    fake_daemon_stop (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_STARTING);
    g_paste_test_bus_wait_until (focus_moved_away, window, NULL);
    g_assert_true (focus_moved_away (window, NULL));
    /* Taken off the window's list of what acts on a daemon for the test's
     * sake: what the user can reach meanwhile is sensitive. */
    gtk_widget_set_sensitive (elsewhere, TRUE);
    g_assert_true (gtk_widget_grab_focus (elsewhere));
    fake_daemon_start (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    g_paste_test_bus_wait_until (list_shown, window, NULL);
    g_assert_true (gtk_root_get_focus (GTK_ROOT (window)) == elsewhere);

    gtk_window_destroy (GTK_WINDOW (window));
    g_paste_test_bus_drain ();
    fake_daemon_stop (&daemon);
}

/* A row's upload is armed once it shows a text item, which is what its fetch
 * lands with. */
static gboolean
upload_armed (gconstpointer window,
              gconstpointer arg G_GNUC_UNUSED)
{
    GtkWidget *row = g_paste_test_gtk_find_widget (GTK_WIDGET (((GPasteUiWindow *) window)->history), G_PASTE_TYPE_UI_ITEM);

    return row && g_paste_test_gtk_shows_label (row, "value 0");
}

/* The toast saying how the upload went, which is all the window does with it. */
static gboolean
upload_toasted (gconstpointer window,
                gconstpointer arg G_GNUC_UNUSED)
{
    return g_paste_test_gtk_shows_label (GTK_WIDGET (window), _("The item was uploaded, and its address copied"));
}

static gboolean
upload_row_unparented (gconstpointer row,
                       gconstpointer arg G_GNUC_UNUSED)
{
    return gtk_widget_get_root (GTK_WIDGET (row)) == NULL;
}

static gboolean
upload_held (gconstpointer daemon,
             gconstpointer arg G_GNUC_UNUSED)
{
    return ((const FakeDaemon *) daemon)->held_upload != NULL;
}

/* A history refresh may replace the row while its upload is still out: the
 * outcome is the window's to report all the same, the row off the list having
 * no window to toast in. */
static void
test_upload_after_row_removed (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteUiWindow) window = test_window ();
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .size = 1, .hold_upload = TRUE };

    g_assert_no_error (error);
    fake_daemon_start (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    g_paste_ui_window_setup (window, client);
    g_paste_test_bus_wait_until (upload_armed, window, NULL);
    g_assert_true (upload_armed (window, NULL));

    g_autoptr (GPasteUiItem) row = g_object_ref (G_PASTE_UI_ITEM (g_paste_test_gtk_find_widget (GTK_WIDGET (window->history), G_PASTE_TYPE_UI_ITEM)));

    g_assert_true (gtk_widget_activate_action (GTK_WIDGET (row), "item.upload", NULL));
    g_paste_test_bus_wait_until (upload_held, &daemon, NULL);
    g_assert_true (upload_held (&daemon, NULL));

    daemon.size = 0;
    g_paste_daemon3_emit_raw_update (daemon.skeleton, G_PASTE_UPDATE_ACTION_REPLACE, G_PASTE_UPDATE_TARGET_ALL, "", 0);
    g_paste_test_bus_wait_until (upload_row_unparented, row, NULL);
    g_assert_null (gtk_widget_get_root (GTK_WIDGET (row)));

    g_paste_daemon3_complete_upload_and_copy (daemon.skeleton, g_steal_pointer (&daemon.held_upload), UPLOADED_URL);
    g_paste_test_bus_wait_until (upload_toasted, window, NULL);
    g_assert_true (upload_toasted (window, NULL));

    gtk_window_destroy (GTK_WINDOW (window));
    g_paste_test_bus_drain ();
    fake_daemon_stop (&daemon);
}

/* An upload offered from a row goes through UploadAndCopy, the daemon keeping
 * the address, and the window says so. */
static void
test_upload (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteUiWindow) window = test_window ();
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .size = 1 };

    g_assert_no_error (error);
    fake_daemon_start (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    g_paste_ui_window_setup (window, client);
    g_paste_test_bus_wait_until (upload_armed, window, NULL);
    g_assert_true (upload_armed (window, NULL));

    g_assert_true (gtk_widget_activate_action (g_paste_test_gtk_find_widget (GTK_WIDGET (window->history), G_PASTE_TYPE_UI_ITEM), "item.upload", NULL));
    g_paste_test_bus_wait_for_count (&daemon.uploads, 1);
    g_paste_test_bus_wait_until (upload_toasted, window, NULL);
    g_assert_true (upload_toasted (window, NULL));

    gtk_window_destroy (GTK_WINDOW (window));
    g_paste_test_bus_drain ();
    fake_daemon_stop (&daemon);
}

static gboolean
showing_history (gconstpointer window,
                 gconstpointer arg G_GNUC_UNUSED)
{
    AdwNavigationSplitView *split_view = ((GPasteUiWindow *) window)->split_view;

    return adw_navigation_split_view_get_collapsed (split_view) && adw_navigation_split_view_get_show_content (split_view);
}

/* The widest window buttons g_paste_ui_window_init () sizes the minimum for:
 * the window's icon, then minimize, maximize and close (KDE Plasma's). The
 * icon only shows for a window that names one, as the application's does. */
#define WIDE_LAYOUT "icon:minimize,maximize,close"

static GPasteUiWindow *
wide_buttons_window (void)
{
    GPasteUiWindow *window = test_window ();

    gtk_window_set_icon_name (GTK_WINDOW (window), G_PASTE_ICON_NAME);

    return window;
}

static gboolean
collapsed_is (gconstpointer window,
              gconstpointer collapsed)
{
    return adw_navigation_split_view_get_collapsed (((GPasteUiWindow *) window)->split_view) == GPOINTER_TO_INT (collapsed);
}

static gboolean
first_frame_painted (gconstpointer window,
                     gconstpointer arg G_GNUC_UNUSED)
{
    GdkFrameClock *clock = gtk_widget_get_frame_clock (GTK_WIDGET (window));

    return clock && gdk_frame_clock_get_frame_counter (clock) >= 1;
}

/* Waits for the window's first frame to be painted: a size asked of it before
 * then is lost. Returns its frame, what the default size has over the width the
 * breakpoint measures -- client-side decorations, whose size is the theme's. */
static gint
settle (GPasteUiWindow *window)
{
    gint width;

    g_paste_test_bus_wait_until (first_frame_painted, window, NULL);
    g_assert_true (first_frame_painted (window, NULL));
    gtk_window_get_default_size (GTK_WINDOW (window), &width, NULL);

    return width - gtk_widget_get_width (GTK_WIDGET (window));
}

/* Resized to a content width of @content, the window being settle ()d with a
 * frame of @frame: on Xvfb, with no window manager, it takes the size asked of
 * it. Waited for until the split view says @collapsed, which is asserted; what
 * then has to fit is checked by the pump that follows, libadwaita warning --
 * fatally, in a test -- when it does not, and nothing announcing that it will
 * not. */
static void
resize_to_content (GPasteUiWindow *window,
                   gint            frame,
                   gint            content,
                   gboolean        collapsed)
{
    gtk_window_set_default_size (GTK_WINDOW (window), content + frame, 400);
    g_paste_test_bus_wait_until (collapsed_is, window, GINT_TO_POINTER (collapsed));
    g_assert_cmpint (adw_navigation_split_view_get_collapsed (window->split_view), ==, collapsed);
    g_paste_test_bus_pump (300);
}

/* The text scale, as GNOME's Large Text and Tweaks' Scaling Factor set it. */
static void
set_text_scale (gdouble scale)
{
    g_object_set (gtk_settings_get_default (), "gtk-xft-dpi", (gint) (96 * 1024 * scale), NULL);
}

/* The window at its minimum width (see g_paste_ui_window_init ()), with the
 * widest window buttons, showing the history page, which a window opened that
 * narrow collapses to: nothing in it asks for more width than that, in any of
 * its states, nor at the text scales up to the 1.5 the minimum is sized for --
 * which libadwaita warns about otherwise, a warning the test aborts on. What is
 * measured is only measured once shown, hence the history page asserted first,
 * and the fixed pumps after each state change: nothing announces the warning
 * not coming. */
static void
test_minimum_width (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteUiWindow) window = wide_buttons_window ();
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .size = 3 };
    GtkSettings *settings = gtk_settings_get_default ();
    g_autofree gchar *layout = NULL;
    gint min_width, min_height, dpi;

    g_assert_no_error (error);
    gtk_widget_get_size_request (GTK_WIDGET (window), &min_width, &min_height);
    g_object_get (settings, "gtk-decoration-layout", &layout, "gtk-xft-dpi", &dpi, NULL);
    g_object_set (settings, "gtk-decoration-layout", WIDE_LAYOUT, NULL);
    fake_daemon_start (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    gtk_window_set_default_size (GTK_WINDOW (window), min_width, min_height);
    g_paste_ui_window_setup (window, client);
    g_paste_test_bus_wait_until (showing_history, window, NULL);
    g_assert_true (showing_history (window, NULL));
    g_assert_true (adw_header_bar_get_show_title (window->header));
    g_paste_test_bus_pump (300);

    /* Collapsed from the start, the list keeps the initial focus rather than
     * losing it to the history page's header. */
    g_paste_test_bus_wait_until (focus_returned, window, NULL);
    g_assert_true (history_has_focus (window));

    /* Large Text, and past it. */
    set_text_scale (1.25);
    g_paste_test_bus_pump (300);
    set_text_scale (1.5);
    g_paste_test_bus_pump (300);
    set_text_scale (1);

    /* The other states the window has at that width: picking items to merge,
     * the search bar up, and the banner offering a retry with no daemon. */
    on_enter_selection_mode (NULL, window);
    g_paste_test_bus_pump (300);
    on_cancel_selection_mode (NULL, window);
    gtk_search_bar_set_search_mode (window->search_bar, TRUE);
    g_paste_test_bus_pump (300);
    fake_daemon_stop (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_ABSENT);
    g_paste_test_bus_pump (300);
    g_assert_true (adw_banner_get_revealed (window->banner));

    gtk_window_destroy (GTK_WINDOW (window));
    g_paste_test_bus_drain ();
    g_object_set (settings, "gtk-decoration-layout", layout, "gtk-xft-dpi", dpi, NULL);
}

/* Both sides of G_PASTE_UI_WINDOW_COLLAPSE_WIDTH with the widest window
 * buttons: collapsed at it, side by side one pixel above, where the sidebar
 * and the history page's header have to fit together -- at a text scale below
 * 1, where the breakpoint is the one in px, and at Large Text's, where it is
 * the one in sp. */
static void
test_collapse_width (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteUiWindow) window = wide_buttons_window ();
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .size = 3 };
    GtkSettings *settings = gtk_settings_get_default ();
    g_autofree gchar *layout = NULL;
    gint dpi;

    g_assert_no_error (error);
    g_object_get (settings, "gtk-decoration-layout", &layout, "gtk-xft-dpi", &dpi, NULL);
    g_object_set (settings, "gtk-decoration-layout", WIDE_LAYOUT, NULL);
    fake_daemon_start (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    gtk_window_set_default_size (GTK_WINDOW (window), 900, 400);
    g_paste_ui_window_setup (window, client);

    gint frame = settle (window);

    resize_to_content (window, frame, G_PASTE_UI_WINDOW_COLLAPSE_WIDTH, TRUE);
    resize_to_content (window, frame, G_PASTE_UI_WINDOW_COLLAPSE_WIDTH + 1, FALSE);

    set_text_scale (0.9);
    resize_to_content (window, frame, G_PASTE_UI_WINDOW_COLLAPSE_WIDTH, TRUE);
    resize_to_content (window, frame, G_PASTE_UI_WINDOW_COLLAPSE_WIDTH + 1, FALSE);

    set_text_scale (1.25);
    resize_to_content (window, frame, G_PASTE_UI_WINDOW_COLLAPSE_WIDTH * 5 / 4, TRUE);
    resize_to_content (window, frame, G_PASTE_UI_WINDOW_COLLAPSE_WIDTH * 5 / 4 + 1, FALSE);

    gtk_window_destroy (GTK_WINDOW (window));
    g_paste_test_bus_drain ();
    fake_daemon_stop (&daemon);
    g_object_set (settings, "gtk-decoration-layout", layout, "gtk-xft-dpi", dpi, NULL);
}

/* A window narrowed while the list has the focus keeps it there, the history
 * page shown; and one narrowed again after the user went back to the
 * histories shows the history once more (on_split_view_uncollapsed ()). */
static void
test_resize (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteUiWindow) window = test_window ();
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .size = 3 };

    g_assert_no_error (error);
    fake_daemon_start (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    gtk_window_set_default_size (GTK_WINDOW (window), 900, 400);
    g_paste_ui_window_setup (window, client);
    g_paste_test_bus_wait_until (list_shown, window, NULL);
    g_assert_true (gtk_widget_grab_focus (g_paste_test_gtk_find_widget (GTK_WIDGET (window->history), GTK_TYPE_LIST_VIEW)));

    gint frame = settle (window);

    resize_to_content (window, frame, 550, TRUE);
    g_assert_true (showing_history (window, NULL));
    g_assert_true (history_has_focus (window));

    /* Back to the histories, wider, then narrow again. The transition back is
     * let finish first: uncollapsed halfway through it, libadwaita warns of a
     * page snapshotted with no allocation. */
    guint hidden = 0;
    AdwNavigationPage *content = adw_navigation_split_view_get_content (window->split_view);
    gulong handler = g_signal_connect_swapped (content, "hidden", G_CALLBACK (g_paste_test_bus_count_emission), &hidden);

    adw_navigation_split_view_set_show_content (window->split_view, FALSE);
    g_paste_test_bus_wait_for_count (&hidden, 1);
    g_assert_cmpuint (hidden, ==, 1);
    g_signal_handler_disconnect (content, handler);
    resize_to_content (window, frame, 890, FALSE);
    resize_to_content (window, frame, 550, TRUE);
    g_assert_true (showing_history (window, NULL));

    gtk_window_destroy (GTK_WINDOW (window));
    g_paste_test_bus_drain ();
    fake_daemon_stop (&daemon);
}

/* The daemon replaced by one of @version, which the client watches start: a
 * Version it learns only from what the daemon announces once exported. The
 * old one gone is enough, the client's grace second not needed. */
static void
restart_daemon_as (FakeDaemon   *daemon,
                   GPasteClient *client,
                   const gchar  *version)
{
    fake_daemon_stop (daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_STARTING);
    daemon->version = version;
    fake_daemon_start (daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
}

static gboolean
shell_owner_known (gconstpointer window,
                   gconstpointer arg G_GNUC_UNUSED)
{
    return ((GPasteUiWindow *) window)->shell_owner_known;
}

/* g_paste_ui_window_compare_versions () over every release shape meson.build
 * names, both ways round: a series' named prereleases before its .0, numeric
 * runs by value however long, leading zeros ignored, a bare major as its own
 * .0 -- after its prereleases. */
static void
test_version_comparison (void)
{
    static const gchar * const versions[] = {
        "3.42.9", "3.42.10", "45.alpha", "45", "45.1",
        "50.alpha", "50.beta", "50.rc", "50.0", "50.1", "50.9", "50.10",
        "51.alpha", "51.alpha1", "51.alpha2", "51.beta", "51.beta1", "51.beta2",
        "51.rc", "51.rc1", "51.rc2", "51.0", "51.0.1", "51.1", "51.10"
    };

    for (guint i = 0; i < G_N_ELEMENTS (versions); ++i)
    {
        g_assert_cmpint (g_paste_ui_window_compare_versions (versions[i], versions[i]), ==, 0);

        for (guint j = i + 1; j < G_N_ELEMENTS (versions); ++j)
        {
            g_assert_cmpint (g_paste_ui_window_compare_versions (versions[i], versions[j]), <, 0);
            g_assert_cmpint (g_paste_ui_window_compare_versions (versions[j], versions[i]), >, 0);
        }
    }

    g_assert_cmpint (g_paste_ui_window_compare_versions ("51.184467440737095516160", "51.184467440737095516161"), <, 0);
    g_assert_cmpint (g_paste_ui_window_compare_versions ("51.00010", "51.10"), ==, 0);
    /* A bare major is its own .0. */
    g_assert_cmpint (g_paste_ui_window_compare_versions ("51", "51.0"), ==, 0);
    g_assert_cmpint (g_paste_ui_window_compare_versions ("51.0", "51"), ==, 0);
    /* Padded as often as a side runs out: 51 = 51.0 = 51.0.0. */
    g_assert_cmpint (g_paste_ui_window_compare_versions ("51", "51.0.0"), ==, 0);
    g_assert_cmpint (g_paste_ui_window_compare_versions ("51.0.0", "51"), ==, 0);
    g_assert_cmpint (g_paste_ui_window_compare_versions ("51", "51.0.1"), <, 0);

    /* And meson.build's own table of prereleases, as it ranks them: one added
     * there is checked here with the rest, between the major before and the
     * .0 after. */
    g_auto (GStrv) ranked = g_strsplit (G_PASTE_TEST_PRE_RELEASES, ",", -1);
    guint n_ranked = g_strv_length (ranked);

    g_assert_cmpuint (n_ranked, >, 0);
    for (guint i = 0; i < n_ranked; ++i)
    {
        g_autofree gchar *version = g_strconcat ("52.", ranked[i], NULL);

        g_assert_cmpint (g_paste_ui_window_compare_versions ("51.9", version), <, 0);
        g_assert_cmpint (g_paste_ui_window_compare_versions (version, "52.0"), <, 0);

        if (i + 1 < n_ranked)
        {
            g_autofree gchar *next = g_strconcat ("52.", ranked[i + 1], NULL);

            g_assert_cmpint (g_paste_ui_window_compare_versions (version, next), <, 0);
            g_assert_cmpint (g_paste_ui_window_compare_versions (next, version), >, 0);
        }
    }
}

/* A daemon of another version gets an offer to restart it, whether it was
 * there before the window or the window watched it start, and the offer goes
 * with that daemon -- dismissed as its presence leaves ready, well before the
 * timeout it has as any toast does, so as not to hold back the ones queued
 * behind it. One of the window's own version gets none, nor one newer than
 * the window, which is the side out of date. Each check is made the
 * moment the presence moves once the Shell watch has answered, the window
 * deciding inside that callback: waited for instead, a toast wrongly up would
 * have timed out by then. */
static void
test_version_toast (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteUiWindow) window = test_window ();
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .size = 1, .version = "0.0" };
    guint dismissals = 0;

    g_assert_no_error (error);
    fake_daemon_start (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    g_paste_ui_window_setup (window, client);
    g_assert_false (window->shell_owner_known);
    g_assert_null (window->version_toast);
    g_paste_test_bus_wait_until (shell_owner_known, window, NULL);
    g_assert_true (shell_owner_known (window, NULL));
    g_paste_test_bus_wait_for_owner (G_DBUS_PROXY (client), daemon.connection);
    g_assert_nonnull (window->version_toast);
    g_assert_false (adw_toast_get_use_markup (window->version_toast));
    g_assert_cmpstr (adw_toast_get_action_name (window->version_toast), ==, "win.restart-daemon");
    g_assert_cmpuint (adw_toast_get_timeout (window->version_toast), >, 0);
    g_signal_connect_swapped (window->version_toast, "dismissed", G_CALLBACK (g_paste_test_bus_count_emission), &dismissals);

    fake_daemon_stop (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_STARTING);
    g_assert_cmpuint (dismissals, ==, 1);
    g_assert_null (window->version_toast);

    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_ABSENT);
    daemon.version = NULL;
    fake_daemon_start (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    g_paste_test_bus_wait_for_owner (G_DBUS_PROXY (client), daemon.connection);
    g_assert_null (window->version_toast);

    restart_daemon_as (&daemon, client, "0.0");
    g_paste_test_bus_wait_for_owner (G_DBUS_PROXY (client), daemon.connection);
    g_assert_nonnull (window->version_toast);

    /* A prerelease of this series is older than its stable release. */
    restart_daemon_as (&daemon, client, "51.beta");
    g_paste_test_bus_wait_for_owner (G_DBUS_PROXY (client), daemon.connection);
    g_assert_nonnull (window->version_toast);

    /* Newer than the window: a restart would bring it back as it is. */
    restart_daemon_as (&daemon, client, "9999");
    g_paste_test_bus_wait_for_owner (G_DBUS_PROXY (client), daemon.connection);
    g_assert_null (window->version_toast);

    gtk_window_destroy (GTK_WINDOW (window));
    g_paste_test_bus_drain ();
    fake_daemon_stop (&daemon);
}

/* The offer belongs to the daemon it was made to: on a direct handoff an older
 * owner taking over gets its own, and a current one taking over from it takes
 * it down, the presence leaving ready in between (/client/presence/handoff). */
static void
test_version_toast_owner_replaced (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteUiWindow) window = test_window ();
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon current = { .version = PACKAGE_VERSION, .allow_replacement = TRUE };
    FakeDaemon older = { .version = "0.0", .allow_replacement = TRUE, .replace = TRUE };
    FakeDaemon replacement = { .version = PACKAGE_VERSION, .replace = TRUE };
    guint dismissals = 0;

    g_assert_no_error (error);
    fake_daemon_start (&current);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    g_paste_ui_window_setup (window, client);
    g_paste_test_bus_wait_until (shell_owner_known, window, NULL);
    g_assert_true (shell_owner_known (window, NULL));
    g_paste_test_bus_wait_for_owner (G_DBUS_PROXY (client), current.connection);
    g_assert_true (window->version_offered);
    g_assert_null (window->version_toast);

    fake_daemon_start (&older);
    g_paste_test_bus_wait_for_owner (G_DBUS_PROXY (client), older.connection);
    g_assert_cmpint (g_paste_client_get_daemon_presence (client), ==, G_PASTE_DAEMON_PRESENCE_READY);
    g_assert_nonnull (window->version_toast);
    g_signal_connect_swapped (window->version_toast, "dismissed", G_CALLBACK (g_paste_test_bus_count_emission), &dismissals);

    fake_daemon_start (&replacement);
    g_paste_test_bus_wait_for_owner (G_DBUS_PROXY (client), replacement.connection);
    g_assert_cmpint (g_paste_client_get_daemon_presence (client), ==, G_PASTE_DAEMON_PRESENCE_READY);
    g_assert_null (window->version_toast);
    g_assert_cmpuint (dismissals, ==, 1);

    /* The list's read of the new owner answered before anything goes: left
     * out, it would outlive the window into the next case. */
    g_paste_test_bus_wait_for_count (&replacement.sizings, 1);
    g_paste_test_bus_round_trip (g_dbus_proxy_get_connection (G_DBUS_PROXY (client)), replacement.connection);
    gtk_window_destroy (GTK_WINDOW (window));
    g_paste_test_bus_drain ();
    fake_daemon_stop (&replacement);
    fake_daemon_stop (&older);
    fake_daemon_stop (&current);
}

static gboolean
restart_enabled (GPasteUiWindow *window)
{
    return g_action_group_get_action_enabled (G_ACTION_GROUP (window), "restart-daemon");
}

/* Waited for alone, the toast then checked at once: the window takes both
 * away in the one callback, and a toast wrongly up would have timed out by the
 * end of a wait for the two. */
static gboolean
restart_withheld (gconstpointer window,
                  gconstpointer arg G_GNUC_UNUSED)
{
    return !restart_enabled ((GPasteUiWindow *) window);
}

static gboolean
shell_owner_is (gconstpointer window,
                gconstpointer owner)
{
    return g_paste_str_equal (((GPasteUiWindow *) window)->shell_owner, owner);
}

/* Nor for the experimental in-shell daemon, whose Reexecute restarts nothing
 * (g_paste_ui_window_restart_can_help ()): the menu's restart goes with the
 * toast, whether the window learns the Shell's owner before the daemon is
 * ready or after. A Shell owning its name apart from the daemon changes
 * nothing, the standalone daemon being offered its restart. */
static void
test_version_toast_in_shell (void)
{
    if (!have_display)
    {
        g_test_skip ("A private Xvfb display is required");
        return;
    }

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteUiWindow) window = test_window ();
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);
    FakeDaemon daemon = { .size = 1, .version = "0.0", .in_shell = TRUE };

    g_assert_no_error (error);
    fake_daemon_start (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    g_paste_ui_window_setup (window, client);
    g_assert_false (window->shell_owner_known);
    g_assert_false (restart_enabled (window));
    g_assert_null (window->version_toast);
    g_paste_test_bus_wait_until (shell_owner_known, window, NULL);
    g_assert_true (shell_owner_known (window, NULL));
    /* Owned by the shell itself, which is what the window has to learn first:
     * restart_can_help () answers no for an owner not known yet whatever else
     * it reads. */
    g_paste_test_bus_wait_for_owner (G_DBUS_PROXY (client), daemon.connection);
    g_paste_test_bus_wait_until (restart_withheld, window, NULL);
    g_assert_false (restart_enabled (window));
    g_assert_null (window->version_toast);

    /* Ready, its owner perhaps not learnt yet: unknown is not elsewhere, so
     * neither is offered then either. */
    restart_daemon_as (&daemon, client, "0.0");
    g_assert_false (restart_enabled (window));
    g_assert_null (window->version_toast);
    g_paste_test_bus_wait_for_owner (G_DBUS_PROXY (client), daemon.connection);
    g_paste_test_bus_wait_until (restart_withheld, window, NULL);
    g_assert_false (restart_enabled (window));
    g_assert_null (window->version_toast);

    fake_daemon_stop (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_STARTING);

    g_autoptr (GDBusConnection) shell = g_paste_test_bus_connect (g_getenv ("DBUS_SESSION_BUS_ADDRESS"));
    guint shell_name = g_bus_own_name_on_connection (shell, "org.gnome.Shell", G_BUS_NAME_OWNER_FLAGS_NONE,
                                                     NULL, NULL, NULL, NULL);

    g_paste_test_bus_wait_until (shell_owner_is, window, g_dbus_connection_get_unique_name (shell));
    g_assert_true (shell_owner_is (window, g_dbus_connection_get_unique_name (shell)));
    daemon.in_shell = FALSE;
    fake_daemon_start (&daemon);
    wait_for_presence (client, G_PASTE_DAEMON_PRESENCE_READY);
    g_paste_test_bus_wait_for_owner (G_DBUS_PROXY (client), daemon.connection);
    g_assert_nonnull (window->version_toast);
    g_assert_true (restart_enabled (window));

    gtk_window_destroy (GTK_WINDOW (window));
    g_paste_test_bus_drain ();
    fake_daemon_stop (&daemon);
    g_bus_unown_name (shell_name);
}

int
main (int argc, char **argv)
{
    g_paste_test_env_setup (G_PASTE_TEST_ENV_DISPLAY);
    have_display = g_paste_test_env_has_display () && gtk_init_check ();
    g_test_init (&argc, &argv, NULL);

    if (have_display)
    {
        g_autoptr (GError) error = NULL;

        adw_init ();
        app = GTK_APPLICATION (adw_application_new ("org.gnome.GPaste.Ui.Test", G_APPLICATION_NON_UNIQUE));
        g_application_register (G_APPLICATION (app), NULL, &error);
        g_assert_no_error (error);
    }

    g_test_add_func ("/ui/daemon-presence/follow", test_follow);
    g_test_add_func ("/ui/daemon-presence/retried-client", test_retried_client);
    g_test_add_func ("/ui/daemon-presence/search-closed-away", test_search_closed_away);
    g_test_add_func ("/ui/header/pinned-filter-star", test_pinned_filter_star);
    g_test_add_func ("/ui/daemon-presence/nothing-asked", test_nothing_asked);
    g_test_add_func ("/ui/daemon-presence/entry-focus-released", test_entry_focus_released);
    g_test_add_func ("/ui/daemon-presence/merge-entry-focus-released", test_merge_entry_focus_released);
    g_test_add_func ("/ui/daemon-presence/reply-after-close", test_reply_after_close);
    g_test_add_func ("/ui/daemon-presence/search-enter-waits", test_search_enter_waits);
    g_test_add_func ("/ui/daemon-presence/search-enter-restart", test_search_enter_restart);
    g_test_add_func ("/ui/daemon-presence/stand-in-answers-first", test_stand_in_answers_first);
    g_test_add_func ("/ui/daemon-presence/search-enter-survives-update", test_search_enter_survives_update);
    g_test_add_func ("/ui/daemon-presence/activate-unread-rows", test_activate_unread_rows);
    g_test_add_func ("/ui/daemon-presence/selection-mode-keys", test_selection_mode_keys);
    g_test_add_func ("/ui/daemon-presence/selection-click-focuses", test_selection_click_focuses);
    g_test_add_func ("/ui/daemon-presence/superseded-refresh", test_superseded_refresh);
    g_test_add_func ("/ui/daemon-presence/row-read-in-place", test_row_read_in_place);
    g_test_add_func ("/ui/daemon-presence/search-relist-keeps-focus", test_search_relist_keeps_focus);
    g_test_add_func ("/ui/daemon-presence/selection-mode-keeps-place", test_selection_mode_keeps_place);
    g_test_add_func ("/ui/daemon-presence/merge-picks-shown", test_merge_picks_shown);
    g_test_add_func ("/ui/daemon-presence/merge-picks-unread", test_merge_picks_unread);
    g_test_add_func ("/ui/daemon-presence/merge-pick-during-reread", test_merge_pick_during_reread);
    g_test_add_func ("/ui/daemon-presence/merge-after-close", test_merge_after_close);
    g_test_add_func ("/ui/daemon-presence/image-preview-off", test_image_preview_off);
    g_test_add_func ("/ui/daemon-presence/short-history-grows", test_short_history_grows);
    g_test_add_func ("/ui/daemon-presence/sidebar-choice", test_sidebar_choice);
    g_test_add_func ("/ui/daemon-presence/app-actions", test_app_actions);
    g_test_add_func ("/ui/daemon-presence/outside-asks", test_outside_asks);
    g_test_add_func ("/ui/daemon-presence/confirmed-without-daemon", test_confirmed_without_daemon);
    g_test_add_data_func ("/ui/daemon-presence/closed-with-question-up/restart", "restart-daemon", test_closed_with_question_up);
    g_test_add_data_func ("/ui/daemon-presence/closed-with-question-up/tracking", "track-changes", test_closed_with_question_up);
    g_test_add_func ("/ui/daemon-presence/closed-while-connecting", test_closed_while_connecting);
    g_test_add_func ("/ui/daemon-presence/client-fails", test_client_fails);
    g_test_add_func ("/ui/daemon-presence/listing-fails", test_listing_fails);
    g_test_add_func ("/ui/daemon-presence/legacy-daemon", test_legacy_daemon);
    g_test_add_func ("/ui/daemon-presence/legacy-replaced", test_legacy_replaced);
    g_test_add_func ("/ui/daemon-presence/legacy-kept", test_legacy_kept);
    g_test_add_data_func ("/ui/daemon-presence/legacy-restart-asked/legacy", GINT_TO_POINTER (TRUE), test_legacy_restart_asked);
    g_test_add_data_func ("/ui/daemon-presence/legacy-restart-asked/current", GINT_TO_POINTER (FALSE), test_legacy_restart_asked);
    g_test_add_func ("/ui/daemon-presence/search-escaped", test_search_escaped);
    g_test_add_func ("/ui/daemon-presence/listing-after-switch", test_listing_after_switch);
    g_test_add_func ("/ui/daemon-presence/listing-overtaken", test_listing_overtaken);
    g_test_add_func ("/ui/daemon-presence/listing-abandoned", test_listing_abandoned);
    g_test_add_func ("/ui/daemon-presence/listing-after-close", test_listing_after_close);
    g_test_add_func ("/ui/daemon-presence/listing-pruned", test_listing_pruned);
    g_test_add_func ("/ui/daemon-presence/listing-handoff", test_listing_handoff);
    g_test_add_func ("/ui/daemon-presence/image-preview-unreadable", test_image_preview_unreadable);
    g_test_add_func ("/ui/daemon-presence/listing-owner-size-error", test_listing_owner_size_error);
    g_test_add_func ("/ui/daemon-presence/owner-learned", test_owner_learned);
    g_test_add_func ("/ui/daemon-presence/listing-daemon-gone", test_listing_daemon_gone);
    g_test_add_func ("/ui/daemon-presence/status-plain", test_status_plain);
    g_test_add_func ("/ui/daemon-presence/size-fails-leaving-search", test_size_fails_leaving_search);
    g_test_add_data_func ("/ui/daemon-presence/filter-fails/search", GINT_TO_POINTER (TRUE), test_filter_fails);
    g_test_add_data_func ("/ui/daemon-presence/filter-fails/pinned", GINT_TO_POINTER (FALSE), test_filter_fails);
    g_test_add_func ("/ui/daemon-presence/filtered-count", test_filtered_count);
    g_test_add_func ("/ui/daemon-presence/upload", test_upload);
    g_test_add_func ("/ui/daemon-presence/upload-after-row-removed", test_upload_after_row_removed);
    g_test_add_func ("/ui/daemon-presence/focus-restored", test_focus_restored);
    g_test_add_func ("/ui/daemon-presence/version-comparison", test_version_comparison);
    g_test_add_func ("/ui/daemon-presence/version-toast", test_version_toast);
    g_test_add_func ("/ui/daemon-presence/version-toast-owner-replaced", test_version_toast_owner_replaced);
    g_test_add_func ("/ui/daemon-presence/version-toast-in-shell", test_version_toast_in_shell);
    g_test_add_func ("/ui/daemon-presence/minimum-width", test_minimum_width);
    g_test_add_func ("/ui/daemon-presence/collapse-width", test_collapse_width);
    g_test_add_func ("/ui/daemon-presence/resize", test_resize);
    return g_paste_test_env_run ();
}
