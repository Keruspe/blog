// SPDX-FileCopyrightText: 2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com>
// SPDX-License-Identifier: BSD-2-Clause

/* The standalone daemon's libadwaita prompt, driven through the GPastePrompt
 * calls the storage layer makes, on a private Xvfb: what each dialog offers,
 * what it answers, and that its text reaches the screen as written. */

#include <gpaste-test-env.h>
#include <gpaste-test-bus.h>
#include <gpaste-test-gtk.h>
#include <gpaste-daemon/gpaste-prompt.h>

/* The private bus has no keyring, and looking one up warns, which g_test makes
 * fatal: the remember switch starts off, with nothing remembered. */
static void
no_keyring (GPasteStorageRemember remember G_GNUC_UNUSED,
            gboolean             *starts_on,
            gboolean             *can_forget)
{
    *starts_on = FALSE;
    *can_forget = FALSE;
}

#define g_paste_prompt_remember_state no_keyring
#include <gpaste-prompt-adw.c>
#undef g_paste_prompt_remember_state

#include <gpaste-daemon/gpaste-passphrase.h>

static gboolean have_display;
static GtkApplication *app;

typedef struct
{
    gboolean              done;
    gboolean              confirmed;
    GPasteStorage         chosen;
    gboolean              import;
    gboolean              cleanup;
    GPastePassphrase     *passphrase;
    GPasteStorageRemember remember;
} Answer;

static void
on_migration_answered (GObject      *source,
                       GAsyncResult *result,
                       gpointer      user_data)
{
    Answer *answer = user_data;
    g_autoptr (GError) error = NULL;

    answer->confirmed = g_paste_prompt_migration_finish (G_PASTE_PROMPT (source), result, &answer->chosen,
                                                         &answer->import, &answer->cleanup, &error);
    g_assert_no_error (error);
    answer->done = TRUE;
}

static void
on_passphrase_answered (GObject      *source,
                        GAsyncResult *result,
                        gpointer      user_data)
{
    Answer *answer = user_data;
    g_autoptr (GError) error = NULL;

    answer->passphrase = g_paste_prompt_passphrase_finish (G_PASTE_PROMPT (source), result, &answer->remember, &error);
    g_assert_no_error (error);
    answer->done = TRUE;
}

static void
on_confirm_answered (GObject      *source,
                     GAsyncResult *result,
                     gpointer      user_data)
{
    Answer *answer = user_data;
    g_autoptr (GError) error = NULL;

    answer->confirmed = g_paste_prompt_confirm_finish (G_PASTE_PROMPT (source), result, &error);
    g_assert_no_error (error);
    answer->done = TRUE;
}

static gboolean
answered (gconstpointer data,
          gconstpointer arg G_GNUC_UNUSED)
{
    return ((const Answer *) data)->done;
}

static void
wait_for (Answer *answer)
{
    g_paste_test_bus_wait_until (answered, answer, NULL);
    g_assert_true (answer->done);
}

/* The window the prompt has just put up: the application's newest. */
static GtkWindow *
shown_window (void)
{
    GList *windows = gtk_application_get_windows (app);

    g_assert_nonnull (windows);

    return windows->data;
}

/* Escape, as the window answers it: the shortcut bound to it, run on the
 * window. That pins the binding and what it does, not the key's delivery --
 * GTK has no public way to synthesise a key event, and a real one needs XTest
 * on the suite's Xvfb. A bubble-phase controller on the window sees the key
 * whichever child has the focus, the password entry's text included, which is
 * what a delivery test would show. */
static void
press_escape (GtkWindow *window)
{
    g_autoptr (GListModel) controllers = gtk_widget_observe_controllers (GTK_WIDGET (window));

    for (guint i = 0; i < g_list_model_get_n_items (controllers); ++i)
    {
        g_autoptr (GObject) controller = g_list_model_get_item (controllers, i);

        if (!GTK_IS_SHORTCUT_CONTROLLER (controller))
            continue;

        for (guint j = 0; j < g_list_model_get_n_items (G_LIST_MODEL (controller)); ++j)
        {
            g_autoptr (GtkShortcut) shortcut = g_list_model_get_item (G_LIST_MODEL (controller), j);
            GtkShortcutTrigger *trigger = gtk_shortcut_get_trigger (shortcut);

            if (GTK_IS_KEYVAL_TRIGGER (trigger) &&
                gtk_keyval_trigger_get_keyval (GTK_KEYVAL_TRIGGER (trigger)) == GDK_KEY_Escape &&
                !gtk_keyval_trigger_get_modifiers (GTK_KEYVAL_TRIGGER (trigger)))
            {
                g_assert_true (gtk_shortcut_action_activate (gtk_shortcut_get_action (shortcut), 0, GTK_WIDGET (window), NULL));
                return;
            }
        }
    }

    g_assert_not_reached ();
}

/* Whether some label shows @text, markup parsed or not. */
static gboolean
shows (GtkWindow   *window,
       const gchar *text)
{
    g_autoptr (GPtrArray) labels = g_paste_test_gtk_find_all (GTK_WIDGET (window), GTK_TYPE_LABEL);

    for (guint i = 0; i < labels->len; ++i)
    {
        if (g_strrstr (gtk_label_get_text (labels->pdata[i]), text))
            return TRUE;
    }

    return FALSE;
}

/* Whether a group of @window describes itself with @text, as the dialog sets
 * it: escaped. */
static gboolean
has_description (GtkWindow   *window,
                 const gchar *text)
{
    g_autoptr (GPtrArray) groups = g_paste_test_gtk_find_all (GTK_WIDGET (window), ADW_TYPE_PREFERENCES_GROUP);
    g_autofree gchar *escaped = g_markup_escape_text (text, -1);

    for (guint i = 0; i < groups->len; ++i)
    {
        if (!g_strcmp0 (adw_preferences_group_get_description (groups->pdata[i]), escaped))
            return TRUE;
    }

    return FALSE;
}

/* No row or banner takes what it shows for markup: the prompt's text is plain. */
static void
assert_plain_rows (GtkWindow *window)
{
    g_autoptr (GPtrArray) rows = g_paste_test_gtk_find_all (GTK_WIDGET (window), ADW_TYPE_PREFERENCES_ROW);
    g_autoptr (GPtrArray) banners = g_paste_test_gtk_find_all (GTK_WIDGET (window), ADW_TYPE_BANNER);

    g_assert_cmpuint (rows->len, >, 0);
    for (guint i = 0; i < rows->len; ++i)
        g_assert_false (adw_preferences_row_get_use_markup (rows->pdata[i]));
    for (guint i = 0; i < banners->len; ++i)
        g_assert_false (adw_banner_get_use_markup (banners->pdata[i]));
}

static const GPasteStorage offered[] = { G_PASTE_STORAGE_FILE, G_PASTE_STORAGE_NOOP };

#if defined(G_PASTE_ENABLE_ENCRYPTION) && defined(G_PASTE_ENABLE_SQLITE)
/* Picking another backend keeps what was ticked: GTK unpicks the one before
 * first, and that moment, nothing picked, turned both switches off. */
static void
test_migration_switch_keeps_toggles (void)
{
    if (!have_display)
    {
        g_test_skip ("no display");
        return;
    }

    static const GPasteStorage backends[] = { G_PASTE_STORAGE_FILE, G_PASTE_STORAGE_SQLITE, G_PASTE_STORAGE_ENCRYPTED_FILE };
    g_autoptr (GPastePrompt) prompt = g_paste_prompt_adw_new (app);
    Answer answer = { 0 };

    g_paste_prompt_migration_async (prompt, backends, G_N_ELEMENTS (backends), G_PASTE_STORAGE_FILE, on_migration_answered, &answer);

    GtkWindow *window = shown_window ();
    MigrationDialog *dialog = g_object_get_data (G_OBJECT (window), "gpaste-migration-dialog");

    gtk_check_button_set_active (dialog->backend_checks[1], TRUE);
    adw_switch_row_set_active (dialog->import_row, TRUE);
    adw_switch_row_set_active (dialog->cleanup_row, TRUE);
    gtk_check_button_set_active (dialog->backend_checks[2], TRUE);
    g_assert_true (adw_switch_row_get_active (dialog->import_row));
    g_assert_true (adw_switch_row_get_active (dialog->cleanup_row));

    g_signal_emit_by_name (dialog->apply, "clicked");
    wait_for (&answer);
    g_assert_true (answer.confirmed);
    g_assert_cmpint (answer.chosen, ==, G_PASTE_STORAGE_ENCRYPTED_FILE);
}
#endif

/* The backend in use is picked, and Keep is offered; another picked instead
 * unpicks it, and Apply answers with that one. */
static void
test_migration_current_picked (void)
{
    if (!have_display)
    {
        g_test_skip ("no display");
        return;
    }

    g_autoptr (GPastePrompt) prompt = g_paste_prompt_adw_new (app);
    Answer answer = { 0 };

    g_paste_prompt_migration_async (prompt, offered, G_N_ELEMENTS (offered), G_PASTE_STORAGE_FILE, on_migration_answered, &answer);

    GtkWindow *window = shown_window ();
    MigrationDialog *dialog = g_object_get_data (G_OBJECT (window), "gpaste-migration-dialog");

    assert_plain_rows (window);
    g_assert_false (adw_banner_get_use_markup (dialog->warning));
    g_assert_true (gtk_check_button_get_active (dialog->backend_checks[0]));
    g_assert_false (gtk_check_button_get_active (dialog->backend_checks[1]));
    g_assert_true (gtk_widget_get_sensitive (dialog->apply));
    /* Asked of the buttons: the Keep button's words are quoted in the
     * description too. */
    g_assert_nonnull (g_paste_test_gtk_find_button (GTK_WIDGET (window), g_paste_prompt_text (G_PASTE_PROMPT_TEXT_MIGRATION_KEEP)));
    g_assert_true (has_description (window, g_paste_prompt_text (G_PASTE_PROMPT_TEXT_MIGRATION_DESCRIPTION)));

    gtk_check_button_set_active (dialog->backend_checks[1], TRUE);
    g_assert_false (gtk_check_button_get_active (dialog->backend_checks[0]));

    /* Deleting the old data without importing it is warned about
     * (g_paste_prompt_cleanup_warns ()). */
    g_assert_false (adw_banner_get_revealed (dialog->warning));
    adw_switch_row_set_active (dialog->cleanup_row, TRUE);
    g_assert_true (adw_banner_get_revealed (dialog->warning));
    adw_switch_row_set_active (dialog->cleanup_row, FALSE);
    g_signal_emit_by_name (dialog->apply, "clicked");
    wait_for (&answer);
    g_assert_true (answer.confirmed);
    g_assert_cmpint (answer.chosen, ==, G_PASTE_STORAGE_NOOP);
}

/* A backend in use this build cannot construct is not on the list: nothing is
 * picked for the user, there is nothing to keep, and Apply answers nothing
 * until they pick one. */
static void
test_migration_nothing_picked (void)
{
    if (!have_display)
    {
        g_test_skip ("no display");
        return;
    }

    g_autoptr (GPastePrompt) prompt = g_paste_prompt_adw_new (app);
    Answer answer = { 0 };

    g_paste_prompt_migration_async (prompt, offered, G_N_ELEMENTS (offered), G_PASTE_STORAGE_SQLITE, on_migration_answered, &answer);

    GtkWindow *window = shown_window ();
    MigrationDialog *dialog = g_object_get_data (G_OBJECT (window), "gpaste-migration-dialog");

    for (guint i = 0; i < G_N_ELEMENTS (offered); ++i)
        g_assert_false (gtk_check_button_get_active (dialog->backend_checks[i]));
    g_assert_false (gtk_widget_get_sensitive (dialog->apply));
    g_assert_null (g_paste_test_gtk_find_button (GTK_WIDGET (window), g_paste_prompt_text (G_PASTE_PROMPT_TEXT_MIGRATION_KEEP)));
    /* Nor is the button named. */
    g_assert_true (has_description (window, g_paste_prompt_text (G_PASTE_PROMPT_TEXT_MIGRATION_DESCRIPTION_UNKEPT)));
    on_apply (NULL, dialog);
    g_main_context_iteration (NULL, FALSE);
    g_assert_false (answer.done);

    gtk_check_button_set_active (dialog->backend_checks[0], TRUE);
    g_assert_true (gtk_widget_get_sensitive (dialog->apply));
    g_signal_emit_by_name (dialog->apply, "clicked");
    wait_for (&answer);
    g_assert_true (answer.confirmed);
    g_assert_cmpint (answer.chosen, ==, G_PASTE_STORAGE_FILE);
}

/* Losing the window, however that happens, is a dismissal, not a failure. */
static void
test_migration_dismissed (void)
{
    if (!have_display)
    {
        g_test_skip ("no display");
        return;
    }

    g_autoptr (GPastePrompt) prompt = g_paste_prompt_adw_new (app);
    Answer answer = { 0 };

    g_paste_prompt_migration_async (prompt, offered, G_N_ELEMENTS (offered), G_PASTE_STORAGE_FILE, on_migration_answered, &answer);
    gtk_window_destroy (shown_window ());
    wait_for (&answer);
    g_assert_false (answer.confirmed);
}

/* Escape closes every prompt as its close button does: a dismissal for the two
 * that ask something, the window gone for the report. */
static void
test_escape_closes (void)
{
    if (!have_display)
    {
        g_test_skip ("no display");
        return;
    }

    g_autoptr (GPastePrompt) prompt = g_paste_prompt_adw_new (app);
    Answer migration = { 0 };
    Answer passphrase = { 0 };

    g_paste_prompt_migration_async (prompt, offered, G_N_ELEMENTS (offered), G_PASTE_STORAGE_FILE, on_migration_answered, &migration);
    press_escape (shown_window ());
    wait_for (&migration);
    g_assert_false (migration.confirmed);

    g_paste_prompt_passphrase_async (prompt, FALSE, NULL, G_PASTE_STORAGE_REMEMBER_UNCHANGED, on_passphrase_answered, &passphrase);
    press_escape (shown_window ());
    wait_for (&passphrase);
    g_assert_null (passphrase.passphrase);

    g_paste_prompt_report (prompt, "Title", "Message");

    GtkWindow *report = shown_window ();

    g_object_add_weak_pointer (G_OBJECT (report), (gpointer *) &report);
    press_escape (report);
    g_paste_test_bus_wait_until (g_paste_test_bus_is_unset, &report, NULL);
    g_assert_null (report);
}

/* What went wrong is shown as written, beside the standing explanation, a "&"
 * or a "<" in it included. */
static void
test_passphrase_error_shown (void)
{
    if (!have_display)
    {
        g_test_skip ("no display");
        return;
    }

    static const gchar *error = "Could not open \"a & b <c>\"";
    g_autoptr (GPastePrompt) prompt = g_paste_prompt_adw_new (app);
    Answer answer = { 0 };

    g_paste_prompt_passphrase_async (prompt, FALSE, error, G_PASTE_STORAGE_REMEMBER_UNCHANGED, on_passphrase_answered, &answer);

    GtkWindow *window = shown_window ();
    PassphraseDialog *dialog = g_object_get_data (G_OBJECT (window), "gpaste-passphrase-dialog");

    assert_plain_rows (window);
    g_assert_true (shows (window, error));
    g_assert_true (shows (window, g_paste_prompt_text (G_PASTE_PROMPT_TEXT_PASSPHRASE_DESCRIPTION)));
    g_assert_cmpint (dialog->remember != NULL, ==, g_paste_prompt_keyring_available ());

    gtk_window_destroy (window);
    wait_for (&answer);
    g_assert_null (answer.passphrase);
}

/* A new passphrase is taken once typed twice alike, Enter in either entry
 * answering then and only then: @user_data says whether the confirmation's
 * answers, or the passphrase's own. */
static void
test_passphrase_confirmed (gconstpointer user_data)
{
    if (!have_display)
    {
        g_test_skip ("no display");
        return;
    }

    g_autoptr (GPastePrompt) prompt = g_paste_prompt_adw_new (app);
    Answer answer = { 0 };

    g_paste_prompt_passphrase_async (prompt, TRUE, NULL, G_PASTE_STORAGE_REMEMBER_UNCHANGED, on_passphrase_answered, &answer);

    GtkWindow *window = shown_window ();
    PassphraseDialog *dialog = g_object_get_data (G_OBJECT (window), "gpaste-passphrase-dialog");

    assert_plain_rows (window);
    g_assert_cmpstr (gtk_button_get_label (GTK_BUTTON (dialog->ok)), ==, g_paste_prompt_text (G_PASTE_PROMPT_TEXT_PASSPHRASE_CONFIRM_ACCEPT));
    g_assert_false (gtk_widget_get_sensitive (dialog->ok));
    gtk_editable_set_text (dialog->entry, "correct horse");
    gtk_editable_set_text (dialog->confirm_entry, "correct hors");
    g_assert_false (gtk_widget_get_sensitive (dialog->ok));
    g_signal_emit_by_name (dialog->entry, "entry-activated");
    g_signal_emit_by_name (dialog->confirm_entry, "entry-activated");
    g_main_context_iteration (NULL, FALSE);
    g_assert_false (answer.done);

    gtk_editable_set_text (dialog->confirm_entry, "correct horse");
    g_assert_true (gtk_widget_get_sensitive (dialog->ok));

    /* The switch turned on, where the build offers one, is the passphrase to
     * remember (g_paste_prompt_remember_answer ()). */
    gboolean offered = dialog->remember != NULL;

    if (offered)
        adw_switch_row_set_active (ADW_SWITCH_ROW (dialog->remember), TRUE);
    g_signal_emit_by_name ((GPOINTER_TO_INT (user_data)) ? dialog->confirm_entry : dialog->entry, "entry-activated");
    wait_for (&answer);
    g_assert_nonnull (answer.passphrase);
    g_assert_cmpstr (g_paste_passphrase_peek (answer.passphrase), ==, "correct horse");
    g_assert_cmpint (answer.remember, ==, (offered) ? G_PASTE_STORAGE_REMEMBER_YES : G_PASTE_STORAGE_REMEMBER_UNCHANGED);
    g_clear_pointer (&answer.passphrase, g_paste_passphrase_free);
}

/* On is to remember, and off to forget only where something is remembered:
 * finding the switch off and leaving it there asks nothing. */
static void
test_remember_answer (void)
{
    g_assert_cmpint (g_paste_prompt_remember_answer (TRUE, FALSE), ==, G_PASTE_STORAGE_REMEMBER_YES);
    g_assert_cmpint (g_paste_prompt_remember_answer (TRUE, TRUE), ==, G_PASTE_STORAGE_REMEMBER_YES);
    g_assert_cmpint (g_paste_prompt_remember_answer (FALSE, TRUE), ==, G_PASTE_STORAGE_REMEMBER_NO);
    g_assert_cmpint (g_paste_prompt_remember_answer (FALSE, FALSE), ==, G_PASTE_STORAGE_REMEMBER_UNCHANGED);
}

/* A passphrase asked for other histories says what it is wanted for in place
 * of the standing explanation, and offers no switch to remember it, which the
 * one for the history in use does in a build with a keyring. */
static void
test_passphrase_other_histories (void)
{
    if (!have_display)
    {
        g_test_skip ("no display");
        return;
    }

    static const gchar *description = "Wanted for \"a & b <c>\"";
    g_autoptr (GPastePrompt) prompt = g_paste_prompt_adw_new (app);
    Answer answer = { 0 };

    g_paste_prompt_other_passphrase_async (prompt, description, NULL, on_passphrase_answered, &answer);

    GtkWindow *window = shown_window ();
    PassphraseDialog *dialog = g_object_get_data (G_OBJECT (window), "gpaste-passphrase-dialog");

    assert_plain_rows (window);
    g_assert_true (shows (window, description));
    g_assert_nonnull (g_paste_test_gtk_find_button (GTK_WIDGET (window), g_paste_prompt_text (G_PASTE_PROMPT_TEXT_PASSPHRASE_ACCEPT)));
    g_assert_false (shows (window, g_paste_prompt_text (G_PASTE_PROMPT_TEXT_PASSPHRASE_DESCRIPTION)));
    g_assert_null (dialog->remember);

    gtk_editable_set_text (dialog->entry, "previous one");
    g_signal_emit_by_name (dialog->entry, "entry-activated");
    wait_for (&answer);
    g_assert_nonnull (answer.passphrase);
    g_assert_cmpstr (g_paste_passphrase_peek (answer.passphrase), ==, "previous one");
    g_assert_cmpint (answer.remember, ==, G_PASTE_STORAGE_REMEMBER_UNCHANGED);
    g_clear_pointer (&answer.passphrase, g_paste_passphrase_free);
}

/* A confirmation shows what its caller worded, escaped, and answers yes from
 * its destructive button alone; Cancel is what Enter answers with, and has the
 * focus; Cancel, Escape and the window going decline. */
static void
test_confirm_answered (void)
{
    if (!have_display)
    {
        g_test_skip ("no display");
        return;
    }

    static const gchar *description = "Images of \"a & b <c>\" go";
    g_autoptr (GPastePrompt) prompt = g_paste_prompt_adw_new (app);
    Answer accepted = { 0 };
    Answer cancelled = { .confirmed = TRUE };
    Answer escaped = { 0 };
    Answer closed = { 0 };

    g_paste_prompt_confirm_async (prompt, "Delete?", description, "Delete", on_confirm_answered, &accepted);

    GtkWindow *window = shown_window ();
    GtkWidget *accept = g_paste_test_gtk_find_button (GTK_WIDGET (window), "Delete");
    GtkWidget *cancel = g_paste_test_gtk_find_button (GTK_WIDGET (window), g_paste_prompt_text (G_PASTE_PROMPT_TEXT_CANCEL));

    g_assert_nonnull (accept);
    g_assert_nonnull (cancel);
    g_assert_true (shows (window, description));
    g_assert_true (gtk_widget_has_css_class (accept, "destructive-action"));
    g_assert_true (gtk_window_get_default_widget (window) == cancel);
    g_assert_true (gtk_window_get_focus (window) == cancel);
    g_signal_emit_by_name (accept, "clicked");
    wait_for (&accepted);
    g_assert_true (accepted.confirmed);

    g_paste_prompt_confirm_async (prompt, "Delete?", description, "Delete", on_confirm_answered, &cancelled);
    cancel = g_paste_test_gtk_find_button (GTK_WIDGET (shown_window ()), g_paste_prompt_text (G_PASTE_PROMPT_TEXT_CANCEL));
    g_assert_nonnull (cancel);
    g_signal_emit_by_name (cancel, "clicked");
    wait_for (&cancelled);
    g_assert_false (cancelled.confirmed);

    g_paste_prompt_confirm_async (prompt, "Delete?", description, "Delete", on_confirm_answered, &escaped);
    press_escape (shown_window ());
    wait_for (&escaped);
    g_assert_false (escaped.confirmed);

    g_paste_prompt_confirm_async (prompt, "Delete?", description, "Delete", on_confirm_answered, &closed);
    gtk_window_destroy (shown_window ());
    wait_for (&closed);
    g_assert_false (closed.confirmed);
}

/* A report says what it was given, a "&" in it included. */
static void
test_report_shown (void)
{
    if (!have_display)
    {
        g_test_skip ("no display");
        return;
    }

    static const gchar *message = "History \"a & b <c>\" was not deleted";
    g_autoptr (GPastePrompt) prompt = g_paste_prompt_adw_new (app);

    g_paste_prompt_report (prompt, "Title", message);

    GtkWindow *window = shown_window ();

    g_assert_true (shows (window, message));
    gtk_window_destroy (window);
}

int
main (int argc, char *argv[])
{
    g_paste_test_env_setup (G_PASTE_TEST_ENV_DISPLAY);
    have_display = g_paste_test_env_has_display () && gtk_init_check ();
    g_test_init (&argc, &argv, NULL);

    if (have_display)
    {
        g_autoptr (GError) error = NULL;

        adw_init ();
        app = GTK_APPLICATION (adw_application_new ("org.gnome.GPaste.Daemon.Test", G_APPLICATION_NON_UNIQUE));
        g_application_register (G_APPLICATION (app), NULL, &error);
        g_assert_no_error (error);
    }

    g_test_add_func ("/prompt-adw/migration/current-picked", test_migration_current_picked);
#if defined(G_PASTE_ENABLE_ENCRYPTION) && defined(G_PASTE_ENABLE_SQLITE)
    g_test_add_func ("/prompt-adw/migration/switch-keeps-toggles", test_migration_switch_keeps_toggles);
#endif
    g_test_add_func ("/prompt-adw/migration/nothing-picked", test_migration_nothing_picked);
    g_test_add_func ("/prompt-adw/migration/dismissed", test_migration_dismissed);
    g_test_add_func ("/prompt-adw/escape", test_escape_closes);
    g_test_add_func ("/prompt-adw/passphrase/error-shown", test_passphrase_error_shown);
    g_test_add_data_func ("/prompt-adw/passphrase/confirmed", GINT_TO_POINTER (TRUE), test_passphrase_confirmed);
    g_test_add_data_func ("/prompt-adw/passphrase/confirmed_first_entry", GINT_TO_POINTER (FALSE), test_passphrase_confirmed);
    g_test_add_func ("/prompt-adw/passphrase/other-histories", test_passphrase_other_histories);
    g_test_add_func ("/prompt-adw/passphrase/remember-answer", test_remember_answer);
    g_test_add_func ("/prompt-adw/report/shown", test_report_shown);
    g_test_add_func ("/prompt-adw/confirm/answered", test_confirm_answered);

    return g_paste_test_env_run ();
}
