// SPDX-FileCopyrightText: 2010-2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com>
// SPDX-License-Identifier: BSD-2-Clause

import './dependencies.js';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import {gettext as _} from 'resource:///org/gnome/shell/extensions/extension.js';

import {ensureActorVisibleInScrollView} from 'resource:///org/gnome/shell/misc/animationUtils.js';
import {Button} from 'resource:///org/gnome/shell/ui/panelMenu.js';
import {PopupMenuSection} from 'resource:///org/gnome/shell/ui/popupMenu.js';

import Clutter from 'gi://Clutter';
import GObject from 'gi://GObject';
import GLib from 'gi://GLib';
import St from 'gi://St';
import GPaste from 'gi://GPaste?version=3';

import {addGPasteFooter} from './actions.js';
import {awaitReply, daemonGone, debugFailure, logFailure, replaceCancellable} from './dependencies.js';
import {GPasteDummyHistoryItem} from './dummyHistoryItem.js';
import {GPasteHistorySwitcher} from './historySwitcher.js';
import {GPasteItem} from './item.js';
import {GPasteItemActionsItem} from './itemActions.js';
import {GPasteSearchItem} from './searchItem.js';
import {GPasteStateSwitch} from './stateSwitch.js';

// Kept outside the indicator's method: the pending D-Bus call holds this
// callback until its reply, and its scope carries only the weak handle.
function onUploadDone(indicator, client, result) {
    try {
        client.upload_and_copy_finish(result);
    } catch (e) {
        // Logged whatever became of the menu; shown only while the extension
        // is still there, like every path resuming after a call.
        console.error(e);
        const current = indicator.deref();
        if (current && !current._destroyed)
            Main.notifyError(_('Could not upload the item'), e.message);
        return;
    }

    // Said without the address, as the graphical tool's toast is: a paste's
    // can carry the key to it (PrivateBin puts it in the fragment), and the
    // daemon has already put it where the user can paste it.
    const current = indicator.deref();
    if (current && !current._destroyed)
        Main.notify(_('The item was uploaded, and its address copied'));
}

export const GPasteIndicator = GObject.registerClass(
class GPasteIndicator extends Button {
    static _CONNECT_RETRIES = 3;
    // Rows to load before any have been laid out (and a real row height is
    // known); _maybeLoadMore() then tops the list up to fill the viewport.
    static _DEFAULT_BATCH = 20;
    // How long a search waits for the typing to pause, in milliseconds:
    // GtkSearchEntry's own, which the graphical tool's search uses.
    static _SEARCH_DELAY = 150;
    // What the search box is sized for when element-size sets no limit: the
    // schema's default size.
    static _UNLIMITED_ELEMENT_SIZE = 80;

    constructor(extension) {
        super(0.0, 'GPaste');

        this._extension = extension;

        this._statusIcon = new St.BoxLayout({style_class: 'panel-status-menu-box'});
        this._statusIcon.add_child(new St.Icon({
            icon_name: 'org.gnome.GPaste.Ui-symbolic',
            style_class: 'system-status-icon',
        }));
        this.add_child(this._statusIcon);

        // The extension's, shared with the in-shell daemon when there is one:
        // one settings instance per process (GPasteDaemonRunner), however many
        // times an unlock builds the indicator again.
        this._settings = extension.settings;
        this._destroyed = false;

        // The rows currently materialised in the scrollable history section.
        // We never hold the whole history: rows are appended in batches as the
        // user scrolls (lazy loading), so St does not have to lay out thousands
        // of actors it cannot recycle.
        this._history = [];
        this._filteredUuids = [];
        this._available = 0;
        this._loading = false;
        // The reads repopulating the list, cancelled and replaced by every pass
        // that starts one -- a reload, a search, a refresh. The list only ever
        // shows one of them, and the search entry asks again on every
        // keystroke: cancelling the others is what keeps a term the user has
        // typed past from painting the list (see replaceCancellable ()).
        this._listing = null;
        // The first row the pass out on _listing is to rebind, and whether it
        // is to leave the list where it was scrolled to, which the pass that
        // gives it up takes over: see _beginPass (). null once one answered,
        // one that failed leaving its first row to the next (_passFailed ()).
        this._passFrom = null;
        this._passKeepsPlace = true;
        // The row the keyboard was on when the daemon went, handed back once
        // the next one's rows are there: see _parkRowFocus (). -1 for none.
        this._owedRowFocus = -1;
        // Whether the keyboard was on anything else the daemon took out of the
        // menu, owed to the search once it is back: see _parkMenuFocus ().
        this._owedSearchFocus = false;

        // Whether there is a daemon to talk to. The client follows it while
        // there is none (g_paste_client_follow_daemon ()).
        this._connected = false;
        this._connecting = false;
        // The backoff between connection attempts, and what resumes _connect ()
        // when a teardown cuts one short.
        this._connectRetryId = 0;
        this._resumeConnect = null;
        // The focus grab an opening menu defers to an idle.
        this._selectSearchId = 0;
        // The search a keystroke waits to make (_onSearchChanged ()).
        this._searchDelayId = 0;

        this._dummyHistoryItem = new GPasteDummyHistoryItem();
        // Its own signal rather than 'activate', which would close the menu on
        // the row about to report what this did. Emitted only while it is saying
        // there is no daemon, or that the history could not be listed
        // (showFailed ()): the two states where the row is an offer rather than
        // a label, which _retry () tells apart.
        this._dummyHistoryItem.connect('retry', this._retry.bind(this));
        this.menu.addMenuItem(this._dummyHistoryItem);

        this._searchItem = new GPasteSearchItem();
        this._searchItem.connect('text-changed', this._onSearchChanged.bind(this));
        this._searchItem.connect('favourites-changed', this._reloadCurrent.bind(this));

        this._settings.connectObject(
            'notify::element-size', this._resetElementSize.bind(this),
            'notify::images-preview', this._resetImagesPreview.bind(this),
            'notify::images-preview-size', this._resetImagesPreview.bind(this),
            this);
        this._resetElementSize();

        this._setup().catch(console.error);
    }

    async _connect(retries = GPasteIndicator._CONNECT_RETRIES, delay = 1) {
        try {
            // GJS' Gio._promisify cannot replace the static GPaste.Client.new
            // constructor inside gnome-shell (the class-object property assignment
            // does not stick), so promise-wrap the raw async pair by hand.
            return await new Promise((resolve, reject) => {
                GPaste.Client.new((_source, res) => {
                    try {
                        resolve(GPaste.Client.new_finish(res));
                    } catch (e) {
                        reject(e);
                    }
                });
            });
        } catch (e) {
            if (retries <= 0) {
                console.error(`GPaste: ${e.message}`);
                return null;
            }
            await this._sleepBeforeRetry(delay);
            if (this._destroyed)
                return null;
            return this._connect(retries - 1, delay * 2);
        }
    }

    // The backoff between connection attempts, as a source we hold the id of
    // rather than a bare setTimeout: a teardown during one has something to
    // remove, where the timer would otherwise go on running -- for as long as
    // the rung it is on -- against an extension that has gone.
    //
    // Cancelling resolves the promise rather than dropping it, so _connect ()
    // resumes and reads _destroyed instead of hanging for good on a source that
    // no longer exists, holding the indicator with it.
    _sleepBeforeRetry(delay) {
        return new Promise(resolve => {
            this._resumeConnect = resolve;
            this._connectRetryId = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, delay, () => {
                this._connectRetryId = 0;
                this._resumeConnect = null;
                resolve();
                return GLib.SOURCE_REMOVE;
            });
            GLib.Source.set_name_by_id(this._connectRetryId, '[GPaste] connect retry');
        });
    }

    _cancelConnectRetry() {
        if (!this._connectRetryId)
            return;

        GLib.Source.remove(this._connectRetryId);
        this._connectRetryId = 0;
        this._resumeConnect();
        this._resumeConnect = null;
    }

    async _setup() {
        // Marks the window where this._client is not assigned yet. _connect ()
        // retries with a backoff, so that window is seconds long, and a second
        // _setup () started inside it -- the placeholder row is an offer the
        // whole time -- would build a second switch, search row, scroll view and
        // footer into the same menu, orphaning the first of each.
        this._connecting = true;
        try {
            this._client = await this._connect();
        } finally {
            this._connecting = false;
        }

        if (this._destroyed || !this._client) {
            // Out of retries: the placeholder has been saying "Loading…" all
            // this while, and now there is something to report.
            if (!this._destroyed)
                this._dummyHistoryItem.showDisconnected();
            this._client = null;
            return;
        }

        this._switch = new GPasteStateSwitch(this._client);
        this._historySwitcher = new GPasteHistorySwitcher(this._client, this._settings, this.menu);

        // Header, inserted before the dummy placeholder added in the constructor.
        // The switch is global state and belongs to nothing under it; the
        // history row names what everything under it -- the search and the list
        // both -- is about. So the two read global then scoped, rather than the
        // global one splitting the group the other three make.
        this.menu.addMenuItem(this._switch, 0);
        this.menu.addMenuItem(this._historySwitcher, 1);
        this.menu.addMenuItem(this._searchItem, 2);

        // The lazily-filled, scrollable history lives in a PopupMenuSection
        // wrapped in an St.ScrollView, between the dummy and the footer.
        this._historySection = new PopupMenuSection();
        this._scrollView = new St.ScrollView({
            hscrollbar_policy: St.PolicyType.NEVER,
            vscrollbar_policy: St.PolicyType.AUTOMATIC,
            overlay_scrollbars: true,
        });
        this._scrollView.child = this._historySection.actor;

        // One row of actions for every item row, moved under whichever asked
        // for it rather than one built per row: the list holds as many rows as
        // the menu is scrolled through, and only ever one of them is asked.
        this._itemActions = new GPasteItemActionsItem(this._scrollView);
        this._itemActions.connect('strip-rich-text', (item, uuid) => this._stripRichText(uuid));
        this._itemActions.connect('upload', (item, uuid) => this._upload(uuid));
        this._historySection.addMenuItem(this._itemActions);
        this._itemActions.hide();
        // The row they are open under: rows are recycled, so which item it
        // shows can change under them, and rebinding it folds them (_refresh ()).
        this._itemActionsRow = null;

        // Fade the history out near the top/bottom edges rather than hard-clipping
        // it against the dummy row and the footer separator.
        this._scrollView.update_fade_effect(new Clutter.Margin({top: 16, bottom: 16}));

        this._footer = addGPasteFooter(this.menu, this._extension);

        const dummyIndex = this.menu.box.get_children().indexOf(this._dummyHistoryItem);
        this.menu.box.insert_child_at_index(this._scrollView, dummyIndex + 1);

        this._updateScrollHeight();

        // The max-height is derived from the work area of the monitor the
        // indicator lives on; recompute it when the monitor layout changes
        // (resolution, monitor hot-plug, panel moved to another monitor).
        Main.layoutManager.connectObject('monitors-changed', this._updateScrollHeight.bind(this), this);
        St.ThemeContext.get_for_stage(global.stage).connectObject('notify::scale-factor', this._updateScrollHeight.bind(this), this);

        // "changed" fires when the content/viewport is resized (fill until the
        // viewport overflows); "notify::value" fires on scroll (load the next
        // batch when the bottom is reached).
        this._scrollView.vadjustment.connectObject(
            'changed', this._maybeLoadMore.bind(this),
            'notify::value', this._maybeLoadMore.bind(this),
            this);

        this._client.connectObject(
            'update', this._update.bind(this),
            'show-history', this._popup.bind(this),
            'tracking', this._toggle.bind(this),
            'notify::daemon-presence', this._onDaemonPresenceChanged.bind(this),
            this);
        this._client.follow_daemon(false);

        // The proxy is built whether or not a daemon answered, and it follows
        // the bus name across a re-exec on its own, so this is the first place
        // that can tell one case from the other. Read once the handler above is
        // watching, and not before: a daemon leaving in between would go
        // unannounced, and _onDaemonStateChanged () would then find the very
        // state it was told to expect and stand down for the rest of the
        // session.
        this._connected = this._daemonReady();

        if (!this._connected)
            this._onDaemonGone();

        // A no-op with no daemon there, and deliberately: see _onStateChanged ().
        // _onDaemonAppeared () reports it once one turns up.
        this._onStateChanged(true);

        // The ctrl-index overlay and ctrl+0-9 selection watch the keyboard for
        // the whole menu rather than any one row, so they hang off a controller
        // on the menu's actor: the menu object itself is a Signals.EventEmitter
        // and has no actor tree of its own to carry actions.
        //
        // Its own name, not _keyController: that one is the controller
        // PanelMenu.Button installs for _onMenuKeyPress ().
        this._indexKeyController = new Clutter.KeyController();
        this._indexKeyController.connectObject(
            'key-press', this._onIndexKeyPress.bind(this),
            // The overlay follows the modifier itself rather than the press and
            // release of the two Control keysyms, so it also gets latched and
            // locked ctrl right (sticky keys), and never misses a release that
            // happened while the menu did not have the focus.
            'modifier-change', this._onModifierChange.bind(this),
            this);
        this.menu.actor.add_action(this._indexKeyController);

        // Last, being the one step that waits on the daemon: one that drops out
        // while it is in flight rejects the call, and a rejection out of here
        // abandons the rest of this function -- so everything that notices a
        // daemon leaving and offers a way back is connected above it, where an
        // abandoned setup costs the indicator neither its daemon handler nor the
        // client's wait for one for the session.
        if (this._connected)
            await this._reload();
    }

    // @extensionDisabled: whether the extension itself is going away, as opposed
    // to the indicator merely being torn down for a non-user session mode (the
    // lock screen), where the extension — and the in-shell daemon it may host —
    // deliberately stays enabled.
    //
    // Returns whether the extension's state was reported to the daemon, so the
    // caller knows when it still has to report it some other way: we can only do
    // it through a client we may never have got (the daemon was unreachable, or
    // is still being connected to).
    shutdown(extensionDisabled) {
        this._destroyed = true;
        // Only report the extension's own state: "track-extension-state" users
        // ask the daemon to stop tracking when the extension goes away, and the
        // lock screen is not that. Reporting it there would stop recording the
        // clipboard for the whole locked session, which is exactly what the
        // "unlock-dialog" session mode exists to prevent.
        const reported = extensionDisabled && !!this._client && this._connected;

        if (reported)
            this._onStateChanged(false);

        // destroy() runs _onDestroy(); don't call it a second time here.
        this.destroy();

        return reported;
    }

    // What the client says of the daemon, which reads a daemon that owns the
    // bus name but has not built what it serves yet as starting, not there.
    _daemonReady() {
        return this._client?.daemon_presence === GPaste.DaemonPresence.READY;
    }

    // A daemon appearing or going away is a change of what the whole menu can
    // say, so it is answered here rather than by each path finding out for
    // itself that its call went nowhere.
    //
    // Returns whether the state actually moved, which is what _reconcileConnection()
    // asks: a caller that gave up on a daemon still sitting there has been told
    // nothing by this, and has its own repainting to do.
    _onDaemonStateChanged() {
        const connected = this._daemonReady();

        if (connected === this._connected)
            return false;

        if (connected)
            this._onDaemonAppeared();
        else
            this._onDaemonGone();

        return true;
    }

    // Between those two edges, the daemon going from starting to absent -- a
    // second after it left nobody owning the name, or once the client gave up
    // on an owner that never served -- is what the placeholder row says.
    _onDaemonPresenceChanged() {
        if (!this._onDaemonStateChanged() && !this._connected)
            this._updateVisibility(true);
    }

    _onDaemonAppeared() {
        this._connected = true;
        // Held back for as long as there was no daemon to tell, this one having
        // come up after the extension did.
        this._onStateChanged(true);
        this._reloadCurrent();
    }

    // Drop everything the menu was showing of a history it can no longer speak
    // for. @_available reaching 0 before the rows go is what the order is for:
    // emptying them moves the scroll adjustment, and its "changed" would have
    // _maybeLoadMore() fill them again from a count that still said there was
    // more to come.
    _forgetHistory() {
        this._available = 0;
        this._filteredUuids = [];
        this._clearRows();
        this._updateVisibility(true);
    }

    _onDaemonGone() {
        const focusIndex = this._focusedRowIndex();
        const focus = global.stage.get_key_focus();
        // The search, its star, the tracking switch and the history switcher go
        // with the daemon too (_updateVisibility ()), and their focus with them.
        const menuFocus = focusIndex < 0 && focus !== null && focus !== this.menu.actor &&
            this.menu.actor.contains(focus);

        this._connected = false;
        // A reply about the history that just went away must not land on the
        // rows the next daemon fills. Cancelled and no more: every path that
        // lists again opens with its own replaceCancellable(), so a successor
        // installed here would be replaced before a request could go out on it.
        this._listing?.cancel();
        this._forgetHistory();
        this._parkRowFocus(focusIndex);
        if (menuFocus)
            this._parkMenuFocus();
    }

    // The placeholder row was activated: try again now -- asking for a daemon
    // rather than waiting for one, since this is the user asking -- and start
    // the client's wait over.
    _retry() {
        // Neither guard here is one a row alone can reach -- the placeholder goes
        // with the menu, and shows Loading, insensitive, while _connecting --
        // which is why no test sees one missing: they keep a stray call
        // harmless.
        if (this._destroyed)
            return;

        // A _setup () still inside _connect () owns the rebuild; starting
        // another here is what would duplicate the menu.
        if (this._connecting)
            return;

        // The menu stays open on activation, so this is the row the user is
        // still looking at: it says the offer was taken before anything goes out
        // on the bus, and whoever answers paints the outcome over it. It also
        // stops being an offer while that is in flight, a second click having
        // nothing to add to the first.
        this._dummyHistoryItem.showLoading();

        // A daemon there whose listing failed (_reconcileConnection ()): asked
        // again.
        if (this._connected) {
            this._reloadCurrent();
            return;
        }

        // Running out of connect retries leaves no proxy at all, so there is
        // nothing to probe with, and the row would be an offer that does
        // nothing. _setup () returned before it built anything in that case, so
        // what it takes is simply running it again.
        if (!this._client) {
            this._setup().catch(console.error);
            return;
        }

        this._client.retry_daemon();
    }

    _onIndexKeyPress() {
        if (!this._controlHeld())
            return Clutter.EVENT_PROPAGATE;

        // gunichar comes back as a one-character string, so the digit it stands
        // for is simply what parses out of it.
        const [, , , unicode] = this._indexKeyController.get_key();
        const nb = parseInt(unicode, 10);

        if (Number.isNaN(nb) || nb < 0 || nb > 9 || nb >= this._history.length)
            return Clutter.EVENT_PROPAGATE;

        this._history[nb].activate(Clutter.get_current_event());

        return Clutter.EVENT_STOP;
    }

    _onModifierChange() {
        this._updateIndexVisibility(this._controlHeld());

        return Clutter.EVENT_PROPAGATE;
    }

    // Held, latched or locked all count: what the overlay answers is whether
    // ctrl+0-9 would select right now, which is the same question.
    _controlHeld() {
        const [, pressed, latched, locked] = this._indexKeyController.get_state();

        return ((pressed | latched | locked) & Clutter.ModifierType.CONTROL_MASK) !== 0;
    }

    _updateIndexVisibility(state) {
        this._history.slice(0, 10).forEach(i => {
            i.showIndex(state);
        });
    }

    _hasSearch() {
        return this._searchItem.text.length > 0;
    }

    // Both filters list rows by uuid rather than by history position, so they
    // share every path that cares about which of the two the list is showing.
    _isFiltered() {
        return this._hasSearch() || this._searchItem.favourites;
    }

    _totalSize() {
        return this._isFiltered() ? this._filteredUuids.length : this._available;
    }

    _resetElementSize() {
        const size = this._settings.get_element_size();
        // 0 is no limit on the rows, not a three-character search box.
        this._searchItem.resetSize((size || GPasteIndicator._UNLIMITED_ELEMENT_SIZE) / 2 + 3);
        this._history.forEach(i => {
            i.setTextSize(size);
        });
    }

    _resetImagesPreview() {
        const enabled = this._settings.get_images_preview();
        const size = this._settings.get_images_preview_size();

        this._history.forEach(i => {
            i.setImagesPreview(enabled, size);
        });
    }

    _createRow(elementSize, slotIndex, index, uuid = null) {
        const item = new GPasteItem(this._client, elementSize, slotIndex, index, uuid);
        // Before the row's own fetch can land: the constructor only starts it,
        // so the settings are in place by the time there is a kind to act on.
        item.setImagesPreview(this._settings.get_images_preview(), this._settings.get_images_preview_size());
        // The rows live in a section that is not part of the menu's item tree
        // (it is nested in the scroll view), so close the menu on activation
        // ourselves rather than relying on the usual menu-item plumbing.
        item.connect('activate', () => this.menu.itemActivated());
        // The rows live in a nested scroll view, which does not scroll a
        // keyboard-focused child into view on its own; do it ourselves so
        // arrow-key navigation never lands on a row clipped outside the
        // viewport (and so Up from the actions reveals the last row).
        item.connect('key-focus-in', () => ensureActorVisibleInScrollView(this._scrollView, item));
        item.connect('actions', (row, shown, fromKeyboard) => this._toggleItemActions(row, shown, fromKeyboard));
        // Appended at the end, which leaves open actions under their row.
        this._historySection.addMenuItem(item);
        this._history.push(item);
        return item;
    }

    _clearRows() {
        // Before the rows go, and without handing the focus back: the row it
        // would go to is among them (see _hideItemActions ()).
        this._hideItemActions(false);
        this._history.forEach(i => i.destroy());
        this._history = [];
    }

    // As the history switcher's _toggleActions () does its rows'.
    _toggleItemActions(row, uuid, fromKeyboard) {
        if (this._itemActions.visible && this._itemActionsRow === row) {
            this._hideItemActions();
            return;
        }

        const index = this._history.indexOf(row);

        if (index < 0)
            return;

        this._itemActionsRow = row;
        this._itemActions.reset(uuid);
        this._historySection.moveMenuItem(this._itemActions, index + 1);
        this._itemActions.show();
        // The list is scrolled, and the row that asked may be the last one in
        // view: the actions would otherwise open below the viewport.
        ensureActorVisibleInScrollView(this._scrollView, this._itemActions);

        if (fromKeyboard)
            this._itemActions.focus();
    }

    // As the history switcher's _hideActions() says: the keyboard goes back to
    // the row the actions were for. _refresh() and _rebuild() pick a surviving
    // focus target after changing the rows. Reached from teardown as well,
    // which may come before _setup () has built any of this.
    _hideItemActions(refocus = true) {
        if (!this._itemActions)
            return;

        const focus = global.stage.get_key_focus();

        if (refocus && focus !== null && this._itemActions.contains(focus))
            this._itemActionsRow?.grab_key_focus();

        this._itemActions.hide();
        this._itemActions.reset();
        this._itemActionsRow = null;
    }

    // Whether @focus is where the focus a row is owed waits: the menu's actor,
    // or the placeholder row, which the Shell hands the focus of a menu with no
    // active item to once it turns sensitive (popupMenu.js, notify::sensitive)
    // -- after the grace second, when the presence reads absent.
    _holdsOwedFocus(focus) {
        return (this._owedRowFocus >= 0 || this._owedSearchFocus) &&
            (focus === this.menu.actor || focus === this._dummyHistoryItem);
    }

    // Which row the keyboard is on, the actions under one counting as that
    // row, and its pin and delete buttons too: -1 for none. Where the focus a
    // row is owed waits counts as that row.
    _focusedRowIndex() {
        const focus = global.stage.get_key_focus();

        if (focus === null || focus === global.stage)
            return -1;
        if (focus === this.menu.actor || this._holdsOwedFocus(focus))
            return this._owedRowFocus;
        if (this._itemActions.contains(focus))
            return this._history.indexOf(this._itemActionsRow);

        return this._history.findIndex(row => row === focus || row.contains(focus));
    }

    // After a pass that may have dropped the row @index was the keyboard on,
    // or hidden the actions under it: the focus goes to the nearest row left,
    // or the history switcher when none is -- but only if it was lost, Clutter
    // handing a destroyed or hidden actor's focus to the stage.
    _restoreRowFocus(index) {
        const focus = global.stage.get_key_focus();
        const parked = this._holdsOwedFocus(focus);

        if (index < 0 || (focus !== null && focus !== global.stage && !parked))
            return;

        // A focus owed across a daemon's absence waits for rows to give it to:
        // the first answer of the next daemon can be an empty one, its history
        // still loading, and the history switcher is not where it was.
        if (parked && this._history.length === 0)
            return;

        this._owedRowFocus = -1;
        (this._history[Math.min(index, this._history.length - 1)] ?? this._historySwitcher).grab_key_focus();
    }

    // The rows go with the daemon, and the switch, the history switcher and
    // the search with them, which leaves nothing in the menu to take a focus
    // that was on a row: Clutter would hand it to the stage, and the keyboard
    // would reach nothing until the menu reopened. So the menu itself holds
    // it, and the row is owed it back once the next daemon's rows are there
    // (_rebuild ()) -- however briefly the daemon was away, a handoff to
    // another being one such spell. The graphical tool's list does the same
    // (g_paste_ui_history_clear_display ()).
    _parkRowFocus(index) {
        const focus = global.stage.get_key_focus();

        if (index < 0 || (focus !== null && focus !== global.stage))
            return;

        this._owedRowFocus = index;
        this.menu.actor.grab_key_focus();
    }

    // As _parkRowFocus () for a focus that was on anything else in the menu
    // the daemon took away: held by the menu, and owed to the search once the
    // daemon is back (_restoreSearchFocus ()).
    _parkMenuFocus() {
        const focus = global.stage.get_key_focus();

        if (focus !== null && focus !== global.stage)
            return;

        this._owedSearchFocus = true;
        this.menu.actor.grab_key_focus();
    }

    // As _restoreRowFocus () for that focus: the search's, or the history
    // switcher's when the history is empty, the search hidden with it.
    _restoreSearchFocus() {
        if (!this._owedSearchFocus)
            return;

        const parked = this._holdsOwedFocus(global.stage.get_key_focus());

        // As in _restoreRowFocus ().
        if (parked && this._history.length === 0)
            return;

        this._owedSearchFocus = false;
        if (!parked)
            return;

        if (this._searchItem.visible)
            this._searchItem.grabFocus();
        else
            this._historySwitcher.grab_key_focus();
    }

    _stripRichText(uuid) {
        this._hideItemActions();
        this._client.strip_rich_text(uuid, null, logFailure('strip_rich_text_finish'));
    }

    // Uploaded, and the address put where the user can paste it, daemon-side
    // (UploadAndCopy's doc in the D-Bus XML says why there): the address
    // arrives in the list as an item of its own, through the update the daemon
    // raises for it, unless the history refused it. This only tells the user
    // how it went.
    _upload(uuid) {
        this._hideItemActions();
        // An upload may outlive a destroyed indicator until the D-Bus call's
        // ten-minute deadline; its callback only needs the indicator to notify.
        this._client.upload_and_copy(uuid, null, onUploadDone.bind(null, new WeakRef(this)));
    }

    _scrollToTop() {
        // Bringing the first row into view resets to the top; unlike poking the
        // adjustment directly it animates and cooperates with the fade effect.
        // With no row to target (empty history or no search results) there is
        // nothing to scroll to, so just pin the adjustment to the top.
        if (this._history.length > 0) {
            ensureActorVisibleInScrollView(this._scrollView, this._history[0]);
        } else {
            const adjustment = this._scrollView.vadjustment;
            adjustment.value = adjustment.lower;
        }
    }

    _loadMore() {
        if (this._loading || !this._client)
            return;

        this._loading = true;

        try {
            const elementSize = this._settings.get_element_size();
            const filtered = this._isFiltered();
            const start = this._history.length;
            const end = Math.min(this._totalSize(), start + this._fillBatch());

            for (let i = start; i < end; ++i)
                this._createRow(elementSize, i, filtered ? -1 : i, filtered ? this._filteredUuids[i] : null);
        } finally {
            // Never leave _loading stuck true on a throw, or lazy loading wedges
            // for the rest of the session.
            this._loading = false;
        }
    }

    // One batch is a viewport's worth of rows: enough to fill the visible area
    // so the menu always has something to scroll to while more history remains.
    // The average row height is derived from the laid-out content (upper /
    // loaded); before anything is laid out we fall back to a fixed count.
    _fillBatch() {
        const adjustment = this._scrollView.vadjustment;
        const page = adjustment.page_size;
        const loaded = this._history.length;

        if (page > 0 && loaded > 0 && adjustment.upper > 0) {
            const rowHeight = adjustment.upper / loaded;
            return Math.max(1, Math.ceil(page / rowHeight) + 1);
        }

        return GPasteIndicator._DEFAULT_BATCH;
    }

    _maybeLoadMore() {
        if (!this._client || this._loading || this._history.length >= this._totalSize())
            return;

        const adjustment = this._scrollView.vadjustment;
        const page = adjustment.page_size;

        if (page <= 0) // not allocated yet
            return;

        const overflowing = adjustment.upper > page;
        const atBottom = (adjustment.value + page) >= (adjustment.upper - 1);

        if (!overflowing || atBottom)
            this._loadMore();
    }

    // Ask the daemon how big the current history is and record it. @cancellable
    // is the caller's, which every path that repopulates the list replaces on
    // entry, so a reload (or a search, or a refresh) started while we were
    // awaiting makes this one stale: drop out rather than publish an answer
    // about a history nobody is showing any more, and likewise once the client
    // has gone.
    //
    // Returns whether the caller may carry on.
    async _fetchAvailable(cancellable) {
        // Sizing asks about the current history, whichever that is, of a
        // daemon that is there: the presence says so, not the history the
        // proxy has cached, which mid-handoff is still the old daemon's -- the
        // one the call would reach.
        if (!this._daemonReady())
            return false;

        let wanted, available;

        // The name having an owner is not the daemon answering: it may go in
        // between, or the call may time out. A size that never came back is the
        // same "nothing to size" as no daemon at all, and the caller reconciles
        // either way -- an exception escaping here would skip that instead.
        try {
            [wanted, available] = await awaitReply(cancellable, this._client.get_history_size(cancellable));
        } catch (e) {
            // Its daemon gone, the presence says so next: no failure to log.
            if (!daemonGone(e))
                console.error(e);
            return false;
        }

        if (!wanted || !this._client)
            return false;

        this._available = available;
        return true;
    }

    async _reload() {
        if (!this._client)
            return;

        const [cancellable] = this._beginPass(0, false);
        const filtered = this._filteredUuids;

        this._filteredUuids = [];

        if (!await this._fetchAvailable(cancellable)) {
            // Rows bound to a filtered answer, in a list the cleared search or
            // filter now counts unfiltered: kept, lazy loading would append
            // history rows after them, and an update at a position would re-read
            // whichever stood there. Gone, the placeholder says why.
            if (filtered.length > 0 && !cancellable.is_cancelled())
                this._clearRows();
            this._passFailed(cancellable);
            return;
        }

        // The entry may have taken a search since: typing over its whole text
        // empties it first, which lists the history at once, and only then
        // arms the search's delay (_onSearchChanged ()). The rows wait for that
        // search, which rebinds every one of them, rather than be rebuilt for a
        // filtered list this answer has nothing of -- blanked until it lands.
        if (this._isFiltered())
            return;

        this._passFrom = null;
        this._rebuild(this._available === 0);
    }

    // A pass that failed leaves the next one its first row -- the rows it never
    // rebound still need rebinding -- but not its place: a failed reload's,
    // inherited, would send an update's refresh back to the top of the list.
    _passFailed(cancellable) {
        if (!cancellable.is_cancelled())
            this._passKeepsPlace = true;
        this._reconcileConnection(cancellable);
    }

    // A fetch gives up when there is no daemon left to ask, and nothing on that
    // path repaints the menu: _rebuild() is what calls _updateVisibility() and
    // it is not reached, so the rows and the placeholder would go on describing
    // a daemon that has gone -- or, for a reload that ran right after one came
    // back, one that is here. So the state is reconciled instead, which is the
    // same question "notify::daemon-presence" answers and lands in the same
    // place. A newer reload owns it once it has cancelled @cancellable.
    //
    // Guarded like every other path resuming after an await: the indicator may
    // have been destroyed while the call was out, and _onDaemonGone() would then
    // paint destroyed actors.
    _reconcileConnection(cancellable) {
        if (this._destroyed || cancellable.is_cancelled())
            return;

        // A daemon that has gone is a change of state, and _onDaemonStateChanged()
        // repaints the whole menu for it. One that is still there and simply did
        // not answer is not a change of anything -- nor is one whose call failed
        // because it was leaving, before the presence says so: the rows a failed
        // call could not refresh stay as they are, as the graphical tool's do,
        // and where there are none the placeholder says the history could not
        // be listed and offers to try again (_retry ()), the search staying for
        // a keystroke to ask again too.
        if (this._onDaemonStateChanged() || this._history.length > 0)
            return;

        // The controls a daemon there offers -- the search, the tracking
        // switch, the history switcher -- only a pass that answered shows
        // otherwise, and this one may be the first since the daemon turned up.
        this._updateVisibility(false);
        this._dummyHistoryItem.showFailed();
    }

    // A search asks the daemon to match; the favourites filter asks it for the
    // pinned items; with both on, only the matches are left to sift, and those
    // are the narrow set already.
    // @keepPlace for one an update re-runs, the list staying where it was
    // scrolled to rather than going back to its top (_rebuild ()).
    async _runFilter(keepPlace = false) {
        if (!this._client)
            return;

        const [cancellable, , keptPlace] = this._beginPass(0, keepPlace);
        let wanted, items;

        // As typed, the daemon matching whatever the case. A daemon that has
        // gone fails the match rather than answering an empty one, and nothing
        // further down repaints the menu: reconciled here as a fetch that gave
        // up is, so a filtered list does not go on showing rows for a history
        // nobody can reach.
        try {
            [wanted, items] = await awaitReply(cancellable, this._hasSearch()
                ? this._client.search_text(this._searchItem.text, cancellable)
                : this._client.get_favourites(cancellable));
        } catch (e) {
            // As in _fetchAvailable ().
            if (!daemonGone(e))
                console.error(e);
            this._passFailed(cancellable);
            return;
        }

        if (!wanted || !this._client)
            return;

        this._passFrom = null;
        this._filteredUuids = items
            .filter(item => !this._hasSearch() || !this._searchItem.favourites || item.is_favourite())
            .map(item => item.get_uuid());
        this._rebuild(this._filteredUuids.length === 0, keptPlace);
    }

    // Reconcile the materialised rows with the current content (history or
    // search results) in place rather than tearing them all down: update the
    // rows we keep, drop any surplus, create any shortfall, then scroll back to
    // the top unless @keepPlace. Reusing the actors avoids the flicker (and
    // focus loss) of rebuilding the whole list on every search keystroke and
    // when entering or leaving search. Shared by the full reload and the
    // search paths.
    _rebuild(empty, keepPlace = false) {
        // The rows are about to be rebound, dropped and added: which of them
        // shows the item the actions are open for is not known again until
        // those rebindings land, and the list has moved under whoever opened
        // them anyway.
        const focusIndex = this._focusedRowIndex();

        this._hideItemActions(false);

        // Hold off lazy loading while the row count (and thus the scroll
        // adjustment) is in flux, so a re-entrant _maybeLoadMore() can't fire.
        this._loading = true;

        try {
            const filtered = this._isFiltered();
            const total = this._totalSize();
            const elementSize = this._settings.get_element_size();

            // Keep a viewport's worth of rows, or the whole content when it is
            // smaller; never drop the rows we already loaded past that (lazy
            // loading tops the list up again on scroll).
            const target = Math.min(total, Math.max(this._history.length, this._fillBatch()));

            while (this._history.length > target)
                this._history.pop().destroy();

            for (let i = 0; i < this._history.length; ++i) {
                if (filtered)
                    this._history[i].setUuid(this._filteredUuids[i]).catch(debugFailure);
                else
                    this._history[i].setIndex(i).catch(debugFailure);
            }

            for (let i = this._history.length; i < target; ++i)
                this._createRow(elementSize, i, filtered ? -1 : i, filtered ? this._filteredUuids[i] : null);
        } finally {
            this._loading = false;
        }

        this._updateVisibility(empty);
        // A new list starts at its top; one an update re-listed stays where it
        // was, the keyboard on the same slot: scrolled back up, a row it went on
        // to would be out of view, and a second Delete would delete an item the
        // user cannot see.
        if (!keepPlace)
            this._scrollToTop();
        this._restoreRowFocus(focusIndex);
        this._restoreSearchFocus();

        const focused = this._history[this._focusedRowIndex()];

        if (keepPlace && focused)
            ensureActorVisibleInScrollView(this._scrollView, focused);
    }

    _cancelSearchDelay() {
        if (this._searchDelayId) {
            GLib.Source.remove(this._searchDelayId);
            this._searchDelayId = 0;
        }
    }

    // A search waits for the typing to pause, as GtkSearchEntry's own delay has
    // the graphical tool's: cancelling the one before only drops its reply,
    // D-Bus having no way to call off a method already sent, so without it the
    // daemon would match the whole history once per character. An emptied
    // entry lists the history at once.
    _onSearchChanged() {
        this._cancelSearchDelay();

        if (!this._hasSearch()) {
            this._reloadCurrent();
            return;
        }

        this._searchDelayId = GLib.timeout_add_once(GLib.PRIORITY_DEFAULT, GPasteIndicator._SEARCH_DELAY, () => {
            this._searchDelayId = 0;
            this._reloadCurrent();
        });
        GLib.Source.set_name_by_id(this._searchDelayId, '[GPaste] search delay');
    }

    _reloadCurrent() {
        // Nothing to ask and nothing to list; re-assert what the menu says
        // instead, since this is also what every menu opening goes through.
        if (!this._connected) {
            this._updateVisibility(true);
            return;
        }

        if (this._isFiltered())
            this._runFilter().catch(console.error);
        else
            this._reload().catch(console.error);
    }

    // Reconcile the materialised rows with the current history in place rather
    // than tearing them all down and rebuilding: drop the rows past the new
    // size, re-fetch the content of those at and after @from (their items
    // shifted), then top up if the viewport gained room.
    async _refresh(refreshFrom) {
        if (!this._client)
            return;

        const [cancellable, from, keepPlace] = this._beginPass(refreshFrom, true);

        if (!await this._fetchAvailable(cancellable)) {
            this._passFailed(cancellable);
            return;
        }

        this._passFrom = null;

        const available = this._available;

        // The rows from @from on are about to show other items, and those past
        // the new size to go: actions open under one of them would be under a
        // row that no longer shows what they act on.
        const focusIndex = this._focusedRowIndex();

        if (this._history.indexOf(this._itemActionsRow) >= from)
            this._hideItemActions(false);

        while (this._history.length > available)
            this._history.pop().destroy();

        for (let i = from; i < this._history.length; ++i)
            this._history[i].setIndex(i).catch(debugFailure);

        this._updateVisibility(available === 0);
        if (!keepPlace)
            this._scrollToTop();

        // A list with no row lays out at no height, which _maybeLoadMore ()
        // takes for one not allocated yet: its rows are made outright, as
        // _rebuild () makes them.
        if (this._history.length === 0 && available > 0)
            this._loadMore();
        else
            this._maybeLoadMore();

        // Once the rows are there: a focus owed across a daemon's absence goes
        // to one of them, or the search, as _rebuild () pays it.
        this._restoreRowFocus(focusIndex);
        this._restoreSearchFocus();
    }

    // Every pass repopulating the list goes out on _listing, giving up the one
    // before -- whose reply, dropped, then never rebinds the rows it was to,
    // from its own @from on, nor scrolls back to the top a new list starts at.
    // So the pass that gives it up rebinds from the earlier of the two -- a
    // refresh superseding a reload or a filter, which rebind every row, from
    // the first -- and leaves the list where it was only if both were to: an
    // update's re-run superseding a new search, or a refresh an emptied one,
    // would otherwise show the new list at the old one's offset. Returns the
    // cancellable, that row and whether the list keeps its place.
    _beginPass(from, keepPlace) {
        if (this._passFrom !== null) {
            from = Math.min(from, this._passFrom);
            keepPlace &&= this._passKeepsPlace;
        }

        this._passFrom = from;
        this._passKeepsPlace = keepPlace;
        this._listing = replaceCancellable(this._listing);

        return [this._listing, from, keepPlace];
    }

    _update(client, action, target, uuid, position) {
        // Nothing to apply an update to while the daemon is away, the rows
        // having gone with it, and the next one is listed afresh. The client
        // forwards no update from a daemon that has lost the name
        // (g_paste_client_g_signal ()), so this keeps one rule -- a daemon to
        // ask is the presence being ready -- rather than leaning on that.
        if (!this._connected)
            return;

        // A filtered list maps its rows to uuids rather than to history
        // positions, so a position says nothing to it. One item changing in
        // place is still worth catching by uuid; anything else means re-running
        // the filter. Not in a pinned-only list, though: what just changed there
        // may be the very flag that puts a row in it, and the update names the
        // item rather than what became of its flag, so it asks again.
        if (this._isFiltered()) {
            if (!this._searchItem.favourites &&
                target === GPaste.UpdateTarget.ITEM && action === GPaste.UpdateAction.REPLACE) {
                const row = this._history.find(i => i.uuid === uuid);

                if (row) {
                    row.refresh();
                    return;
                }
            }

            this._runFilter(true).catch(console.error);
            return;
        }

        switch (target) {
        case GPaste.UpdateTarget.ALL:
            this._refresh(0).catch(console.error);
            break;
        case GPaste.UpdateTarget.ITEM:
            switch (action) {
            case GPaste.UpdateAction.REPLACE:
                this._history[position]?.refresh();
                break;
            case GPaste.UpdateAction.REMOVE:
                this._refresh(position).catch(console.error);
                break;
            }
            break;
        }
    }

    _updateVisibility(empty) {
        // The tracking switch acts on a daemon: offered with none there it
        // would either fail unreported or quietly start the one the client
        // waits for without calling, showing the state the user just set
        // either way.
        if (this._switch)
            this._switch.visible = this._connected;

        // Hidden for the same reason, and one of its own: it names a daemon's
        // history, and switching is an ordinary method call -- which is also
        // what bus-activates a daemon.
        if (this._historySwitcher)
            this._historySwitcher.visible = this._connected;

        if (!this._connected) {
            // A _connect () still retrying is a daemon starting with nothing to
            // ask it of -- there is no proxy yet -- and a row offering a retry
            // there is one _retry () refuses, the connection in flight owning
            // the rebuild. A row that only ever says "Loading…" is not reactive
            // and offers no way out, which is why the client stops reporting a
            // daemon that never serves as starting once its wait gives up.
            if (this._connecting || this._client?.daemon_presence === GPaste.DaemonPresence.STARTING)
                this._dummyHistoryItem.showLoading();
            else
                this._dummyHistoryItem.showDisconnected();

            this._searchItem.hide();
            return;
        }

        if (!empty) {
            this._dummyHistoryItem.hide();
            this._searchItem.show();
        } else if (this._hasSearch()) {
            this._dummyHistoryItem.showNoResult();
            this._searchItem.show();
        } else if (this._searchItem.favourites) {
            this._dummyHistoryItem.showNoPinned();
            this._searchItem.show();
        } else {
            this._dummyHistoryItem.showEmpty();
            this._searchItem.hide();
        }
    }

    _popup() {
        this.menu.open();
    }

    _toggle(c, state) {
        this._switch.syncState(state);
    }

    _selectSearch() {
        if (this._history.length > 0)
            this._searchItem.grabFocus();
    }

    // Reported only while there is a daemon to report it to. The proxy is built
    // with G_DBUS_PROXY_FLAGS_NONE, so this is an ordinary call on an
    // activatable service: made with none there it would start the very daemon
    // the client's wait refuses to start on its own, within a second of the user
    // stopping it and with nothing they could do about it short of turning the
    // extension off.
    _onStateChanged(state) {
        if (this._client && this._connected)
            this._client.report_extension_state(state, null, logFailure('report_extension_state_finish'));
    }

    _onOpenStateChanged(menu, state) {
        // Whatever the last change scheduled was for a menu in the state it has
        // just left: a search typed just before closing is not run on the
        // closed menu, and the next opening lists afresh anyway.
        this._cancelSelectSearch();
        this._cancelSearchDelay();

        if (state) {
            // The menu opens on the history, so both filters go; reset() drops
            // them without announcing either, which is what leaves this one
            // reload to cover the pair rather than one round trip per filter
            // that happened to be on.
            this._searchItem.reset();
            this._reloadCurrent();
            // Held by its id: the grab is for a menu that is open, and a close
            // or a teardown before the idle runs leaves it reaching into one
            // that is not.
            this._selectSearchId = GLib.idle_add_once(GLib.PRIORITY_DEFAULT_IDLE, () => {
                this._selectSearchId = 0;
                this._selectSearch();
            });
            GLib.Source.set_name_by_id(this._selectSearchId, '[GPaste] select search');
        } else {
            this._updateIndexVisibility(false);
            // Never reopen expanded: the menu opens on the history it is already
            // in, and the chooser is a detour from that.
            this._historySwitcher?.collapse();
            // Nor reopen on the actions of a row: the focus is the menu's own
            // to hand back here, so they are folded without taking it.
            this._hideItemActions(false);
            // The focus goes with the menu, and a row owed it is not owed it
            // on the next opening, nor is the search.
            this._owedRowFocus = -1;
            this._owedSearchFocus = false;
        }
        super._onOpenStateChanged(menu, state);
    }

    _cancelSelectSearch() {
        if (this._selectSearchId) {
            GLib.Source.remove(this._selectSearchId);
            this._selectSearchId = 0;
        }
    }

    // The footer items are menu items and walk among themselves, but the
    // history above them is not in the menu's item tree -- its rows live in
    // a section nested in the scroll view -- so Up from the first of them has
    // nothing there to land on. Bridge that one step.
    //
    // Runs after the focus manager's own controller on the same actor, so it
    // only ever sees an Up the ordinary navigation had no answer for. Every
    // other key chains up, which is what leaves PanelMenu.Button its Left/Right
    // walk to the neighbouring panel menus.
    //
    // Both ways a shell calling itself 51 invokes this are served: 51.rc reads
    // the key off the controller it installs and passes nothing, while 51.beta
    // still connects 'key-press-event' and passes (actor, event). The key comes
    // from the event we were handed when there is one, and otherwise from the
    // one Clutter is dispatching -- what upstream's own binding closures read.
    // Neither is promised: get_current_event() answers null outside a dispatch,
    // and a key this override cannot name is one it has no answer for, so it
    // chains up like any other. Whatever we were handed goes back to the parent
    // untouched.
    _onMenuKeyPress(...args) {
        if (this._switch && this._switch.active)
            return super._onMenuKeyPress(...args);

        const symbol = args[1]?.get_key_symbol() ?? Clutter.get_current_event()?.get_key_symbol();

        if (symbol !== Clutter.KEY_Up)
            return super._onMenuKeyPress(...args);

        const focus = global.stage.get_key_focus();

        if (!this._footer || !focus || !this._footer.open.contains(focus))
            return super._onMenuKeyPress(...args);

        const last = this._lastHistoryItem();

        if (!last)
            return super._onMenuKeyPress(...args);

        last.grab_key_focus();

        return Clutter.EVENT_STOP;
    }

    _lastHistoryItem() {
        for (let i = this._history.length - 1; i >= 0; --i) {
            if (this._history[i].visible)
                return this._history[i];
        }
        return null;
    }

    _updateScrollHeight() {
        // Size against the monitor the indicator (and thus its menu) lives on,
        // not always the primary one.
        const monitor = Main.layoutManager.findIndexForActor(this);
        const workArea = Main.layoutManager.getWorkAreaForMonitor(monitor);
        // The work area is in physical pixels, and St scales a stylesheet's by
        // the UI scale factor: divided out, as PanelMenu's own max-height is.
        const {scaleFactor} = St.ThemeContext.get_for_stage(global.stage);

        this._scrollView.style = `max-height: ${Math.floor(workArea.height * 0.6 / scaleFactor)}px`;
    }

    // An override of PanelMenu's own, which its constructor connects to
    // 'destroy' before ours has run a line: a teardown before _setup () has
    // finished, settings connected and a reconnect perhaps pending, reaches it
    // all the same. Chained up last, since that is what destroys the menu the
    // rows are in.
    _onDestroy() {
        // Set here and not only in shutdown (): the actor can be destroyed by
        // other routes, and a _setup () suspended on its connection would
        // otherwise resume past this and build its menu into an actor that has
        // gone.
        this._destroyed = true;
        // And the reads still out go with it: nothing is left to show them, and
        // what awaits them stops at the reply rather than reaching for a menu
        // that has gone. Both this and the select-search idle below are
        // doubled -- by _reconcileConnection ()'s _destroyed check, and by the
        // menu's own close on destroy (_onOpenStateChanged ()) -- which is why
        // no test sees either missing alone.
        this._listing?.cancel();
        this._cancelConnectRetry();
        this._cancelSelectSearch();
        this._cancelSearchDelay();
        Main.layoutManager.disconnectObject(this);
        St.ThemeContext.get_for_stage(global.stage).disconnectObject(this);
        this._settings.disconnectObject(this);
        this._clearRows();
        // The history switcher holds the client too, and a GC may hold it for
        // longer still: its wait is ours to stop. Once our handlers are off
        // it, since stopping moves the presence, and the notify would land on
        // an indicator whose actors are going.
        this._client?.disconnectObject(this);
        this._client?.unfollow_daemon();
        this._client = null;

        super._onDestroy();
    }
});
