// SPDX-FileCopyrightText: 2010-2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com>
// SPDX-License-Identifier: BSD-2-Clause

import * as BarLevel from 'resource:///org/gnome/shell/ui/barLevel.js';
import * as CheckBox from 'resource:///org/gnome/shell/ui/checkBox.js';
import * as Dialog from 'resource:///org/gnome/shell/ui/dialog.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as ModalDialog from 'resource:///org/gnome/shell/ui/modalDialog.js';
import * as ShellEntry from 'resource:///org/gnome/shell/ui/shellEntry.js';

import Clutter from 'gi://Clutter';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import Pango from 'gi://Pango';
import St from 'gi://St';

import GPasteDaemon from 'gi://GPasteDaemon?version=1';

// The gnome-shell half of the GPastePrompt contract, the St counterpart of the
// standalone daemon's GPastePromptAdw. gnome-shell can run neither gtk_init nor
// adw_init, so the storage questions are asked with St widgets here; that is
// what lets the in-shell daemon call the very same in-process code the
// standalone one does.
//
// Everything about *what the answers mean* stays in the C storage layer: these
// dialogs only collect a passphrase, or a backend and two toggles, and hand
// them to the request.

// What the Adwaita prompt says under a row, said under the St widget it
// explains, in a class the shell's theme styles.
function explanation(text) {
    const label = new St.Label({style_class: 'message-dialog-description', text});

    label.clutter_text.ellipsize = Pango.EllipsizeMode.NONE;
    label.clutter_text.line_wrap = true;

    return label;
}

// A dialog asking @request: whichever way it goes away, the request gets
// exactly one answer. Replying marks it, so 'closed' and 'destroy' only bite on
// a real dismissal. Both are connected because a dialog can be destroyed
// without being closed, and 'closed' alone would then strand the request — and
// with it the daemon waiting on the storage to settle. A close is followed by
// 'destroy' too, ModalDialog destroying a dialog it closes, so no case tells
// the 'closed' connection missing (test-prompt.cjs pins 'destroy').
const RequestDialog = GObject.registerClass(
class GPasteRequestDialog extends ModalDialog.ModalDialog {
    constructor(request) {
        super({styleClass: 'prompt-dialog'});

        this._request = request;
        this._answered = false;

        this.connect('closed', () => this._dismiss());
        this.connect('destroy', () => this._dismiss());
    }

    _dismiss() {
        this._answer(() => this._request.dismiss());
    }

    _answer(reply) {
        if (this._answered)
            return;

        this._answered = true;
        reply();
    }

    _reply(reply) {
        this._answer(reply);
        this.close();
    }
});

// A wrong passphrase is reported by re-asking with an error message, so the
// dialog never has to know whether the one it collected was any good.
const PassphraseDialog = GObject.registerClass(
class GPastePassphraseDialog extends RequestDialog {
    constructor(request) {
        super(request);

        this._strengthRatingId = 0;

        const confirm = request.get_confirm();
        const errorMessage = request.get_error_message();

        const content = new Dialog.MessageDialogContent({
            title: GPasteDaemon.prompt_text(GPasteDaemon.PromptText.PASSPHRASE_TITLE),
            description: request.get_shown_description(),
        });

        this._entry = this._addEntry(content, GPasteDaemon.prompt_text(GPasteDaemon.PromptText.PASSPHRASE));
        this._confirmEntry = confirm ? this._addEntry(content, GPasteDaemon.prompt_text(GPasteDaemon.PromptText.PASSPHRASE_CONFIRM)) : null;

        if (confirm)
            this._addStrengthMeter(content);

        // Only offer to remember it when the request says to: a build without
        // libsecret has no keyring to remember it in, and a passphrase asked
        // for other histories than the one in use is never remembered.
        this._remember = null;
        if (request.offers_remember()) {
            // Where the switch starts, and whether leaving it off means
            // anything, are two different questions with one subtle rule
            // between them — answered C-side so the two backends cannot drift,
            // and in one keyring round trip rather than two.
            const [startsOn, canForget] =
                GPasteDaemon.Prompt.remember_state(request.get_remember());

            this._remembered = canForget;

            this._remember = new CheckBox.CheckBox(GPasteDaemon.prompt_text(GPasteDaemon.PromptText.REMEMBER));
            this._remember.checked = startsOn;
            content.add_child(this._remember);
            content.add_child(explanation(GPasteDaemon.prompt_text(GPasteDaemon.PromptText.REMEMBER_SUBTITLE)));
        }

        this._errorLabel = new St.Label({style_class: 'prompt-dialog-error-label'});
        this._errorLabel.clutter_text.ellipsize = Pango.EllipsizeMode.NONE;
        this._errorLabel.clutter_text.line_wrap = true;
        this._errorLabel.visible = !!errorMessage;
        if (errorMessage)
            this._errorLabel.text = errorMessage;
        content.add_child(this._errorLabel);

        this.contentLayout.add_child(content);

        this._okButton = this.addButton({
            label: request.get_accept_label(),
            action: () => this._onOk(),
            default: true,
        });
        this.addButton({
            label: GPasteDaemon.prompt_text(GPasteDaemon.PromptText.CANCEL),
            action: () => this.close(),
            key: Clutter.KEY_Escape,
        });

        this.setInitialKeyFocus(this._entry);
        this._updateOk();
    }

    _dismiss() {
        // The rating waiting to run would read an entry that is going with the
        // dialog, and write into a meter that is going with it too.
        if (this._strengthRatingId) {
            GLib.Source.remove(this._strengthRatingId);
            this._strengthRatingId = 0;
        }

        this._answer(() => this._request.reply_passphrase(null, GPasteDaemon.StorageRemember.UNCHANGED));
    }

    _addEntry(content, hintText) {
        const entry = new St.PasswordEntry({
            style_class: 'prompt-dialog-password-entry',
            hint_text: hintText,
            can_focus: true,
            x_expand: true,
        });

        entry.clutter_text.connect('activate', () => this._onActivate());
        entry.clutter_text.connect('text-changed', () => this._onTextChanged(entry));
        ShellEntry.addContextMenu(entry);
        content.add_child(entry);

        return entry;
    }

    // The same libpwquality rating the Adwaita prompt shows, scored C-side:
    // libpwquality is not introspectable, so the level and its hint both come
    // from g_paste_prompt_passphrase_strength().
    _addStrengthMeter(content) {
        // Built without libpwquality there is nothing to rate with, and a meter
        // stuck at zero reads as a verdict rather than an absence. Say so
        // instead, as the libadwaita backend does.
        if (!GPasteDaemon.Prompt.pwquality_available()) {
            content.add_child(new St.Label({
                style_class: 'message-dialog-description',
                text: GPasteDaemon.prompt_text(GPasteDaemon.PromptText.PASSPHRASE_STRENGTH_UNAVAILABLE),
            }));
            return;
        }

        // The extension ships no stylesheet, so everything here wears a class
        // the shell's theme styles, or an inline style: a BarLevel's own
        // 'barlevel' class gets no height and no colours, the theme styling a
        // bar only as a 'slider' or an OSD's 'level'.
        const box = new St.BoxLayout({style: 'spacing: 12px;'});

        box.add_child(new St.Label({
            text: GPasteDaemon.prompt_text(GPasteDaemon.PromptText.PASSPHRASE_STRENGTH),
            y_align: Clutter.ActorAlign.CENTER,
        }));

        // BarLevel is normalized to 0..1, so the 0-4 rating is scaled into it.
        this._strengthLevel = new BarLevel.BarLevel({
            style_class: 'slider',
            x_expand: true,
            y_align: Clutter.ActorAlign.CENTER,
        });
        this._strengthHint = new St.Label({style_class: 'message-dialog-description'});

        box.add_child(this._strengthLevel);
        box.add_child(this._strengthHint);
        content.add_child(box);
    }

    _onTextChanged(entry) {
        // The error flags the previous wrong attempt; clear it as soon as the
        // passphrase is amended so it does not bleed into the next try.
        this._errorLabel.visible = false;

        // Only re-rate when the passphrase itself changed: typing the
        // confirmation rates a string that did not move.
        if (this._strengthLevel && entry === this._entry)
            this._rateStrength();

        this._updateOk();
    }

    // At most one rating per PROMPT_STRENGTH_RATING_DELAY, the delay both
    // prompts rate on: a rating is a cracklib dictionary pass, and the thread it
    // runs on here is the compositor's own.
    _rateStrength() {
        if (this._strengthRatingId)
            return;

        this._strengthRatingId = GLib.timeout_add(GLib.PRIORITY_DEFAULT,
            GPasteDaemon.PROMPT_STRENGTH_RATING_DELAY, () => {
                this._strengthRatingId = 0;

                // What the entry holds when the rating runs, not what armed it:
                // that is what makes one rating per delay enough.
                const [level, hint] = GPasteDaemon.Prompt.passphrase_strength(this._entry.get_text());

                this._strengthLevel.value = level / GPasteDaemon.PROMPT_STRENGTH_MAX;
                this._strengthHint.text = hint ?? '';

                return GLib.SOURCE_REMOVE;
            });
        GLib.Source.set_name_by_id(this._strengthRatingId, '[GPaste] password strength rating');
    }

    _updateOk() {
        this._okButton.reactive = this._okButton.can_focus = this._isComplete();
    }

    // The rule lives in C so the two prompt backends cannot come to disagree
    // about what counts as an answer.
    _isComplete() {
        return GPasteDaemon.Prompt.passphrase_is_complete(
            this._entry.get_text(),
            this._confirmEntry ? this._confirmEntry.get_text() : null);
    }

    _onActivate() {
        if (this._isComplete())
            this._onOk();
    }

    _onOk() {
        // What the switch answers is asked C-side too, as where it starts is.
        const remember = GPasteDaemon.Prompt.remember_answer(!!this._remember?.checked, !!this._remembered);

        this._reply(() => this._request.reply_passphrase(this._entry.get_text(), remember));
    }
});

const MigrationDialog = GObject.registerClass(
class GPasteMigrationDialog extends RequestDialog {
    constructor(request) {
        super(request);

        this._current = request.get_current();
        this._offered = request.get_offered();
        // null until the user picks one, whenever the backend in use cannot be
        // kept (see g_paste_prompt_request_can_keep ()): preselecting another
        // would have the dialog claim a backend they never chose.
        this._chosen = request.can_keep() ? this._current : null;

        const content = new Dialog.MessageDialogContent({
            title: GPasteDaemon.prompt_text(GPasteDaemon.PromptText.MIGRATION_TITLE),
            // Naming no "Keep as is" where none is offered (see below).
            description: GPasteDaemon.prompt_text(this._chosen === null
                ? GPasteDaemon.PromptText.MIGRATION_DESCRIPTION_UNKEPT
                : GPasteDaemon.PromptText.MIGRATION_DESCRIPTION),
        });

        this._backendButtons = new Map();

        // An inline style, as the strength meter's (_addStrengthMeter ()).
        const backends = new St.BoxLayout({
            orientation: Clutter.Orientation.VERTICAL,
            style: 'spacing: 6px;',
        });

        // St has no radio button, so a set of toggles kept mutually exclusive by
        // hand is the closest thing; the labels and the offered set both come
        // from the C side, which knows what this build can construct.
        // Headed as the Adwaita dialog's group of radios is, in bold for want
        // of a heading class the theme styles.
        backends.add_child(new St.Label({
            text: GPasteDaemon.prompt_text(GPasteDaemon.PromptText.STORAGE_BACKEND),
            style: 'font-weight: bold;',
        }));

        for (const backend of this._offered) {
            const button = new CheckBox.CheckBox(GPasteDaemon.Prompt.storage_label(backend));

            button.checked = backend === this._current;
            button.connect('clicked', () => this._selectBackend(backend));
            this._backendButtons.set(backend, button);
            backends.add_child(button);
        }

        content.add_child(backends);

        this._import = new CheckBox.CheckBox(GPasteDaemon.prompt_text(GPasteDaemon.PromptText.IMPORT));
        this._cleanup = new CheckBox.CheckBox(GPasteDaemon.prompt_text(GPasteDaemon.PromptText.CLEANUP));
        this._import.connect('clicked', () => this._updateState());
        this._cleanup.connect('clicked', () => this._updateState());
        content.add_child(this._import);
        content.add_child(explanation(GPasteDaemon.prompt_text(GPasteDaemon.PromptText.IMPORT_SUBTITLE)));
        content.add_child(this._cleanup);
        content.add_child(explanation(GPasteDaemon.prompt_text(GPasteDaemon.PromptText.CLEANUP_SUBTITLE)));

        this._warning = new St.Label({
            style_class: 'prompt-dialog-error-label',
            text: GPasteDaemon.prompt_text(GPasteDaemon.PromptText.CLEANUP_WARNING),
        });
        this._warning.clutter_text.ellipsize = Pango.EllipsizeMode.NONE;
        this._warning.clutter_text.line_wrap = true;
        content.add_child(this._warning);

        this.contentLayout.add_child(content);

        this._apply = this.addButton({
            label: GPasteDaemon.prompt_text(GPasteDaemon.PromptText.MIGRATION_ACCEPT),
            action: () => this._onApply(),
            default: true,
        });
        // Only when there is something to keep: the button answers with the
        // backend in use, and one that is not on offer is not an answer the
        // reply accepts — it would become the very dismissal the button exists
        // to avoid.
        if (this._chosen !== null) {
            this.addButton({
                label: GPasteDaemon.prompt_text(GPasteDaemon.PromptText.MIGRATION_KEEP),
                action: () => this._onKeep(),
            });
        }
        this.addButton({
            label: GPasteDaemon.prompt_text(GPasteDaemon.PromptText.CANCEL),
            action: () => this.close(),
            key: Clutter.KEY_Escape,
        });

        this._updateState();
    }

    _selectBackend(backend) {
        this._chosen = backend;

        for (const [kind, button] of this._backendButtons)
            button.checked = kind === backend;

        this._updateState();
    }

    // The same rules the Adwaita dialog applies, and for the same reason they
    // are exported from C: importing only makes sense between two different
    // storing backends, and there is only old data to delete once we actually
    // leave one that stored something.
    _updateState() {
        const chosenAnything = this._chosen !== null;
        const canImport = chosenAnything && GPasteDaemon.Prompt.can_import(this._current, this._chosen);
        const backendChanges = chosenAnything && GPasteDaemon.Prompt.backend_changes(this._current, this._chosen);

        // Nothing picked yet: there is no answer to apply until the user names
        // a backend.
        this._setReactive(this._apply, chosenAnything);

        this._setSensitive(this._import, canImport);
        this._setSensitive(this._cleanup, backendChanges);

        this._warning.visible = GPasteDaemon.Prompt.cleanup_warns(this._import.checked, this._cleanup.checked);
    }

    _setSensitive(check, sensitive) {
        if (!sensitive)
            check.checked = false;

        this._setReactive(check, sensitive);
    }

    _setReactive(actor, sensitive) {
        actor.reactive = actor.can_focus = sensitive;
        actor.opacity = sensitive ? 255 : 128;
    }

    _onApply() {
        // Nothing to apply. The dialog's Enter binding skips a default button
        // that is not reactive, but a greyed-out Apply is still the key focus
        // the dialog opens with, and whether St clicks a focused button that is
        // not reactive on a key press is St's business: with nothing picked,
        // the answer is refused here, whatever asked for it (test-prompt.cjs).
        if (this._chosen === null)
            return;

        this._reply(() => this._request.reply_migration(this._chosen, this._import.checked, this._cleanup.checked));
    }

    // "Nothing changes, and stop asking", which Cancel next to it does not do:
    // dismissing, the storage layer's "no choice made", leaves the revision
    // alone and the dialog comes back on the next start. Answers with the
    // current backend rather than what is ticked, so it undoes the fiddling
    // too.
    _onKeep() {
        this._reply(() => this._request.reply_migration(this._current, false, false));
    }
});

// Whether to go through with what cannot be undone, worded by the request:
// Cancel is the default, the destructive answer never one a stray Enter gives.
const ConfirmDialog = GObject.registerClass(
class GPasteConfirmDialog extends RequestDialog {
    constructor(request) {
        super(request);

        this.contentLayout.add_child(new Dialog.MessageDialogContent({
            title: request.get_title(),
            description: request.get_description(),
        }));

        this.addButton({
            label: GPasteDaemon.prompt_text(GPasteDaemon.PromptText.CANCEL),
            action: () => this.close(),
            key: Clutter.KEY_Escape,
            default: true,
        });
        this.addButton({
            label: request.get_accept_label(),
            action: () => this._reply(() => request.reply_confirm()),
        });
    }
});

// Not a question: it says what did not happen and offers one way out, so it
// carries no request and answers nothing.
const ReportDialog = GObject.registerClass(
class GPasteReportDialog extends ModalDialog.ModalDialog {
    constructor(title, message) {
        super({styleClass: 'prompt-dialog'});

        this.contentLayout.add_child(new Dialog.MessageDialogContent({
            title,
            description: message,
        }));

        this.addButton({
            label: GPasteDaemon.prompt_text(GPasteDaemon.PromptText.CLOSE),
            action: () => this.close(),
            key: Clutter.KEY_Escape,
            default: true,
        });
    }
});

export const GPasteShellPrompt = GObject.registerClass({
    Implements: [GPasteDaemon.Prompt],
}, class GPasteShellPrompt extends GObject.Object {
    constructor() {
        super();

        this._open = new Set();
        // What was asked while the session was locked, to be shown once it is
        // not: see _show ().
        this._deferred = [];
        this._shutDown = false;

        Main.sessionMode.connectObject('updated', () => this._onSessionUpdated(), this);
    }

    // The extension stays enabled on the lock screen, where the in-shell daemon
    // goes on running, and a modal dialog goes above the shield: a storage
    // question there could be answered by anyone at the machine -- every
    // history deleted, or re-encrypted under a passphrase of theirs. So, as
    // GNOME Shell's own polkit dialog does, one asked while locked waits for the
    // unlock, and one up already is hidden until then, its grab under the
    // shield's.
    //
    // @create builds the dialog once it can be shown; @abandon answers for one
    // that never is, asked once the extension is going or still held back by
    // the lock then (shutdown ()).
    _show(create, abandon) {
        if (this._shutDown) {
            abandon();
            return;
        }

        if (Main.sessionMode.isLocked) {
            this._deferred.push({create, abandon});
            return;
        }

        const dialog = create();

        // Track it so shutdown() can take it away again. Closing is what
        // answers the request, so the entry is dropped from there.
        this._open.add(dialog);
        dialog.connect('destroy', () => this._open.delete(dialog));

        // It cannot fail on GNOME Shell 51, the only one metadata.json declares:
        // open() answers false only when pushModal() does, and Shell 51's
        // pushModal() answers true whatever else holds a grab -- a dialog
        // opened over another modal stacks on it, and no check of the seat's
        // grab state is there to refuse it -- so no answer is owed for an open
        // that failed.
        dialog.open();
    }

    _onSessionUpdated() {
        const locked = Main.sessionMode.isLocked;

        for (const dialog of this._open)
            dialog.visible = !locked;

        if (locked)
            return;

        for (const {create, abandon} of this._deferred.splice(0))
            this._show(create, abandon);
    }

    // The extension is going away, so nothing is left to act on an answer: the
    // runner has stood down and the settings it shared are about to be dropped.
    // Close whatever is still up, which dismisses the request behind it and
    // unblocks the storage settle rather than leaving it pending for good with
    // an ownerless dialog on screen.
    shutdown() {
        // Set first: dismissing a prompt can make the storage layer ask the
        // next question rather than give up — backing out of the passphrase
        // for an encrypted destination sends it straight back to the migration
        // prompt — and answering that with a fresh dialog would put a modal
        // window on screen for an extension that is already gone, still able
        // to rewrite the history on disk.
        this._shutDown = true;
        Main.sessionMode.disconnectObject(this);

        for (const {abandon} of this._deferred.splice(0))
            abandon();

        for (const dialog of [...this._open])
            dialog.close();
    }

    vfunc_passphrase(request) {
        this._show(() => new PassphraseDialog(request), () => request.dismiss());
    }

    vfunc_migration(request) {
        this._show(() => new MigrationDialog(request), () => request.dismiss());
    }

    vfunc_confirm(request) {
        this._show(() => new ConfirmDialog(request), () => request.dismiss());
    }

    // There is nothing to dismiss here, so a report never shown ends in the
    // log rather than nowhere: it still has to reach someone.
    vfunc_report(title, message) {
        this._show(() => new ReportDialog(title, message), () => console.error(`GPaste: ${title}: ${message}`));
    }
});
