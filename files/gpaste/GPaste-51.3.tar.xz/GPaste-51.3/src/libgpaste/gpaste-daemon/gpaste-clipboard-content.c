// SPDX-FileCopyrightText: 2010-2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com>
// SPDX-License-Identifier: BSD-2-Clause

#include <string.h>

#include <gpaste-daemon/gpaste-clipboard-content.h>
#include <gpaste-daemon/gpaste-clipboard-provider-private.h>
#include <gpaste-daemon/gpaste-color-item.h>
#include <gpaste-daemon/gpaste-daemon-util.h>
#include <gpaste-daemon/gpaste-image-item.h>
#include <gpaste-daemon/gpaste-password-item.h>
#include <gpaste-daemon/gpaste-sensitive-mime.h>
#include <gpaste-daemon/gpaste-text-item.h>
#include <gpaste-daemon/gpaste-uris-item.h>

/**
 * g_paste_clipboard_content_clear:
 * @content: a #GPasteClipboardContent
 *
 * Release whatever @content currently holds and reset it to %CLIPBOARD_CONTENT_NONE.
 */
G_PASTE_VISIBLE void
g_paste_clipboard_content_clear (GPasteClipboardContent *content)
{
    switch (content->kind)
    {
    /* Wiped: the text a selection carries is a password's cleartext as
     * readily as anything -- a hinted copy, the password a selection was
     * given -- whose item keeps its own copy in secure memory. Counted among
     * a published password's wipes (/meta/publish/wipes-password,
     * /gdk/publish/wipes-password). */
    case CLIPBOARD_CONTENT_TEXT:
        g_clear_pointer (&content->str, g_paste_util_free_cleartext);
        break;
    case CLIPBOARD_CONTENT_IMAGE:
        g_clear_pointer (&content->str, g_free);
        break;
    case CLIPBOARD_CONTENT_FILE_LIST:
        if (content->file_list)
            g_boxed_free (GDK_TYPE_FILE_LIST, g_steal_pointer (&content->file_list));
        break;
    case CLIPBOARD_CONTENT_COLOR:
    case CLIPBOARD_CONTENT_IGNORED:
    case CLIPBOARD_CONTENT_WITHHELD:
    case CLIPBOARD_CONTENT_NONE:
        break;
    }
    content->kind = CLIPBOARD_CONTENT_NONE;
    /* Leave the union readable, not merely dead. The set_*_take() helpers assign
     * through g_set_str_take(), which *reads* @str to compare and free it before
     * storing — and after a colour that is four floats reinterpreted as a
     * pointer, which it would then strcmp() and g_free(). Clearing the kind is
     * not enough; the bytes have to go too. */
    content->str = NULL;
}

/**
 * g_paste_clipboard_content_set_ignored:
 * @content: a #GPasteClipboardContent
 *
 * Say the selection holds something this provider does not keep
 *
 * The selection has an owner, so it is not empty and ensure_not_empty() must
 * leave it alone; and what it holds is nothing the daemon has a value for, so
 * every getter answers %NULL. That covers an owner offering only types the daemon
 * does not handle and a text the size policy turns down alike: keeping a value
 * for either has the provider report content its selection has replaced, and the
 * second one can be arbitrarily large.
 */
G_PASTE_VISIBLE void
g_paste_clipboard_content_set_ignored (GPasteClipboardContent *content)
{
    g_paste_clipboard_content_clear (content);
    content->kind = CLIPBOARD_CONTENT_IGNORED;
}

/**
 * g_paste_clipboard_content_set_withheld:
 * @content: a #GPasteClipboardContent
 *
 * Say the selection holds a secret that is not a text, kept as nothing
 *
 * Every getter answers %NULL, as for g_paste_clipboard_content_set_ignored (),
 * but the selection is identified: what it holds is no password.
 */
G_PASTE_VISIBLE void
g_paste_clipboard_content_set_withheld (GPasteClipboardContent *content)
{
    g_paste_clipboard_content_clear (content);
    content->kind = CLIPBOARD_CONTENT_WITHHELD;
}

/**
 * g_paste_clipboard_content_is_identified:
 * @content: a #GPasteClipboardContent
 *
 * Returns: whether @content says what the selection holds, nothing included:
 *          %FALSE only for g_paste_clipboard_content_set_ignored ()
 */
G_PASTE_VISIBLE gboolean
g_paste_clipboard_content_is_identified (const GPasteClipboardContent *content)
{
    return content->kind != CLIPBOARD_CONTENT_IGNORED;
}

/**
 * g_paste_clipboard_content_is_empty:
 * @content: a #GPasteClipboardContent
 *
 * Returns: whether @content holds nothing
 */
G_PASTE_VISIBLE gboolean
g_paste_clipboard_content_is_empty (const GPasteClipboardContent *content)
{
    return content->kind == CLIPBOARD_CONTENT_NONE;
}

/**
 * g_paste_clipboard_content_set_text:
 * @content: a #GPasteClipboardContent
 * @text: the text to hold (copied)
 *
 * Replace @content with @text.
 */
G_PASTE_VISIBLE void
g_paste_clipboard_content_set_text (GPasteClipboardContent *content,
                                    const gchar            *text)
{
    g_paste_clipboard_content_set_text_take (content, g_strdup (text));
}

/**
 * g_paste_clipboard_content_set_text_take:
 * @content: a #GPasteClipboardContent
 * @text: (transfer full): the text to hold
 *
 * Replace @content with @text, consuming it.
 *
 * Every clipboard update goes through here with a string the caller just built
 * and immediately drops, so this avoids a copy on the hot path.
 */
G_PASTE_VISIBLE void
g_paste_clipboard_content_set_text_take (GPasteClipboardContent *content,
                                         gchar                  *text)
{
    g_paste_clipboard_content_clear (content);
    content->kind = CLIPBOARD_CONTENT_TEXT;
    g_set_str_take (&content->str, text);
}

/**
 * g_paste_clipboard_content_set_image_checksum:
 * @content: a #GPasteClipboardContent
 * @checksum: the image checksum to hold (copied)
 *
 * Replace @content with an image identified by @checksum.
 */
G_PASTE_VISIBLE void
g_paste_clipboard_content_set_image_checksum (GPasteClipboardContent *content,
                                              const gchar            *checksum)
{
    g_paste_clipboard_content_set_image_checksum_take (content, g_strdup (checksum));
}

/**
 * g_paste_clipboard_content_set_image_checksum_take:
 * @content: a #GPasteClipboardContent
 * @checksum: (transfer full): the image checksum to hold
 *
 * Replace @content with an image identified by @checksum, consuming it.
 */
G_PASTE_VISIBLE void
g_paste_clipboard_content_set_image_checksum_take (GPasteClipboardContent *content,
                                                   gchar                  *checksum)
{
    g_paste_clipboard_content_clear (content);
    content->kind = CLIPBOARD_CONTENT_IMAGE;
    g_set_str_take (&content->str, checksum);
}

/**
 * g_paste_clipboard_content_set_color:
 * @content: a #GPasteClipboardContent
 * @rgba: the colour to hold (copied)
 *
 * Replace @content with the colour @rgba.
 */
G_PASTE_VISIBLE void
g_paste_clipboard_content_set_color (GPasteClipboardContent *content,
                                     const GdkRGBA          *rgba)
{
    g_paste_clipboard_content_clear (content);
    content->kind = CLIPBOARD_CONTENT_COLOR;
    content->rgba = *rgba;
}

/**
 * g_paste_clipboard_content_set_file_list:
 * @content: a #GPasteClipboardContent
 * @file_list: (nullable): the file list to hold (copied)
 *
 * Replace @content with @file_list. A %NULL @file_list leaves @content empty.
 */
G_PASTE_VISIBLE void
g_paste_clipboard_content_set_file_list (GPasteClipboardContent *content,
                                         GdkFileList            *file_list)
{
    g_paste_clipboard_content_clear (content);

    if (!file_list)
        return;

    content->kind = CLIPBOARD_CONTENT_FILE_LIST;
    content->file_list = g_boxed_copy (GDK_TYPE_FILE_LIST, file_list);
}

/**
 * g_paste_clipboard_content_get_text:
 * @content: a #GPasteClipboardContent
 *
 * Returns: (nullable): the held text, or %NULL unless @content holds text
 */
G_PASTE_VISIBLE const gchar *
g_paste_clipboard_content_get_text (const GPasteClipboardContent *content)
{
    return (content->kind == CLIPBOARD_CONTENT_TEXT) ? content->str : NULL;
}

/**
 * g_paste_clipboard_content_get_image_checksum:
 * @content: a #GPasteClipboardContent
 *
 * Returns: (nullable): the held image checksum, or %NULL unless @content holds an image
 */
G_PASTE_VISIBLE const gchar *
g_paste_clipboard_content_get_image_checksum (const GPasteClipboardContent *content)
{
    return (content->kind == CLIPBOARD_CONTENT_IMAGE) ? content->str : NULL;
}

/**
 * g_paste_clipboard_content_get_file_list:
 * @content: a #GPasteClipboardContent
 *
 * Returns: (nullable) (transfer none): the held file list, or %NULL unless @content holds one
 */
G_PASTE_VISIBLE GdkFileList *
g_paste_clipboard_content_get_file_list (const GPasteClipboardContent *content)
{
    return (content->kind == CLIPBOARD_CONTENT_FILE_LIST) ? content->file_list : NULL;
}

/**
 * g_paste_clipboard_content_classify_text:
 * @content: the currently held content (for dedup against the new text)
 * @settings: a #GPasteSettings instance (trim and min/max size policy)
 * @may_reselect: whether re-owning the selection with the trimmed text is
 *                allowed -- the clipboard selection, while tracking, and only
 *                when this read knows what it carries. The primary is never
 *                re-owned (a selection made with the mouse is not GPaste's to
 *                rewrite), and neither is a text whose sensitive hint never
 *                answered, which would put hint-less text over what may be a
 *                secret. A caller passing a plain is_clipboard () here would
 *                undo that
 * @text: the candidate text just read from the selection
 * @sensitive: whether the completed hint reads identify a password
 * @out_value: (out) (transfer full) (nullable): the trimmed text to act on, or
 *             %NULL when that is @text as it is (or there is nothing to act on)
 *
 * Apply the shared trim/size/dedup policy to a candidate clipboard text, so both
 * backends accept and normalise text identically. A text @sensitive says is a
 * secret is held to none of the three: see the size check below.
 *
 * A text trimming leaves as it is comes back as %NULL rather than as a copy: a
 * selection's text can be megabytes, and the update already holds it.
 *
 * Returns: the action the backend should take for @text
 */
G_PASTE_VISIBLE GPasteClipboardTextAction
g_paste_clipboard_content_classify_text (const GPasteClipboardContent *content,
                                         GPasteSettings               *settings,
                                         gboolean                      may_reselect,
                                         const gchar                  *text,
                                         gboolean                      sensitive,
                                         gchar                       **out_value)
{
    gboolean trim_items = !sensitive && g_paste_settings_get_trim_items (settings);
    g_autofree gchar *stripped = trim_items ? g_strstrip (g_strdup (text)) : NULL;
    const gchar *to_add = trim_items ? stripped : text;
    guint64 length = strlen (to_add);

    *out_value = NULL;

    gboolean unchanged = content->kind == CLIPBOARD_CONTENT_TEXT && g_paste_str_equal (content->str, text);

    /* The size policy is what keeps noise and blobs out of the history, and a
     * secret is neither: it is an exposure sitting on a selection, and the item
     * built for it is what records that -- what a countdown then takes back off,
     * and what a sync carries over as a password rather than as bare text. A
     * secret turned down here produces no item, so there is nothing to record it
     * with and nothing to take it off, and the cleartext stays on the selection
     * for the rest of the session. So neither size setting applies to one: they
     * are the user's filter for noise and blobs, and a four-digit PIN or a long
     * generated passphrase is a secret like any other
     * (/clipboard/sensitive_size_policy).
     *
     * That includes a secret larger than max-text-item-size, and it is accepted
     * knowingly: a password item weighs nothing against max-memory-usage either
     * (g_paste_password_item_new () sets its size to 0, its length being the
     * secret), so nothing bounds what hinted text the history keeps but
     * max-history-size. We want as little interaction with a password's contents
     * as there can be -- no measuring it against a limit, no second policy for
     * how large one may be, no refusing one and leaving it on the selection with
     * nothing to take it off -- and an application marking megabytes of text as
     * a secret is one choosing to have it handled as one.
     *
     * An empty one is refused all the same: a selection carrying no text is no
     * exposure, and a password of no value would answer selection_holds () for
     * every selection holding none -- the empty string being what this daemon
     * writes to empty one. */
    if (!length ||
        (!sensitive && (length < g_paste_settings_get_min_text_item_size (settings) ||
                        length > g_paste_settings_get_max_text_item_size (settings))))
        return unchanged ? G_PASTE_CLIPBOARD_TEXT_UNCHANGED : G_PASTE_CLIPBOARD_TEXT_DROP;

    /* Trimming changed the clipboard's own text: re-own it with the stripped
     * form, duplicate or not -- the padded form is what is on the selection. */
    if (trim_items && may_reselect && !g_paste_str_equal (text, stripped))
    {
        *out_value = g_steal_pointer (&stripped);
        return G_PASTE_CLIPBOARD_TEXT_RESELECT;
    }

    /* A duplicate is the raw text the cache holds, or its trimmed form: the
     * primary selection is never re-owned with the stripped text, so an owner
     * re-asserting it hands back the padded text while the cache holds the
     * trimmed item's value. Taking that for new content would re-add it over
     * whatever was copied since and, with synchronization on, publish it over
     * the clipboard. A password is never one (see @sensitive). */
    if (!sensitive && content->kind == CLIPBOARD_CONTENT_TEXT && (unchanged || g_paste_str_equal (content->str, to_add)))
        return G_PASTE_CLIPBOARD_TEXT_UNCHANGED;

    /* Only a trimmed form that differs is handed back; otherwise the caller keeps
     * the text it already owns (see above). */
    if (trim_items && !g_paste_str_equal (text, stripped))
        *out_value = g_steal_pointer (&stripped);

    return G_PASTE_CLIPBOARD_TEXT_SET;
}

/**
 * g_paste_clipboard_file_list_equal:
 * @a: (nullable): a #GdkFileList
 * @b: (nullable): another #GdkFileList
 *
 * Returns: whether @a and @b list the same files in the same order
 */
G_PASTE_VISIBLE gboolean
g_paste_clipboard_file_list_equal (GdkFileList *a,
                                   GdkFileList *b)
{
    if (a == b)
        return TRUE;
    if (!a || !b)
        return FALSE;

    /* gdk_file_list_get_files is (transfer container): it hands back a fresh
     * GSList whose GFiles stay owned by the list, hence g_autoptr (GSList). The
     * other sites taking one say so in a line of their own, the trap being one
     * each of them can fall into. */
    g_autoptr (GSList) files_a = gdk_file_list_get_files (a);
    g_autoptr (GSList) files_b = gdk_file_list_get_files (b);
    const GSList *fa = files_a;
    const GSList *fb = files_b;

    for (; fa && fb; fa = fa->next, fb = fb->next)
    {
        if (!g_file_equal (G_FILE (fa->data), G_FILE (fb->data)))
            return FALSE;
    }

    return !fa && !fb;
}

/**
 * g_paste_clipboard_file_list_new:
 * @uris: the URIs of the files, %NULL-terminated
 *
 * Returns: (transfer full): a #GdkFileList of the files @uris name, in order
 */
G_PASTE_VISIBLE GdkFileList *
g_paste_clipboard_file_list_new (const gchar * const *uris)
{
    g_return_val_if_fail (uris, NULL);

    g_autoslist (GFile) files = NULL;

    for (const gchar * const *uri = uris; *uri; ++uri)
        files = g_slist_prepend (files, g_file_new_for_uri (*uri));
    files = g_slist_reverse (files);

    return gdk_file_list_new_from_list (files);
}

/**
 * g_paste_clipboard_file_list_from_bytes:
 * @bytes: a text/uri-list
 *
 * A file list as it comes off a selection. Each of its files costs far more
 * than its line -- a #GFile, and the nodes of every list it is copied into --
 * and that is spent before any size policy weighs the item it makes: a few
 * megabytes of short lines would be millions of objects, built on gnome-shell's
 * own thread for the daemon it hosts. So a list of more than
 * %G_PASTE_CLIPBOARD_MAX_FILES files is turned down, its lines counted before
 * any of it is decoded.
 *
 * Returns: (transfer full) (nullable): the #GdkFileList @bytes lists, or %NULL
 *          for one listing too many files, or none
 */
G_PASTE_VISIBLE GdkFileList *
g_paste_clipboard_file_list_from_bytes (GBytes *bytes)
{
    g_return_val_if_fail (bytes, NULL);

    gsize size = 0;
    const gchar *data = g_bytes_get_data (bytes, &size);

    /* No list at all, its data perhaps no pointer. */
    if (!size)
        return NULL;

    const gchar *end = data + size;
    guint newlines = 0;

    for (const gchar *nl = data; nl < end && (nl = memchr (nl, '\n', (gsize) (end - nl))); ++nl)
    {
        if (++newlines > G_PASTE_CLIPBOARD_MAX_FILES)
            return NULL;
    }

    g_autofree gchar *text = g_strndup (data, size);
    g_auto (GStrv) uris = g_uri_list_extract_uris (text);

    if (g_strv_length (uris) > G_PASTE_CLIPBOARD_MAX_FILES)
        return NULL;

    return g_paste_clipboard_file_list_new ((const gchar * const *) uris);
}

/**
 * g_paste_clipboard_file_list_get_uris:
 * @file_list: a #GdkFileList
 *
 * Returns: (transfer full): the URIs of the files @file_list holds, in order
 */
G_PASTE_VISIBLE GStrv
g_paste_clipboard_file_list_get_uris (GdkFileList *file_list)
{
    g_return_val_if_fail (file_list, NULL);

    /* (transfer container): the container is ours, the GFiles are not. */
    g_autoptr (GSList) files = gdk_file_list_get_files (file_list);
    g_autoptr (GStrvBuilder) uris = g_strv_builder_new ();

    for (const GSList *f = files; f; f = f->next)
        g_strv_builder_take (uris, g_file_get_uri (G_FILE (f->data)));

    return g_strv_builder_end (uris);
}

/**
 * g_paste_clipboard_text_from_bytes:
 * @bytes: (nullable): what a text transfer brought, %NULL for one that failed
 * @not_utf8: (out) (optional): set when @bytes holds no UTF-8 text
 *
 * A text as it comes off a selection, the way both backends read one: up to its
 * first NUL, which some owners end it with, and the empty text for a transfer
 * whose bytes hold no data at all -- what a pipe written nothing brings back.
 *
 * Returns: (transfer full) (nullable): the text, %NULL for a failed transfer or
 *          one that is not UTF-8
 */
G_PASTE_VISIBLE gchar *
g_paste_clipboard_text_from_bytes (GBytes   *bytes,
                                   gboolean *not_utf8)
{
    if (not_utf8)
        *not_utf8 = FALSE;
    if (!bytes)
        return NULL;

    gsize size = 0;
    const gchar *text = g_bytes_get_data (bytes, &size);

    if (!text)
        return g_strdup ("");

    const gchar *nul = memchr (text, '\0', size);

    if (nul)
        size = (gsize) (nul - text);
    if (!g_utf8_validate_len (text, size, NULL))
    {
        if (not_utf8)
            *not_utf8 = TRUE;
        return NULL;
    }

    return g_strndup (text, size);
}

static void g_paste_clipboard_read_guard_set_deadline (GPasteClipboardReadGuard *guard, guint seconds);

static void
g_paste_clipboard_read_guard_timed_out (gpointer user_data)
{
    GPasteClipboardReadGuard *guard = user_data;

    /* This is the source firing, so it is spent: drop the id before anything can
     * reach for g_source_remove () on it. */
    guard->timeout_id = 0;

    /* A read landed while this was pending, so what the deadline is on has not
     * happened: the batch gets what is left of its silence allowance rather than
     * a new source per read (a text update fires up to eight of them). Rounded
     * down to the second the timer works in, which can only ever hand the batch
     * a little more rope. */
    gint64 silence = (g_get_monotonic_time () - guard->last_read) / G_USEC_PER_SEC;

    if (silence < guard->timeout)
    {
        g_paste_clipboard_read_guard_set_deadline (guard, guard->timeout - silence);
        return;
    }

    /* Held before the conclusion rather than read off @guard after it: what the
     * guard is embedded in is the very thing @expired concludes, and concluding
     * is free to free it -- the callback it ends in reaches the history, which
     * publishes, which lands back in an update that counts its last read out. */
    g_autoptr (GCancellable) cancellable = g_object_ref (guard->cancellable);

    guard->expired (guard->user_data);

    /* Asked for after the conclusion and not before it: g_cancellable_cancel ()
     * runs the handlers connected to it in this very thread, so a read that
     * failed from one of them would count itself out -- and free what is being
     * concluded -- under the call above. */
    g_cancellable_cancel (cancellable);
}

static void
g_paste_clipboard_read_guard_set_deadline (GPasteClipboardReadGuard *guard,
                                           guint                     seconds)
{
    guard->timeout_id = g_timeout_add_seconds_once (seconds,
                                                    g_paste_clipboard_read_guard_timed_out,
                                                    guard);
    g_source_set_name_by_id (guard->timeout_id, "[GPaste] clipboard read guard");
}

/**
 * g_paste_clipboard_read_guard_arm:
 * @guard: the #GPasteClipboardReadGuard to arm
 * @expired: what to conclude when the deadline runs out
 * @user_data: what to conclude it on
 *
 * Give a batch of clipboard reads its cancellable and its deadline.
 *
 * Armed before the first read goes out, so it covers every one of them, and
 * dropped when they are concluded, so it outlives none.
 */
G_PASTE_VISIBLE void
g_paste_clipboard_read_guard_arm (GPasteClipboardReadGuard *guard,
                                  GSourceOnceFunc           expired,
                                  gpointer                  user_data)
{
    g_return_if_fail (guard);
    g_return_if_fail (expired);

    guard->cancellable = g_cancellable_new ();
    guard->last_read = g_get_monotonic_time ();
    guard->timeout = G_PASTE_CLIPBOARD_READ_TIMEOUT;
    guard->expired = expired;
    guard->user_data = user_data;
    g_paste_clipboard_read_guard_set_deadline (guard, guard->timeout);
}

/**
 * g_paste_clipboard_read_guard_touch:
 * @guard: the #GPasteClipboardReadGuard to hand its deadline back
 *
 * Start @guard's deadline over, one of the reads it covers having just landed
 *
 * A read coming in is the batch demonstrably moving, which is what that deadline
 * is a deadline on: see %G_PASTE_CLIPBOARD_READ_TIMEOUT.
 *
 * Written down rather than acted on: the source, when it fires, re-arms itself
 * for what is left of the allowance since the last read landed, so a batch that
 * keeps moving keeps the one source it was armed with. A guard with no deadline
 * left is one whose batch was already concluded, and a timestamp written on it
 * is one nothing is left to compare.
 */
G_PASTE_VISIBLE void
g_paste_clipboard_read_guard_touch (GPasteClipboardReadGuard *guard)
{
    g_return_if_fail (guard);

    if (!guard->timeout_id)
        return;

    guard->last_read = g_get_monotonic_time ();
}

/**
 * g_paste_clipboard_read_guard_disarm:
 * @guard: the #GPasteClipboardReadGuard to disarm
 *
 * Drop the deadline, keeping the cancellable the reads went out on
 *
 * What a conclusion does: the reads it concluded without may still be out there
 * holding that cancellable, and the guard has nothing left to say to them.
 */
G_PASTE_VISIBLE void
g_paste_clipboard_read_guard_disarm (GPasteClipboardReadGuard *guard)
{
    g_return_if_fail (guard);

    g_clear_handle_id (&guard->timeout_id, g_source_remove);
}

/* Bring @guard's deadline forward to the next turn of the main loop, the batch it
 * covers having stopped being worth waiting for. */
static void
g_paste_clipboard_read_guard_expire_soon (GPasteClipboardReadGuard *guard)
{
    g_return_if_fail (guard);

    /* No deadline left is a batch already concluded, as it is for
     * g_paste_clipboard_read_guard_touch (). */
    if (!guard->timeout_id)
        return;

    g_clear_handle_id (&guard->timeout_id, g_source_remove);

    /* Silence is what the deadline measures, and there is none left to wait out:
     * whatever answers now answers for content nothing holds. An idle rather than
     * a deadline of zero seconds, which the timer would round up to the next
     * second boundary -- the superseded update would hold its provider, and on
     * X11 the requestor window behind it, for that whole extra second. */
    guard->timeout = 0;
    guard->timeout_id = g_idle_add_once (g_paste_clipboard_read_guard_timed_out, guard);
    g_source_set_name_by_id (guard->timeout_id, "[GPaste] clipboard read guard");
}

/**
 * g_paste_clipboard_read_guard_clear:
 * @guard: the #GPasteClipboardReadGuard to release
 *
 * Release what @guard holds, once every read it covered is in
 */
G_PASTE_VISIBLE void
g_paste_clipboard_read_guard_clear (GPasteClipboardReadGuard *guard)
{
    g_return_if_fail (guard);

    g_paste_clipboard_read_guard_disarm (guard);
    g_clear_object (&guard->cancellable);
}

/* Let go of everything a sync was handed: the selection its text was going to,
 * and the caller's data with the notify that releases it.
 *
 * Run from the deadline as much as from the free, and cleared as it runs so that
 * whichever comes second finds nothing left. A read that never lands never
 * reaches the free -- cancelling cannot fail it, see either backend -- and what
 * @destroy holds is a ref on the whole clipboards manager, where @data itself is
 * only a struct. */
static void
g_paste_clipboard_sync_data_release (GPasteClipboardSyncData *data)
{
    GDestroyNotify destroy = data->destroy;
    gpointer user_data = data->user_data;

    g_clear_object (&data->other);
    data->destroy = NULL;
    data->user_data = NULL;

    if (destroy)
        destroy (user_data);
}

/* The deadline on a sync ran out: let go of the selection its text was going to
 * and of what the caller gave us, which is all a sync has to conclude. The read
 * landing afterwards then finds no target and only frees itself. */
static void
g_paste_clipboard_sync_timed_out (gpointer user_data)
{
    GPasteClipboardSyncData *data = user_data;

    g_debug ("clipboard: giving up on a sync read that never came back");
    g_paste_clipboard_sync_data_release (data);
}

/**
 * g_paste_clipboard_sync_data_new:
 * @other: the selection the text being read is going to
 * @callback: what to publish the text with once it lands
 * @user_data: (nullable): the data to pass to @callback
 * @destroy: (nullable): how to release @user_data
 *
 * What a sync read has to keep alive, guard included
 *
 * Returns: (transfer full): the newly allocated #GPasteClipboardSyncData
 */
G_PASTE_VISIBLE GPasteClipboardSyncData *
g_paste_clipboard_sync_data_new (GPasteClipboardProvider    *other,
                                 GPasteClipboardSyncCallback callback,
                                 gpointer                    user_data,
                                 GDestroyNotify              destroy)
{
    g_return_val_if_fail (G_PASTE_IS_CLIPBOARD_PROVIDER (other), NULL);
    g_return_val_if_fail (callback, NULL);

    GPasteClipboardSyncData *data = g_new0 (GPasteClipboardSyncData, 1);

    data->other = g_object_ref (other);
    data->callback = callback;
    data->user_data = user_data;
    data->destroy = destroy;
    g_paste_clipboard_read_guard_arm (&data->guard, g_paste_clipboard_sync_timed_out, data);

    return data;
}

/**
 * g_paste_clipboard_sync_data_wants_text:
 * @data: the #GPasteClipboardSyncData the read was fired with
 *
 * Returns: whether a landed sync read still has anywhere to be published
 *
 * What deliver () refuses on, asked before the text is built rather than after:
 * a backend whose read hands it the bytes rather than a string would otherwise
 * copy a whole selection -- of any size -- for a sync the deadline already let
 * go of, which is the one case where nothing is ever going to read it.
 */
G_PASTE_VISIBLE gboolean
g_paste_clipboard_sync_data_wants_text (const GPasteClipboardSyncData *data)
{
    g_return_val_if_fail (data, FALSE);

    return data->other != NULL;
}

/**
 * g_paste_clipboard_sync_data_deliver:
 * @data: the #GPasteClipboardSyncData the read was fired with
 * @text: (nullable): what the read came back with
 *
 * Hand a landed sync read's text to whoever asked for the sync
 *
 * The whole of what a backend does with a sync read that has landed, so that
 * neither of them decides on its own what a selection carries afterwards: a read
 * that came back with no text at all (%NULL), and one whose target the deadline
 * already let go of, both publish nothing. An empty text is a text: it is
 * published, the destination then carrying what the source does.
 */
G_PASTE_VISIBLE void
g_paste_clipboard_sync_data_deliver (GPasteClipboardSyncData *data,
                                     const gchar             *text)
{
    g_return_if_fail (data);

    /* No target left is the guard having concluded this sync already. */
    if (!text || !data->other)
        return;

    data->callback (data->other, text, data->user_data);
}

/**
 * g_paste_clipboard_sync_data_free:
 * @data: the #GPasteClipboardSyncData to release
 *
 * Release what a sync read was keeping alive, whether or not it concluded
 */
G_PASTE_VISIBLE void
g_paste_clipboard_sync_data_free (GPasteClipboardSyncData *data)
{
    g_return_if_fail (data);

    g_paste_clipboard_read_guard_clear (&data->guard);
    g_paste_clipboard_sync_data_release (data);

    g_free (data);
}

/* What one mime read has to carry, whichever backend fired it: the update it
 * counts into, and which entry of which list it was fired for.
 *
 * Which list is the tag over the union, and the only thing that may read either
 * member -- the two enums are separate numberings of the same small integers, so
 * a value of one says nothing about the other. Neither of the two entry points
 * below can be handed the wrong one: each takes its own enum, and there is no
 * call anywhere that names a list without naming a value from it. */
struct _GPasteClipboardMimeCtx
{
    gpointer data;
    gboolean sensitive;
    union {
        GPasteSpecialMime   special; /* !sensitive */
        GPasteSensitiveMime hint;    /* sensitive */
    };
};

static GPasteClipboardMimeCtx *
g_paste_clipboard_mime_ctx_new (gpointer data)
{
    GPasteClipboardMimeCtx *ctx = g_new0 (GPasteClipboardMimeCtx, 1);

    ctx->data = data;

    return ctx;
}

/**
 * g_paste_clipboard_mime_ctx_free:
 * @ctx: the #GPasteClipboardMimeCtx to release
 *
 * Release what one mime read was carrying, once it has reported
 *
 * A pair with g_paste_clipboard_update_add_special_mime_read () and its
 * sensitive counterpart, which hand out a (transfer full) pointer: a backend
 * fires a read with one and reports through
 * g_paste_clipboard_update_on_mime_read (), which gives it back here. Spelled
 * out rather than left as the g_free () it is today, so it still holds once the
 * struct gains anything of its own to release.
 */
G_PASTE_VISIBLE void
g_paste_clipboard_mime_ctx_free (GPasteClipboardMimeCtx *ctx)
{
    g_return_if_fail (ctx);

    g_free (ctx);
}

/* What an update's mime reads found out about the selection carrying a secret.
 *
 * A hint that matched is proof and outranks everything: an answer that came back
 * says what the selection is, whatever else stayed silent.
 *
 * The one reader is the conclusion below, which is why this is not exported:
 * what a read adds up to is #GPasteClipboardSecret's, and a provider's callers
 * are handed that answer rather than the reads it was taken from. */
static GPasteClipboardSecret
g_paste_clipboard_mime_results_get_secret (const GPasteClipboardMimeResults *results)
{
    g_return_val_if_fail (results, G_PASTE_CLIPBOARD_SECRET_UNKNOWN);

    if (results->sensitive)
        return G_PASTE_CLIPBOARD_SECRET_YES;

    return (results->sensitive_unknown) ? G_PASTE_CLIPBOARD_SECRET_UNKNOWN : G_PASTE_CLIPBOARD_SECRET_NO;
}

/* Record what one finished sensitive-mime read means: a sensitive mime is a fact
 * about the content, so only whether it matched is kept.
 *
 * A read fired at all means the selection offers the hint, so one that fails is
 * an owner refusing to serve what it advertises -- which says nothing about the
 * content either way, and is the very shape a GTK-owned selection has today. One
 * served empty did answer, and an answer that does not match is a no: only %NULL
 * is unknown, never empty bytes. */
static void
g_paste_clipboard_mime_results_store_sensitive (GPasteClipboardMimeResults *results,
                                                GPasteSensitiveMime         mime,
                                                GBytes                     *bytes)
{
    if (!bytes)
        results->sensitive_unknown = TRUE;
    else if (g_paste_sensitive_mime_matches (mime, bytes))
        results->sensitive = TRUE;
}

/* Record what one finished special-mime read means: a special mime is a
 * representation of the content to publish again later, so the bytes are what is
 * kept. That is the whole of what tells the two lists apart, and neither backend
 * has anything of its own to say about it. */
static void
g_paste_clipboard_mime_results_store_special (GPasteClipboardMimeResults *results,
                                              GPasteSpecialMime           mime,
                                              GBytes                     *bytes)
{
    /* The one place either list is indexed, so the bound is checked here even
     * though the type says which list it is: an enum is an integer to the
     * compiler, and writing past the array would be silent. */
    g_return_if_fail (mime >= G_PASTE_SPECIAL_MIME_FIRST && mime < G_PASTE_SPECIAL_MIME_LAST);

    if (!bytes || !g_bytes_get_size (bytes))
        return;

    gsize size = 0;
    gconstpointer data = g_bytes_get_data (bytes, &size);

    /* A copy of its size: a transfer's bytes are its stream's buffer, grown by
     * doubling, which an item kept in the history would otherwise hold whole
     * while only its size counts against max-memory-usage. No test sees what a
     * GBytes was allocated with. */
    g_clear_object (&results->special_mime[mime]);
    results->special_mime[mime] = g_paste_binary_data_new (mime, g_bytes_new (data, size));
}

/**
 * g_paste_clipboard_mime_results_clear:
 * @results: the #GPasteClipboardMimeResults to release
 *
 * Release whatever representations are still in @results
 *
 * The ones g_paste_clipboard_content_to_item() put on an item are gone from it
 * already, so what is left is what nothing took.
 */
G_PASTE_VISIBLE void
g_paste_clipboard_mime_results_clear (GPasteClipboardMimeResults *results)
{
    g_return_if_fail (results);

    for (GPasteSpecialMime mime = G_PASTE_SPECIAL_MIME_FIRST; mime < G_PASTE_SPECIAL_MIME_LAST; ++mime)
        g_clear_object (&results->special_mime[mime]);
}

/**
 * g_paste_clipboard_content_to_item:
 * @settings: a #GPasteSettings instance, for the timeout a new password takes
 * @kind: what the read produced
 * @text: (nullable): the text, for %CLIPBOARD_CONTENT_TEXT
 * @texture: (nullable): the image, for %CLIPBOARD_CONTENT_IMAGE
 * @file_list: (nullable): the files, for %CLIPBOARD_CONTENT_FILE_LIST
 * @rgba: (nullable): the colour, for %CLIPBOARD_CONTENT_COLOR
 * @sensitive: whether the owner marked its content a secret
 * @special_mimes: (array fixed-size=5): the alternative representations, one
 *                 slot per #GPasteSpecialMime (%G_PASTE_SPECIAL_MIME_LAST of
 *                 them)
 *
 * Build the item a finished clipboard read describes. Both backends end their
 * update here, which is what keeps them agreeing on what each kind produces and
 * on which kinds carry special values.
 *
 * Returns: (transfer full) (nullable): the item, or %NULL when there is none
 */
G_PASTE_VISIBLE GPasteItem *
g_paste_clipboard_content_to_item (GPasteSettings            *settings,
                                   GPasteClipboardContentKind kind,
                                   const gchar               *text,
                                   GdkTexture                *texture,
                                   GdkFileList               *file_list,
                                   const GdkRGBA             *rgba,
                                   gboolean                   sensitive,
                                   GPasteBinaryData         **special_mimes)
{
    g_return_val_if_fail (G_PASTE_IS_SETTINGS (settings), NULL);

    /* A secret is kept only as a password, which only a text can be: an image,
     * a file list or a colour its owner marked one is not kept at all, which is
     * what the hint asks of a clipboard manager. */
    if (sensitive && kind != CLIPBOARD_CONTENT_TEXT)
        return NULL;

    GPasteItem *item = NULL;

    switch (kind)
    {
    case CLIPBOARD_CONTENT_FILE_LIST:
        if (file_list)
            item = G_PASTE_ITEM (g_paste_uris_item_new (file_list));
        break;
    case CLIPBOARD_CONTENT_COLOR:
        if (rgba)
            item = G_PASTE_ITEM (g_paste_color_item_new (rgba));
        break;
    case CLIPBOARD_CONTENT_TEXT:
        /* The owner said its text is a secret, so it lands as one: the history
         * shows a placeholder rather than the value, no client can read it back,
         * and the timeout takes it off the selection it is still sitting on. */
        if (text && sensitive)
            item = g_paste_password_item_new (NULL, text, (guint) g_paste_settings_get_password_timeout (settings));
        else if (text)
            item = G_PASTE_ITEM (g_paste_text_item_new (text));
        break;
    case CLIPBOARD_CONTENT_IMAGE:
        if (texture)
            item = G_PASTE_ITEM (g_paste_image_item_new (texture));
        break;
    case CLIPBOARD_CONTENT_IGNORED:
    case CLIPBOARD_CONTENT_WITHHELD:
    case CLIPBOARD_CONTENT_NONE:
        break;
    }

    /* Only these two ever come with alternative representations, and a text the
     * owner marked a secret is not one of them: publishing a password again as
     * HTML would put the very value nothing can read back on the selection in a
     * second form. */
    if (item && special_mimes && !sensitive &&
        (kind == CLIPBOARD_CONTENT_TEXT || kind == CLIPBOARD_CONTENT_FILE_LIST))
    {
        for (GPasteSpecialMime mime = G_PASTE_SPECIAL_MIME_FIRST; mime < G_PASTE_SPECIAL_MIME_LAST; ++mime)
        {
            if (special_mimes[mime])
                g_paste_item_add_special_value (item, g_steal_pointer (&special_mimes[mime]));
        }
    }

    return item;
}

/* Everything an update was holding for the item it has just built.
 *
 * At the conclusion and not at the teardown, which is the whole of what an
 * update outliving its own conclusion may be left holding: cancelling cannot
 * fail the reads still out (see the backends), so nothing bounds how long they
 * keep the struct alive, and what waits on them is a counter where this is a
 * whole texture, a settings ref and a provider ref. Each read holds the
 * provider itself for as long as it is out, so this ref adds nothing while they
 * are; it is a read that never lands that would otherwise keep all of it for
 * the rest of the session.
 *
 * Called again from the teardown, for whatever a read landing afterwards stored
 * on its way in: every release here clears what it released, so the second pass
 * finds either that or nothing.
 *
 * The one thing an update holds that is not released here is the mime a read was
 * fired with, which the reads still out may be holding themselves: the teardown
 * is the only place that knows they are all in. */
static void
g_paste_clipboard_update_release_content (GPasteClipboardUpdate *update)
{
    g_paste_clipboard_mime_results_clear (&update->mimes);

    /* The kind says which member of the union is the live one, and it is the
     * only one there is to release: the update is fired for one kind and every
     * read that writes here is that kind's. */
    switch (update->content_kind)
    {
    /* As g_paste_clipboard_content_clear () frees a text. */
    case CLIPBOARD_CONTENT_TEXT:
        g_clear_pointer (&update->text, g_paste_util_free_cleartext);
        break;
    case CLIPBOARD_CONTENT_IMAGE:
        g_clear_object (&update->texture);
        break;
    case CLIPBOARD_CONTENT_FILE_LIST:
        if (update->file_list)
            g_boxed_free (GDK_TYPE_FILE_LIST, g_steal_pointer (&update->file_list));
        break;
    case CLIPBOARD_CONTENT_COLOR:
    case CLIPBOARD_CONTENT_IGNORED:
    case CLIPBOARD_CONTENT_WITHHELD:
    case CLIPBOARD_CONTENT_NONE:
        break;
    }

    g_clear_object (&update->settings);
}

/* What g_paste_clipboard_update_then () chains onto an update. */
typedef struct
{
    GPasteClipboardUpdateThenFunc func;
    gpointer                      data;
} GPasteClipboardUpdateThen;

/* The text the copy being handed over found on the selection, for the length
 * of that callback alone: see g_paste_clipboard_update_overtaken_text (). Put
 * back after it rather than cleared, a callback being free to conclude another
 * update on its way.
 *
 * Here rather than an argument of the callback, whose type
 * (#GPasteClipboardProviderUpdateCallback) is in GPasteDaemon-1's GIR for
 * whatever implements a provider. And needed at all because a released copy
 * cannot be concluded ahead of what overtakes it, against the live cache and
 * records: that is a change, under the backend's own change emission --
 * mutter's owner-changed among them -- or a publication the clipboards manager
 * is in the middle of -- a Select's loop, a sync, an expiry, a strip or
 * ensure_not_empty () inside another read's callback, a handler of the
 * history's own signals -- and a conclusion there re-enters the manager and
 * the history mid-operation and publishes under that emission, which
 * g_paste_clipboard_update_supersede () exists not to do. Concluded first, the
 * copy would still have to act on nothing, the selection being what overtook
 * it: decisions without their actions, which is what the manager makes of the
 * records it froze at the release (judge_overtaken ()). */
static const gchar *overtaken_text;

/**
 * g_paste_clipboard_update_overtaken_text:
 *
 * Returns: (nullable): while an update's callback is handed a copy its owner
 *          served whole before leaving and that something overtook before it
 *          concluded (g_paste_clipboard_update_owner_gone ()), the text that
 *          read found on the selection, as the provider's cache takes it from a
 *          read that concludes first -- the selection's own bytes where the
 *          hint never answered -- and %NULL otherwise
 *
 * What such a copy is judged by, the cache answering for whatever overtook it.
 */
const gchar *
g_paste_clipboard_update_overtaken_text (void)
{
    return overtaken_text;
}

/* Hand @item (transfer full, nullable) to whoever asked for @update, and run
 * what was chained onto it (g_paste_clipboard_update_then ()). @seen is the text
 * an overtaken copy found on the selection, %NULL for any other.
 *
 * Everything this conclusion has of its own is done with before any call below,
 * every one of which can end up back here: publishing drops the previous owner,
 * which can fail a transfer this very update is still waiting on --
 * synchronously, on the mutter backend -- the callback reaches the history,
 * which publishes too, and what was chained onto the update reaches the
 * manager the same way. A read failing counts itself out, and the last one to
 * do so frees the update, so anything read off it afterwards is read off freed
 * memory -- the provider included, whose only ref is the update's, hence the
 * one taken over below. */
static void
g_paste_clipboard_update_answer (GPasteClipboardUpdate *update,
                                 GPasteItem            *item,
                                 const gchar           *seen)
{
    g_autoptr (GPasteItem) owned = item;
    gboolean superseded = update->superseded;
    gboolean reselect = update->reselect;
    /* Read before the release below, not after: that includes the mime results
     * @sensitive lives in, and a *_clear () completed to zero the struct it
     * owns -- the natural reading of its name -- would silently land every
     * marked password as ordinary text. An overtaken update answers %UNKNOWN,
     * as g_paste_clipboard_update_conclude () says, bar a copy its owner served
     * whole before leaving: what its hint said before the owner left, if it
     * did, is what that copy is judged by
     * (/clipboard/released_copy/answered_no). */
    GPasteClipboardSecret secret = (superseded && !update->released) ? G_PASTE_CLIPBOARD_SECRET_UNKNOWN
                                                                       : g_paste_clipboard_mime_results_get_secret (&update->mimes);

    g_paste_clipboard_update_release_content (update);
    g_paste_clipboard_read_guard_disarm (&update->guard);

    /* Taken over rather than ref'd alongside: this is where the update stops
     * holding the provider up, and a conclusion the reads outlive would
     * otherwise hold it for as long as they do. */
    g_autoptr (GPasteClipboardProvider) provider = g_steal_pointer (&update->provider);
    GPasteClipboardProviderUpdateCallback callback = update->callback;
    gpointer user_data = update->user_data;
    GSList *thens = g_steal_pointer (&update->thens);

    /* Re-own trimmed text only after its reads are complete, so replacing the
     * owner cannot abort the remaining MIME transfers. Publishing the item also
     * preserves a password's sensitive hint. */
    if (reselect && owned)
        g_paste_clipboard_provider_select_item_full (provider, owned, FALSE);

    /* (transfer full) to the callback, and ours to release when there is none:
     * an update fired with no callback is part of the contract -- what a
     * backend's update () itself checks on every early return -- and what the
     * item holds can be a password's cleartext. */
    if (callback)
    {
        const gchar *outer = overtaken_text;

        overtaken_text = seen;
        callback (provider, g_steal_pointer (&owned), superseded, secret, user_data);
        overtaken_text = outer;
    }

    for (GSList *l = thens; l; l = l->next)
    {
        GPasteClipboardUpdateThen *then = l->data;

        then->func (provider, superseded, then->data);
    }
    g_slist_free_full (thens, g_free);
}

/* Build what the update read and hand it to whoever asked for it.
 *
 * Separate from the teardown below because the guard concludes an update whose
 * reads will never come back, and those reads are what frees the struct: the
 * item is built, the caller is called back, everything either of them was built
 * from is released above, and what waits on reads that may never land is the
 * counter they report to. */
static void
g_paste_clipboard_update_conclude (GPasteClipboardUpdate *update)
{
    update->concluded = TRUE;

    /* @slot names the update in flight, and this one has stopped being it,
     * whichever of the two ways it concluded: an update left there is what the
     * next one to start marks and releases, which it does without asking whether
     * anything is left to conclude. */
    if (*update->slot == update)
        *update->slot = NULL;

    /* Overtaken while it was reading (see @superseded): nothing to build an item
     * from -- bar a copy its owner served whole before leaving (@released),
     * which goes on below -- and no selection to re-own. What is left to answer
     * is the secret, and %UNKNOWN is the only thing this update can say: what it
     * read is what that selection carried, the update that overtook it answers
     * for what sits there now, and a record already kept has no grounds to be
     * retired here. */
    if (update->superseded && !update->released)
    {
        g_paste_clipboard_update_answer (update, NULL, NULL);
        return;
    }

    /* A hint read the deadline outlasted answered nothing, and neither does
     * concluding without it: the text lands as text either way, but a record
     * already kept for this selection has no grounds to be retired here. */
    if (update->sensitive_pending)
        update->mimes.sensitive_unknown = TRUE;

    /* Text policy needs the hint results: passwords preserve whitespace and
     * must reach the manager even when their value matches its text cache.
     *
     * An unanswered hint is not a password, so size, trimming and dedup still
     * apply; only re-owning does not, as it would put the stripped text over
     * what may be a secret with no hint on it. Such a text is classified as the
     * primary's is: trimmed for the history, left as it stands on the selection
     * (the /clipboard/unknown_hint tests). The cache keeps the selection's exact
     * value for matching a recorded password, even when history policy trims or
     * rejects the item. */
    /* @unidentified says the cache is to keep the selection's own bytes; the
     * string itself is only taken aside when the classification below is about
     * to replace them, and is stolen rather than copied even then -- a
     * selection's text can be megabytes, which is the same reason
     * classify_text () hands back %NULL for a text it leaves as it is. */
    gboolean unidentified = update->produced && update->content_kind == CLIPBOARD_CONTENT_TEXT && update->mimes.sensitive_unknown;
    g_autoptr (GPasteCleartext) unidentified_text = NULL;
    /* See the DROP case below. */
    gboolean empty_text = FALSE;

    if (update->produced && update->content_kind == CLIPBOARD_CONTENT_TEXT)
    {
        g_autofree gchar *value = NULL;
        /* GPaste rewrites nothing it is not recording: not while paused, nor
         * for a read only identifying the selection -- nor for a copy that
         * selection has moved on from. */
        gboolean may_reselect = (!update->superseded &&
                                 g_paste_clipboard_provider_is_clipboard (update->provider) &&
                                 !update->mimes.sensitive_unknown &&
                                 update->record &&
                                 g_paste_settings_get_track_changes (update->settings));
        GPasteClipboardTextAction action = g_paste_clipboard_content_classify_text (update->cache, update->settings,
                                                                                    may_reselect, update->text,
                                                                                    update->mimes.sensitive, &value);

        switch (action)
        {
        case G_PASTE_CLIPBOARD_TEXT_UNCHANGED:
            update->unchanged = TRUE;
            update->produced = FALSE;
            break;
        case G_PASTE_CLIPBOARD_TEXT_DROP:
            update->produced = FALSE;
            /* And nothing to keep the selection's own bytes for: the cache is
             * what @unidentified would hold them in, and this is the one text the
             * size policy turns down -- which can be megabytes of it, the very
             * case g_paste_clipboard_content_set_ignored () exists for and what
             * the chain below reaches instead.
             *
             * What the cache would have been kept for is matching a standing
             * password record, and a cache holding no value is what
             * confirm_password () reads as a read that saw nothing: the record
             * stands unconfirmed rather than being retired, which is the side
             * that keeps a secret recorded (/clipboard/unknown_hint/dropped).
             *
             * Except for the empty text, which is not a read that saw nothing:
             * it is the owner's answer, and the one a password manager clearing
             * what it copied gives -- with the hint on it or not, served or not,
             * the value being what says what sits there. The cache holds that
             * empty string, which is cheap and is exactly what sits there, so
             * the record for the password it replaced is confirmed as gone and
             * retired, where a cache holding no value would leave that record
             * unconfirmed for good: every re-read answers the same, and an
             * unconfirmed record fails every wait for expiry, a re-exec and a
             * storage migration included (the
             * /clipboard/empty_text_retires_record tests). The mutter
             * backend hands an empty transfer over as that empty
             * string too (g_paste_clipboard_meta_update_on_text ()).
             * A text over max-text-item-size -- never a secret, which
             * the limits do not apply to -- is what the cache must not hold.
             * One under min-text-item-size is a few bytes, kept as any text
             * a read could not identify is, so that a standing record is
             * matched against what sits there rather than left unconfirmed
             * (/clipboard/unknown_hint/short). */
            empty_text = !*update->text;
            unidentified = unidentified && !empty_text && strlen (update->text) <= g_paste_settings_get_max_text_item_size (update->settings);
            break;
        case G_PASTE_CLIPBOARD_TEXT_RESELECT:
            update->reselect = TRUE;
            G_GNUC_FALLTHROUGH;
        case G_PASTE_CLIPBOARD_TEXT_SET:
            if (value)
            {
                if (unidentified)
                    unidentified_text = g_steal_pointer (&update->text);
                g_set_str_take (&update->text, g_steal_pointer (&value));
            }
            break;
        }
    }

    /* Nothing produced means nothing to build, whatever the kind said; and the
     * union means only the member matching the kind may be read, which is the
     * one the builder is handed. */
    GPasteClipboardContentKind kind = (update->produced) ? update->content_kind : CLIPBOARD_CONTENT_NONE;
    g_autoptr (GPasteItem) item = g_paste_clipboard_content_to_item (update->settings,
                                                                     kind,
                                                                     (kind == CLIPBOARD_CONTENT_TEXT) ? update->text : NULL,
                                                                     (kind == CLIPBOARD_CONTENT_IMAGE) ? update->texture : NULL,
                                                                     (kind == CLIPBOARD_CONTENT_FILE_LIST) ? update->file_list : NULL,
                                                                     (kind == CLIPBOARD_CONTENT_COLOR) ? &update->rgba : NULL,
                                                                     update->mimes.sensitive,
                                                                     update->mimes.special_mime);

    /* The text the cache takes from this read, where it takes one: for a read
     * whose hint never answered, whichever of the two is the selection's own --
     * the one taken aside above when trimming replaced it, and update->text
     * itself otherwise, which the item, when there is one, was built from by
     * copy -- and for a text item otherwise, the item's value, this very string.
     * Taken rather than copied: the release below would free it. */
    g_autoptr (GPasteCleartext) text = NULL;

    if (unidentified)
        text = (unidentified_text) ? g_steal_pointer (&unidentified_text) : g_steal_pointer (&update->text);
    else if (item && kind == CLIPBOARD_CONTENT_TEXT)
        text = g_steal_pointer (&update->text);

    /* Deduplication only remembers content whose update survived. Publishing a
     * cache entry while MIME reads are pending would let a superseded update
     * suppress its successor without either producing a history item. A copy
     * overtaken once its owner left fills nothing either: the cache answers for
     * what overtook it, and the text it would have taken is what the copy is
     * judged by instead (g_paste_clipboard_update_overtaken_text ()). */
    if (!update->superseded)
    {
        if (text)
            g_paste_clipboard_content_set_text_take (update->cache, g_steal_pointer (&text));
        else if (item)
        {
            switch (kind)
            {
            case CLIPBOARD_CONTENT_IMAGE:
                g_paste_clipboard_content_set_image_checksum (update->cache, g_paste_image_item_get_checksum (G_PASTE_IMAGE_ITEM (item)));
                break;
            case CLIPBOARD_CONTENT_FILE_LIST:
                g_paste_clipboard_content_set_file_list (update->cache, update->file_list);
                break;
            case CLIPBOARD_CONTENT_COLOR:
                g_paste_clipboard_content_set_color (update->cache, &update->rgba);
                break;
            case CLIPBOARD_CONTENT_TEXT:
            case CLIPBOARD_CONTENT_NONE:
            case CLIPBOARD_CONTENT_IGNORED:
            case CLIPBOARD_CONTENT_WITHHELD:
                g_assert_not_reached ();
            }
        }
        else if (empty_text)
            g_paste_clipboard_content_set_text (update->cache, "");
        /* A secret that is not a text is read for what it is, and kept as
         * nothing: the selection is identified all the same, and no password is
         * on it (g_paste_clipboards_manager_confirm_password ()). */
        else if (kind != CLIPBOARD_CONTENT_NONE && kind != CLIPBOARD_CONTENT_TEXT && update->mimes.sensitive)
            g_paste_clipboard_content_set_withheld (update->cache);
        /* Rejection and read failure establish no match with the previous
         * owner. Keep an unidentified selection non-empty so it cannot be
         * restored over. */
        else if (!update->unchanged)
            g_paste_clipboard_content_set_ignored (update->cache);
    }

    g_paste_clipboard_update_answer (update, g_steal_pointer (&item), (update->superseded) ? text : NULL);
}

/* The guard ran out: conclude the update with what did arrive. Why it concludes
 * rather than failing the reads still out -- cancelling cannot fail them -- and
 * what that leaves behind is each backend's own answer, beside its update (). */
static void
g_paste_clipboard_update_timed_out (gpointer user_data)
{
    GPasteClipboardUpdate *update = user_data;

    g_debug ("%s: %s",
             g_paste_clipboard_provider_target_name (g_paste_clipboard_provider_is_clipboard (update->provider)),
             (update->superseded) ? "concluding a clipboard read its selection has moved on from"
                                  : "giving up on a clipboard read that never came back");
    g_paste_clipboard_update_conclude (update);
}

/**
 * g_paste_clipboard_update_supersede:
 * @slot: where the backend keeps the update in flight on this selection
 *
 * Give up on the update @slot holds, the selection it was reading having changed
 * under it
 *
 * Every read it has left is now a read of content nothing holds, and letting it
 * conclude would add the *older* copy to the history as the newest entry and
 * hand the provider's cache a text its selection has replaced. Marked rather
 * than concluded here, a conclusion calling back into the clipboards manager
 * whose notify () this is running under: what is left of that update is a
 * counter and a guard, and the guard's deadline -- brought forward to the next
 * turn of the main loop -- answers for both there instead.
 *
 * Everything of any size goes now rather than at that update's own conclusion,
 * which a read that never lands leaves a whole %G_PASTE_CLIPBOARD_READ_TIMEOUT
 * away: a superseded texture is one nothing will ever be built from, and a
 * superseded text can be a password's cleartext. The one exception is a copy its
 * owner served whole before leaving, which is still recorded
 * (g_paste_clipboard_update_owner_gone ()) and keeps what it is built from until
 * its conclusion, already brought forward to the next turn.
 *
 * Called for its own sake by the paths that answer a change without starting an
 * update -- a selection released, an owner offering only types this build does
 * not handle -- since what makes the update in flight stale is the change, not
 * the one replacing it: those answer their caller and return, and the update
 * they leave behind would otherwise land as if its selection still stood.
 */
G_PASTE_VISIBLE void
g_paste_clipboard_update_supersede (GPasteClipboardUpdate **slot)
{
    g_return_if_fail (slot);

    if (!*slot)
        return;

    GPasteClipboardUpdate *previous = g_steal_pointer (slot);

    previous->superseded = TRUE;
    if (!previous->released)
        g_paste_clipboard_update_release_content (previous);

    /* And concluded on the next turn of the main loop rather than at its own
     * deadline: the callers that supersede without starting a successor leave
     * nothing else to bound it, so a conclusion %G_PASTE_CLIPBOARD_READ_TIMEOUT
     * away is one reaching the clipboards manager with an update that says
     * nothing, against a cache that has moved on twice over -- while holding the
     * provider, and on X11 the requestor window behind it, for that whole while.
     * Soon and not here for the reason above: a conclusion calls back into the
     * notify () this is running under. */
    g_paste_clipboard_read_guard_expire_soon (&previous->guard);
}

/**
 * g_paste_clipboard_update_owner_gone:
 * @slot: where the backend keeps the update in flight on this selection
 *
 * Give up on what is left of the update @slot holds, its selection having been
 * released: the content it read is the last that selection held, and what is
 * still out was asked of an owner that is gone and will answer none of it.
 * Concluded on the next turn of the main loop, as its deadline would conclude
 * it, what is still out counting as unanswered -- a hint among it leaving the
 * content's secrecy unknown. An owner serving one request at a time and leaving
 * once it served the content does exactly this, a paste helper set to exit
 * after so many requests among them.
 *
 * It stays in @slot until then, and whatever reaches that selection first -- a
 * new owner, or a publication -- supersedes it there. Its copy is recorded all
 * the same, being complete -- nothing still out will ever answer -- as is any
 * copy whose reads all came back before the change: it fills no cache and
 * re-owns nothing, those being the change's to answer for, and goes to the
 * callback as a superseded update's item for the history alone.
 *
 * An update whose content has not landed has nothing to build an item from,
 * and is superseded (g_paste_clipboard_update_supersede ()).
 *
 * Returns: (transfer none) (nullable): the update left to conclude, which the
 *          answer to the release is chained onto
 *          (g_paste_clipboard_update_then ()), or %NULL when there is none
 */
G_PASTE_VISIBLE GPasteClipboardUpdate *
g_paste_clipboard_update_owner_gone (GPasteClipboardUpdate **slot)
{
    g_return_val_if_fail (slot, NULL);

    if (!*slot)
        return NULL;

    /* Content whose bytes are in but still being decoded counts as not landed,
     * and is lost the same way: the one decode run off the read's own callback
     * is the mutter backend's gdk_content_deserialize_async (), reached only in
     * a host that initialised GTK, which gnome-shell never is. */
    if (!(*slot)->produced)
    {
        g_paste_clipboard_update_supersede (slot);
        return NULL;
    }

    /* Left in @slot, so that whatever comes next for the selection supersedes
     * it, however soon. What that puts there is newer than the copy, and a
     * conclusion landing after it would fill the cache, re-own the selection
     * with a trimmed text and answer the manager for a selection that has moved
     * on: a password published there meanwhile would be taken for gone, its
     * countdown with it (/meta/release/publish-before-conclusion,
     * /gdk/formats/release-publish). Superseded, it is recorded and does none
     * of those (/meta/release/trimmed-before-publication); the price is that it
     * lands at the head of the history, above whatever that change put there. */
    GPasteClipboardUpdate *previous = *slot;

    previous->released = TRUE;
    g_paste_clipboard_read_guard_expire_soon (&previous->guard);

    return previous;
}

/**
 * g_paste_clipboard_update_then:
 * @update: the #GPasteClipboardUpdate to chain onto, not concluded yet
 * @then: (scope async): what to run once it has concluded
 * @data: what to run it with
 *
 * Have @update run @then once it has concluded and its callback has returned,
 * superseded or not: what a backend answers a release with when the update it
 * ended has a copy to hand over first (g_paste_clipboard_update_owner_gone ()),
 * the copy reaching the history and the other selection before the release
 * clears the cache it fills.
 *
 * @then is told whether @update was superseded, and is the last thing the
 * conclusion does; @data is the backend's to release from it. Every one chained
 * runs, in the order chained: a selection released twice before the update
 * the first release ended has concluded hands that same update back twice, and
 * both releases are owed their answer (/meta/release/twice).
 */
G_PASTE_VISIBLE void
g_paste_clipboard_update_then (GPasteClipboardUpdate        *update,
                               GPasteClipboardUpdateThenFunc then,
                               gpointer                      data)
{
    g_return_if_fail (update);
    g_return_if_fail (!update->concluded);
    g_return_if_fail (then);

    GPasteClipboardUpdateThen *chained = g_new (GPasteClipboardUpdateThen, 1);

    chained->func = then;
    chained->data = data;
    update->thens = g_slist_append (update->thens, chained);
}

/**
 * g_paste_clipboard_update_new:
 * @provider: the #GPasteClipboardProvider being read
 * @settings: a #GPasteSettings instance, for what the item is built under
 * @content_kind: the kind the content read is for
 * @slot: where the backend keeps the update in flight on this selection
 * @cache: the provider's committed content, written only when this update
 *         completes
 * @callback: (scope async) (nullable): who to hand the item to
 * @user_data: what to hand it with
 *
 * Start an update, guard armed and one read outstanding, giving up on the one it
 * overtakes
 *
 * The one read is the caller's own: a backend fires its reads and then counts
 * itself out with g_paste_clipboard_update_maybe_done(), so an update whose
 * reads all answered synchronously still concludes exactly once.
 *
 * Whatever @slot held is superseded (g_paste_clipboard_update_supersede ()),
 * this being one of the changes that leave it reading a selection nothing holds.
 *
 * Returns: (transfer full): the newly allocated #GPasteClipboardUpdate
 */
G_PASTE_VISIBLE GPasteClipboardUpdate *
g_paste_clipboard_update_new (GPasteClipboardProvider              *provider,
                              GPasteSettings                       *settings,
                              GPasteClipboardContentKind            content_kind,
                              GPasteClipboardUpdate               **slot,
                              GPasteClipboardContent               *cache,
                              GPasteClipboardProviderUpdateCallback callback,
                              gpointer                              user_data)
{
    g_return_val_if_fail (G_PASTE_IS_CLIPBOARD_PROVIDER (provider), NULL);
    g_return_val_if_fail (G_PASTE_IS_SETTINGS (settings), NULL);
    g_return_val_if_fail (slot, NULL);
    g_return_val_if_fail (cache, NULL);
    /* An update reads some content, and with it the hints saying it is a
     * secret: a kind carrying none -- nothing there, ignored, withheld -- is
     * no update to make. */
    g_return_val_if_fail (content_kind == CLIPBOARD_CONTENT_TEXT || content_kind == CLIPBOARD_CONTENT_IMAGE ||
                          content_kind == CLIPBOARD_CONTENT_FILE_LIST || content_kind == CLIPBOARD_CONTENT_COLOR, NULL);

    g_paste_clipboard_update_supersede (slot);

    GPasteClipboardUpdate *update = g_new0 (GPasteClipboardUpdate, 1);

    /* Refs for the whole update -- the content read plus every mime read --
     * released when it is: it spans main-loop iterations, and a provider being
     * disposed under one is what these are here to survive. */
    update->provider = g_object_ref (provider);
    update->settings = g_object_ref (settings);
    update->callback = callback;
    update->user_data = user_data;
    update->pending = 1;
    update->record = TRUE;
    update->content_kind = content_kind;
    update->slot = slot;
    update->cache = cache;

    *slot = update;

    g_paste_clipboard_read_guard_arm (&update->guard, g_paste_clipboard_update_timed_out, update);

    return update;
}

/**
 * g_paste_clipboard_update_is_expired:
 * @update: the #GPasteClipboardUpdate a read counted into
 *
 * Returns: whether @update has already moved on without the read asking
 *
 * What a read landing asks before it touches anything but the counter. Nothing
 * is waiting for it either way, and what it brings back can only reach the
 * provider's cache -- where it would name content that selection no longer
 * holds, and dedup that very content out of every later update.
 *
 * Asked of the update and not of the guard's cancellable, which answers a moment
 * too late for both: a conclusion disarms the guard and takes the provider
 * over, and only then cancels -- the cancellation being what runs the handlers
 * that could free the very update being concluded (see
 * g_paste_clipboard_read_guard_timed_out ()) -- and an update overtaken by the
 * next one has its guard brought forward to an idle
 * (g_paste_clipboard_update_supersede ()), which concludes and cancels it a
 * main-loop turn later, its reads landing in between.
 */
G_PASTE_VISIBLE gboolean
g_paste_clipboard_update_is_expired (const GPasteClipboardUpdate *update)
{
    g_return_val_if_fail (update, TRUE);

    return update->concluded || update->superseded;
}

/**
 * g_paste_clipboard_update_add_read:
 * @update: the #GPasteClipboardUpdate about to fire one more read
 *
 * Count one read into @update
 *
 * Written beside the call that fires the read and never before the choice of
 * whether to fire one: a read counted in that never goes out leaves @update
 * unable to conclude -- and, its guard having only concluded it, never freed.
 */
G_PASTE_VISIBLE void
g_paste_clipboard_update_add_read (GPasteClipboardUpdate *update)
{
    g_return_if_fail (update);

    ++update->pending;
}

/**
 * g_paste_clipboard_update_add_special_mime_read:
 * @update: the #GPasteClipboardUpdate the read counts into
 * @mime: which entry it is being fired for
 *
 * Count one special-mime read into @update and build what it has to carry
 *
 * The two halves of firing one, which is why they are one call: the count and
 * the context are the same read, and a backend that wrote only one of them
 * would either wedge @update (see add_read ()) or lose what its answer means.
 * All that is left to a backend is the call that fetches the bytes.
 *
 * Returns: (transfer full): the #GPasteClipboardMimeCtx to fire the read with
 */
G_PASTE_VISIBLE GPasteClipboardMimeCtx *
g_paste_clipboard_update_add_special_mime_read (GPasteClipboardUpdate *update,
                                                GPasteSpecialMime      mime)
{
    g_return_val_if_fail (update, NULL);

    g_paste_clipboard_update_add_read (update);

    GPasteClipboardMimeCtx *ctx = g_paste_clipboard_mime_ctx_new (update);

    ctx->special = mime;

    return ctx;
}

/**
 * g_paste_clipboard_update_add_sensitive_mime_read:
 * @update: the #GPasteClipboardUpdate the read counts into
 * @mime: the #GPasteSensitiveMime it is being fired for
 *
 * Count one sensitive-mime read into @update and build what it has to carry
 *
 * The sensitive half of g_paste_clipboard_update_add_special_mime_read (), and
 * the same bargain: what the answer means is decided here rather than by the
 * backend that fetched it.
 *
 * Returns: (transfer full): the #GPasteClipboardMimeCtx to fire the read with
 */
G_PASTE_VISIBLE GPasteClipboardMimeCtx *
g_paste_clipboard_update_add_sensitive_mime_read (GPasteClipboardUpdate *update,
                                                  GPasteSensitiveMime    mime)
{
    g_return_val_if_fail (update, NULL);

    g_paste_clipboard_update_add_read (update);
    ++update->sensitive_pending;

    GPasteClipboardMimeCtx *ctx = g_paste_clipboard_mime_ctx_new (update);

    ctx->sensitive = TRUE;
    ctx->hint = mime;

    return ctx;
}

/**
 * g_paste_clipboard_update_add_sensitive_offer_read:
 * @update: the #GPasteClipboardUpdate the read counts into
 *
 * Count into @update the read that asks which hints the selection offers
 *
 * For a backend that has to make a round trip of its own to learn that before
 * it can hand g_paste_clipboard_update_read_sensitive_mimes () an answer; one
 * whose formats already say has no use for this.
 *
 * Counted among the hint reads and not merely among the reads, because it is out
 * after the same thing they are: a deadline this one outlasts leaves every hint
 * it would have fired unfired, which is the update having learned nothing about
 * the selection rather than the selection saying its content is ordinary.
 * Reported with g_paste_clipboard_update_on_sensitive_offer_read ().
 */
G_PASTE_VISIBLE void
g_paste_clipboard_update_add_sensitive_offer_read (GPasteClipboardUpdate *update)
{
    g_return_if_fail (update);

    g_paste_clipboard_update_add_read (update);
    ++update->sensitive_pending;
}

/**
 * g_paste_clipboard_update_on_sensitive_offer_read:
 * @update: the #GPasteClipboardUpdate the read counted into
 * @answered: whether the selection said what it offers
 *
 * Count the offer-list read out of @update, as a hint read and as a read
 *
 * Called once the hint reads it fires have been added, so the batch is never
 * momentarily empty and concluded from under them -- and, for the same reason,
 * never momentarily out of hint reads either.
 *
 * A read that got no answer is not a selection offering no hint, and leaves the
 * update's secrecy unknown: see #GPasteClipboardMimeResults.
 */
G_PASTE_VISIBLE void
g_paste_clipboard_update_on_sensitive_offer_read (GPasteClipboardUpdate *update,
                                                  gboolean               answered)
{
    g_return_if_fail (update);

    if (!answered)
        update->mimes.sensitive_unknown = TRUE;

    --update->sensitive_pending;
    g_paste_clipboard_update_maybe_done (update);
}

/**
 * g_paste_clipboard_update_read_special_mimes:
 * @update: the #GPasteClipboardUpdate the reads count into
 * @offer: what @offered consults to answer, opaque here
 * @offered: (scope call): whether the selection offers a mimetype
 * @backend: what @read fires the read on
 * @read: (scope async): fires the read of one mimetype
 *
 * Fire, on top of the content read, every special value @update wants and the
 * selection offers.
 *
 * They ride along with a file list, and with a text only where rich text is
 * wanted -- turning that setting off is asking for the text and nothing dressed
 * on top of it.
 */
G_PASTE_VISIBLE void
g_paste_clipboard_update_read_special_mimes (GPasteClipboardUpdate         *update,
                                             gconstpointer                  offer,
                                             GPasteClipboardMimeOfferedFunc offered,
                                             gpointer                       backend,
                                             GPasteClipboardMimeReadFunc    read)
{
    g_return_if_fail (update);
    g_return_if_fail (offered);
    g_return_if_fail (read);

    if (update->content_kind != CLIPBOARD_CONTENT_FILE_LIST &&
        (update->content_kind != CLIPBOARD_CONTENT_TEXT || !g_paste_settings_get_rich_text_support (update->settings)))
        return;

    for (GPasteSpecialMime mime = G_PASTE_SPECIAL_MIME_FIRST; mime < G_PASTE_SPECIAL_MIME_LAST; ++mime)
    {
        const gchar *mimetype = g_paste_special_mime_get (mime);

        if (offered (offer, mimetype))
            read (backend, mimetype, update->guard.cancellable, g_paste_clipboard_update_add_special_mime_read (update, mime));
    }
}

/**
 * g_paste_clipboard_update_read_sensitive_mimes:
 * @update: the #GPasteClipboardUpdate the reads count into
 * @offer: what @offered consults to answer, opaque here
 * @offered: (scope call): whether the selection offers a mimetype
 * @backend: what @read fires the read on
 * @read: (scope async): fires the read of one mimetype
 *
 * Fire every hint @update wants and the selection offers.
 *
 * Callable on its own by a backend that learns which hints are on offer only
 * once its other reads are out: see
 * g_paste_clipboard_update_add_sensitive_offer_read ().
 */
G_PASTE_VISIBLE void
g_paste_clipboard_update_read_sensitive_mimes (GPasteClipboardUpdate         *update,
                                               gconstpointer                  offer,
                                               GPasteClipboardMimeOfferedFunc offered,
                                               gpointer                       backend,
                                               GPasteClipboardMimeReadFunc    read)
{
    g_return_if_fail (update);
    g_return_if_fail (offered);
    g_return_if_fail (read);

    for (GPasteSensitiveMime mime = G_PASTE_SENSITIVE_MIME_FIRST; mime < G_PASTE_SENSITIVE_MIME_LAST; ++mime)
    {
        const gchar *mimetype = g_paste_sensitive_mime_get (mime);

        if (offered (offer, mimetype))
            read (backend, mimetype, update->guard.cancellable, g_paste_clipboard_update_add_sensitive_mime_read (update, mime));
    }
}

/**
 * g_paste_clipboard_update_read_mimes:
 * @update: the #GPasteClipboardUpdate the reads count into
 * @offer: what @offered consults to answer, opaque here
 * @offered: (scope call): whether the selection offers a mimetype
 * @backend: what @read fires the read on
 * @read: (scope async): fires the read of one mimetype
 *
 * Fire, on top of the content read, every representation @update wants and the
 * selection offers: g_paste_clipboard_update_read_special_mimes () and
 * g_paste_clipboard_update_read_sensitive_mimes () against the same @offer.
 *
 * Those two are the whole of the policy, and it is here rather than in either
 * backend because it is not theirs: they differ in how a selection is asked
 * what it offers and in how bytes are fetched, in nothing else, and a condition
 * written once per backend is a condition one of them will be missing. A backend
 * with no single @offer answering for both families -- the GDK one, whose
 * formats leave the hints out -- calls the two halves with two answers instead.
 */
G_PASTE_VISIBLE void
g_paste_clipboard_update_read_mimes (GPasteClipboardUpdate         *update,
                                     gconstpointer                  offer,
                                     GPasteClipboardMimeOfferedFunc offered,
                                     gpointer                       backend,
                                     GPasteClipboardMimeReadFunc    read)
{
    g_paste_clipboard_update_read_special_mimes (update, offer, offered, backend, read);
    g_paste_clipboard_update_read_sensitive_mimes (update, offer, offered, backend, read);
}

/**
 * g_paste_clipboard_update_on_mime_read:
 * @ctx: (transfer full): what the read was fired with
 * @bytes: (nullable): what it came back with
 *
 * Record what one finished mime read means and count it out of its update
 *
 * The whole of what a backend does with a mime read that has landed: what the
 * bytes mean is #GPasteClipboardMimeResults' answer, and what a read reporting
 * does to the update is this file's, so neither backend has anything to add
 * around it.
 */
G_PASTE_VISIBLE void
g_paste_clipboard_update_on_mime_read (GPasteClipboardMimeCtx *ctx,
                                       GBytes                 *bytes)
{
    g_return_if_fail (ctx);

    g_autoptr (GPasteClipboardMimeCtx) owned = ctx;
    GPasteClipboardUpdate *update = ctx->data;

    if (ctx->sensitive)
        --update->sensitive_pending;

    /* As for the content reads (g_paste_clipboard_update_is_expired ()): an
     * update that has moved on stores nothing more, or a sibling read that never
     * reports would keep these bytes for the rest of the session. */
    if (!g_paste_clipboard_update_is_expired (update))
    {
        if (ctx->sensitive)
            g_paste_clipboard_mime_results_store_sensitive (&update->mimes, ctx->hint, bytes);
        else
            g_paste_clipboard_mime_results_store_special (&update->mimes, ctx->special, bytes);
    }

    g_paste_clipboard_update_maybe_done (update);
}

/**
 * g_paste_clipboard_update_maybe_done:
 * @update: the #GPasteClipboardUpdate one of whose reads has just reported
 *
 * Count one read out of @update, and conclude it once none is left
 *
 * Every read an update fires ends here, whatever it came back with and whether
 * or not anything is still waiting for it: this is what says the batch is still
 * moving (the guard's deadline measures silence) and what eventually releases
 * what the update was built from.
 */
G_PASTE_VISIBLE void
g_paste_clipboard_update_maybe_done (GPasteClipboardUpdate *update)
{
    g_return_if_fail (update);

    /* A read reporting is this batch demonstrably alive, so the rest of it gets
     * its deadline back. A no-op once the update is concluded, the guard having
     * been disarmed by the conclusion. */
    g_paste_clipboard_read_guard_touch (&update->guard);

    if (--update->pending > 0)
        return;

    if (!update->concluded)
        g_paste_clipboard_update_conclude (update);

    /* Anything a read that outlived the guard stored on its way in; the
     * conclusion released the rest of it where it stood. */
    g_paste_clipboard_update_release_content (update);
    g_paste_clipboard_read_guard_clear (&update->guard);

    /* Here and not at the conclusion, with everything the item was built from:
     * this is what a read was fired *with*, and a backend is free to have handed
     * the very pointer to its transfer -- the mutter one does, and that transfer
     * reads the string after the call returns. A guard concluding the update
     * leaves those reads running, so the string they are holding may only go
     * once every one of them has reported, which is here. */
    g_clear_pointer (&update->mime, g_free);

    /* Taken over by the conclusion, which every path here has been through. */
    g_clear_object (&update->provider);
    g_free (update);
}
