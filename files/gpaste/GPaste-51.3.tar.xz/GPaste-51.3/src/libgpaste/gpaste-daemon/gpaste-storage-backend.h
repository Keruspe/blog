// SPDX-FileCopyrightText: 2010-2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com>
// SPDX-License-Identifier: BSD-2-Clause

#pragma once

#include <gpaste-3/gpaste-settings.h>
#include <gpaste-3/gpaste-storage.h>

#include <gpaste-daemon/gpaste-item.h>

G_BEGIN_DECLS

#define G_PASTE_TYPE_STORAGE_BACKEND (g_paste_storage_backend_get_type ())

G_PASTE_DERIVABLE_TYPE (StorageBackend, storage_backend, STORAGE_BACKEND, GObject)

/* Laid out by what reads best, not for an older layout's sake: see
 * libgpaste_daemon_soversion in src/libgpaste/meson.build. */
struct _GPasteStorageBackendClass
{
    GObjectClass parent_class;

    /*< pure virtual >*/
    /* Every vfunc here is given the history's *name*, not a path: the path is
     * the backend's own, derived with g_paste_storage_backend_get_history_file_path().
     *
     * Returns %FALSE when the history file is present but could not be read back
     * (a failed decryption, parse or I/O error), so a caller can tell a genuine
     * empty history apart from a read that silently yielded nothing -- and
     * likewise for a read @cancellable stopped partway, a partial history being
     * one nothing may persist over.
     *
     * A write returns whether the store of @name holds @history now: one that
     * fails leaves it as it was, and leaves none where there was none. */
    gboolean (*read_history_file)  (GPasteStorageBackend *self,
                                    const gchar          *name,
                                    GCancellable         *cancellable,
                                    GList               **history,
                                    gsize                *size);
    gboolean (*write_history_file) (GPasteStorageBackend *self,
                                    const gchar          *name,
                                    const GList          *history);

    /*< protected >*/
    /* Which flavour this instance is. Everything else about the flavour --
     * the on-disk extension, whether it encrypts, whether it may keep password
     * items -- follows from it, so this is the one thing a backend answers. */
    GPasteStorage         (*get_kind)       (GPasteStorageBackend *self);
    void                  (*delete_history) (GPasteStorageBackend *self,
                                             const gchar          *name,
                                             GError              **error);
    GStrv                 (*list_histories) (GPasteStorageBackend *self,
                                             GError              **error);

    /*< protected, optional: how many items a history holds >*/
    /* Answer without materializing the history, where the store can count on its
     * own. The default reads the history and counts what came back, which is
     * what listing every history's size costs when a backend has nothing
     * cheaper; a store that can count must answer the same set read_history_file
     * would have returned, cap and favourites included, or a listing and the
     * history it leads to would disagree. */
    gsize    (*count_history)              (GPasteStorageBackend *self,
                                            const gchar          *name);

    /*< protected, optional: passphrase verification >*/
    /* Whether the history called @name proves this backend's passphrase wrong:
     * it holds encrypted data the backend cannot open. Everything else -- an
     * empty placeholder, a truncated or foreign file, an I/O error -- is
     * inconclusive and must answer %FALSE: condemning a passphrase over a
     * corrupt file tells the user their correct one is wrong. A check that
     * could not be made at all -- the key not derived -- answers %FALSE too,
     * and says so (g_paste_storage_backend_set_unverifiable ()).
     *
     * Only ever asked of a backend built with the passphrase under test. */
    gboolean (*history_refutes_passphrase)  (GPasteStorageBackend *self,
                                             const gchar          *name);
    /* Whether it proves the passphrase right: it holds what this backend
     * encrypted under it. Read-only too, as verifying has to be, and set by
     * every backend setting history_refutes_passphrase. */
    gboolean (*history_confirms_passphrase) (GPasteStorageBackend *self,
                                             const gchar          *name);

    /*< protected, optional: re-encrypt an existing history under a new key >*/
    /* @self holds the passphrase the history is currently encrypted with; only
     * the encrypted flavors implement this. Returns %FALSE when @name could not
     * be re-keyed, having put back what it had already changed, so a caller
     * re-keying several histories can stop instead of ending up with a set
     * split across two passphrases -- unless what changed could not all be put
     * back either, which sets @split (never %NULL, and %FALSE on entry). */
    gboolean (*rekey)                (GPasteStorageBackend *self,
                                      const gchar          *name,
                                      const gchar          *new_passphrase,
                                      gboolean             *split);

    /*< protected, optional: incremental updates >*/
    /* @history is the whole history as it now stands, for reconciling whatever
     * rode along with the add -- a dedup, a grown line, an eviction. It is
     * %NULL when nothing did, which is the common case: reconciliation only
     * ever drops rows the history no longer has, so there is then nothing to
     * do. A backend that does not implement all four of these gets the full
     * history written out instead, and so always sees a non-%NULL one. */
    void     (*add_item)             (GPasteStorageBackend *self,
                                      const gchar          *name,
                                      GPasteItem           *item,
                                      const GList          *history);
    void     (*remove_item)          (GPasteStorageBackend *self,
                                      const gchar          *name,
                                      const gchar          *uuid);
    void     (*replace_item)         (GPasteStorageBackend *self,
                                      const gchar          *name,
                                      const gchar          *old_uuid,
                                      GPasteItem           *item);
    void     (*clear_history)        (GPasteStorageBackend *self,
                                      const gchar          *name);
    /* Whether a write of @name failed since the last full one or emptying
     * that landed, the store lagging the history until one does. Asked on
     * the main thread after every write, so it must not wait on a read in
     * flight. Unset, the base class answers it from the full writes it sees,
     * which is all a backend without the incremental vfuncs makes, and, for
     * the backends of this library, from what their incremental writes record
     * of themselves. A backend from outside it implementing those has no way
     * to record them, and answers this itself. */
    gboolean (*has_diverged)         (GPasteStorageBackend *self,
                                      const gchar          *name);
};

GPasteSettings *g_paste_storage_backend_get_settings (GPasteStorageBackend *self);

GPasteStorage  g_paste_storage_backend_get_kind      (GPasteStorageBackend *self);
const gchar   *g_paste_storage_backend_get_extension (GPasteStorageBackend *self);
gboolean       g_paste_storage_backend_is_encrypted  (GPasteStorageBackend *self);
gboolean       g_paste_storage_backend_stores_item   (GPasteStorageBackend *self,
                                                      GPasteItem           *item);

gchar *g_paste_storage_backend_get_history_file_path (GPasteStorageBackend *self,
                                                      const gchar          *name);

gboolean g_paste_storage_backend_read_history  (GPasteStorageBackend *self,
                                                const gchar          *name,
                                                GCancellable         *cancellable,
                                                GList               **history,
                                                gsize                *size);
gboolean g_paste_storage_backend_write_history (GPasteStorageBackend *self,
                                                const gchar          *name,
                                                const GList          *history);
void g_paste_storage_backend_delete_history    (GPasteStorageBackend *self,
                                                const gchar          *name,
                                                GError              **error);
GStrv g_paste_storage_backend_list_histories   (GPasteStorageBackend *self,
                                                GError              **error);
gsize g_paste_storage_backend_count_history    (GPasteStorageBackend *self,
                                                const gchar          *name);
gboolean g_paste_storage_backend_delete_history_images (const gchar *name,
                                                        GError     **error);
gboolean g_paste_storage_backend_rekey         (GPasteStorageBackend *self,
                                                const gchar          *name,
                                                const gchar          *new_passphrase,
                                                gboolean             *split);

void     g_paste_storage_backend_add_item             (GPasteStorageBackend *self,
                                                       const gchar          *name,
                                                       GPasteItem           *item,
                                                       const GList          *history);
void     g_paste_storage_backend_remove_item          (GPasteStorageBackend *self,
                                                       const gchar          *name,
                                                       const gchar          *uuid,
                                                       const GList          *history);
void     g_paste_storage_backend_replace_item         (GPasteStorageBackend *self,
                                                       const gchar          *name,
                                                       const gchar          *old_uuid,
                                                       GPasteItem           *item,
                                                       const GList          *history);
void     g_paste_storage_backend_clear_history        (GPasteStorageBackend *self,
                                                       const gchar          *name,
                                                       const GList          *history);

gboolean g_paste_storage_backend_is_incremental       (GPasteStorageBackend *self);
gboolean g_paste_storage_backend_has_diverged         (GPasteStorageBackend *self,
                                                       const gchar          *name);

gboolean g_paste_storage_backend_lock     (GCancellable *cancellable);
gboolean g_paste_storage_backend_try_lock (void);
void     g_paste_storage_backend_unlock   (void);

GPasteStorageBackend *g_paste_storage_backend_new (GPasteStorage   storage_kind,
                                                   GPasteSettings *settings);
GPasteStorageBackend *g_paste_storage_backend_new_with_passphrase (GPasteStorage   storage_kind,
                                                                   GPasteSettings *settings,
                                                                   const gchar    *passphrase);

const gchar *g_paste_storage_get_extension (GPasteStorage storage_kind);
gboolean     g_paste_storage_name_fits     (GPasteStorage storage_kind,
                                            const gchar  *name);
gboolean     g_paste_storage_is_supported  (GPasteStorage storage_kind);

#ifdef G_PASTE_ENABLE_ENCRYPTION
void         g_paste_storage_backend_set_passphrase (const gchar *passphrase);
const gchar *g_paste_storage_backend_get_passphrase (void);

gboolean g_paste_storage_passphrase_can_decrypt (GPasteStorage   storage_kind,
                                                 GPasteSettings *settings,
                                                 const gchar    *passphrase);
gboolean g_paste_storage_passphrase_verifiable  (GPasteStorage   storage_kind,
                                                 GPasteSettings *settings);

gboolean g_paste_storage_backend_refutes_passphrase (GPasteStorageBackend *self,
                                                     const gchar          *name);
#endif

G_END_DECLS
