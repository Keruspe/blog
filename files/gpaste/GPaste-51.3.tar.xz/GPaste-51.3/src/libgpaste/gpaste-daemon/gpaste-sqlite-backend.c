// SPDX-FileCopyrightText: 2010-2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com>
// SPDX-License-Identifier: BSD-2-Clause

#include <gpaste-3/gpaste-util.h>

#include <gpaste-daemon/gpaste-color-item.h>
#include <gpaste-daemon/gpaste-daemon-util.h>
#include <gpaste-daemon/gpaste-image-item.h>
#include <gpaste-daemon/gpaste-passphrase.h>
#include <gpaste-daemon/gpaste-password-item.h>
#include <gpaste-daemon/gpaste-sqlite-backend.h>
#include <gpaste-daemon/gpaste-storage-backend-private.h>
#include <gpaste-daemon/gpaste-text-item.h>
#include <gpaste-daemon/gpaste-uris-item.h>

#include <sqlite3.h>

#ifdef G_PASTE_ENABLE_ENCRYPTION
#define GCR_API_SUBJECT_TO_CHANGE
#include <gcr/gcr.h>

#include <sodium.h>

#include <gpaste-daemon/gpaste-secret-stream-converter.h>
#endif

/* The SQLite storage backend: one database per history (<name>.db in the
 * history dir), storing the same data as the plain XML backend. It implements
 * the incremental vfuncs, so the saver feeds it per-operation changes instead
 * of full snapshots.
 *
 * Items live in an `items` table ordered by a monotonic `rank` (highest =
 * front of the history, so adds and selects never renumber anything), with
 * their extra MIME payloads in a `special_values` child table. The schema is
 * versioned through PRAGMA user_version so it can evolve: older databases are
 * migrated stepwise on open, newer ones are refused rather than corrupted:
 * every read and write leaves one as it is, while emptying the history
 * replaces it with an empty database, and deleting the history removes it.
 *
 * Like the plain XML backend, password items are never persisted (the file is
 * user-readable). Images are stored as blobs in the `items.image` column, which
 * is the whole of such a row: nothing on disk backs it, and its value is the
 * image's checksum, which names no file.
 *
 * The encrypted flavor (g_paste_sqlite_backend_new_encrypted, ".dbs" extension)
 * encrypts every content column — items.value, items.name, items.image and
 * special_values.data — with crypto_secretbox, each stored blob being
 * nonce ‖ ciphertext. The key is derived from the passphrase with crypto_pwhash
 * (Argon2id, same parameters as the encrypted file backend's stream converter);
 * the random salt, the Argon2 parameters and a key-check secretbox live in a
 * `meta` table so the key can be re-derived and verified — a wrong passphrase
 * is refused like a newer schema, so it can never overwrite the real data with
 * a wrongly-encrypted history. Unlike the plain flavor it persists password
 * items (the content is unreadable without the passphrase), trading a metadata
 * leak for incremental (non-rewriting) updates: row count, kind, rank, date,
 * checksum and a special value's mime stay in the clear because reading has to
 * order and filter on them, and a secretbox is exactly NONCEBYTES + MACBYTES
 * longer than what it seals, so every value's length shows through too -- a
 * password's among them, beside the `kind` column saying it is one. The
 * encrypted file flavor does not leak that last one, its 4 KiB chunking
 * blurring it. */

#define G_PASTE_SQLITE_SCHEMA_VERSION 3

/* Far beyond any reachable rank (one increment per add/select), but cheap to
 * guard against: past this, ranks are compacted back to 1..N on open. */
#define G_PASTE_SQLITE_RANK_COMPACT_THRESHOLD (G_GINT64_CONSTANT (1) << 62)

/* How long a connection waits out another one holding the database, in
 * milliseconds: every connection of this backend's, its probes' included. */
#define G_PASTE_SQLITE_BUSY_TIMEOUT 5000

struct _GPasteSqliteBackend
{
    GPasteStorageBackend parent_instance;

    /* The one open connection, lazily (re)opened for the last used database.
     * The lock serializes the vfuncs: the saver runs writes one at a time, but
     * a background load can overlap an in-flight write. */
    sqlite3          *db;
    gchar            *db_path;
    GMutex            lock;
    /* A database deleted while @lock was taken (delete_history ()), which
     * the cached connection must not answer for again: under @forgotten_lock
     * rather than @lock, which a load may hold for as long as its read takes. */
    gchar            *forgotten;
    GMutex            forgotten_lock;

#ifdef G_PASTE_ENABLE_ENCRYPTION
    /* When set, the content columns are encrypted, the ".dbs" extension is used,
     * and password entries are persisted rather than skipped. The key is
     * salt-dependent, hence derived per database and cached (in gcr secure
     * memory) alongside the connection. */
    GPastePassphrase *passphrase;
    guchar           *key;
#endif
};

G_PASTE_DEFINE_TYPE (SqliteBackend, sqlite_backend, G_PASTE_TYPE_STORAGE_BACKEND)

static void
g_paste_sqlite_backend_close (sqlite3 *db)
{
    sqlite3_close (db);
}

G_DEFINE_AUTOPTR_CLEANUP_FUNC (sqlite3, g_paste_sqlite_backend_close)

static gboolean
g_paste_sqlite_backend_exec (sqlite3     *db,
                             const gchar *sql)
{
    gchar *err = NULL;

    if (sqlite3_exec (db, sql, NULL, NULL, &err) != SQLITE_OK)
    {
        g_warning ("sqlite: failed to run “%s”: %s", sql, err);
        sqlite3_free (err);
        return FALSE;
    }

    return TRUE;
}

/* Finish an open transaction: COMMIT when @success, ROLLBACK otherwise (also
 * rolling back when the COMMIT itself fails). Returns the effective success. */
static gboolean
g_paste_sqlite_backend_finish_transaction (sqlite3 *db,
                                           gboolean success)
{
    if (!g_paste_sqlite_backend_exec (db, (success) ? "COMMIT;" : "ROLLBACK;") && success)
    {
        g_paste_sqlite_backend_exec (db, "ROLLBACK;");
        return FALSE;
    }

    return success;
}

/* Run a query expected to produce a single integer (e.g. an aggregate or a
 * PRAGMA), returning @fallback when it produces nothing or fails. */
static gint64
g_paste_sqlite_backend_query_int64 (sqlite3     *db,
                                    const gchar *sql,
                                    gint64       fallback)
{
    sqlite3_stmt *stmt = NULL;
    gint64 value = fallback;

    if (sqlite3_prepare_v2 (db, sql, -1, &stmt, NULL) != SQLITE_OK)
    {
        g_warning ("sqlite: failed to prepare “%s”: %s", sql, sqlite3_errmsg (db));
        return fallback;
    }

    if (sqlite3_step (stmt) == SQLITE_ROW)
        value = sqlite3_column_int64 (stmt, 0);

    sqlite3_finalize (stmt);

    return value;
}

#ifdef G_PASTE_ENABLE_ENCRYPTION
/*******************/
/* Encrypted flavor */
/*******************/

#define G_PASTE_SQLITE_KEY_CHECK_MAGIC "GPasteSqliteKeyCheck1"

static void
g_paste_sqlite_backend_free_key (gpointer key)
{
    g_paste_util_secure_free (key, crypto_secretbox_KEYBYTES);
}

/* The passphrase, or NULL for a plain database. Safe to call whether or not
 * encryption was built in (see the stub below). */
static const gchar *
g_paste_sqlite_backend_get_passphrase (GPasteStorageBackend *self)
{
    return g_paste_passphrase_peek (G_PASTE_SQLITE_BACKEND (self)->passphrase);
}

/* The derived content key of the currently open database, or NULL for the
 * plain flavor. Only valid after a successful open. */
static const guchar *
g_paste_sqlite_backend_get_key (GPasteStorageBackend *self)
{
    return G_PASTE_SQLITE_BACKEND (self)->key;
}

/* Encrypt @length bytes into a freshly allocated nonce ‖ ciphertext blob. */
static guchar *
g_paste_sqlite_backend_encrypt (const guchar *key,
                                gconstpointer data,
                                gsize         length,
                                gsize        *blob_length)
{
    *blob_length = crypto_secretbox_NONCEBYTES + crypto_secretbox_MACBYTES + length;

    guchar *blob = g_malloc (*blob_length);

    randombytes_buf (blob, crypto_secretbox_NONCEBYTES);
    crypto_secretbox_easy (blob + crypto_secretbox_NONCEBYTES, data, length, blob, key);

    return blob;
}

/* Decrypt a nonce ‖ ciphertext blob. The plaintext gets a trailing NUL so the
 * same helper serves text values and raw bytes alike. NULL on a failed
 * authentication (wrong key or corrupted data). */
static guchar *
g_paste_sqlite_backend_decrypt (const guchar *key,
                                gconstpointer blob,
                                gsize         blob_length,
                                gsize        *length)
{
    if (blob_length < crypto_secretbox_NONCEBYTES + crypto_secretbox_MACBYTES)
        return NULL;

    gsize plain_length = blob_length - crypto_secretbox_NONCEBYTES - crypto_secretbox_MACBYTES;
    g_autofree guchar *plain = g_malloc (plain_length + 1);
    const guchar *bytes = blob;

    if (crypto_secretbox_open_easy (plain, bytes + crypto_secretbox_NONCEBYTES,
                                    blob_length - crypto_secretbox_NONCEBYTES, bytes, key) != 0)
        return NULL;

    plain[plain_length] = '\0';
    if (length)
        *length = plain_length;

    return g_steal_pointer (&plain);
}

/* The parameters come out of the `meta` table, so they are only as trustworthy
 * as the file: g_paste_crypto_derive_key() is what refuses the ones no GPaste
 * ever wrote. */
static gboolean
g_paste_sqlite_backend_derive_key (const gchar  *passphrase,
                                   const guchar *salt,
                                   guint64       opslimit,
                                   guint64       memlimit,
                                   guchar       *key)
{
    g_autoptr (GError) error = NULL;

    if (g_paste_crypto_derive_key (passphrase, strlen (passphrase),
                                   salt, opslimit, memlimit,
                                   key, crypto_secretbox_KEYBYTES, &error))
        return TRUE;

    g_warning ("sqlite: %s", error->message);

    return FALSE;
}

/* Read the salt, Argon2 parameters and key-check blob from the meta table.
 * Quietly returns FALSE when they are absent (fresh database, or no meta table
 * at all), leaving it to the caller to decide what that means. */
static gboolean
g_paste_sqlite_backend_load_crypto_params (sqlite3 *db,
                                           guchar  *salt,
                                           guint64 *opslimit,
                                           guint64 *memlimit,
                                           guchar **check,
                                           gsize   *check_length)
{
    sqlite3_stmt *stmt = NULL;

    if (sqlite3_prepare_v2 (db, "SELECT key, value FROM meta;", -1, &stmt, NULL) != SQLITE_OK)
        return FALSE;

    gboolean has_salt = FALSE;
    gboolean has_opslimit = FALSE;
    gboolean has_memlimit = FALSE;

    while (sqlite3_step (stmt) == SQLITE_ROW)
    {
        const gchar *key = (const gchar *) sqlite3_column_text (stmt, 0);

        /* The blob first, then its length: asking a column its size can convert
         * the value, which is what invalidates the pointer the other order
         * hands back. */
        if (g_paste_str_equal (key, "salt"))
        {
            gconstpointer blob = sqlite3_column_blob (stmt, 1);

            if (sqlite3_column_bytes (stmt, 1) == crypto_pwhash_SALTBYTES)
            {
                memcpy (salt, blob, crypto_pwhash_SALTBYTES);
                has_salt = TRUE;
            }
        }
        else if (g_paste_str_equal (key, "opslimit"))
        {
            *opslimit = sqlite3_column_int64 (stmt, 1);
            has_opslimit = TRUE;
        }
        else if (g_paste_str_equal (key, "memlimit"))
        {
            *memlimit = sqlite3_column_int64 (stmt, 1);
            has_memlimit = TRUE;
        }
        else if (g_paste_str_equal (key, "check"))
        {
            gconstpointer blob = sqlite3_column_blob (stmt, 1);

            *check_length = sqlite3_column_bytes (stmt, 1);
            g_clear_pointer (check, g_free);
            *check = g_memdup2 (blob, *check_length);
        }
    }

    sqlite3_finalize (stmt);

    return has_salt && has_opslimit && has_memlimit && *check;
}

/* Whether @key opens the stored key-check secretbox. */
static gboolean
g_paste_sqlite_backend_key_checks_out (const guchar *key,
                                       const guchar *check,
                                       gsize         check_length)
{
    g_autofree guchar *magic = g_paste_sqlite_backend_decrypt (key, check, check_length, NULL);

    return magic && g_paste_str_equal ((const gchar *) magic, G_PASTE_SQLITE_KEY_CHECK_MAGIC);
}

/* Store a key check for @key, the salt it was derived from and the Argon2
 * parameters in the meta table, replacing any previous ones. Assumes a
 * transaction is already open, so a caller doing more than this (a re-key, which
 * must swap the parameters and re-encrypt the content as one unit) can share it. */
static gboolean
g_paste_sqlite_backend_write_crypto_params (sqlite3      *db,
                                            const guchar *salt,
                                            guint64       opslimit,
                                            guint64       memlimit,
                                            const guchar *key)
{
    if (!g_paste_sqlite_backend_exec (db, "DELETE FROM meta;"))
        return FALSE;

    sqlite3_stmt *stmt = NULL;
    gboolean success = (sqlite3_prepare_v2 (db, "INSERT INTO meta (key, value) VALUES (?, ?);", -1, &stmt, NULL) == SQLITE_OK);

    if (success)
    {
        gsize check_length;
        g_autofree guchar *check = g_paste_sqlite_backend_encrypt (key, G_PASTE_SQLITE_KEY_CHECK_MAGIC,
                                                                   strlen (G_PASTE_SQLITE_KEY_CHECK_MAGIC), &check_length);

        sqlite3_bind_text (stmt, 1, "salt", -1, SQLITE_STATIC);
        sqlite3_bind_blob64 (stmt, 2, salt, crypto_pwhash_SALTBYTES, SQLITE_STATIC);
        success = (sqlite3_step (stmt) == SQLITE_DONE);
        sqlite3_reset (stmt);
        sqlite3_clear_bindings (stmt);

        if (success)
        {
            sqlite3_bind_text (stmt, 1, "opslimit", -1, SQLITE_STATIC);
            sqlite3_bind_int64 (stmt, 2, opslimit);
            success = (sqlite3_step (stmt) == SQLITE_DONE);
            sqlite3_reset (stmt);
            sqlite3_clear_bindings (stmt);
        }

        if (success)
        {
            sqlite3_bind_text (stmt, 1, "memlimit", -1, SQLITE_STATIC);
            sqlite3_bind_int64 (stmt, 2, memlimit);
            success = (sqlite3_step (stmt) == SQLITE_DONE);
            sqlite3_reset (stmt);
            sqlite3_clear_bindings (stmt);
        }

        if (success)
        {
            sqlite3_bind_text (stmt, 1, "check", -1, SQLITE_STATIC);
            sqlite3_bind_blob64 (stmt, 2, check, check_length, SQLITE_TRANSIENT);
            success = (sqlite3_step (stmt) == SQLITE_DONE);
        }

        sqlite3_finalize (stmt);
    }

    if (!success)
        g_warning ("sqlite: failed to store the encryption parameters: %s", sqlite3_errmsg (db));

    return success;
}

typedef enum
{
    G_PASTE_SQLITE_KEYING_FAILED,
    G_PASTE_SQLITE_KEYING_KEYED,
    /* Another connection keyed the database, or wrote to it, first. */
    G_PASTE_SQLITE_KEYING_OVERTAKEN,
} GPasteSqliteKeying;

/* Store @salt and a key check for @key in their own transaction: what
 * preparing a database for a passphrase needs. Under that transaction's lock,
 * the database has to be as setup_crypto () found it before deriving @key --
 * parameters salted @seen_salt, or none if %NULL, and no item -- or another
 * connection keyed it, or wrote under its key, in between: replacing its
 * parameters then would leave what it writes under a key nothing derives. */
static GPasteSqliteKeying
g_paste_sqlite_backend_store_crypto_params (sqlite3      *db,
                                            const guchar *salt,
                                            guint64       opslimit,
                                            guint64       memlimit,
                                            const guchar *key,
                                            const guchar *seen_salt)
{
    if (!g_paste_sqlite_backend_exec (db, "BEGIN IMMEDIATE;"))
        return G_PASTE_SQLITE_KEYING_FAILED;

    guchar stored_salt[crypto_pwhash_SALTBYTES];
    guint64 stored_opslimit = 0;
    guint64 stored_memlimit = 0;
    g_autofree guchar *stored_check = NULL;
    gsize stored_check_length = 0;
    gboolean stored = g_paste_sqlite_backend_load_crypto_params (db, stored_salt, &stored_opslimit, &stored_memlimit,
                                                                 &stored_check, &stored_check_length);

    if (stored != (seen_salt != NULL) || (stored && memcmp (stored_salt, seen_salt, sizeof (stored_salt))) ||
        g_paste_sqlite_backend_query_int64 (db, "SELECT COUNT (*) FROM items;", -1) != 0)
    {
        g_paste_sqlite_backend_exec (db, "ROLLBACK;");
        return G_PASTE_SQLITE_KEYING_OVERTAKEN;
    }

    gboolean written = g_paste_sqlite_backend_write_crypto_params (db, salt, opslimit, memlimit, key);

    return (g_paste_sqlite_backend_finish_transaction (db, written)) ? G_PASTE_SQLITE_KEYING_KEYED : G_PASTE_SQLITE_KEYING_FAILED;
}

/* Re-encrypt one content column, row by row: @ids_sql lists the rowids holding
 * a value, then each is fetched through @select_sql, decrypted with @old_key and
 * written back through @update_sql (binding the new blob, then the rowid)
 * encrypted with @new_key. The rowids are taken first so no UPDATE ever runs
 * against the cursor that produced them, and only the rowids are held — one
 * value is in the clear at a time rather than the whole column, and it is wiped
 * as soon as it has been re-encrypted.
 *
 * Assumes the caller's transaction is open. Gives up on anything short of a
 * complete pass: a value that does not decrypt means real corruption (the key
 * check passed), and a scan cut short — a busy database, an I/O error — must not
 * be mistaken for the end of the column, or the key check would be swapped while
 * part of it is still under the old key, which no passphrase would then open. */
static gboolean
g_paste_sqlite_backend_rekey_column (sqlite3      *db,
                                     const guchar *old_key,
                                     const guchar *new_key,
                                     const gchar  *ids_sql,
                                     const gchar  *select_sql,
                                     const gchar  *update_sql)
{
    g_autoptr (GArray) rowids = g_array_new (FALSE, FALSE, sizeof (gint64));
    sqlite3_stmt *stmt = NULL;

    if (sqlite3_prepare_v2 (db, ids_sql, -1, &stmt, NULL) != SQLITE_OK)
    {
        g_warning ("sqlite: failed to prepare \u201c%s\u201d: %s", ids_sql, sqlite3_errmsg (db));
        return FALSE;
    }

    gint rc;

    while ((rc = sqlite3_step (stmt)) == SQLITE_ROW)
    {
        gint64 rowid = sqlite3_column_int64 (stmt, 0);

        g_array_append_val (rowids, rowid);
    }

    sqlite3_finalize (stmt);

    if (rc != SQLITE_DONE)
    {
        g_warning ("sqlite: could not read every row of \u201c%s\u201d: %s", ids_sql, sqlite3_errmsg (db));
        return FALSE;
    }

    sqlite3_stmt *select = NULL;
    sqlite3_stmt *update = NULL;
    gboolean success = (sqlite3_prepare_v2 (db, select_sql, -1, &select, NULL) == SQLITE_OK &&
                        sqlite3_prepare_v2 (db, update_sql, -1, &update, NULL) == SQLITE_OK);

    if (!success)
        g_warning ("sqlite: failed to prepare the re-encryption of \u201c%s\u201d: %s", select_sql, sqlite3_errmsg (db));

    for (guint i = 0; success && i < rowids->len; ++i)
    {
        gint64 rowid = g_array_index (rowids, gint64, i);

        sqlite3_bind_int64 (select, 1, rowid);

        if (sqlite3_step (select) != SQLITE_ROW)
        {
            g_warning ("sqlite: a value went missing while re-encrypting it: %s", sqlite3_errmsg (db));
            success = FALSE;
        }
        else
        {
            /* The blob first, then its length, as in load_crypto_params (): one
             * call's arguments are evaluated in no order C promises. */
            gconstpointer cipher = sqlite3_column_blob (select, 0);
            gsize cipher_length = sqlite3_column_bytes (select, 0);
            gsize length = 0;
            g_autofree guchar *plain = g_paste_sqlite_backend_decrypt (old_key, cipher, cipher_length, &length);

            if (!plain)
            {
                g_warning ("sqlite: a stored value did not decrypt; leaving the passphrase alone");
                success = FALSE;
            }
            else
            {
                gsize blob_length;
                g_autofree guchar *blob = g_paste_sqlite_backend_encrypt (new_key, plain, length, &blob_length);

                /* Item contents, passwords included: do not leave them behind in
                 * freed heap now that they are stored again. */
                sodium_memzero (plain, length);

                sqlite3_bind_blob64 (update, 1, blob, blob_length, SQLITE_STATIC);
                sqlite3_bind_int64 (update, 2, rowid);

                if (sqlite3_step (update) != SQLITE_DONE)
                {
                    g_warning ("sqlite: failed to re-encrypt a stored value: %s", sqlite3_errmsg (db));
                    success = FALSE;
                }

                sqlite3_reset (update);
                sqlite3_clear_bindings (update);
            }
        }

        sqlite3_reset (select);
        sqlite3_clear_bindings (select);
    }

    sqlite3_finalize (select);
    sqlite3_finalize (update);

    return success;
}

/* Every content column, as the (select, update) pair
 * g_paste_sqlite_backend_rekey_column() drives. A column added to the schema
 * that holds user content has to be listed here too, or a passphrase change
 * would leave it behind, unreadable. */
static const struct
{
    const gchar *ids_sql;
    const gchar *select_sql;
    const gchar *update_sql;
} g_paste_sqlite_backend_content_columns[] = {
    { "SELECT rowid FROM items;",
      "SELECT value FROM items WHERE rowid = ?;",
      "UPDATE items SET value = ? WHERE rowid = ?;" },
    { "SELECT rowid FROM items WHERE name IS NOT NULL;",
      "SELECT name FROM items WHERE rowid = ?;",
      "UPDATE items SET name = ? WHERE rowid = ?;" },
    { "SELECT rowid FROM items WHERE image IS NOT NULL;",
      "SELECT image FROM items WHERE rowid = ?;",
      "UPDATE items SET image = ? WHERE rowid = ?;" },
    { "SELECT rowid FROM special_values;",
      "SELECT data FROM special_values WHERE rowid = ?;",
      "UPDATE special_values SET data = ? WHERE rowid = ?;" },
};

/* One pass of setup_crypto (): the database's own parameters taken when they
 * check out, and %G_PASTE_SQLITE_KEYING_KEYED once @key is the one the database
 * is keyed for. */
static GPasteSqliteKeying
g_paste_sqlite_backend_key_database (sqlite3     *db,
                                     const gchar *passphrase,
                                     guchar      *key,
                                     gboolean    *wrong_passphrase)
{
    guchar salt[crypto_pwhash_SALTBYTES];
    guint64 opslimit = 0;
    guint64 memlimit = 0;
    g_autofree guchar *check = NULL;
    gsize check_length = 0;

    gboolean loaded = g_paste_sqlite_backend_load_crypto_params (db, salt, &opslimit, &memlimit, &check, &check_length);
    /* derive_key () says why when it refuses the parameters. */
    gboolean derived = loaded && g_paste_sqlite_backend_derive_key (passphrase, salt, opslimit, memlimit, key);

    if (derived && g_paste_sqlite_backend_key_checks_out (key, check, check_length))
        return G_PASTE_SQLITE_KEYING_KEYED;

    /* The wrong passphrase for a history that still holds data must be
     * refused: accepting it would load empty and the next save would destroy
     * the real content. So must parameters that are incomplete or that no key
     * can be derived with, which are no new store, replacing them being what
     * would make the content unreadable for good. An empty history has nothing
     * to lose, so it is (re-)keyed for this passphrase instead of locking the
     * user out, whichever of those it was -- and a count that cannot be read is
     * no proof of empty. */
    if (g_paste_sqlite_backend_query_int64 (db, "SELECT COUNT (*) FROM items;", -1) != 0)
    {
        if (derived)
            *wrong_passphrase = TRUE;
        else if (!loaded)
            g_warning ("sqlite: incomplete encryption parameters in a history holding data; not touching it");

        return G_PASTE_SQLITE_KEYING_FAILED;
    }

    guchar fresh_salt[crypto_pwhash_SALTBYTES];

    randombytes_buf (fresh_salt, sizeof (fresh_salt));

    if (!g_paste_sqlite_backend_derive_key (passphrase, fresh_salt, crypto_pwhash_OPSLIMIT_MODERATE, crypto_pwhash_MEMLIMIT_MODERATE, key))
    {
        g_warning ("sqlite: could not derive the encryption key (out of memory?)");
        return G_PASTE_SQLITE_KEYING_FAILED;
    }

    return g_paste_sqlite_backend_store_crypto_params (db, fresh_salt, crypto_pwhash_OPSLIMIT_MODERATE, crypto_pwhash_MEMLIMIT_MODERATE,
                                                       key, (loaded) ? salt : NULL);
}

/* Prepare the encrypted flavor on an open database: derive the key from the
 * per-database salt and verify it against the stored key check. A fresh
 * database (or one that is still empty — nothing to lose) gets a new salt and
 * check for this passphrase instead, and only such a one: parameters missing
 * from a database holding data are refused, since its ciphertext still needs
 * the salt and limits it was written with. @wrong_passphrase is set when the
 * passphrase does not unlock existing data, the one failure the caller must
 * report differently. */
static gboolean
g_paste_sqlite_backend_setup_crypto (sqlite3     *db,
                                     const gchar *passphrase,
                                     guchar      *key,
                                     gboolean    *wrong_passphrase)
{
    *wrong_passphrase = FALSE;

    if (!g_paste_sqlite_backend_exec (db, "CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value NOT NULL);"))
        return FALSE;

    /* Twice at most: a database another connection keys while this one derives
     * a key of its own is then read again, its parameters the ones to take. */
    for (guint attempt = 0; attempt < 2; ++attempt)
    {
        GPasteSqliteKeying keying = g_paste_sqlite_backend_key_database (db, passphrase, key, wrong_passphrase);

        if (keying != G_PASTE_SQLITE_KEYING_OVERTAKEN)
            return keying == G_PASTE_SQLITE_KEYING_KEYED;
    }

    g_warning ("sqlite: the encryption parameters kept changing while being set up; not touching them");

    return FALSE;
}
#else
static const gchar *
g_paste_sqlite_backend_get_passphrase (GPasteStorageBackend *self G_GNUC_UNUSED)
{
    return NULL;
}

static const guchar *
g_paste_sqlite_backend_get_key (GPasteStorageBackend *self G_GNUC_UNUSED)
{
    return NULL;
}
#endif /* G_PASTE_ENABLE_ENCRYPTION */

static gboolean
g_paste_sqlite_backend_create_schema (sqlite3 *db)
{
    return g_paste_sqlite_backend_exec (db,
        "CREATE TABLE IF NOT EXISTS items ("
        "    id       INTEGER PRIMARY KEY,"
        "    uuid     TEXT    NOT NULL UNIQUE,"
        "    kind     TEXT    NOT NULL,"
        "    value    TEXT    NOT NULL,"
        "    rank     INTEGER NOT NULL," /* highest = front of the history */
        "    date     INTEGER,"          /* Image: unix seconds */
        "    checksum TEXT,"             /* Image: hex sha256 */
        "    name     TEXT,"             /* Password: reserved for an encrypted variant */
        "    image    BLOB,"             /* Image: the encoded PNG */
        "    favourite INTEGER NOT NULL DEFAULT 0," /* pinned: exempt from both caps */
        "    timeout   INTEGER NOT NULL DEFAULT 0"  /* Password: seconds on the clipboard, 0 for no limit */
        ");"
        "CREATE UNIQUE INDEX IF NOT EXISTS items_rank ON items (rank DESC);"
        "CREATE TABLE IF NOT EXISTS special_values ("
        "    item_id  INTEGER NOT NULL REFERENCES items (id) ON DELETE CASCADE,"
        "    position INTEGER NOT NULL,"
        "    mime     TEXT    NOT NULL," /* GPasteSpecialMime value nick */
        "    data     BLOB    NOT NULL,"
        "    PRIMARY KEY (item_id, position)"
        ");");
}

/* Upgrade a database created by an older GPaste (its user_version is @from) to
 * the current schema. One `case @from` per historical version, each falling
 * through to the next so any old database upgrades stepwise. */
static gboolean
g_paste_sqlite_backend_migrate_schema (sqlite3 *db,
                                       gint64   from)
{
    switch (from)
    {
    case 1:
        /* Favourites. The default is what makes this a pure addition: every
         * item an older GPaste stored comes back unpinned, which is what it
         * was. */
        if (!g_paste_sqlite_backend_exec (db, "ALTER TABLE items ADD COLUMN favourite INTEGER NOT NULL DEFAULT 0;"))
            return FALSE;
        G_GNUC_FALLTHROUGH;
    case 2:
        /* Password timeouts, a pure addition for the same reason: every password
         * an older GPaste stored comes back with no timeout, which is what it
         * had. */
        if (!g_paste_sqlite_backend_exec (db, "ALTER TABLE items ADD COLUMN timeout INTEGER NOT NULL DEFAULT 0;"))
            return FALSE;
        G_GNUC_FALLTHROUGH;
    default:
        return TRUE;
    }
}

/* The schema version @db is at, or -1 (with a warning) when it cannot be read:
 * a database that answers nothing is not one without a schema, which is what
 * 0 says, and creating the schema over its tables would leave them as they
 * are while recording them as current. */
static gint64
g_paste_sqlite_backend_schema_version (sqlite3     *db,
                                       const gchar *db_path)
{
    gint64 version = g_paste_sqlite_backend_query_int64 (db, "PRAGMA user_version;", -1);

    if (version < 0)
        g_warning ("sqlite: could not read the schema version of “%s”: %s; not touching it", db_path, sqlite3_errmsg (db));

    return version;
}

/* Get the (cached) connection for @db_path, opening and preparing the database
 * as needed. Returns NULL (and warns) when the database cannot be used, e.g.
 * when it was created by a newer GPaste: a read or a write then leaves it as
 * it is, where emptying the history replaces it (clear_history ()). Must be
 * called with the backend lock held. */
static sqlite3 *
g_paste_sqlite_backend_open (GPasteStorageBackend *self,
                             const gchar          *db_path)
{
    GPasteSqliteBackend *backend = G_PASTE_SQLITE_BACKEND (self);

    g_mutex_lock (&backend->forgotten_lock);
    gboolean forgotten = backend->forgotten && g_paste_str_equal (backend->forgotten, backend->db_path);

    g_clear_pointer (&backend->forgotten, g_free);
    g_mutex_unlock (&backend->forgotten_lock);

    if (backend->db && !forgotten && g_paste_str_equal (backend->db_path, db_path))
        return backend->db;

    g_clear_pointer (&backend->db, g_paste_sqlite_backend_close);
    g_clear_pointer (&backend->db_path, g_free);
#ifdef G_PASTE_ENABLE_ENCRYPTION
    /* The key is salt-dependent, so it dies with its database's connection. */
    g_clear_pointer (&backend->key, g_paste_sqlite_backend_free_key);
#endif

    if (!g_paste_util_ensure_history_dir_exists ())
        return NULL;

    g_autoptr (sqlite3) db = NULL;

    if (sqlite3_open_v2 (db_path, &db, SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE | SQLITE_OPEN_FULLMUTEX, NULL) != SQLITE_OK)
    {
        g_warning ("sqlite: failed to open “%s”: %s", db_path, db ? sqlite3_errmsg (db) : "out of memory");
        return NULL;
    }

    sqlite3_busy_timeout (db, G_PASTE_SQLITE_BUSY_TIMEOUT);

    /* secure_delete zeroes what a delete frees, which SQLite keeps otherwise
     * unless built with SQLITE_SECURE_DELETE -- as Fedora's is, which is why no
     * test here can tell it apart: see forget_deleted () for the other copy, in
     * the write-ahead log, which /history/sqlite_deleted_text_gone pins. */
    if (!g_paste_sqlite_backend_exec (db,
                                      "PRAGMA journal_mode = WAL;"
                                      "PRAGMA synchronous = NORMAL;"
                                      "PRAGMA foreign_keys = ON;"
                                      "PRAGMA secure_delete = ON;"))
        return NULL;

    gint64 version = g_paste_sqlite_backend_schema_version (db, db_path);

    if (version < 0)
        return NULL;

    if (version > G_PASTE_SQLITE_SCHEMA_VERSION)
    {
        g_warning ("sqlite: “%s” uses schema version %" G_GINT64_FORMAT " from a newer GPaste (this one supports %d); not touching it",
                   db_path, version, G_PASTE_SQLITE_SCHEMA_VERSION);
        return NULL;
    }

    /* The schema and the version saying which it is go in one transaction: a
     * step committed on its own, with the version write still to fail, would
     * have the next open run that step again and fail on what it already did
     * ("duplicate column"), every time. Rolled back whole, the upgrade is
     * simply tried again. */
    if (version != G_PASTE_SQLITE_SCHEMA_VERSION)
    {
        if (!g_paste_sqlite_backend_exec (db, "BEGIN IMMEDIATE;"))
            return NULL;

        /* Again, under the write lock: another connection may have upgraded
         * the database between the read above and taking it, and running the
         * steps a second time would fail on the columns they added. A newer
         * version found here is left alone like the one above, the next open
         * saying why. */
        version = g_paste_sqlite_backend_schema_version (db, db_path);

        gboolean ok = (version >= 0 && version <= G_PASTE_SQLITE_SCHEMA_VERSION);

        if (ok && version == 0)
            ok = g_paste_sqlite_backend_create_schema (db);
        else if (ok && version != G_PASTE_SQLITE_SCHEMA_VERSION)
            ok = g_paste_sqlite_backend_migrate_schema (db, version);

        if (ok && version != G_PASTE_SQLITE_SCHEMA_VERSION)
            ok = g_paste_sqlite_backend_exec (db, "PRAGMA user_version = " G_STRINGIFY (G_PASTE_SQLITE_SCHEMA_VERSION) ";");

        if (!g_paste_sqlite_backend_finish_transaction (db, ok))
            return NULL;
    }

#ifdef G_PASTE_ENABLE_ENCRYPTION
    if (backend->passphrase)
    {
        guchar *key = gcr_secure_memory_alloc (crypto_secretbox_KEYBYTES);
        gboolean wrong_passphrase = FALSE;

        if (!g_paste_sqlite_backend_setup_crypto (db, g_paste_passphrase_peek (backend->passphrase), key, &wrong_passphrase))
        {
            if (wrong_passphrase)
                g_warning ("sqlite: the passphrase does not unlock “%s”; not touching it", db_path);
            g_paste_sqlite_backend_free_key (key);
            return NULL;
        }

        backend->key = key;
    }
#endif

    /* Through the negative ranks, in one transaction: rows are updated in id
     * order, which is not rank order once an older item is selected again, so
     * a row given its new rank directly could take one another row still holds
     * -- and the unique index on rank refuses the whole update. No positive
     * rank is ever negated twice, nor clashes with a negative one. */
    if (g_paste_sqlite_backend_query_int64 (db, "SELECT COALESCE (MAX (rank), 0) FROM items;", 0) > G_PASTE_SQLITE_RANK_COMPACT_THRESHOLD &&
        g_paste_sqlite_backend_exec (db, "BEGIN IMMEDIATE;"))
    {
        gboolean compacted = g_paste_sqlite_backend_exec (db,
                                                          "UPDATE items SET rank = -ranked.new_rank "
                                                          "FROM (SELECT id, ROW_NUMBER () OVER (ORDER BY rank) AS new_rank FROM items) AS ranked "
                                                          "WHERE items.id = ranked.id;"
                                                          "UPDATE items SET rank = -rank;");

        g_paste_sqlite_backend_finish_transaction (db, compacted);
    }

    backend->db = g_steal_pointer (&db);
    backend->db_path = g_strdup (db_path);

    return backend->db;
}

/*****************/
/* Writing items */
/*****************/

/* Bind @data as-is, or as an encrypted blob when @key is set (the encrypted
 * flavor). Text values go through this too: they are just bytes to bind.
 *
 * Returns the bind's result code. A refused bind leaves the parameter NULL, and
 * a step goes through with it all the same, so the callers have to look:
 * %SQLITE_TOOBIG is a value past what a row holds (SQLITE_MAX_LENGTH, which
 * max-text-item-size and max-memory-usage both let through), anything else a
 * write that failed. */
static gint
g_paste_sqlite_backend_bind_content (sqlite3_stmt *stmt,
                                     gint          position,
                                     const guchar *key,
                                     gconstpointer data,
                                     gsize         length)
{
#ifdef G_PASTE_ENABLE_ENCRYPTION
    if (key)
    {
        gsize blob_length;
        g_autofree guchar *blob = g_paste_sqlite_backend_encrypt (key, data, length, &blob_length);

        /* Handed over rather than copied once more: an image's sealed blob is
         * its whole PNG. */
        return sqlite3_bind_blob64 (stmt, position, g_steal_pointer (&blob), blob_length, g_free);
    }
#else
    (void) key;
#endif

    return sqlite3_bind_blob64 (stmt, position, data, length, SQLITE_TRANSIENT);
}

/* Like bind_content but for text: a plain database keeps it a readable TEXT
 * column, an encrypted one stores the ciphertext blob. */
static gint
g_paste_sqlite_backend_bind_text (sqlite3_stmt *stmt,
                                  gint          position,
                                  const guchar *key,
                                  const gchar  *text)
{
#ifdef G_PASTE_ENABLE_ENCRYPTION
    if (key)
        return g_paste_sqlite_backend_bind_content (stmt, position, key, text, strlen (text));
#else
    (void) key;
#endif

    return sqlite3_bind_text (stmt, position, text, -1, SQLITE_TRANSIENT);
}

static gboolean
g_paste_sqlite_backend_write_special_values (sqlite3      *db,
                                             const guchar *key,
                                             gint64        item_id,
                                             GPasteItem   *item)
{
    const GSList *special_values = g_paste_item_get_special_values (item);

    if (!special_values)
        return TRUE;

    sqlite3_stmt *stmt = NULL;

    if (sqlite3_prepare_v2 (db, "INSERT INTO special_values (item_id, position, mime, data) VALUES (?, ?, ?, ?);", -1, &stmt, NULL) != SQLITE_OK)
    {
        g_warning ("sqlite: failed to prepare special value insertion: %s", sqlite3_errmsg (db));
        return FALSE;
    }

    GEnumClass *mime_class = g_type_class_get (G_PASTE_TYPE_SPECIAL_MIME);
    gboolean success = TRUE;
    gint64 position = 0;

    for (const GSList *val = special_values; success && val; val = val->next, ++position)
    {
        GPasteBinaryData *value = val->data;
        GEnumValue *gev = g_enum_get_value (mime_class, g_paste_binary_data_get_mime (value));

        /* Skip a value carrying an unknown mime rather than dereferencing NULL,
         * mirroring the guarded read path in read_special_values. */
        if (!gev)
        {
            g_warning ("sqlite: unknown mime: %d", g_paste_binary_data_get_mime (value));
            continue;
        }

        const gchar *mime = gev->value_nick;
        gsize data_length;
        gconstpointer data = g_bytes_get_data (g_paste_binary_data_get_bytes (value), &data_length);

        sqlite3_bind_int64 (stmt, 1, item_id);
        sqlite3_bind_int64 (stmt, 2, position);
        sqlite3_bind_text (stmt, 3, mime, -1, SQLITE_STATIC);

        gint bound = g_paste_sqlite_backend_bind_content (stmt, 4, key, data, data_length);

        /* One representation of a value the item still holds: it is left out,
         * as the read drops one it cannot use, and the item stays. */
        if (bound == SQLITE_TOOBIG)
            g_warning ("sqlite: a %s representation is too large to store, and is left out", mime);
        else if (bound != SQLITE_OK)
        {
            g_warning ("sqlite: failed to write a special value: %s", sqlite3_errstr (bound));
            success = FALSE;
        }
        else if (sqlite3_step (stmt) != SQLITE_DONE)
        {
            g_warning ("sqlite: failed to write a special value: %s", sqlite3_errmsg (db));
            success = FALSE;
        }

        sqlite3_reset (stmt);
        sqlite3_clear_bindings (stmt);
    }

    sqlite3_finalize (stmt);

    return success;
}

/* Bind an image item's PNG for the `image` blob column: from the bytes the
 * item carries, falling back to the file it was read from for an item that
 * carries none (e.g. imported from the file backend). No bytes anywhere leaves
 * the column NULL, and is %SQLITE_OK. */
static gint
g_paste_sqlite_backend_bind_image (sqlite3_stmt    *stmt,
                                   gint             position,
                                   const guchar    *key,
                                   GPasteImageItem *image)
{
    GBytes *png = g_paste_image_item_get_png_bytes (image);

    if (png)
    {
        gsize length;
        gconstpointer data = g_bytes_get_data (png, &length);

        return g_paste_sqlite_backend_bind_content (stmt, position, key, data, length);
    }

    const gchar *cache_path = g_paste_image_item_get_cache_path (image);
    g_autofree gchar *data = NULL;
    gsize length = 0;

    /* Best effort, like the file backend's own materialization: an item whose
     * cache file has gone -- or that never had one -- is stored without its
     * image rather than not at all, and the column simply stays NULL. */
    if (cache_path && g_file_get_contents (cache_path, &data, &length, NULL))
        return g_paste_sqlite_backend_bind_content (stmt, position, key, data, length);

    return SQLITE_OK;
}

/* Replace an item's stored special values with the ones it carries. */
static gboolean
g_paste_sqlite_backend_rewrite_special_values (sqlite3      *db,
                                               const guchar *key,
                                               gint64        item_id,
                                               GPasteItem   *item)
{
    sqlite3_stmt *del = NULL;

    if (sqlite3_prepare_v2 (db, "DELETE FROM special_values WHERE item_id = ?;", -1, &del, NULL) != SQLITE_OK)
    {
        g_warning ("sqlite: failed to prepare special value cleanup: %s", sqlite3_errmsg (db));
        return FALSE;
    }

    sqlite3_bind_int64 (del, 1, item_id);

    gboolean success = (sqlite3_step (del) == SQLITE_DONE);

    sqlite3_finalize (del);

    return success && g_paste_sqlite_backend_write_special_values (db, key, item_id, item);
}

/* The timeout column of @item's row: only a password ever carries one, but
 * the column is NOT NULL, so every other item stores 0. As an int64, since a
 * timeout is a guint and the ones above G_MAXINT would otherwise be stored
 * negative. Plaintext, being a duration, not content. */
static gint64
g_paste_sqlite_backend_item_timeout (GPasteItem *item)
{
    return (G_PASTE_IS_PASSWORD_ITEM (item)) ? (gint64) g_paste_password_item_get_timeout (G_PASTE_PASSWORD_ITEM (item)) : 0;
}

/* Bind an item's content columns: uuid, kind and value at the fixed positions
 * 1-3, then the image (date, checksum, image blob) or password (name) columns
 * starting at @meta_base, with the favourite flag and the password timeout
 * closing the group at @meta_base + 4 and @meta_base + 5. The INSERT and UPDATE
 * statements share this layout and differ only by @meta_base — the INSERT
 * carries an extra rank column between the value and the meta group, so it binds
 * at base 5 while the UPDATE binds at 4. Keeping the two in one place stops
 * their column indices drifting apart.
 *
 * Returns the first of the content binds' result codes that is not
 * %SQLITE_OK, as bind_content () has them: the others bind short strings
 * SQLite does not copy, and integers. */
static gint
g_paste_sqlite_backend_bind_item (sqlite3_stmt *stmt,
                                  const guchar *key,
                                  GPasteItem   *item,
                                  gint          meta_base)
{
    sqlite3_bind_text (stmt, 1, g_paste_item_get_uuid (item), -1, SQLITE_STATIC);
    /* The nick is a static string owned by the enum class, hence SQLITE_STATIC. */
    sqlite3_bind_text (stmt, 2, g_paste_item_kind_to_string (g_paste_item_get_kind (item)), -1, SQLITE_STATIC);

    gint bound = g_paste_sqlite_backend_bind_text (stmt, 3, key, g_paste_item_get_real_value (item));

    /* Every kind has one, so it is bound outside the per-kind branches below.
     * Plaintext like rank and date: the read has to order and filter on it. */
    sqlite3_bind_int (stmt, meta_base + 4, g_paste_item_is_favourite (item));
    sqlite3_bind_int64 (stmt, meta_base + 5, g_paste_sqlite_backend_item_timeout (item));

    if (G_PASTE_IS_IMAGE_ITEM (item))
    {
        GPasteImageItem *image = G_PASTE_IMAGE_ITEM (item);
        const gchar *checksum = g_paste_image_item_get_checksum (image);

        sqlite3_bind_int64 (stmt, meta_base, g_date_time_to_unix ((GDateTime *) g_paste_image_item_get_date (image)));
        if (checksum)
            sqlite3_bind_text (stmt, meta_base + 1, checksum, -1, SQLITE_STATIC);
        if (bound == SQLITE_OK)
            bound = g_paste_sqlite_backend_bind_image (stmt, meta_base + 3, key, image);
    }
    else if (G_PASTE_IS_PASSWORD_ITEM (item) && bound == SQLITE_OK)
        bound = g_paste_sqlite_backend_bind_text (stmt, meta_base + 2, key, g_paste_password_item_get_name (G_PASTE_PASSWORD_ITEM (item)));

    return bound;
}

/* Warn about an item a bind or a step refused with @code. %SQLITE_TOOBIG is one
 * too large for a row, which the caller leaves out, and is %TRUE; anything else
 * is a write that failed. */
static gboolean
g_paste_sqlite_backend_left_out (sqlite3 *db,
                                 gint     code)
{
    if (code == SQLITE_TOOBIG)
    {
        g_warning ("sqlite: an item is too large to store, and is left out of the store");
        return TRUE;
    }

    g_warning ("sqlite: failed to write an item: %s", sqlite3_errmsg (db));

    return FALSE;
}

/* Insert @item with @rank, or move the already-stored item with the same uuid
 * to @rank (its value never changes, only its position and whether it is
 * pinned). Special values are written with a new row, and left as they are by
 * a move: an item's strings never change once it is in its history, a strip
 * or an edit putting a new item in its place (replace_item ()), so a select
 * binds no value, image or alternative only for the conflict to discard it.
 *
 * An item too large for a row is left out, the way a password is in the plain
 * flavour, rather than failing the write: every write of its history would
 * carry it, and fail, for as long as the history held it.
 *
 * @maybe_stored says whether a row of @item may be there already: a full write
 * has just emptied the table, and tries no move it knows cannot match. */
static gboolean
g_paste_sqlite_backend_upsert_item (GPasteStorageBackend *self,
                                    sqlite3              *db,
                                    const guchar         *key,
                                    GPasteItem           *item,
                                    gint64                rank,
                                    gboolean              maybe_stored)
{
    sqlite3_stmt *stmt = NULL;

    if (maybe_stored)
    {
        if (sqlite3_prepare_v2 (db, "UPDATE items SET rank = ?, favourite = ?, timeout = ? WHERE uuid = ?;", -1, &stmt, NULL) != SQLITE_OK)
        {
            g_warning ("sqlite: failed to prepare item move: %s", sqlite3_errmsg (db));
            return FALSE;
        }

        sqlite3_bind_int64 (stmt, 1, rank);
        sqlite3_bind_int (stmt, 2, g_paste_item_is_favourite (item));
        sqlite3_bind_int64 (stmt, 3, g_paste_sqlite_backend_item_timeout (item));
        sqlite3_bind_text (stmt, 4, g_paste_item_get_uuid (item), -1, SQLITE_STATIC);

        gint moved = sqlite3_step (stmt);

        sqlite3_finalize (stmt);
        stmt = NULL;
        if (moved != SQLITE_DONE)
        {
            g_warning ("sqlite: failed to move an item: %s", sqlite3_errmsg (db));
            return FALSE;
        }
        if (sqlite3_changes (db))
            return TRUE;
    }

    if (sqlite3_prepare_v2 (db,
                            "INSERT INTO items (uuid, kind, value, rank, date, checksum, name, image, favourite, timeout) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?) "
                            "ON CONFLICT (uuid) DO UPDATE SET rank = excluded.rank, favourite = excluded.favourite, timeout = excluded.timeout "
                            "RETURNING id;",
                            -1, &stmt, NULL) != SQLITE_OK)
    {
        g_warning ("sqlite: failed to prepare item insertion: %s", sqlite3_errmsg (db));
        return FALSE;
    }

    /* uuid, kind, value at 1-3, then rank at 4, then the meta group at base 5. */
    gint ret = g_paste_sqlite_backend_bind_item (stmt, key, item, 5);

    sqlite3_bind_int64 (stmt, 4, rank);
    if (ret == SQLITE_OK)
        ret = sqlite3_step (stmt);

    gint64 item_id = (ret == SQLITE_ROW) ? sqlite3_column_int64 (stmt, 0) : 0;
    gboolean left_out = (ret != SQLITE_ROW && g_paste_sqlite_backend_left_out (db, ret));

    sqlite3_finalize (stmt);

    if (left_out)
        g_paste_storage_backend_leave_out (self, item);
    if (ret != SQLITE_ROW)
        return left_out;

    return g_paste_sqlite_backend_rewrite_special_values (db, key, item_id, item);
}

/* How many of @history's items this backend persists, to rank a full rewrite
 * (front item gets the highest rank): an item left out as too large keeps its
 * rank, leaving a gap. */
static gint64
g_paste_sqlite_backend_count_stored (GPasteStorageBackend *self,
                                     const GList          *history)
{
    gint64 count = 0;

    for (const GList *h = history; h; h = g_list_next (h))
    {
        if (g_paste_storage_backend_stores_item (self, h->data))
            ++count;
    }

    return count;
}

/* Remove the database at @db_path and what SQLite keeps beside it. @backend's
 * lock is held. */
static void
g_paste_sqlite_backend_unlink (GPasteSqliteBackend *backend,
                               const gchar         *db_path,
                               GError             **error)
{
    /* Close our connection first so the WAL is checkpointed and its sidecar
     * files can go away with the database. */
    if (backend->db && g_paste_str_equal (backend->db_path, db_path))
    {
        g_clear_pointer (&backend->db, g_paste_sqlite_backend_close);
        g_clear_pointer (&backend->db_path, g_free);
#ifdef G_PASTE_ENABLE_ENCRYPTION
        g_clear_pointer (&backend->key, g_paste_sqlite_backend_free_key);
#endif
    }

    g_paste_sqlite_backend_delete_database (db_path, error);
}

/**
 * g_paste_sqlite_backend_delete_database:
 * @db_path: the database to delete
 * @error: return location for a #GError, or %NULL
 *
 * Delete the database at @db_path and what SQLite keeps beside it, with no
 * connection to it open: what has no backend to delete with, no key being
 * needed to unlink a file.
 *
 * Errors come from unlinking the database, in %G_IO_ERROR.
 */
void
g_paste_sqlite_backend_delete_database (const gchar *db_path,
                                        GError     **error)
{
    g_autoptr (GFile) db_file = g_file_new_for_path (db_path);

    g_file_delete (db_file, NULL, error);

    static const gchar *sidecars[] = { "-wal", "-shm" };

    for (guint64 i = 0; i < G_N_ELEMENTS (sidecars); ++i)
    {
        g_autofree gchar *sidecar_path = g_strconcat (db_path, sidecars[i], NULL);
        g_autoptr (GFile) sidecar = g_file_new_for_path (sidecar_path);

        /* Only present while a connection is (or was) open, so a missing one is
         * the normal case and not worth reporting -- the database itself is the
         * delete that counts, and it reports through @error above. */
        g_file_delete (sidecar, NULL, NULL);
    }
}

/* What a delete took -- a text made a password, an item deleted or edited, a
 * history emptied -- has to be in no file afterwards, as it is in none once the
 * plain file flavour rewrites its document. secure_delete zeroes it in the
 * database, and the write-ahead log still holds the pages it was on until a
 * checkpoint, for as long as the connection lives: truncated here, which writes
 * those pages back and empties the log. The encrypted flavour's too: an image's
 * date and checksum and an alternative's mime are stored in clear. Best effort:
 * a reader holding the log defers it to the next delete -- at once, the busy
 * timeout lifted for it, a checkpoint waiting otherwise for every reader to be
 * done, the backend's lock held all along. */
static void
g_paste_sqlite_backend_forget_deleted (sqlite3 *db)
{
    sqlite3_busy_timeout (db, 0);
    if (sqlite3_wal_checkpoint_v2 (db, NULL, SQLITE_CHECKPOINT_TRUNCATE, NULL, NULL) != SQLITE_OK)
        g_debug ("sqlite: could not empty the write-ahead log: %s", sqlite3_errmsg (db));
    sqlite3_busy_timeout (db, G_PASTE_SQLITE_BUSY_TIMEOUT);
}

/* Write @history over the history called @name, @backend's lock held: see
 * write_history_file in #GPasteStorageBackendClass for what it returns, which
 * its callers record: the base class for the vfunc, add_item () for the full
 * write it makes itself. */
static gboolean
g_paste_sqlite_backend_write_locked (GPasteStorageBackend *self,
                                     const gchar          *name,
                                     const GList          *history)
{
    GPasteSqliteBackend *backend = G_PASTE_SQLITE_BACKEND (self);
    g_autofree gchar *history_file_path = g_paste_storage_backend_get_history_file_path (self, name);
    /* A database this write creates and then fails to fill goes again, as the
     * file flavour never installs a document it failed to write: left there,
     * it is a history listed as if written while holding nothing -- a backup
     * answered for, which the user may then delete the original over. */
    gboolean created = !g_file_test (history_file_path, G_FILE_TEST_EXISTS);
    sqlite3 *db = g_paste_sqlite_backend_open (self, history_file_path);

    /* An open fails past creating the database too: its schema, its key. */
    if (!db)
    {
        if (created)
            g_paste_sqlite_backend_unlink (backend, history_file_path, NULL);
        return FALSE;
    }

    const guchar *key = g_paste_sqlite_backend_get_key (self);

    /* Count what we'll actually store so the front item gets the highest rank. */
    gint64 rank = g_paste_sqlite_backend_count_stored (self, history);

    /* One transaction, so replacing the whole content is atomic: a failure
     * (or crash) rolls back to the previous state instead of losing data. */
    gboolean began = g_paste_sqlite_backend_exec (db, "BEGIN IMMEDIATE;");
    gboolean success = began && g_paste_sqlite_backend_exec (db, "DELETE FROM items;");

    for (const GList *h = history; success && h; h = g_list_next (h))
    {
        GPasteItem *item = h->data;

        if (!g_paste_storage_backend_stores_item (self, item))
            continue;

        success = g_paste_sqlite_backend_upsert_item (self, db, key, item, rank--, FALSE);
    }

    if (began)
        success = g_paste_sqlite_backend_finish_transaction (db, success);

    if (success)
    {
        g_paste_sqlite_backend_forget_deleted (db);
        return TRUE;
    }

    if (created)
        g_paste_sqlite_backend_unlink (backend, history_file_path, NULL);

    return FALSE;
}

static gboolean
g_paste_sqlite_backend_write_history_file (GPasteStorageBackend *self,
                                           const gchar          *name,
                                           const GList          *history)
{
    GPasteSqliteBackend *backend = G_PASTE_SQLITE_BACKEND (self);
    g_autoptr (GMutexLocker) locker = g_mutex_locker_new (&backend->lock);

    return g_paste_sqlite_backend_write_locked (self, name, history);
}

/*****************/
/* Reading items */
/*****************/

/* Read a content column: the column bytes as-is for a plain database, the
 * decrypted plaintext for an encrypted one (with a trailing NUL either way, so
 * the result doubles as a string). NULL when decryption fails. */
static guchar *
g_paste_sqlite_backend_read_content (sqlite3_stmt *stmt,
                                     gint          column,
                                     const guchar *key,
                                     gsize        *length)
{
    gconstpointer blob = sqlite3_column_blob (stmt, column);
    gsize blob_length = sqlite3_column_bytes (stmt, column);

#ifdef G_PASTE_ENABLE_ENCRYPTION
    if (key)
        return g_paste_sqlite_backend_decrypt (key, blob, blob_length, length);
#else
    (void) key;
#endif

    guchar *content = g_malloc (blob_length + 1);

    if (blob_length)
        memcpy (content, blob, blob_length);
    content[blob_length] = '\0';
    if (length)
        *length = blob_length;

    return content;
}

/* An item's alternative representations, read back onto it.
 *
 * Returns %FALSE when the scan stopped short of the end of the rows (a corrupt
 * page, an I/O error): the item then carries some of what was stored for it and
 * not the rest, and the caller must not pass that off as the whole of it -- the
 * same answer read_history_file's own scan carries up, and for the same reason.
 *
 * A row the scan did reach and this build could make nothing of is the other
 * thing: a representation dropped, not a history refused. The item itself came
 * back, and what it is missing is one of the several spellings of a value it
 * still holds -- the file backend reads an unknown mime the same way, and the
 * write path already skips one. */
static gboolean
g_paste_sqlite_backend_read_special_values (sqlite3_stmt *stmt,
                                            GEnumClass   *mime_class,
                                            const guchar *key,
                                            gint64        item_id,
                                            GPasteItem   *item)
{
    sqlite3_bind_int64 (stmt, 1, item_id);

    gint rc;

    while ((rc = sqlite3_step (stmt)) == SQLITE_ROW)
    {
        const gchar *mime = (const gchar *) sqlite3_column_text (stmt, 0);
        GEnumValue *gev = g_enum_get_value_by_nick (mime_class, mime);

        if (!gev)
        {
            g_warning ("sqlite: unknown mime: %s", mime);

            continue;
        }

        gsize length = 0;
        g_autofree guchar *data = g_paste_sqlite_backend_read_content (stmt, 1, key, &length);

        if (!data)
        {
            g_warning ("sqlite: failed to decrypt a special value; dropping it");

            continue;
        }

        /* As in the file backend: an empty blob is no representation. */
        if (!length)
            continue;

        GBytes *bytes = g_bytes_new_take (g_steal_pointer (&data), length);

        g_paste_item_add_special_value (item, g_paste_binary_data_new (gev->value, bytes));
    }

    /* Said before the reset, which is what replaces the message the connection
     * last reported: the scan that stopped short is this one, and the caller
     * only ever learns that some row could not be read back. */
    if (rc != SQLITE_DONE)
    {
        g_warning ("sqlite: could not read every special value of an item: %s",
                   sqlite3_errmsg (sqlite3_db_handle (stmt)));
    }

    sqlite3_reset (stmt);
    sqlite3_clear_bindings (stmt);

    return rc == SQLITE_DONE;
}

/* A constructor refusing the value a row stores -- a colour that does not parse,
 * a uri list nothing could be made of -- is a row this build was meant to read
 * and could not, exactly as one that did not decrypt is. Every kind whose value
 * is parsed rather than taken as it stands answers through here, so none of them
 * can drop a row quietly and leave the history reading back as complete. */
static GPasteItem *
g_paste_sqlite_backend_built_item (GPasteItem *item,
                                   gboolean   *unreadable)
{
    if (!item)
    {
        g_warning ("sqlite: failed to build an item from a stored value; dropping it");
        *unreadable = TRUE;
    }

    return item;
}

/* One row, as the item it stores.
 *
 * @unreadable is set when %NULL is a row this build could make nothing of -- a
 * value that does not decrypt or that its kind's constructor refuses, a kind it
 * does not know, an image whose stored blob does not decrypt or that no texture
 * can be made of -- as against the rows dropped on purpose, an image read with
 * images turned off, with no date, or with no blob to build it from. The caller
 * cannot tell those apart from the %NULL alone, and it has to: what it does with
 * a row it was meant to read and could not is refuse the whole history, the same
 * as for a scan that stopped short, or the next save writes the rows that did
 * come back over the ones that did not.
 *
 * Deliberately stricter than the file backend, which warns about an <item> it
 * cannot make sense of and reads the history around it. The two are not being
 * asked the same thing. A row here is one the store still holds intact and that
 * only this build could not turn back into an item -- a kind a newer GPaste
 * wrote, an image whose loader is no longer installed -- so handing back the
 * rest as a complete history is what has the next save delete it. Refusing
 * leaves the user a history that reads back empty until whatever it holds can be
 * understood again, and leaves the store itself untouched, which is the side to
 * be wrong on: an empty history is a session's inconvenience where a row written
 * over is gone. */
static GPasteItem *
g_paste_sqlite_backend_read_item (sqlite3_stmt *stmt,
                                  const guchar *key,
                                  gboolean      images_support,
                                  gboolean     *unreadable)
{
    const gchar *kind_str = (const gchar *) sqlite3_column_text (stmt, 2);
    GPasteItemKind kind = g_paste_item_kind_from_string (kind_str);
    /* A password's value comes back through here too, so the buffer is wiped
     * rather than merely freed once the item has taken a copy of it. */
    gsize value_length = 0;
    g_autoptr (GPasteCleartext) value = (gchar *) g_paste_sqlite_backend_read_content (stmt, 3, key, &value_length);

    *unreadable = FALSE;

    if (!value)
    {
        g_warning ("sqlite: failed to decrypt an item; dropping it");
        *unreadable = TRUE;

        return NULL;
    }

    /* The plain flavours hand back a column's bytes as they are, which only
     * GPaste's own writes keep to UTF-8: another tool's row, or a damaged page,
     * is one this build makes nothing of, where the constructors would refuse
     * it with a critical. Over its whole length: a NUL in it would have the
     * item cut it short, and the next save keep only that much. */
    if (!g_utf8_validate_len (value, value_length, NULL))
    {
        g_warning ("sqlite: an item's value is not UTF-8; dropping it");
        *unreadable = TRUE;

        return NULL;
    }

    switch (kind)
    {
    case G_PASTE_ITEM_KIND_TEXT:
        return g_paste_sqlite_backend_built_item (g_paste_text_item_new (value), unreadable);
    case G_PASTE_ITEM_KIND_URIS:
        return g_paste_sqlite_backend_built_item (g_paste_uris_item_new_from_str (value), unreadable);
    case G_PASTE_ITEM_KIND_PASSWORD:
    {
        gsize name_length = 0;
        g_autoptr (GPasteCleartext) name = (gchar *) g_paste_sqlite_backend_read_content (stmt, 6, key, &name_length);

        /* A password is always written with a name -- get_name () answers the
         * G_PASTE_PASSWORD_ITEM_NO_NAME placeholder for the ones that carry
         * none, and bind_item () binds that -- so nothing here comes back NULL
         * except a name that did not decrypt. Letting it through would build a
         * nameless password out of a named one and leave the history reading
         * back as complete: the next save rewrites the row with the placeholder,
         * and the name the user gave the secret is gone. */
        if (!name)
        {
            g_warning ("sqlite: failed to decrypt a password's name; dropping it");
            *unreadable = TRUE;

            return NULL;
        }

        /* As the value above: a plain database's password row is another
         * tool's, GPaste keeping none there. */
        if (!g_utf8_validate_len (name, name_length, NULL))
        {
            g_warning ("sqlite: a password's name is not UTF-8; dropping it");
            *unreadable = TRUE;

            return NULL;
        }

        /* Clamped before the cast, as the file backend's own parse is: a stored
         * value past G_MAXUINT truncates, and 2^32 truncates to 0 -- the one
         * value that means the password never comes off the clipboard. */
        gint64 timeout = CLAMP (sqlite3_column_int64 (stmt, 9), 0, G_PASTE_PASSWORD_TIMEOUT_MAX);

        return g_paste_sqlite_backend_built_item (g_paste_password_item_new (name, value, (guint) timeout),
                                                  unreadable);
    }
    case G_PASTE_ITEM_KIND_COLOR:
        return g_paste_sqlite_backend_built_item (g_paste_color_item_new_from_str (value), unreadable);
    case G_PASTE_ITEM_KIND_IMAGE:
    {
        /* Images turned off, a row with no date -- or one GDateTime cannot
         * hold, which is as good as none -- or one holding no blob: the blob is
         * the whole of such a row, so an image that is not in it is nowhere -- a
         * row names no file, its value being the checksum. Nothing this build
         * failed at, and nothing left on disk to go looking for. */
        if (!images_support ||
            sqlite3_column_type (stmt, 4) == SQLITE_NULL ||
            sqlite3_column_type (stmt, 7) == SQLITE_NULL)
            return NULL;

        g_autoptr (GDateTime) date = g_date_time_new_from_unix_local (sqlite3_column_int64 (stmt, 4));

        if (!date)
            return NULL;
        const gchar *checksum = (const gchar *) sqlite3_column_text (stmt, 5);
        gsize length = 0;
        guchar *data = g_paste_sqlite_backend_read_content (stmt, 7, key, &length);

        if (!data)
        {
            /* Nothing to fall back to: a row stores its image as a blob and its
             * value as the checksum, which names no file. */
            g_warning ("sqlite: failed to decrypt an image; dropping it");
            *unreadable = TRUE;

            return NULL;
        }

        g_autoptr (GBytes) png = g_bytes_new_take (data, length);
        GPasteItem *image = g_paste_image_item_new_from_bytes (png, date, checksum);

        /* Bytes that came back but that no texture could be made of are the
         * same answer as bytes that did not: a row this build was meant to read
         * and could not. */
        if (!image)
        {
            g_warning ("sqlite: failed to decode a stored image; dropping it");
            *unreadable = TRUE;
        }

        return image;
    }
    case G_PASTE_ITEM_KIND_INVALID:
        break;
    }

    g_warning ("Unknown item kind: %s", kind_str);
    *unreadable = TRUE;

    return NULL;
}

/* A read-only connection of its own to the database at @path, for what probes
 * it without the backend's state -- a count, a passphrase check: it creates no
 * database, opens no special file (g_paste_storage_is_special_file ()), and
 * waits out another connection busy with the database, as every connection of
 * the backend's does. Without that wait its reads would fail at once, a
 * passphrase check's then finding no parameters to refute with and counting
 * an empty history, either way accepting a passphrase the key check refuses.
 * %NULL when the database cannot be opened. */
static sqlite3 *
g_paste_sqlite_backend_open_readonly (const gchar *path)
{
    g_autoptr (sqlite3) db = NULL;

    if (g_paste_storage_is_special_file (path) || sqlite3_open_v2 (path, &db, SQLITE_OPEN_READONLY, NULL) != SQLITE_OK)
        return NULL;

    sqlite3_busy_timeout (db, G_PASTE_SQLITE_BUSY_TIMEOUT);

    return g_steal_pointer (&db);
}

/* What read_history_file would have returned, counted in the database rather
 * than carried out of it: same predicate, same cap, same favourites, and the
 * same image rows dropped when images are turned off.
 *
 * On a connection of its own, closed again on the way out, rather than the
 * cached one: counting needs no content and so no key, while opening another
 * database through the cache would evict the current history's connection --
 * and with it the derived key, which only a fresh Argon2 pass can replace. That
 * matters here because listing counts every history in turn.
 *
 * Read-only, so a history that is not there is not created by being counted; it
 * simply counts 0, as an unreadable one does. A row whose content cannot be
 * decoded at all is still counted, where a read refuses the whole history over
 * it: telling the two apart needs the key, which counting deliberately does not
 * take (below), so a corrupt history is named with a size here and opens empty.
 * That divergence is the smaller of the two problems the corruption causes --
 * the alternative is an Argon2 pass for every history listed.
 *
 * Opening by hand means the gates g_paste_sqlite_backend_open () applies have to
 * be applied here too, or a listing answers for a database a read refuses. A
 * user_version from a newer GPaste counts 0, the way that read reports nothing;
 * the schema the version names picks the query, since a database still on v1 has
 * no favourite column and a count that assumed one would answer 0 for a history
 * that reads back in full. The passphrase is the one gate it cannot apply: the
 * key is per-database and only an Argon2 pass produces it, which a listing
 * cannot afford once per history, so a `.dbs` written under some other
 * passphrase is counted here and refused on the read. */
static gsize
g_paste_sqlite_backend_count_history (GPasteStorageBackend *self,
                                      const gchar          *name)
{
    g_autofree gchar *history_file_path = g_paste_storage_backend_get_history_file_path (self, name);
    /* Nor under the backend's lock, which a load holds across the key
     * derivation and the decoding of every image -- and this runs on the main
     * loop, which in gnome-shell is the compositor's. A stall no test
     * measures. */
    g_autoptr (sqlite3) db = g_paste_sqlite_backend_open_readonly (history_file_path);

    if (!db)
        return 0;

    gint64 version = g_paste_sqlite_backend_query_int64 (db, "PRAGMA user_version;", 0);

    /* 0 is a database with no schema yet, which a read creates and finds empty;
     * anything past ours is one this GPaste will not touch. */
    if (!version || version > G_PASTE_SQLITE_SCHEMA_VERSION)
        return 0;

    gboolean images_support = g_paste_storage_backend_reads_images (self);
    const gchar *query;

    /* With images, the image rows read_item () drops on purpose are left out
     * too -- no blob, no date, or one GDateTime cannot hold -- each still
     * taking its place under the cap, as it does in the read. */
    if (version >= 2)
    {
        query = (images_support)
            ? "SELECT COUNT (*) FROM items "
              "WHERE (favourite = 1 "
              "       OR id IN (SELECT id FROM items WHERE favourite = 0 ORDER BY rank DESC LIMIT ?1)) "
              "  AND (kind != ?2 OR (image IS NOT NULL AND date BETWEEN ?3 AND ?4));"
            : "SELECT COUNT (*) FROM items "
              "WHERE kind != ?2 "
              "  AND (favourite = 1 "
              "       OR id IN (SELECT id FROM items WHERE favourite = 0 ORDER BY rank DESC LIMIT ?1));";
    }
    else
    {
        /* v1 has no favourite column, and the migration that adds one defaults
         * every row to unpinned: what a read of this database returns is the cap
         * applied to all of it. */
        query = (images_support)
            ? "SELECT COUNT (*) FROM items "
              "WHERE id IN (SELECT id FROM items ORDER BY rank DESC LIMIT ?1) "
              "  AND (kind != ?2 OR (image IS NOT NULL AND date BETWEEN ?3 AND ?4));"
            : "SELECT COUNT (*) FROM items "
              "WHERE kind != ?2 "
              "  AND id IN (SELECT id FROM items ORDER BY rank DESC LIMIT ?1);";
    }

    sqlite3_stmt *stmt = NULL;
    gsize count = 0;

    if (sqlite3_prepare_v2 (db, query, -1, &stmt, NULL) != SQLITE_OK)
    {
        g_warning ("sqlite: failed to prepare history count query: %s", sqlite3_errmsg (db));

        return 0;
    }

    sqlite3_bind_int64 (stmt, 1, g_paste_storage_backend_get_read_cap (self));

    /* The nick the rows were written with, not a literal: it is one enum
     * registration away from being something else. */
    sqlite3_bind_text (stmt, 2, g_paste_item_kind_to_string (G_PASTE_ITEM_KIND_IMAGE), -1, SQLITE_STATIC);
    if (images_support)
    {
        /* The dates g_date_time_new_from_unix_local () takes, which read_item ()
         * builds an image's from. */
        g_autoptr (GDateTime) first = g_date_time_new_local (1, 1, 1, 0, 0, 0);
        g_autoptr (GDateTime) last = g_date_time_new_local (9999, 12, 31, 23, 59, 59);

        sqlite3_bind_int64 (stmt, 3, (first) ? g_date_time_to_unix (first) : G_MININT64);
        sqlite3_bind_int64 (stmt, 4, (last) ? g_date_time_to_unix (last) : G_MAXINT64);
    }

    if (sqlite3_step (stmt) == SQLITE_ROW)
        count = sqlite3_column_int64 (stmt, 0);

    sqlite3_finalize (stmt);

    return count;
}

static gboolean
g_paste_sqlite_backend_read_history_file (GPasteStorageBackend *self,
                                          const gchar          *name,
                                          GCancellable         *cancellable,
                                          GList               **history,
                                          gsize                *size)
{
    GPasteSqliteBackend *backend = G_PASTE_SQLITE_BACKEND (self);
    g_autoptr (GMutexLocker) locker = g_mutex_locker_new (&backend->lock);
    g_autofree gchar *history_file_path = g_paste_storage_backend_get_history_file_path (self, name);

    *history = NULL;
    *size = 0;

    /* As in the file flavour's read: a load given up on creates nothing. Asked
     * under the lock a delete takes as well: a delete that cancelled this load
     * and took the lock first is seen here, and one coming later waits for this
     * read to be done before it unlinks. */
    if (g_cancellable_is_cancelled (cancellable))
        return FALSE;

    /* Opening creates the database on first read, so a fresh history shows up
     * in listings just like the file backend's empty placeholder. */
    sqlite3 *db = g_paste_sqlite_backend_open (self, history_file_path);

    /* A NULL db means the (possibly encrypted) database is present but could not
     * be opened/decrypted: report the failure so a caller never mistakes it for
     * a genuinely empty history. */
    if (!db)
        return FALSE;

    sqlite3_stmt *stmt = NULL;

    /* The LIMIT applies to the items the size cap can actually evict: a
     * favourite is read back however deep it has sunk, or the next save would
     * destroy the very thing pinning it was meant to protect. */
    if (sqlite3_prepare_v2 (db,
                            "SELECT id, uuid, kind, value, date, checksum, name, image, favourite, timeout FROM items "
                            "WHERE favourite = 1 "
                            "   OR id IN (SELECT id FROM items WHERE favourite = 0 ORDER BY rank DESC LIMIT ?) "
                            "ORDER BY rank DESC;",
                            -1, &stmt, NULL) != SQLITE_OK)
    {
        g_warning ("sqlite: failed to prepare history query: %s", sqlite3_errmsg (db));
        return FALSE;
    }

    sqlite3_bind_int64 (stmt, 1, g_paste_storage_backend_get_read_cap (self));

    /* Prepared once for the whole load: reset and re-bound per item.
     * add_special_value prepends, so walking positions backwards rebuilds each
     * item's special values in their original order. */
    sqlite3_stmt *sv_stmt = NULL;

    if (sqlite3_prepare_v2 (db, "SELECT mime, data FROM special_values WHERE item_id = ? ORDER BY position DESC;", -1, &sv_stmt, NULL) != SQLITE_OK)
    {
        g_warning ("sqlite: failed to prepare special value query: %s", sqlite3_errmsg (db));
        sqlite3_finalize (stmt);
        return FALSE;
    }

    GEnumClass *mime_class = g_type_class_get (G_PASTE_TYPE_SPECIAL_MIME);
    const guchar *key = g_paste_sqlite_backend_get_key (self);
    gboolean images_support = g_paste_storage_backend_reads_images (self);

    gint rc = SQLITE_DONE;
    gboolean complete = TRUE;
    gboolean cancelled = FALSE;
    /* The rows read with no valid uuid of their own, and the one their item was
     * given instead (see below). */
    g_autoptr (GArray) adopted_ids = g_array_new (FALSE, FALSE, sizeof (sqlite3_int64));
    g_autoptr (GPtrArray) adopted_uuids = g_ptr_array_new_with_free_func (g_free);

    /* Row by row, this being a read that does stop halfway: what has been built
     * so far is dropped by the caller either way, so the rows after the cancel
     * are decryptions and image loads nobody is waiting for. Answered as
     * incomplete, a partial history being one nothing may persist over -- the
     * same answer a row this build could make nothing of gets.
     *
     * Asked before the first step and not only between rows: a store with no
     * rows to walk would otherwise answer a cancelled read as a complete empty
     * history, which is what this function's own contract says it may not do. */
    while (!(cancelled = g_cancellable_is_cancelled (cancellable)) &&
           (rc = sqlite3_step (stmt)) == SQLITE_ROW)
    {
        gboolean unreadable = FALSE;
        GPasteItem *item = g_paste_sqlite_backend_read_item (stmt, key, images_support, &unreadable);

        if (!item)
        {
            complete = complete && !unreadable;

            continue;
        }

        const gchar *uuid = (const gchar *) sqlite3_column_text (stmt, 1);

        if (uuid && g_uuid_string_is_valid (uuid))
            g_paste_item_set_uuid (item, uuid);
        else
        {
            sqlite3_int64 id = sqlite3_column_int64 (stmt, 0);

            g_array_append_val (adopted_ids, id);
            g_ptr_array_add (adopted_uuids, g_strdup (g_paste_item_get_uuid (item)));
        }

        g_paste_item_set_favourite (item, sqlite3_column_int (stmt, 8));

        complete = g_paste_sqlite_backend_read_special_values (sv_stmt, mime_class, key,
                                                               sqlite3_column_int64 (stmt, 0), item) && complete;

        *history = g_list_prepend (*history, item);
        *size += g_paste_item_get_size (item);
    }

    complete = complete && !cancelled && (rc == SQLITE_DONE);

    /* Said while the statements are still open: finalizing them is what replaces
     * the message the connection last reported -- which answers for a scan that
     * stopped short and for nothing else, a row this build could make nothing of
     * having already said so where it was found.
     *
     * A scan given up on is not one that failed, and the connection has no
     * message for it: sqlite last reported on the step that produced a row,
     * which reads back as "not an error". */
    if (!complete && !cancelled)
    {
        g_warning ("sqlite: could not read every row of the history: %s",
                   (rc == SQLITE_DONE) ? "a row could not be read back" : sqlite3_errmsg (db));
    }

    sqlite3_finalize (sv_stmt);
    sqlite3_finalize (stmt);

    /* A row another tool wrote with no valid uuid is read with the one its item
     * was built with, and every write after this read keys on that uuid: the
     * row is given it in the store too, once the scan is done, or a delete of
     * the item would delete nothing and the next reconcile delete the row as
     * one the history no longer holds (/history/sqlite_null_uuid_adopted).
     * A row that cannot be given it leaves the history unread, as one cut
     * short does, rather than installed over a row no write can reach. */
    if (complete && adopted_ids->len)
    {
        sqlite3_stmt *adopt = NULL;

        complete = sqlite3_prepare_v2 (db, "UPDATE items SET uuid = ?1 WHERE id = ?2;", -1, &adopt, NULL) == SQLITE_OK;
        for (guint i = 0; complete && i < adopted_ids->len; ++i)
        {
            sqlite3_bind_text (adopt, 1, adopted_uuids->pdata[i], -1, SQLITE_STATIC);
            sqlite3_bind_int64 (adopt, 2, g_array_index (adopted_ids, sqlite3_int64, i));
            complete = sqlite3_step (adopt) == SQLITE_DONE;
            sqlite3_reset (adopt);
        }
        if (!complete)
            g_warning ("sqlite: could not give a row with no valid uuid one: %s", sqlite3_errmsg (db));
        sqlite3_finalize (adopt);
    }

    /* A scan cut short is not the end of the history. Handing back the rows it
     * did reach, as a successful read, is what has the caller install them as
     * the whole model -- and the next clipboard change then writes that
     * truncation back over the rows still in the store. Report the failure
     * instead, which is what stops the history being persisted at all, exactly
     * as the file backend refuses a parse that did not finish. */
    if (!complete)
    {
        g_clear_list (history, g_object_unref);
        *size = 0;

        return FALSE;
    }

    *history = g_list_reverse (*history);

    return TRUE;
}

/***********************/
/* Incremental updates */
/***********************/

/* The history only ever hands us items and uuids it also reflects in the
 * snapshot, so the snapshot is the authoritative fallback: after applying the
 * granular hint, any stored row missing from it (items evicted by the size or
 * memory limits, or a deduplicated older copy — those never get their own
 * remove operation) is dropped. Returns whether it was, every one of them. */
static gboolean
g_paste_sqlite_backend_reconcile (GPasteStorageBackend *self,
                                  sqlite3              *db,
                                  const GList          *history)
{
    /* What this backend leaves out -- an item it does not store, or one too
     * large -- is not counted: the model holds it and the store does not, and
     * an extra row the store still holds would make up for it. */
    gint64 expected = g_paste_storage_backend_count_kept (self, history);

    /* The common case: nothing rode along, the store already matches. Only
     * build the uuid set (and scan the table) when it actually does not, or
     * could not be counted: -1, which no count is. */
    if (g_paste_sqlite_backend_query_int64 (db, "SELECT COUNT (*) FROM items;", -1) == expected)
        return TRUE;

    g_autoptr (GHashTable) uuids = g_hash_table_new (g_str_hash, g_str_equal);

    for (const GList *h = history; h; h = g_list_next (h))
    {
        GPasteItem *item = h->data;

        if (g_paste_storage_backend_stores_item (self, item))
            g_hash_table_add (uuids, (gpointer) g_paste_item_get_uuid (item));
    }

    sqlite3_stmt *stmt = NULL;

    if (sqlite3_prepare_v2 (db, "SELECT uuid FROM items;", -1, &stmt, NULL) != SQLITE_OK)
    {
        g_warning ("sqlite: failed to prepare reconciliation query: %s", sqlite3_errmsg (db));
        return FALSE;
    }

    g_autoptr (GStrvBuilder) extra = g_strv_builder_new ();
    gint ret;

    while ((ret = sqlite3_step (stmt)) == SQLITE_ROW)
    {
        const gchar *uuid = (const gchar *) sqlite3_column_text (stmt, 0);

        /* A row with no uuid, which another tool's table can hold, is read
         * as an item of a uuid of its own (read_history_file ()): nothing
         * here names it, and no uuid could delete it. */
        if (uuid && !g_hash_table_contains (uuids, uuid))
            g_strv_builder_add (extra, uuid);
    }

    if (ret != SQLITE_DONE)
        g_warning ("sqlite: failed to scan for reconciliation: %s", sqlite3_errmsg (db));
    sqlite3_finalize (stmt);
    if (ret != SQLITE_DONE)
        return FALSE;

    g_auto (GStrv) to_delete = g_strv_builder_end (extra);

    if (!to_delete || !*to_delete)
        return TRUE;

    sqlite3_stmt *del = NULL;

    if (sqlite3_prepare_v2 (db, "DELETE FROM items WHERE uuid = ?;", -1, &del, NULL) != SQLITE_OK)
    {
        g_warning ("sqlite: failed to prepare reconciliation cleanup: %s", sqlite3_errmsg (db));
        return FALSE;
    }

    gboolean reconciled = TRUE;

    for (GStrv uuid = to_delete; *uuid; ++uuid)
    {
        sqlite3_bind_text (del, 1, *uuid, -1, SQLITE_STATIC);

        if (sqlite3_step (del) != SQLITE_DONE)
        {
            g_warning ("sqlite: failed to reconcile an item: %s", sqlite3_errmsg (db));
            reconciled = FALSE;
        }

        sqlite3_reset (del);
        sqlite3_clear_bindings (del);
    }

    sqlite3_finalize (del);

    return reconciled;
}

/* An "add" is not always a pure insert: the same operation also covers
 * selecting an existing item (moved to the front) and re-adding a duplicate
 * (the older copy is dropped), and eviction of trailing items can ride along.
 * Hence upsert-and-reconcile rather than a bare INSERT. */
static void
g_paste_sqlite_backend_add_item (GPasteStorageBackend *self,
                                 const gchar          *name,
                                 GPasteItem           *item,
                                 const GList          *history)
{
    g_autofree gchar *db_path = g_paste_storage_backend_get_history_file_path (self, name);
    GPasteSqliteBackend *backend = G_PASTE_SQLITE_BACKEND (self);
    g_autoptr (GMutexLocker) locker = g_mutex_locker_new (&backend->lock);

    /* A store some write left behind lags the model for good otherwise:
     * nothing retries a write, and the reconciliation below only drops rows.
     * An add carrying the whole snapshot writes it in full instead, the history
     * asking for one sooner, and the store still lags should that fail too. */
    if (history && g_paste_storage_backend_has_diverged (self, name))
    {
        if (g_paste_sqlite_backend_write_locked (self, name, history))
            g_paste_storage_backend_converge (self, name);
        return;
    }

    sqlite3 *db = g_paste_sqlite_backend_open (self, db_path);

    if (!db || !g_paste_sqlite_backend_exec (db, "BEGIN IMMEDIATE;"))
    {
        g_paste_storage_backend_diverge (self, name);
        return;
    }

    const guchar *key = g_paste_sqlite_backend_get_key (self);
    gboolean success = TRUE;

    if (g_paste_storage_backend_stores_item (self, item))
    {
        /* -1, which no rank is: a read that failed would otherwise rank the
         * newest item 1, the bottom of the store, and commit it there. */
        gint64 top = g_paste_sqlite_backend_query_int64 (db, "SELECT COALESCE (MAX (rank), 0) FROM items;", -1);

        success = (top >= 0 && g_paste_sqlite_backend_upsert_item (self, db, key, item, top + 1, TRUE));
    }

    /* A %NULL history says nothing was displaced by this add, so no row can
     * have been orphaned and there is nothing to reconcile. One that fails
     * leaves rows the add still commits around: the store lags all the same. */
    gboolean reconciled = TRUE;

    if (success && history)
        reconciled = g_paste_sqlite_backend_reconcile (self, db, history);

    /* No forget_deleted (): what an add displaces is the oldest item evicted,
     * on every copy once the history is full, or an older copy of what it
     * adds -- nothing the user deleted. A checkpoint with its syncs on every
     * copy is what SQLite's own, every thousand pages, spares. */
    if (!g_paste_sqlite_backend_finish_transaction (db, success) || !reconciled)
        g_paste_storage_backend_diverge (self, name);
}

/* The removal of @uuid from @db, under the backend's lock already: see
 * write_locked (). */
static void
g_paste_sqlite_backend_remove_locked (GPasteStorageBackend *self,
                                      sqlite3              *db,
                                      const gchar          *name,
                                      const gchar          *uuid)
{
    sqlite3_stmt *stmt = NULL;

    if (sqlite3_prepare_v2 (db, "DELETE FROM items WHERE uuid = ?;", -1, &stmt, NULL) != SQLITE_OK)
    {
        g_warning ("sqlite: failed to prepare item removal: %s", sqlite3_errmsg (db));
        g_paste_storage_backend_diverge (self, name);
        return;
    }

    sqlite3_bind_text (stmt, 1, uuid, -1, SQLITE_STATIC);

    if (sqlite3_step (stmt) != SQLITE_DONE)
    {
        g_warning ("sqlite: failed to remove an item: %s", sqlite3_errmsg (db));
        g_paste_storage_backend_diverge (self, name);
    }

    sqlite3_finalize (stmt);
    g_paste_sqlite_backend_forget_deleted (db);
}

static void
g_paste_sqlite_backend_remove_item (GPasteStorageBackend *self,
                                    const gchar          *name,
                                    const gchar          *uuid)
{
    g_autofree gchar *db_path = g_paste_storage_backend_get_history_file_path (self, name);
    GPasteSqliteBackend *backend = G_PASTE_SQLITE_BACKEND (self);
    g_autoptr (GMutexLocker) locker = g_mutex_locker_new (&backend->lock);
    sqlite3 *db = g_paste_sqlite_backend_open (self, db_path);

    if (!db)
    {
        g_paste_storage_backend_diverge (self, name);
        return;
    }

    g_paste_sqlite_backend_remove_locked (self, db, name, uuid);
}

static void
g_paste_sqlite_backend_replace_item (GPasteStorageBackend *self,
                                     const gchar          *name,
                                     const gchar          *old_uuid,
                                     GPasteItem           *item)
{
    g_autofree gchar *db_path = g_paste_storage_backend_get_history_file_path (self, name);
    GPasteSqliteBackend *backend = G_PASTE_SQLITE_BACKEND (self);
    g_autoptr (GMutexLocker) locker = g_mutex_locker_new (&backend->lock);
    sqlite3 *db = g_paste_sqlite_backend_open (self, db_path);

    if (!db)
    {
        g_paste_storage_backend_diverge (self, name);
        return;
    }

    const guchar *key = g_paste_sqlite_backend_get_key (self);

    /* In the plain flavor, an item turning into a password (make_password) must
     * vanish from storage, exactly as the plain XML backend drops passwords on
     * rewrite. The encrypted flavor persists it like any other item. */
    if (!g_paste_storage_backend_stores_item (self, item))
    {
        g_paste_sqlite_backend_remove_locked (self, db, name, old_uuid);
        return;
    }

    if (!g_paste_sqlite_backend_exec (db, "BEGIN IMMEDIATE;"))
    {
        g_paste_storage_backend_diverge (self, name);
        return;
    }

    sqlite3_stmt *stmt = NULL;
    gboolean success = (sqlite3_prepare_v2 (db,
                                            "UPDATE items SET uuid = ?, kind = ?, value = ?, date = ?, checksum = ?, name = ?, image = ?, favourite = ?, timeout = ? WHERE uuid = ? "
                                            "RETURNING id;",
                                            -1, &stmt, NULL) == SQLITE_OK);

    if (!success)
    {
        g_warning ("sqlite: failed to prepare item replacement: %s", sqlite3_errmsg (db));
        g_paste_sqlite_backend_exec (db, "ROLLBACK;");
        g_paste_storage_backend_diverge (self, name);
        return;
    }

    /* uuid, kind, value at 1-3, the meta group at base 4, then old uuid at 10. */
    gint ret = g_paste_sqlite_backend_bind_item (stmt, key, item, 4);

    sqlite3_bind_text (stmt, 10, old_uuid, -1, SQLITE_STATIC);
    if (ret == SQLITE_OK)
        ret = sqlite3_step (stmt);

    /* No row means the replaced item was never persisted -- left out as too
     * large -- and the replacement, which this flavour stores, is then written
     * by no update: the next full write is what puts it in. */
    gboolean found = (ret == SQLITE_ROW);
    gint64 item_id = found ? sqlite3_column_int64 (stmt, 0) : 0;
    gboolean left_out = FALSE;

    if (ret != SQLITE_ROW && ret != SQLITE_DONE)
    {
        left_out = g_paste_sqlite_backend_left_out (db, ret);
        success = FALSE;
    }

    sqlite3_finalize (stmt);

    /* As upsert_item () leaves one out: what it replaces is gone all the same,
     * removed under the lock already held, as for a replacement not stored. */
    if (left_out)
    {
        g_paste_sqlite_backend_exec (db, "ROLLBACK;");
        g_paste_storage_backend_leave_out (self, item);
        g_paste_sqlite_backend_remove_locked (self, db, name, old_uuid);
        return;
    }

    success = success && found && g_paste_sqlite_backend_rewrite_special_values (db, key, item_id, item);

    if (!g_paste_sqlite_backend_finish_transaction (db, success))
        g_paste_storage_backend_diverge (self, name);
    else
        g_paste_sqlite_backend_forget_deleted (db);
}

static void
g_paste_sqlite_backend_clear_history (GPasteStorageBackend *self,
                                      const gchar          *name)
{
    g_autofree gchar *db_path = g_paste_storage_backend_get_history_file_path (self, name);
    GPasteSqliteBackend *backend = G_PASTE_SQLITE_BACKEND (self);
    g_autoptr (GMutexLocker) locker = g_mutex_locker_new (&backend->lock);
    sqlite3 *db = g_paste_sqlite_backend_open (self, db_path);

    /* Keep the (now empty) database so the history is still listed. Level
     * with the history once emptied, as a full write leaves it, whatever
     * failed before: the next add needs no full write to catch up. */
    if (db && g_paste_sqlite_backend_exec (db, "DELETE FROM items;"))
    {
        g_paste_sqlite_backend_forget_deleted (db);
        g_paste_storage_backend_converge (self, name);
        return;
    }

    /* One open () refuses -- under another passphrase, from a newer GPaste --
     * is replaced by an empty one: emptying a history that could not be read
     * writes over it (g_paste_history_empty ()), as the file flavour's empty
     * document does. */
    if (!db)
    {
        g_autoptr (GError) error = NULL;

        g_paste_sqlite_backend_unlink (backend, db_path, &error);

        if (!error && g_paste_sqlite_backend_open (self, db_path))
        {
            g_paste_storage_backend_converge (self, name);
            return;
        }

        if (error)
            g_warning ("sqlite: could not replace “%s” with an empty history: %s", db_path, error->message);
    }

    g_paste_storage_backend_diverge (self, name);
}

/**************/
/* Management */
/**************/

#ifdef G_PASTE_ENABLE_ENCRYPTION
/* Re-encrypt @name under @new_passphrase. Everything — every content column and
 * the meta parameters the key is checked against — moves in a single
 * transaction, so the database is only ever readable with the old passphrase or
 * with the new one, never stuck between them: nothing here ever sets @split. */
static gboolean
g_paste_sqlite_backend_rekey (GPasteStorageBackend *self,
                              const gchar          *name,
                              const gchar          *new_passphrase,
                              gboolean             *split G_GNUC_UNUSED)
{
    if (!g_paste_sqlite_backend_get_passphrase (self))
    {
        g_warning ("This history is not encrypted: it has no passphrase to change");
        return FALSE;
    }

    g_autofree gchar *db_path = g_paste_storage_backend_get_history_file_path (self, name);
    GPasteSqliteBackend *backend = G_PASTE_SQLITE_BACKEND (self);
    g_autoptr (GMutexLocker) locker = g_mutex_locker_new (&backend->lock);
    /* Opening verifies the current passphrase against the stored key check, so
     * by here backend->key is the one everything is encrypted with. */
    sqlite3 *db = g_paste_sqlite_backend_open (self, db_path);

    if (!db)
        return FALSE;

    guchar salt[crypto_pwhash_SALTBYTES];
    guint64 opslimit = crypto_pwhash_OPSLIMIT_MODERATE;
    guint64 memlimit = crypto_pwhash_MEMLIMIT_MODERATE;
    guchar *new_key = gcr_secure_memory_alloc (crypto_secretbox_KEYBYTES);

    randombytes_buf (salt, sizeof (salt));

    if (!g_paste_sqlite_backend_derive_key (new_passphrase, salt, opslimit, memlimit, new_key))
    {
        g_warning ("sqlite: could not derive the new encryption key (out of memory?)");
        g_paste_sqlite_backend_free_key (new_key);

        return FALSE;
    }

    if (!g_paste_sqlite_backend_exec (db, "BEGIN IMMEDIATE;"))
    {
        g_paste_sqlite_backend_free_key (new_key);

        return FALSE;
    }

    gboolean success = TRUE;

    for (guint64 i = 0; success && i < G_N_ELEMENTS (g_paste_sqlite_backend_content_columns); ++i)
    {
        success = g_paste_sqlite_backend_rekey_column (db, backend->key, new_key,
                                                       g_paste_sqlite_backend_content_columns[i].ids_sql,
                                                       g_paste_sqlite_backend_content_columns[i].select_sql,
                                                       g_paste_sqlite_backend_content_columns[i].update_sql);
    }

    /* The new salt and key check land in the same transaction as the content
     * they describe: rolling back takes them with it. */
    success = success && g_paste_sqlite_backend_write_crypto_params (db, salt, opslimit, memlimit, new_key);
    success = g_paste_sqlite_backend_finish_transaction (db, success);

    if (!success)
    {
        g_paste_sqlite_backend_free_key (new_key);
        g_warning ("Failed to re-encrypt the history \"%s\"; it keeps its current passphrase", name);

        return FALSE;
    }

    /* The pages under the passphrase being retired leave the database file now
     * rather than once its last connection closes: the live history's backend
     * holds one, and the file alone, its log lost with a process dying
     * meanwhile, would open under that passphrase. */
    g_paste_sqlite_backend_forget_deleted (db);

    /* Committed. This instance deliberately stays keyed to the passphrase it was
     * built with: a passphrase change re-keys every history through one backend,
     * so adopting the new one here would make the next history — still encrypted
     * with the old one — fail to open. Only the cached connection has to go, its
     * key no longer matching what is now on disk; re-opening this database
     * through this instance then refuses it at the key check rather than reading
     * it with a stale key. */
    g_clear_pointer (&backend->db, g_paste_sqlite_backend_close);
    g_clear_pointer (&backend->db_path, g_free);
    g_clear_pointer (&backend->key, g_paste_sqlite_backend_free_key);
    g_paste_sqlite_backend_free_key (new_key);

    return TRUE;
}
#endif /* G_PASTE_ENABLE_ENCRYPTION */

static void
g_paste_sqlite_backend_delete_history (GPasteStorageBackend *self,
                                       const gchar          *name,
                                       GError              **error)
{
    const gchar *extension = g_paste_storage_backend_get_extension (self);
    g_autofree gchar *db_path = g_paste_util_get_history_file_path (name, extension);
    GPasteSqliteBackend *backend = G_PASTE_SQLITE_BACKEND (self);

    /* Taken, the lock is a read or a write of another history -- the writes
     * of this one landed before a delete reaches here
     * (g_paste_history_saver_drain_history ()) --, a load among them holding
     * it across a key derivation and the decoding of every row: waited for,
     * that would hold the main loop, gnome-shell's compositor for the in-shell
     * daemon. The database goes without it, and should the connection cached
     * still be this one's, the next open drops it rather than write to a file
     * no longer listed. Dropping it checkpoints nothing and unlinks no log:
     * SQLite skips that for a database unlinked under its connection
     * (SQLITE_FCNTL_HAS_MOVED), so a database written under the name meanwhile
     * keeps the commits its own log holds
     * (/storage/sqlite/forgotten-spares-new-log). */
    if (!g_mutex_trylock (&backend->lock))
    {
        g_mutex_lock (&backend->forgotten_lock);
        g_set_str (&backend->forgotten, db_path);
        g_mutex_unlock (&backend->forgotten_lock);
        g_paste_sqlite_backend_delete_database (db_path, error);
        return;
    }

    g_paste_sqlite_backend_unlink (backend, db_path, error);
    g_mutex_unlock (&backend->lock);
}

static GPasteStorage
g_paste_sqlite_backend_get_kind (GPasteStorageBackend *self)
{
    return g_paste_sqlite_backend_get_passphrase (self) ? G_PASTE_STORAGE_ENCRYPTED_SQLITE : G_PASTE_STORAGE_SQLITE;
}

static void
g_paste_sqlite_backend_finalize (GObject *object)
{
    GPasteSqliteBackend *self = G_PASTE_SQLITE_BACKEND (object);

    /* With the connection, here rather than in dispose (): the write vfuncs
     * read it for as long as they can run, which is until the last reference
     * goes. */
    g_clear_pointer (&self->db, g_paste_sqlite_backend_close);
    g_clear_pointer (&self->db_path, g_free);
    g_clear_pointer (&self->forgotten, g_free);
    g_mutex_clear (&self->lock);
    g_mutex_clear (&self->forgotten_lock);
#ifdef G_PASTE_ENABLE_ENCRYPTION
    g_clear_pointer (&self->key, g_paste_sqlite_backend_free_key);
    g_paste_passphrase_free (self->passphrase);
#endif

    G_OBJECT_CLASS (g_paste_sqlite_backend_parent_class)->finalize (object);
}

#ifdef G_PASTE_ENABLE_ENCRYPTION
/* Whether the database of the history called @name keys this backend's
 * passphrase -- %FALSE when there is no key to check it against, @checks_out
 * then saying nothing -- and, when @has_data is asked for, whether it holds any
 * item. Read-only: verification must never create or touch anything, and open ()
 * re-keys an empty database for whatever passphrase it is given. */
static gboolean
g_paste_sqlite_backend_check_passphrase (GPasteStorageBackend *self,
                                         const gchar          *name,
                                         gboolean             *checks_out,
                                         gboolean             *has_data)
{
    g_autofree gchar *path = g_paste_storage_backend_get_history_file_path (self, name);
    g_autoptr (sqlite3) db = g_paste_sqlite_backend_open_readonly (path);

    if (!db)
        return FALSE;

    guchar salt[crypto_pwhash_SALTBYTES];
    guint64 opslimit = 0;
    guint64 memlimit = 0;
    g_autofree guchar *check = NULL;
    gsize check_length = 0;

    if (!g_paste_sqlite_backend_load_crypto_params (db, salt, &opslimit, &memlimit, &check, &check_length))
        return FALSE;

    const gchar *passphrase = g_paste_sqlite_backend_get_passphrase (self);
    /* Where every other derived key lives: the stack is pageable, so a key on it
     * can reach the swap between here and the memzero below. */
    guchar *key = gcr_secure_memory_alloc (crypto_secretbox_KEYBYTES);
    g_autoptr (GError) derive_error = NULL;
    gboolean derived = g_paste_crypto_derive_key (passphrase, strlen (passphrase), salt, opslimit, memlimit,
                                                  key, crypto_secretbox_KEYBYTES, &derive_error);

    /* Parameters out of range are the file's, a derivation that did not
     * complete is a check not made, as in the file flavour's refutation. */
    if (!derived)
    {
        g_warning ("sqlite: %s", derive_error->message);
        if (g_error_matches (derive_error, G_IO_ERROR, G_IO_ERROR_FAILED))
            g_paste_storage_backend_set_unverifiable (self);
    }

    *checks_out = derived && g_paste_sqlite_backend_key_checks_out (key, check, check_length);
    g_paste_sqlite_backend_free_key (key);
    /* A count that still cannot be read is inconclusive, which refuting asks to
     * answer as no refutation rather than condemn a passphrase over an I/O
     * error. Accepting a wrong one there costs no data: the open that follows
     * refuses it on the same count (setup_crypto()), and the history stays
     * unreadable rather than written over. */
    if (has_data)
        *has_data = g_paste_sqlite_backend_query_int64 (db, "SELECT COUNT (*) FROM items;", 0) > 0;

    return derived;
}

/**
 * g_paste_sqlite_backend_database_has_items:
 * @path: the database to look into
 *
 * Whether the database at @path holds an item, which is what its key check
 * refutes a passphrase over: an empty one is keyed afresh by whatever opens it.
 * Read-only, as verifying has to be, and with no key: nothing but the count and
 * the parameters the check needs are asked. A database that cannot be read, or
 * whose parameters are missing or ask for what no key is derived for, holds
 * nothing to go by.
 *
 * Returns: whether a wrong passphrase would be refused over the database
 */
gboolean
g_paste_sqlite_backend_database_has_items (const gchar *path)
{
    g_autoptr (sqlite3) db = g_paste_sqlite_backend_open_readonly (path);

    if (!db)
        return FALSE;

    guchar salt[crypto_pwhash_SALTBYTES];
    guint64 opslimit = 0;
    guint64 memlimit = 0;
    /* Loaded and not read: load_crypto_params () answers for whole parameters
     * alone, and a database without its key check is no more verifiable than
     * one without its salt. */
    g_autofree guchar *check = NULL;
    gsize check_length = 0;

    if (!g_paste_sqlite_backend_load_crypto_params (db, salt, &opslimit, &memlimit, &check, &check_length) ||
        !g_paste_crypto_parameters_derivable (opslimit, memlimit))
        return FALSE;

    return g_paste_sqlite_backend_query_int64 (db, "SELECT COUNT (*) FROM items;", 0) > 0;
}

/* See the vfunc: only encrypted data this backend's key does not open refutes
 * the passphrase. No crypto parameters (a corrupt or foreign file) and an empty
 * history both say nothing -- the latter gets re-keyed on open instead of
 * locking the user out. */
static gboolean
g_paste_sqlite_backend_history_refutes_passphrase (GPasteStorageBackend *self,
                                                   const gchar          *name)
{
    gboolean checks_out = FALSE;
    gboolean has_data = FALSE;

    return g_paste_sqlite_backend_check_passphrase (self, name, &checks_out, &has_data) && !checks_out && has_data;
}

/* See the vfunc: the key check proves it, empty database or not -- one that
 * fails proving nothing, since open () would re-key an empty one for it. */
static gboolean
g_paste_sqlite_backend_history_confirms_passphrase (GPasteStorageBackend *self,
                                                    const gchar          *name)
{
    gboolean checks_out = FALSE;

    return g_paste_sqlite_backend_check_passphrase (self, name, &checks_out, NULL) && checks_out;
}
#endif

static void
g_paste_sqlite_backend_class_init (GPasteSqliteBackendClass *klass)
{
    GPasteStorageBackendClass *storage_class = G_PASTE_STORAGE_BACKEND_CLASS (klass);

    storage_class->read_history_file = g_paste_sqlite_backend_read_history_file;
    storage_class->write_history_file = g_paste_sqlite_backend_write_history_file;
    storage_class->get_kind = g_paste_sqlite_backend_get_kind;
    storage_class->delete_history = g_paste_sqlite_backend_delete_history;
    storage_class->count_history = g_paste_sqlite_backend_count_history;

    storage_class->add_item = g_paste_sqlite_backend_add_item;
    storage_class->remove_item = g_paste_sqlite_backend_remove_item;
    storage_class->replace_item = g_paste_sqlite_backend_replace_item;
    storage_class->clear_history = g_paste_sqlite_backend_clear_history;

#ifdef G_PASTE_ENABLE_ENCRYPTION
    storage_class->rekey = g_paste_sqlite_backend_rekey;
    storage_class->history_refutes_passphrase = g_paste_sqlite_backend_history_refutes_passphrase;
    storage_class->history_confirms_passphrase = g_paste_sqlite_backend_history_confirms_passphrase;
#endif

    G_OBJECT_CLASS (klass)->finalize = g_paste_sqlite_backend_finalize;
}

static void
g_paste_sqlite_backend_init (GPasteSqliteBackend *self)
{
    g_mutex_init (&self->lock);
    g_mutex_init (&self->forgotten_lock);
}

#ifdef G_PASTE_ENABLE_ENCRYPTION
/**
 * g_paste_sqlite_backend_new_encrypted:
 * @settings: a #GPasteSettings instance
 * @passphrase: the passphrase the encryption key is derived from
 *
 * Create a SQLite storage backend that encrypts the history's content columns
 * (with the ".dbs" extension) using a key derived from @passphrase. Unlike the
 * plain flavor it persists password entries, since the content is unreadable
 * without the passphrase.
 *
 * Returns: (transfer full) (nullable): a newly allocated #GPasteStorageBackend,
 *          or %NULL if libsodium could not be initialised;
 *          free it with g_object_unref
 */
G_PASTE_VISIBLE GPasteStorageBackend *
g_paste_sqlite_backend_new_encrypted (GPasteSettings *settings,
                                      const gchar    *passphrase)
{
    g_return_val_if_fail (G_PASTE_IS_SETTINGS (settings), NULL);
    g_return_val_if_fail (passphrase && *passphrase, NULL);

    if (sodium_init () < 0)
    {
        g_warning ("Could not initialise libsodium");
        return NULL;
    }

    GPasteStorageBackend *self = g_paste_storage_backend_new (G_PASTE_STORAGE_SQLITE, settings);
    GPasteSqliteBackend *backend = G_PASTE_SQLITE_BACKEND (self);

    backend->passphrase = g_paste_passphrase_new (passphrase);

    return self;
}

#endif
