// SPDX-FileCopyrightText: 2010-2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com>
// SPDX-License-Identifier: BSD-2-Clause

#include <gpaste-3/gpaste-error.h>
#include <gpaste-3/gpaste-util.h>

#include <gpaste-daemon/gpaste-daemon-util.h>
#include <gpaste-daemon/gpaste-file-backend.h>
#include <gpaste-daemon/gpaste-noop-backend.h>
#include <gpaste-daemon/gpaste-storage-backend-private.h>

#include <glib/gstdio.h>

#ifdef G_PASTE_ENABLE_SQLITE
#include <gpaste-daemon/gpaste-sqlite-backend.h>
#endif

#ifdef G_OS_UNIX
#include <errno.h>
#include <fcntl.h>
#include <sys/file.h>
#include <unistd.h>
#endif

#ifdef G_PASTE_ENABLE_LIBSECRET
#include <gpaste-daemon/gpaste-storage-keyring.h>
#endif

#ifdef G_PASTE_ENABLE_ENCRYPTION
#include <gpaste-daemon/gpaste-passphrase.h>
#include <gpaste-daemon/gpaste-secret-stream-converter.h>

/* The daemon's single master passphrase for the encrypted backend, obtained
 * once at startup (prompt or keyring). Kept process-wide in gcr secure memory
 * so every history the daemon builds resolves the encrypted backend without
 * threading the secret through every constructor. */
static GPastePassphrase *g_paste_storage_passphrase = NULL;

/**
 * g_paste_storage_backend_set_passphrase:
 * @passphrase: (nullable): the master passphrase, or %NULL to clear it
 *
 * Set the passphrase used by every encrypted file backend created afterwards.
 */
G_PASTE_VISIBLE void
g_paste_storage_backend_set_passphrase (const gchar *passphrase)
{
    /* Copied before the one it replaces goes: @passphrase may be that one's
     * own cleartext, which g_paste_storage_backend_get_passphrase () hands
     * out, and freeing it wipes it. */
    g_autoptr (GPastePassphrase) replaced = g_steal_pointer (&g_paste_storage_passphrase);

    g_paste_storage_passphrase = g_paste_passphrase_new (passphrase);
}

/**
 * g_paste_storage_backend_get_passphrase:
 *
 * Returns: (nullable): the master passphrase set with
 *          g_paste_storage_backend_set_passphrase(), or %NULL
 */
G_PASTE_VISIBLE const gchar *
g_paste_storage_backend_get_passphrase (void)
{
    return g_paste_passphrase_peek (g_paste_storage_passphrase);
}
#endif

/* Process-wide advisory lock serialising history persistence across daemons.
 * Whoever persists holds it for its whole lifetime; a daemon taking over (the
 * gnome-shell extension replacing the standalone daemon, or vice versa) blocks
 * on it before its first read, so it never loads a stale history while the
 * previous owner is still flushing its final state. The kernel drops the lock
 * when the holder's process dies, so a crash cannot wedge the successor. */
static GMutex   g_paste_storage_lock_mutex;
static gint     g_paste_storage_lock_fd = -1;
/* Counted by _unlock() so a wait still in progress on the worker thread gives
 * up instead of installing a lock nobody wants any more: one that began before
 * a release, which is what the count it started from tells. Written under the
 * mutex, which is only ever held for the bookkeeping — never across the wait —
 * hence read atomically from the waiting thread. */
static guint    g_paste_storage_lock_releases;

#ifdef G_OS_UNIX
/* The one file both lock () and try_lock () take, made where need be: -1 when
 * it cannot be opened, with a warning saying why. A history directory that
 * cannot be made is the helper's own to report: once it has logged, errno
 * says nothing of it.
 *
 * A lock file that cannot be opened or locked tells no daemon apart, so both
 * answer that the store may be touched: refused instead, every load would read
 * nothing, the history it was for staying unwritten, and every Backup, Empty or
 * Delete would blame another daemon, for as long as the file stays as it is. */
static gint
g_paste_storage_backend_open_lock_file (void)
{
    if (!g_paste_util_ensure_history_dir_exists ())
        return -1;

    g_autofree gchar *dir = g_paste_util_get_history_dir_path ();
    g_autofree gchar *path = g_build_filename (dir, "lock", NULL);
    gint fd = open (path, O_RDWR | O_CREAT | O_CLOEXEC, 0600);

    if (fd < 0)
        g_warning ("Failed to open the history lock file: %s", g_strerror (errno));

    return fd;
}
#endif

/**
 * g_paste_storage_backend_lock:
 * @cancellable: (nullable): the load this wait belongs to, to give it up with
 *
 * Acquire the process-wide history lock, blocking until any other daemon holding
 * it releases it (or its process dies). Idempotent: once held, further calls are
 * a no-op. Meant to be called off the main thread before the store is touched --
 * by the history's load worker, and by the startup gates' wait -- so a takeover
 * waits out the previous owner's final write.
 *
 * Two things end the wait short of the lock, and they answer different
 * questions: @cancellable says the load this is waiting for has been given up on
 * (superseded, or abandoned by the owner), where g_paste_storage_backend_unlock()
 * called since the wait began says this process has let go of the lock and
 * wants none. Either way no lock is installed, and what was waiting must not
 * touch the store: it is what the answer says.
 *
 * Returns: whether this process may touch the store: it holds the lock, or the
 *     lock file cannot be opened or locked, which no daemon can then hold either
 */
G_PASTE_VISIBLE gboolean
g_paste_storage_backend_lock (GCancellable *cancellable)
{
    return g_paste_storage_backend_lock_since (g_paste_storage_backend_get_releases (), cancellable);
}

G_PASTE_VISIBLE guint
g_paste_storage_backend_get_releases (void)
{
    return (guint) g_atomic_int_get (&g_paste_storage_lock_releases);
}

G_PASTE_VISIBLE gboolean
g_paste_storage_backend_lock_since (guint         releases,
                                    GCancellable *cancellable)
{
#ifdef G_OS_UNIX
    {
        g_autoptr (GMutexLocker) locker = g_mutex_locker_new (&g_paste_storage_lock_mutex);

        /* Held, but maybe by a wait begun after this process let go of the
         * one this wait was counted from: that release ends this wait all the
         * same, whoever has taken the lock since. */
        if (g_paste_storage_lock_fd >= 0)
            return g_paste_storage_backend_get_releases () == releases;
    }

    gint fd = g_paste_storage_backend_open_lock_file ();

    /* open_lock_file () says why it failed, and why that refuses nothing. A
     * release since the count ends the wait all the same, as everywhere
     * below. */
    if (fd < 0)
        return g_paste_storage_backend_get_releases () == releases;

    gint64 start = g_get_monotonic_time ();
    gboolean logged = FALSE;

    /* The wait deliberately happens *outside* the mutex: it can last as long as
     * the previous daemon takes to finish writing, and _unlock() runs on the main
     * thread of every exit path — holding the mutex here would block it (and, in
     * the gnome-shell host, freeze the compositor) for that whole time.
     *
     * Each attempt is made under it, though, and the lock installed the moment
     * it is taken: try_lock () holds the mutex too, and finding this file
     * holding the lock not yet installed, its own flock () would be refused as
     * if another daemon held it. */
    for (;;)
    {
        gint refused;

        {
            g_autoptr (GMutexLocker) locker = g_mutex_locker_new (&g_paste_storage_lock_mutex);

            /* Another wait of this process's got it, and a lock of this
             * process's is one flock () refuses this wait's own file. As
             * above, a release since the count this wait was given ends it. */
            if (g_paste_storage_lock_fd >= 0)
            {
                close (fd);
                return g_paste_storage_backend_get_releases () == releases;
            }

            if (flock (fd, LOCK_EX | LOCK_NB) == 0)
            {
                /* A wait given up on drops it, rather than hold the lock for a
                 * load nobody wants -- another wait of this process's then
                 * takes it. */
                if (g_paste_storage_backend_get_releases () != releases ||
                    g_cancellable_is_cancelled (cancellable))
                {
                    close (fd);
                    return FALSE;
                }

                g_paste_storage_lock_fd = fd;
                return TRUE;
            }

            refused = errno;
        }

        if (refused != EWOULDBLOCK && refused != EINTR)
        {
            g_warning ("Failed to lock the history: %s", g_strerror (refused));
            close (fd);
            return g_paste_storage_backend_get_releases () == releases;
        }

        /* A brief handover is normal; only warn if the previous daemon really is
         * taking a long time to finish writing, so a stuck one is diagnosable. */
        if (!logged && g_get_monotonic_time () - start > 5 * G_USEC_PER_SEC)
        {
            g_message ("Waiting for the previous GPaste daemon to finish writing the history");
            logged = TRUE;
        }

        if (g_paste_storage_backend_get_releases () != releases ||
            g_cancellable_is_cancelled (cancellable))
        {
            close (fd);
            return FALSE;
        }

        g_usleep (100 * 1000); /* 100ms */
    }
#else
    return TRUE;
#endif
}

/**
 * g_paste_storage_backend_try_lock:
 *
 * Acquire the process-wide history lock if nobody else holds it, without
 * waiting: for what may only touch the store while no other daemon can be
 * writing it, and has a later chance if one is (see
 * g_paste_file_backend_settle_rekeys()). Like g_paste_storage_backend_lock(),
 * once held it stays held.
 *
 * Returns: whether this process may touch the store, as
 *     g_paste_storage_backend_lock() answers it
 */
G_PASTE_VISIBLE gboolean
g_paste_storage_backend_try_lock (void)
{
#ifdef G_OS_UNIX
    g_autoptr (GMutexLocker) locker = g_mutex_locker_new (&g_paste_storage_lock_mutex);

    if (g_paste_storage_lock_fd >= 0)
        return TRUE;

    gint fd = g_paste_storage_backend_open_lock_file ();

    if (fd < 0)
        return TRUE;

    if (flock (fd, LOCK_EX | LOCK_NB) < 0)
    {
        gboolean held_elsewhere = (errno == EWOULDBLOCK || errno == EINTR);

        if (!held_elsewhere)
            g_warning ("Failed to lock the history: %s", g_strerror (errno));
        close (fd);
        return !held_elsewhere;
    }

    g_paste_storage_lock_fd = fd;
#endif

    return TRUE;
}

/**
 * g_paste_storage_backend_unlock:
 *
 * Release the process-wide history lock acquired with
 * g_paste_storage_backend_lock(). Call it after the final write has been flushed,
 * so a daemon taking over can proceed. Safe to call when the lock is not held.
 */
G_PASTE_VISIBLE void
g_paste_storage_backend_unlock (void)
{
#ifdef G_OS_UNIX
    g_autoptr (GMutexLocker) locker = g_mutex_locker_new (&g_paste_storage_lock_mutex);

    g_atomic_int_inc (&g_paste_storage_lock_releases);

    if (g_paste_storage_lock_fd < 0)
        return;

    /* Closing the fd drops the flock. */
    close (g_paste_storage_lock_fd);
    g_paste_storage_lock_fd = -1;
#endif
}

typedef struct
{
    GPasteSettings *settings;
    gboolean        read_whole;
    gboolean        unverifiable;

    /* The histories a write failed for since the last full write or emptying
     * of them that landed, for a backend with no has_diverged of its own: the
     * full writes g_paste_storage_backend_write_history () sees, and those an
     * incremental backend records itself (g_paste_storage_backend_diverge ()).
     * And the items, by uuid, a write left out of the store as too large for
     * it (g_paste_storage_backend_leave_out ()). Guarded by @records_lock rather
     * than by a backend's own lock, which a load may hold for as long as its
     * read takes: the writes record into them on storage workers, a backend's
     * lock held, and the main thread asks after every write. Nothing else is
     * ever taken under @records_lock. */
    GHashTable     *diverged;
    GHashTable     *left_out;
    GMutex          records_lock;
} GPasteStorageBackendPrivate;

G_PASTE_DEFINE_ABSTRACT_TYPE_WITH_PRIVATE (StorageBackend, storage_backend, G_TYPE_OBJECT)

/* A backend that can update the stored history in place does; one that cannot
 * has the whole thing written out again. */
#define G_PASTE_STORAGE_BACKEND_UPDATE(vfunc, ...)                                         \
    do {                                                                                   \
        const GPasteStorageBackendClass *klass = G_PASTE_STORAGE_BACKEND_GET_CLASS (self); \
                                                                                           \
        if (klass->vfunc)                                                                  \
            klass->vfunc (self, name, ##__VA_ARGS__);                                      \
        else                                                                               \
            g_paste_storage_backend_write_history (self, name, history);                   \
    } while (FALSE)

/**
 * g_paste_storage_backend_get_kind:
 * @self: a #GPasteStorageBackend instance
 *
 * Which storage flavour @self is.
 *
 * Returns: the #GPasteStorage kind
 */
G_PASTE_VISIBLE GPasteStorage
g_paste_storage_backend_get_kind (GPasteStorageBackend *self)
{
    g_return_val_if_fail (G_PASTE_IS_STORAGE_BACKEND (self), G_PASTE_STORAGE_NOOP);

    const GPasteStorageBackendClass *klass = G_PASTE_STORAGE_BACKEND_GET_CLASS (self);

    g_return_val_if_fail (klass->get_kind, G_PASTE_STORAGE_NOOP);

    return klass->get_kind (self);
}

/**
 * g_paste_storage_backend_get_extension:
 * @self: a #GPasteStorageBackend instance
 *
 * The on-disk extension @self stores histories under.
 *
 * Returns: the extension (without the leading dot)
 */
G_PASTE_VISIBLE const gchar *
g_paste_storage_backend_get_extension (GPasteStorageBackend *self)
{
    return g_paste_storage_get_extension (g_paste_storage_backend_get_kind (self));
}

/**
 * g_paste_storage_backend_is_encrypted:
 * @self: a #GPasteStorageBackend instance
 *
 * Whether @self encrypts the history on disk -- which is also what decides
 * whether it may keep password items at all.
 *
 * Returns: %TRUE for the encrypted flavours
 */
G_PASTE_VISIBLE gboolean
g_paste_storage_backend_is_encrypted (GPasteStorageBackend *self)
{
    return g_paste_storage_is_encrypted (g_paste_storage_backend_get_kind (self));
}

/**
 * g_paste_storage_backend_stores_item:
 * @self: a #GPasteStorageBackend instance
 * @item: a #GPasteItem
 *
 * Whether @self keeps @item at all: a password only in an encrypted flavour,
 * whose store cannot be read without the passphrase.
 *
 * Returns: whether @item reaches the store
 */
G_PASTE_VISIBLE gboolean
g_paste_storage_backend_stores_item (GPasteStorageBackend *self,
                                     GPasteItem           *item)
{
    return g_paste_storage_backend_is_encrypted (self) || g_paste_item_get_kind (item) != G_PASTE_ITEM_KIND_PASSWORD;
}

/**
 * g_paste_storage_backend_get_history_file_path:
 * @self: a #GPasteStorageBackend instance
 * @name: the name of a history
 *
 * Where this backend keeps the history called @name. A history is identified by
 * its name everywhere; the path is each backend's own business, which is why it
 * derives it here rather than being handed one.
 *
 * Returns: the newly allocated path
 */
G_PASTE_VISIBLE gchar *
g_paste_storage_backend_get_history_file_path (GPasteStorageBackend *self,
                                               const gchar          *name)
{
    g_return_val_if_fail (G_PASTE_IS_STORAGE_BACKEND (self), NULL);
    g_return_val_if_fail (name, NULL);

    return g_paste_util_get_history_file_path (name, g_paste_storage_backend_get_extension (self));
}

/**
 * g_paste_storage_backend_read_history:
 * @self: a #GPasteStorageBackend instance
 * @name: the name of the history to load
 * @cancellable: (nullable): a #GCancellable to give the read up on
 * @history: (out) (element-type GPasteItem): the history we just read
 * @size: (out): the size used by the history
 *
 * Reads the history from our storage backend
 *
 * Returns: %FALSE when the history exists on disk but could not be read back
 *          (a failed decryption, parse or I/O error, or @cancellable giving up
 *          on it), %TRUE otherwise (including a genuinely empty or absent
 *          history)
 */
G_PASTE_VISIBLE gboolean
g_paste_storage_backend_read_history (GPasteStorageBackend *self,
                                      const gchar          *name,
                                      GCancellable         *cancellable,
                                      GList               **history,
                                      gsize                *size)
{
    g_return_val_if_fail (G_PASTE_IS_STORAGE_BACKEND (self), FALSE);
    g_return_val_if_fail (name, FALSE);
    g_return_val_if_fail (history && !*history, FALSE);
    g_return_val_if_fail (size, FALSE);

    /* @history is required to come in empty (asserted above), but @size is not:
     * settle it here, a backend's failure path being free to leave it alone.
     * Not to say a failure hands back nothing: the file flavours' parse answers
     * what it read before the error, with its size, which the caller drops with
     * the failure (/history/file_parser_malformed). */
    *size = 0;

    return G_PASTE_STORAGE_BACKEND_GET_CLASS (self)->read_history_file (self, name, cancellable, history, size);
}

/**
 * g_paste_storage_backend_write_history:
 * @self: a #GPasteStorageBackend instance
 * @name: the name of the history to save
 * @history: (element-type GPasteItem): the history to write
 *
 * Save the history by writing it to our storage backend. A write that fails
 * leaves the store of @name as it was, and leaves none where there was none --
 * bar a file flavour's write over a history already there that could not
 * write one of its images: the rest goes in without it, the saver's next
 * write trying it again, where a history one image kept failing would
 * otherwise never be written again.
 *
 * Returns: whether the store of @name holds @history now
 */
G_PASTE_VISIBLE gboolean
g_paste_storage_backend_write_history (GPasteStorageBackend *self,
                                       const gchar          *name,
                                       const GList          *history)
{
    g_return_val_if_fail (G_PASTE_IS_STORAGE_BACKEND (self), FALSE);
    g_return_val_if_fail (name, FALSE);

    const GPasteStorageBackendClass *klass = G_PASTE_STORAGE_BACKEND_GET_CLASS (self);
    gboolean written = klass->write_history_file (self, name, history);

    if (!klass->has_diverged)
    {
        if (written)
            g_paste_storage_backend_converge (self, name);
        else
            g_paste_storage_backend_diverge (self, name);
    }

    return written;
}

/* Whether a file flavour still keeps a history under @name. The images/<name>/
 * directory belongs to the *name*, not to one backend: after a migration the
 * source's delete_history runs while the destination still references (or just
 * materialized) images in that very directory, so it must only go away once no
 * flavour reading it stores the name anymore. The database flavours keep their
 * images in the store and read no file there, so they do not count. */
static gboolean
_g_paste_storage_backend_history_still_stored (const gchar *name)
{
    static const GPasteStorage file_flavours[] = { G_PASTE_STORAGE_FILE, G_PASTE_STORAGE_ENCRYPTED_FILE };

    for (gsize i = 0; i < G_N_ELEMENTS (file_flavours); ++i)
    {
        if (g_paste_util_history_is_stored (name, file_flavours[i]))
            return TRUE;
    }

    return FALSE;
}

/**
 * g_paste_storage_backend_delete_history_images:
 * @name: the name of the history whose images to sweep
 * @error: return location for a #GError, or %NULL
 *
 * A history's images live in their own directory (so histories never share,
 * nor cross-delete, image files): deleting or emptying the history takes them
 * with it, whichever backend stored the history itself -- once no file flavour
 * stores a history of that name any more, since such a store reads them and
 * sweeps its own when it is written.
 *
 * Keyed by name alone, no backend instance being needed to find them, so a
 * caller holding only the name of a history that is not the current one can
 * sweep it too.
 *
 * Fails with a %G_IO_ERROR when the images cannot be listed or one of them,
 * or their directory, cannot be deleted.
 *
 * Returns: %FALSE, with @error set to the first thing that went wrong, when
 *          anything the sweep should have removed is still on disk. The rest is
 *          swept anyway: these are the clipboard's screenshots, so every one
 *          that can go, goes.
 */
G_PASTE_VISIBLE gboolean
g_paste_storage_backend_delete_history_images (const gchar *name,
                                               GError     **error)
{
    /* A file flavour still storing the name reads them: a migration's
     * destination, whose cleanup deletes the source history under the same
     * name, or the old data a migration was told to keep. */
    if (_g_paste_storage_backend_history_still_stored (name))
        return TRUE;

    g_autofree gchar *images_dir_path = g_paste_file_backend_images_dir (name);
    g_autoptr (GFile) images_dir = g_file_new_for_path (images_dir_path);
    g_autoptr (GError) failure = NULL;
    /* A history that never held an image has no directory to sweep, and comes
     * back as an empty list. A listing that failed is not that: sweeping what it
     * did return would leave the rest behind, so there is nothing to do here but
     * say so. */
    g_auto (GStrv) images = g_paste_util_list_directory (images_dir, G_FILE_ATTRIBUTE_STANDARD_NAME, &failure);

    if (!images)
    {
        g_propagate_prefixed_error (error, g_steal_pointer (&failure),
                                    "Could not list the images of \"%s\": ", name);

        return FALSE;
    }

    for (GStrv image = images; *image; ++image)
    {
        g_autoptr (GFile) child = g_file_get_child (images_dir, *image);
        g_autoptr (GError) delete_error = NULL;

        if (!g_file_delete (child, NULL, &delete_error) && !failure)
            failure = g_steal_pointer (&delete_error);
    }

    g_autoptr (GError) rmdir_error = NULL;

    /* Whatever the loop left behind makes this fail too, with a less specific
     * message: the first failure is the one that says why. */
    if (!g_file_delete (images_dir, NULL, &rmdir_error) &&
        !g_error_matches (rmdir_error, G_IO_ERROR, G_IO_ERROR_NOT_FOUND) &&
        !failure)
        failure = g_steal_pointer (&rmdir_error);

    if (!failure)
        return TRUE;

    g_propagate_error (error, g_steal_pointer (&failure));

    return FALSE;
}

/* What g_paste_storage_delete_history () does per flavour, through
 * storage_flavours[] below. A history of the no-storage flavour has nothing on
 * the disk to delete. */
static void
delete_nothing (GPasteStorage storage_kind G_GNUC_UNUSED,
                const gchar  *name         G_GNUC_UNUSED,
                GError      **error        G_GNUC_UNUSED)
{
}

static void
delete_file_history (GPasteStorage storage_kind,
                     const gchar  *name,
                     GError      **error)
{
    g_paste_file_backend_delete_files (name, storage_kind == G_PASTE_STORAGE_ENCRYPTED_FILE, error);
}

#ifdef G_PASTE_ENABLE_SQLITE
static void
delete_database_history (GPasteStorage storage_kind,
                         const gchar  *name,
                         GError      **error)
{
    g_autofree gchar *path = g_paste_util_get_history_file_path (name, g_paste_storage_get_extension (storage_kind));

    g_paste_sqlite_backend_delete_database (path, error);
}
#endif

#ifdef G_PASTE_ENABLE_ENCRYPTION
#define WITH_ENCRYPTION(constructor) constructor
#else
#define WITH_ENCRYPTION(constructor) NULL
#endif

#ifdef G_PASTE_ENABLE_SQLITE
#define WITH_SQLITE(constructor) constructor
#else
#define WITH_SQLITE(constructor) NULL
#endif

/* Every storage flavour, indexed by its kind: what it is called on disk, what
 * the longest file it keeps for a history adds after the history's name, and
 * how this build constructs it -- a plain one through its class, an encrypted
 * one through a constructor keying it -- a flavour whose feature is not built
 * naming neither; how a history of it is deleted with no backend open on it,
 * and, for an encrypted one, which of its files hold what a wrong passphrase
 * is refused over (g_paste_storage_passphrase_verifiable ()), NULL again for
 * what this build cannot do. Adding a flavour is one row plus its enum value,
 * every lookup of a kind going through here, g_paste_storage_is_supported ()
 * included; a reader wanting several flavours names the ones it wants, in its
 * own order (detect_current_backend (),
 * _g_paste_storage_backend_history_still_stored ()).
 *
 * @get_type for an encrypted flavour is the no-storage backend on purpose:
 * anything reaching it has already failed to key one. Keeping the history in
 * memory is the only safe answer -- never plaintext on disk. */
static const struct
{
    const gchar          *extension;
    const gchar          *longest_suffix;
    GType                 (*get_type)       (void);
    GPasteStorageBackend *(*new_encrypted)  (GPasteSettings *settings,
                                             const gchar    *passphrase);
    void                  (*delete_history) (GPasteStorage storage_kind,
                                             const gchar  *name,
                                             GError      **error);
    gboolean              (*holds_data)     (const gchar *path);
} storage_flavours[G_PASTE_N_STORAGE] = {
    [G_PASTE_STORAGE_NOOP]             = { "noop", "",                                      g_paste_noop_backend_get_type,   NULL,                                                                 delete_nothing,                        NULL },
    /* The temporary a save is written to before its move into place. */
    [G_PASTE_STORAGE_FILE]             = { "xml",  ".xml" G_PASTE_FILE_BACKEND_TEMP_SUFFIX, g_paste_file_backend_get_type,   NULL,                                                                 delete_file_history,                   NULL },
    /* The original a change of passphrase keeps aside. */
    [G_PASTE_STORAGE_ENCRYPTED_FILE]   = { "xmls", ".xmls" G_PASTE_FILE_BACKEND_REKEY_OLD,  g_paste_noop_backend_get_type,   WITH_ENCRYPTION (g_paste_file_backend_new_encrypted),                 delete_file_history,                   WITH_ENCRYPTION (g_paste_secret_stream_file_has_frame) },
    /* The rollback journal SQLite opens beside a new database to turn it to
     * write-ahead logging, longer than the log and its index. */
#ifdef G_PASTE_ENABLE_SQLITE
    [G_PASTE_STORAGE_SQLITE]           = { "db",   ".db-journal",                           g_paste_sqlite_backend_get_type, NULL,                                                                 delete_database_history,               NULL },
#else
    /* Not built in: the kind degrades to the file flavour
     * (_g_paste_storage_backend_get_type ()), which then keeps the history as
     * its own. */
    [G_PASTE_STORAGE_SQLITE]           = { "db",   ".xml" G_PASTE_FILE_BACKEND_TEMP_SUFFIX, NULL,                            NULL,                                                                 NULL,                                  NULL },
#endif
    [G_PASTE_STORAGE_ENCRYPTED_SQLITE] = { "dbs",  ".dbs-journal",                          g_paste_noop_backend_get_type,   WITH_SQLITE (WITH_ENCRYPTION (g_paste_sqlite_backend_new_encrypted)), WITH_SQLITE (delete_database_history), WITH_SQLITE (WITH_ENCRYPTION (g_paste_sqlite_backend_database_has_items)) },
};

/* What follows a delete of the history called @name, whatever deleted it: its
 * images directory, once no file flavour stores the name, the database ones
 * keeping their images in the store. @error keeps the store's own failure over
 * this one. */
static void
_g_paste_storage_delete_history_images (const gchar *name,
                                        GError     **error)
{
    g_autoptr (GError) images_error = NULL;

    if (g_paste_storage_backend_delete_history_images (name, &images_error))
        return;

    /* Never over the store's own failure: the first thing that went wrong is
     * what says why, and a caller that asked for no error still has to hear
     * about images left on disk. A store that was not there is no failure:
     * a caller takes it for a history deleted all the same
     * (g_paste_history_delete_full ()), which with its images left it is not. */
    if (error && g_error_matches (*error, G_IO_ERROR, G_IO_ERROR_NOT_FOUND))
        g_clear_error (error);
    if (error && !*error)
        g_propagate_error (error, g_steal_pointer (&images_error));
    else
        g_warning ("Could not delete the images of \"%s\": %s", name, images_error->message);
}

G_PASTE_VISIBLE void
g_paste_storage_delete_history (GPasteStorage storage_kind,
                                const gchar  *name,
                                GError      **error)
{
    /* Refused rather than skipped: a caller taking back what an import left
     * would otherwise read the copies as gone. */
    if (storage_kind >= G_PASTE_N_STORAGE || !storage_flavours[storage_kind].delete_history)
    {
        g_set_error (error, G_PASTE_ERROR, G_PASTE_ERROR_FAILED, "This build cannot delete a history stored as “%s”", g_paste_storage_get_extension (storage_kind));
        return;
    }

    storage_flavours[storage_kind].delete_history (storage_kind, name, error);
    _g_paste_storage_delete_history_images (name, error);
}

gboolean
g_paste_storage_backend_reaches_history (GPasteStorageBackend *self,
                                         const gchar          *name)
{
    gboolean noop = (g_paste_storage_backend_get_kind (self) == G_PASTE_STORAGE_NOOP);

    for (GPasteStorage kind = G_PASTE_STORAGE_NOOP + 1; kind < G_PASTE_N_STORAGE; ++kind)
    {
        if ((noop || !g_paste_storage_is_supported (kind)) && g_paste_util_history_is_stored (name, kind))
            return FALSE;
    }

    return TRUE;
}

/**
 * g_paste_storage_backend_delete_history:
 * @self: a #GPasteStorageBackend instance
 * @name: the name of the history to delete
 * @error: return location for a #GError, or %NULL
 *
 * Delete a history from our storage backend
 *
 * Backends propagate what unlinking their store returned, and the image sweep
 * that follows propagates its own, so errors land in %G_IO_ERROR or
 * %G_FILE_ERROR. The sweep is reported because those files are the clipboard's
 * screenshots in the plain flavours: "the history is gone" must not be answered
 * while they are still there. A history kept by a storage @self cannot reach --
 * a flavour this build cannot open, or any while @self stores nothing -- is
 * refused with %G_PASTE_ERROR_FAILED, nothing deleted.
 */
G_PASTE_VISIBLE void
g_paste_storage_backend_delete_history (GPasteStorageBackend *self,
                                        const gchar          *name,
                                        GError              **error)
{
    g_return_if_fail (G_PASTE_IS_STORAGE_BACKEND (self));
    g_return_if_fail (name);

    if (!g_paste_storage_backend_reaches_history (self, name))
    {
        g_set_error (error, G_PASTE_ERROR, G_PASTE_ERROR_FAILED,
                     "“%s” is kept by a storage this one cannot reach", name);
        return;
    }

    if (G_PASTE_STORAGE_BACKEND_GET_CLASS (self)->delete_history)
        G_PASTE_STORAGE_BACKEND_GET_CLASS (self)->delete_history (self, name, error);

    _g_paste_storage_delete_history_images (name, error);
}

/* The default list_histories: enumerate the history dir for files of a
 * flavour, the ones named with its @extension, so e.g. plain ".xml" and
 * encrypted ".xmls" histories never get mixed up. */
static GStrv
_g_paste_storage_list_histories (const gchar *extension,
                                 GError     **error)
{
    g_autoptr (GFile) history_dir = g_paste_util_get_history_dir ();
    g_autofree gchar *suffix = g_strconcat (".", extension, NULL);
    gsize suffix_len = strlen (suffix);
    /* A fresh profile has no history dir and lists nothing, which is an empty
     * list rather than a failure. A truncated listing is a failure and comes
     * back as NULL: "no histories" is exactly the answer that makes every
     * passphrase verify and a migration import nothing, then let its cleanup
     * delete the originals it never read.
     *
     * The name on disk, not the display one: what comes out of here is handed
     * straight back to g_paste_util_get_history_file_path() by read/delete/rekey,
     * and the display name is a UTF-8 rendering of the bytes — a file whose name
     * is not valid UTF-8 would come back under a name that names no file, and
     * every one of those callers would then act on nothing while reporting that
     * it acted. */
    g_auto (GStrv) files = g_paste_util_list_directory (history_dir, G_FILE_ATTRIBUTE_STANDARD_NAME, error);

    if (!files)
        return NULL;

    g_autoptr (GStrvBuilder) history_names = g_strv_builder_new ();
    g_autofree gchar *history_dir_path = g_file_get_path (history_dir);

    for (GStrv file = files; *file; ++file)
    {
        if (!g_str_has_suffix (*file, suffix))
            continue;

        g_autofree gchar *path = g_build_filename (history_dir_path, *file, NULL);

        if (g_paste_storage_is_special_file (path))
            continue;

        g_autofree gchar *name = g_strdup (*file);

        name[strlen (name) - suffix_len] = '\0';
        /* A stray file -- ".xml", or one an older GPaste wrote for an empty name
         * -- names nothing a history could be read, counted or deleted under.
         * So do the "." and ".." and the names past this storage's length GPaste
         * 50 took as well, whose histories stay on the disk, unlisted, after an
         * upgrade: accepted, the name naming images/<name>/ here too, where no
         * such name has a place, and a rename path being more than so rare a
         * history is worth. */
        if (g_paste_util_history_name_is_valid (name))
            g_strv_builder_take (history_names, g_steal_pointer (&name));
    }

    return g_strv_builder_end (history_names);
}

gboolean
g_paste_storage_is_special_file (const gchar *path)
{
    GStatBuf st;

    return !g_stat (path, &st) && !S_ISREG (st.st_mode);
}

/**
 * g_paste_storage_backend_list_histories:
 * @self: a #GPasteStorageBackend instance
 * @error: return location for a #GError, or %NULL
 *
 * Get the list of available histories from our storage backend
 *
 * Errors come from enumerating the store, in %G_IO_ERROR or %G_FILE_ERROR. A
 * partial listing is never returned as a success: if any flavor fails, so does
 * the call.
 *
 * Returns: (transfer full): The list of history names
 */
G_PASTE_VISIBLE GStrv
g_paste_storage_backend_list_histories (GPasteStorageBackend *self,
                                        GError              **error)
{
    g_return_val_if_fail (G_PASTE_IS_STORAGE_BACKEND (self), NULL);
    g_return_val_if_fail (!error || !(*error), NULL);

    if (G_PASTE_STORAGE_BACKEND_GET_CLASS (self)->list_histories)
        return G_PASTE_STORAGE_BACKEND_GET_CLASS (self)->list_histories (self, error);

    return _g_paste_storage_list_histories (g_paste_storage_backend_get_extension (self), error);
}

/**
 * g_paste_storage_backend_count_history:
 * @self: a #GPasteStorageBackend instance
 * @name: the name of the history to count
 *
 * How many items the history called @name holds, without loading it where the
 * backend can tell without.
 *
 * Reading a history back to count it is what listing every history's size
 * costs, once per history, in the daemon's main loop; a backend that can ask
 * its store overrides this. The fallback reads and counts, so the answer is
 * the same either way.
 *
 * Returns: the number of items @name holds, and 0 for a history that is empty,
 *          absent or unreadable
 */
G_PASTE_VISIBLE gsize
g_paste_storage_backend_count_history (GPasteStorageBackend *self,
                                       const gchar          *name)
{
    g_return_val_if_fail (G_PASTE_IS_STORAGE_BACKEND (self), 0);
    g_return_val_if_fail (name, 0);

    if (G_PASTE_STORAGE_BACKEND_GET_CLASS (self)->count_history)
        return G_PASTE_STORAGE_BACKEND_GET_CLASS (self)->count_history (self, name);

    g_autolist (GPasteItem) history = NULL;
    gsize size;

    g_paste_storage_backend_read_history (self, name, NULL /* cancellable */, &history, &size);

    return g_list_length (history);
}

/**
 * g_paste_storage_backend_rekey:
 * @self: a #GPasteStorageBackend instance, holding the passphrase @name is
 *        currently encrypted with
 * @name: the name of the history to re-encrypt
 * @new_passphrase: the passphrase to encrypt @name with from now on
 * @split: (out) (optional): set to whether a failure left part of @name under
 *         @new_passphrase
 *
 * Re-encrypt an existing history under @new_passphrase, in place: the data stays
 * where it is, only the key changes. Meant for a passphrase change, which —
 * unlike a migration — has no second backend to copy into.
 *
 * Only the encrypted flavors can do this, and each does it its own way (a
 * database re-encrypts its columns in one transaction, a file rewrites itself
 * and its image side files), so this dispatches to the backend rather than
 * trying to be generic. A backend that cannot re-key says so instead of
 * reporting a success that never happened.
 *
 * A failure puts back what the re-key had already changed, so @name is left as
 * it was: a caller re-keying several histories can stop rather than split them
 * across two passphrases -- unless the filesystem refuses that too, in which
 * case @split is set and the originals that could not be put back are left
 * beside their files, the journal naming them.
 *
 * Returns: whether @name is now encrypted under @new_passphrase
 */
G_PASTE_VISIBLE gboolean
g_paste_storage_backend_rekey (GPasteStorageBackend *self,
                               const gchar          *name,
                               const gchar          *new_passphrase,
                               gboolean             *split)
{
    gboolean left_split = FALSE;

    if (split)
        *split = FALSE;

    g_return_val_if_fail (G_PASTE_IS_STORAGE_BACKEND (self), FALSE);
    g_return_val_if_fail (name, FALSE);
    g_return_val_if_fail (new_passphrase && *new_passphrase, FALSE);

    if (!G_PASTE_STORAGE_BACKEND_GET_CLASS (self)->rekey)
    {
        g_warning ("This storage backend has no passphrase to change");
        return FALSE;
    }

    gboolean rekeyed = G_PASTE_STORAGE_BACKEND_GET_CLASS (self)->rekey (self, name, new_passphrase, &left_split);

    if (split)
        *split = left_split;

    return rekeyed;
}

/**
 * g_paste_storage_backend_add_item:
 * @self: a #GPasteStorageBackend instance
 * @name: the name of the history to update
 * @item: the #GPasteItem just added at the front of the history
 * @history: (element-type GPasteItem): the full history (used as a fallback snapshot)
 *
 * Persist a newly added item, possibly without rewriting the whole history
 */
G_PASTE_VISIBLE void
g_paste_storage_backend_add_item (GPasteStorageBackend *self,
                                  const gchar          *name,
                                  GPasteItem           *item,
                                  const GList          *history)
{
    g_return_if_fail (G_PASTE_IS_STORAGE_BACKEND (self));
    g_return_if_fail (name);

    G_PASTE_STORAGE_BACKEND_UPDATE (add_item, item, history);
}

/**
 * g_paste_storage_backend_remove_item:
 * @self: a #GPasteStorageBackend instance
 * @name: the name of the history to update
 * @uuid: the uuid of the removed item
 * @history: (element-type GPasteItem): the full history (used as a fallback snapshot)
 *
 * Persist the removal of an item, possibly without rewriting the whole history
 */
G_PASTE_VISIBLE void
g_paste_storage_backend_remove_item (GPasteStorageBackend *self,
                                     const gchar          *name,
                                     const gchar          *uuid,
                                     const GList          *history)
{
    g_return_if_fail (G_PASTE_IS_STORAGE_BACKEND (self));
    g_return_if_fail (name);

    G_PASTE_STORAGE_BACKEND_UPDATE (remove_item, uuid);
}

/**
 * g_paste_storage_backend_replace_item:
 * @self: a #GPasteStorageBackend instance
 * @name: the name of the history to update
 * @old_uuid: the uuid of the item being replaced
 * @item: the #GPasteItem taking its place
 * @history: (element-type GPasteItem): the full history (used as a fallback snapshot)
 *
 * Persist an item replacement, possibly without rewriting the whole history
 */
G_PASTE_VISIBLE void
g_paste_storage_backend_replace_item (GPasteStorageBackend *self,
                                      const gchar          *name,
                                      const gchar          *old_uuid,
                                      GPasteItem           *item,
                                      const GList          *history)
{
    g_return_if_fail (G_PASTE_IS_STORAGE_BACKEND (self));
    g_return_if_fail (name);
    g_return_if_fail (old_uuid);

    G_PASTE_STORAGE_BACKEND_UPDATE (replace_item, old_uuid, item);
}

/**
 * g_paste_storage_backend_clear_history:
 * @self: a #GPasteStorageBackend instance
 * @name: the name of the history to clear
 * @history: (element-type GPasteItem): the (now empty) full history
 *
 * Persist the emptying of a history, possibly without rewriting the whole file
 */
G_PASTE_VISIBLE void
g_paste_storage_backend_clear_history (GPasteStorageBackend *self,
                                       const gchar          *name,
                                       const GList          *history)
{
    g_return_if_fail (G_PASTE_IS_STORAGE_BACKEND (self));
    g_return_if_fail (name);

    G_PASTE_STORAGE_BACKEND_UPDATE (clear_history);
}

/**
 * g_paste_storage_backend_is_incremental:
 * @self: a #GPasteStorageBackend instance
 *
 * Whether the backend implements all of the incremental update methods, so it
 * never needs a full snapshot outside of an add (whose snapshot it reconciles
 * against) and never takes the full-rewrite fallback. A backend implementing
 * only some of them counts as non-incremental: the add/remove/replace/clear
 * wrappers then fall back to rewriting the whole history, and callers may
 * coalesce successive updates into a single write.
 *
 * Returns: %TRUE if every incremental update method is implemented
 */
G_PASTE_VISIBLE gboolean
g_paste_storage_backend_is_incremental (GPasteStorageBackend *self)
{
    g_return_val_if_fail (G_PASTE_IS_STORAGE_BACKEND (self), FALSE);

    const GPasteStorageBackendClass *klass = G_PASTE_STORAGE_BACKEND_GET_CLASS (self);

    return klass->add_item && klass->remove_item && klass->replace_item && klass->clear_history;
}

/**
 * g_paste_storage_backend_has_diverged:
 * @self: a #GPasteStorageBackend instance
 * @name: the name of a history
 *
 * Whether a write of @name failed since the last full write or emptying of it
 * that landed, the store holding what the history no longer does, or missing
 * what it does, until one lands. Never waits on a read or a write in flight.
 *
 * Returns: whether the next write of @name has to be a full one
 */
G_PASTE_VISIBLE gboolean
g_paste_storage_backend_has_diverged (GPasteStorageBackend *self,
                                      const gchar          *name)
{
    g_return_val_if_fail (G_PASTE_IS_STORAGE_BACKEND (self), FALSE);
    g_return_val_if_fail (name, FALSE);

    const GPasteStorageBackendClass *klass = G_PASTE_STORAGE_BACKEND_GET_CLASS (self);

    if (klass->has_diverged)
        return klass->has_diverged (self, name);

    GPasteStorageBackendPrivate *priv = g_paste_storage_backend_get_instance_private (self);
    g_autoptr (GMutexLocker) locker = g_mutex_locker_new (&priv->records_lock);

    return g_hash_table_contains (priv->diverged, name);
}

void
g_paste_storage_backend_diverge (GPasteStorageBackend *self,
                                 const gchar          *name)
{
    GPasteStorageBackendPrivate *priv = g_paste_storage_backend_get_instance_private (self);
    g_autoptr (GMutexLocker) locker = g_mutex_locker_new (&priv->records_lock);

    g_hash_table_add (priv->diverged, g_strdup (name));
}

void
g_paste_storage_backend_converge (GPasteStorageBackend *self,
                                  const gchar          *name)
{
    GPasteStorageBackendPrivate *priv = g_paste_storage_backend_get_instance_private (self);
    g_autoptr (GMutexLocker) locker = g_mutex_locker_new (&priv->records_lock);

    g_hash_table_remove (priv->diverged, name);
}

void
g_paste_storage_backend_leave_out (GPasteStorageBackend *self,
                                   GPasteItem           *item)
{
    GPasteStorageBackendPrivate *priv = g_paste_storage_backend_get_instance_private (self);
    g_autoptr (GMutexLocker) locker = g_mutex_locker_new (&priv->records_lock);

    g_hash_table_add (priv->left_out, g_strdup (g_paste_item_get_uuid (item)));
}

/* What g_paste_storage_backend_left_out () answers, @records_lock held. */
static gboolean
g_paste_storage_backend_left_out_locked (GPasteStorageBackend        *self,
                                         GPasteStorageBackendPrivate *priv,
                                         GPasteItem                  *item)
{
    return !g_paste_storage_backend_stores_item (self, item) ||
           g_hash_table_contains (priv->left_out, g_paste_item_get_uuid (item));
}

G_PASTE_VISIBLE gboolean
g_paste_storage_backend_left_out (GPasteStorageBackend *self,
                                  GPasteItem           *item)
{
    g_return_val_if_fail (G_PASTE_IS_STORAGE_BACKEND (self), FALSE);
    g_return_val_if_fail (G_PASTE_IS_ITEM (item), FALSE);

    GPasteStorageBackendPrivate *priv = g_paste_storage_backend_get_instance_private (self);
    g_autoptr (GMutexLocker) locker = g_mutex_locker_new (&priv->records_lock);

    return g_paste_storage_backend_left_out_locked (self, priv, item);
}

gint64
g_paste_storage_backend_count_kept (GPasteStorageBackend *self,
                                    const GList          *history)
{
    GPasteStorageBackendPrivate *priv = g_paste_storage_backend_get_instance_private (self);
    g_autoptr (GMutexLocker) locker = g_mutex_locker_new (&priv->records_lock);
    gint64 kept = 0;

    for (const GList *h = history; h; h = g_list_next (h))
    {
        if (!g_paste_storage_backend_left_out_locked (self, priv, h->data))
            ++kept;
    }

    return kept;
}

static void
g_paste_storage_backend_dispose (GObject *object)
{
    GPasteStorageBackendPrivate *priv = g_paste_storage_backend_get_instance_private (G_PASTE_STORAGE_BACKEND (object));

    g_clear_object (&priv->settings);

    G_OBJECT_CLASS (g_paste_storage_backend_parent_class)->dispose (object);
}

/* The records go with the mutex guarding them, which only finalize () may
 * clear: a write still out on a backend disposed early, with
 * g_object_run_dispose (), records into them as it lands. */
static void
g_paste_storage_backend_finalize (GObject *object)
{
    GPasteStorageBackendPrivate *priv = g_paste_storage_backend_get_instance_private (G_PASTE_STORAGE_BACKEND (object));

    g_hash_table_unref (priv->diverged);
    g_hash_table_unref (priv->left_out);
    g_mutex_clear (&priv->records_lock);

    G_OBJECT_CLASS (g_paste_storage_backend_parent_class)->finalize (object);
}

G_PASTE_VISIBLE void
g_paste_storage_backend_read_whole (GPasteStorageBackend *self)
{
    GPasteStorageBackendPrivate *priv = g_paste_storage_backend_get_instance_private (self);

    priv->read_whole = TRUE;
}

void
g_paste_storage_backend_set_unverifiable (GPasteStorageBackend *self)
{
    GPasteStorageBackendPrivate *priv = g_paste_storage_backend_get_instance_private (self);

    priv->unverifiable = TRUE;
}

gboolean
g_paste_storage_backend_is_unverifiable (GPasteStorageBackend *self)
{
    GPasteStorageBackendPrivate *priv = g_paste_storage_backend_get_instance_private (self);

    return priv->unverifiable;
}

guint64
g_paste_storage_backend_get_read_cap (GPasteStorageBackend *self)
{
    GPasteStorageBackendPrivate *priv = g_paste_storage_backend_get_instance_private (self);

    return (priv->read_whole) ? G_MAXINT64 : g_paste_settings_get_max_history_size (priv->settings);
}

gboolean
g_paste_storage_backend_reads_images (GPasteStorageBackend *self)
{
    GPasteStorageBackendPrivate *priv = g_paste_storage_backend_get_instance_private (self);

    return priv->read_whole || g_paste_settings_get_images_support (priv->settings);
}

/**
 * g_paste_storage_backend_get_settings:
 * @self: a #GPasteStorageBackend instance
 *
 * Get the #GPasteSettings @self was built with. Every backend shares the one
 * instance the caller created, so this is a plain accessor rather than a vfunc.
 *
 * Returns: (transfer none): the #GPasteSettings
 */
G_PASTE_VISIBLE GPasteSettings *
g_paste_storage_backend_get_settings (GPasteStorageBackend *self)
{
    g_return_val_if_fail (G_PASTE_IS_STORAGE_BACKEND (self), NULL);

    const GPasteStorageBackendPrivate *priv = g_paste_storage_backend_get_instance_private (self);

    return priv->settings;
}

static void
g_paste_storage_backend_class_init (GPasteStorageBackendClass *klass)
{
    /* Every vfunc starts NULL, GType zeroing the class: the header says which
     * a subclass has to fill and what one left NULL means. */
    G_OBJECT_CLASS (klass)->dispose = g_paste_storage_backend_dispose;
    G_OBJECT_CLASS (klass)->finalize = g_paste_storage_backend_finalize;
}

static void
g_paste_storage_backend_init (GPasteStorageBackend *self)
{
    GPasteStorageBackendPrivate *priv = g_paste_storage_backend_get_instance_private (self);

    priv->diverged = g_hash_table_new_full (g_str_hash, g_str_equal, g_free, NULL);
    priv->left_out = g_hash_table_new_full (g_str_hash, g_str_equal, g_free, NULL);
    g_mutex_init (&priv->records_lock);
}

/* A plain kind this build lacks degrades to another plain kind. */
static GType
_g_paste_storage_backend_get_type (GPasteStorage storage_kind)
{
    if (storage_kind >= G_PASTE_N_STORAGE || !storage_flavours[storage_kind].get_type)
        return G_PASTE_TYPE_FILE_BACKEND;

    return storage_flavours[storage_kind].get_type ();
}

/* NULL when this build cannot construct the requested encrypted flavor. */
static GPasteStorageBackend *
_g_paste_storage_backend_new_encrypted (GPasteStorage   storage_kind,
                                        GPasteSettings *settings,
                                        const gchar    *passphrase)
{
    if (storage_kind >= G_PASTE_N_STORAGE || !storage_flavours[storage_kind].new_encrypted)
        return NULL;

    return storage_flavours[storage_kind].new_encrypted (settings, passphrase);
}

/**
 * g_paste_storage_get_extension:
 * @storage_kind: a #GPasteStorage kind
 *
 * The on-disk file extension a given storage kind uses. This is the single
 * source of truth every history path, the migration detection and the shared
 * images cleanup derive from, so a new flavour only needs its extension
 * declared here.
 *
 * Returns: the extension (without the leading dot)
 */
G_PASTE_VISIBLE const gchar *
g_paste_storage_get_extension (GPasteStorage storage_kind)
{
    if (storage_kind >= G_PASTE_N_STORAGE || !storage_flavours[storage_kind].extension)
        return storage_flavours[G_PASTE_STORAGE_NOOP].extension;

    return storage_flavours[storage_kind].extension;
}

/* The longest file name the history directory takes, as pathconf () says --
 * of the nearest folder above it while it is not made yet: 143 bytes on
 * eCryptfs with encrypted names, where most filesystems take 255. 255 when
 * nothing says, which g_paste_util_history_name_is_valid () bounds every name
 * by anyway. */
static gsize
g_paste_storage_name_max (void)
{
    g_autofree gchar *dir = g_paste_util_get_history_dir_path ();

    for (;;)
    {
        errno = 0;

        glong max = pathconf (dir, _PC_NAME_MAX);

        if (max > 0)
            return MIN ((gsize) max, 255);
        if (errno != ENOENT)
            return 255;

        g_autofree gchar *parent = g_path_get_dirname (dir);

        if (g_paste_str_equal (parent, dir))
            return 255;
        g_set_str_take (&dir, g_steal_pointer (&parent));
    }
}

/**
 * g_paste_storage_name_fits:
 * @storage_kind: a #GPasteStorage kind
 * @name: a name g_paste_util_history_name_is_valid() accepts
 *
 * Whether a history created under @name could have every file the
 * @storage_kind flavour keeps for it named after it, in the history directory
 * as its filesystem bounds a file name. Asked before creating one: a history
 * already there is one a save landed for, and stays readable whatever this
 * says.
 *
 * A question about the flavour, not about a backend: answered the same while
 * an encrypted store is locked, and the daemon runs on the "no storage"
 * backend over it, as once it is unlocked.
 *
 * Returns: whether the @storage_kind flavour can keep a new history called @name
 */
G_PASTE_VISIBLE gboolean
g_paste_storage_name_fits (GPasteStorage storage_kind,
                           const gchar  *name)
{
    g_return_val_if_fail (g_paste_util_history_name_is_valid (name), FALSE);

    if (storage_kind >= G_PASTE_N_STORAGE)
        storage_kind = G_PASTE_STORAGE_NOOP;

    return strlen (name) + strlen (storage_flavours[storage_kind].longest_suffix) <= g_paste_storage_name_max ();
}

/**
 * g_paste_storage_is_supported:
 * @storage_kind: a #GPasteStorage kind
 *
 * Whether this build can open @storage_kind at all. A history on disk in a
 * format this build lacks is still recognised as what it is, its extension
 * being known whatever is built (g_paste_storage_get_extension()), but nothing
 * can be read from it or deleted through it here.
 *
 * Returns: whether this build can construct a backend of @storage_kind
 */
G_PASTE_VISIBLE gboolean
g_paste_storage_is_supported (GPasteStorage storage_kind)
{
    if (storage_kind >= G_PASTE_N_STORAGE)
        return FALSE;
    if (g_paste_storage_is_encrypted (storage_kind))
        return storage_flavours[storage_kind].new_encrypted != NULL;

    return storage_flavours[storage_kind].get_type != NULL;
}

#ifdef G_PASTE_ENABLE_ENCRYPTION
/**
 * g_paste_storage_passphrase_can_decrypt:
 * @storage_kind: the encrypted #GPasteStorage kind to verify against
 * @settings: a #GPasteSettings instance
 * @passphrase: the passphrase to check
 *
 * Check whether @passphrase actually unlocks the existing encrypted histories
 * of the @storage_kind flavor, so a wrong (or stale keyring) passphrase is never
 * accepted and given the chance to overwrite the real data. Nothing is written
 * to find out. The active history decides when it holds data, which may leave
 * others on another passphrase -- what a change of passphrase whose rollback
 * failed leaves -- and the others decide otherwise, any of them opening with
 * @passphrase being enough.
 *
 * Returns: %FALSE when the active history holds data @passphrase does not
 *          unlock, or holds none and another history refutes it while none
 *          opens with it; and when the histories could not be listed at all,
 *          or one could not be checked -- its key not derived, as a memory
 *          limit refuses it -- while none opens with @passphrase: an
 *          unverifiable passphrase is refused rather than assumed good
 */
G_PASTE_VISIBLE gboolean
g_paste_storage_passphrase_can_decrypt (GPasteStorage   storage_kind,
                                        GPasteSettings *settings,
                                        const gchar    *passphrase)
{
    g_return_val_if_fail (G_PASTE_IS_SETTINGS (settings), FALSE);
    g_return_val_if_fail (passphrase && *passphrase, FALSE);

    g_autoptr (GPasteStorageBackend) backend = _g_paste_storage_backend_new_encrypted (storage_kind, settings, passphrase);

    /* A flavor this build cannot construct stores nothing to be wrong about. */
    if (!backend)
        return TRUE;

    const GPasteStorageBackendClass *klass = G_PASTE_STORAGE_BACKEND_GET_CLASS (backend);

    if (!klass->history_refutes_passphrase)
        return TRUE;
    /* The vfunc's contract: the one answers with the other. */
    g_return_val_if_fail (klass->history_confirms_passphrase, FALSE);

    g_autoptr (GError) error = NULL;
    g_auto (GStrv) names = g_paste_storage_backend_list_histories (backend, &error);

    /* Cannot read the store, so nothing refutes the passphrase and nothing
     * confirms it either. Refuse: the caller either prompts again or keeps the
     * history closed, where accepting would open it empty over real data. */
    if (!names)
    {
        g_warning ("Could not list the histories to verify the passphrase: %s", error->message);
        return FALSE;
    }

    /* The active history decides when it holds what this flavour encrypted:
     * the one the daemon loads, and the one a wrong passphrase would cost. The
     * others may be keyed differently -- what a change of passphrase whose
     * rollback failed leaves -- and stay closed under this one, read as
     * unreadable and so never written over: refusing a passphrase over them
     * would refuse every passphrase, and nothing could open again. */
    const gchar *active = g_paste_util_resolve_history_name (g_paste_settings_get_history_name (settings));

    if (klass->history_refutes_passphrase (backend, active))
        return FALSE;
    if (klass->history_confirms_passphrase (backend, active))
        return TRUE;
    /* A check that could not be made says no more than the store that could
     * not be listed above: none of the others could be checked either, their
     * keys derived as this one's is. */
    if (g_paste_storage_backend_is_unverifiable (backend))
        return FALSE;

    /* Otherwise the others: with nothing to go by in the active one -- absent,
     * never written -- a passphrase none of them opens and some refute is a
     * typo as likely as not, and the active history written under it would be
     * one more under a passphrase of its own. One some history opens is no
     * typo: those refuting it are a store split across passphrases, each of
     * which some history refutes. It is taken, the histories it does not open
     * reading as unreadable, never written over, and only a passphrase in hand
     * can bring them back to it (gpaste-client doctor). */
    gboolean refuted = FALSE;

    for (GStrv name = names; name && *name; ++name)
    {
        /* Asked above, and answered neither: a document of ours damaged past
         * its header pays a key derivation for each ask. */
        if (g_paste_str_equal (*name, active))
            continue;
        if (klass->history_refutes_passphrase (backend, *name))
            refuted = TRUE;
        else if (klass->history_confirms_passphrase (backend, *name))
            return TRUE;
    }

    return !refuted && !g_paste_storage_backend_is_unverifiable (backend);
}

/**
 * g_paste_storage_passphrase_verifiable:
 * @storage_kind: an encrypted #GPasteStorage flavour
 * @settings: a #GPasteSettings instance
 *
 * Whether any history of @storage_kind holds what a wrong passphrase is refused
 * over: an encrypted stream past its header, or a database holding an item.
 * With none -- nothing stored yet, the placeholder a first read leaves, a
 * database emptied, which an open keys afresh for whatever it is given, a
 * foreign file -- g_paste_storage_passphrase_can_decrypt() accepts every
 * passphrase, and the one given keys everything written from then on.
 *
 * Returns: whether a wrong passphrase would be refused
 */
G_PASTE_VISIBLE gboolean
g_paste_storage_passphrase_verifiable (GPasteStorage   storage_kind,
                                       GPasteSettings *settings)
{
    g_return_val_if_fail (G_PASTE_IS_SETTINGS (settings), FALSE);

    /* Asked of the files, by name: no key could be checked without the
     * passphrase this is about. */
    if (storage_kind >= G_PASTE_N_STORAGE || !storage_flavours[storage_kind].holds_data)
        return FALSE;

    gboolean (*refutable) (const gchar *path) = storage_flavours[storage_kind].holds_data;

    const gchar *extension = g_paste_storage_get_extension (storage_kind);
    g_auto (GStrv) names = _g_paste_storage_list_histories (extension, NULL);

    /* A store that cannot be listed refuses every passphrase (can_decrypt ()). */
    if (!names)
        return TRUE;

    for (GStrv name = names; *name; ++name)
    {
        g_autofree gchar *path = g_paste_util_get_history_file_path (*name, extension);

        if (refutable (path))
            return TRUE;
    }

    return FALSE;
}

/**
 * g_paste_storage_backend_refutes_passphrase:
 * @self: a #GPasteStorageBackend instance, built with the passphrase in question
 * @name: the name of a history
 *
 * Whether the history called @name proves @self's passphrase wrong: see
 * history_refutes_passphrase in #GPasteStorageBackendClass.
 *
 * Returns: whether @name refutes the passphrase
 */
G_PASTE_VISIBLE gboolean
g_paste_storage_backend_refutes_passphrase (GPasteStorageBackend *self,
                                            const gchar          *name)
{
    g_return_val_if_fail (G_PASTE_IS_STORAGE_BACKEND (self), FALSE);
    g_return_val_if_fail (name, FALSE);

    const GPasteStorageBackendClass *klass = G_PASTE_STORAGE_BACKEND_GET_CLASS (self);

    return klass->history_refutes_passphrase && klass->history_refutes_passphrase (self, name);
}
#endif

/* The shared constructor: @passphrase is the key an encrypted @storage_kind is
 * built with, already resolved by the caller (%NULL when there is none). An
 * encrypted kind we cannot key — or cannot build in this configuration — always
 * degrades to "no storage", never to plaintext on disk. */
static GPasteStorageBackend *
_g_paste_storage_backend_new (GPasteStorage   storage_kind,
                              GPasteSettings *settings,
                              const gchar    *passphrase)
{
    if (g_paste_storage_is_encrypted (storage_kind))
    {
        if (passphrase)
        {
            GPasteStorageBackend *backend = _g_paste_storage_backend_new_encrypted (storage_kind, settings, passphrase);

            if (backend)
                return backend;
        }

        /* Without a passphrase (or the flavor's support built in) we must not
         * fall back to plaintext on disk; keep the history in memory only. */
        if (g_paste_storage_is_supported (storage_kind))
            g_warning ("No passphrase for the encrypted storage backend; not storing the history");
        else
            g_warning ("This build cannot open the encrypted storage backend; not storing the history");
        storage_kind = G_PASTE_STORAGE_NOOP;
    }

    GPasteStorageBackend *self = g_object_new (_g_paste_storage_backend_get_type (storage_kind), NULL);
    GPasteStorageBackendPrivate *priv = g_paste_storage_backend_get_instance_private (self);

    priv->settings = g_object_ref (settings);

    return self;
}

/**
 * g_paste_storage_backend_new:
 * @storage_kind: the kind of storage we want to use to save and load history
 * @settings: a #GPasteSettings instance
 *
 * Create a new instance of #GPasteStorageBackend, keyed (when @storage_kind is
 * encrypted) with the process-wide passphrase, falling back to the one
 * remembered in the keyring.
 *
 * Returns: a newly allocated #GPasteStorageBackend
 *          free it with g_object_unref
 */
G_PASTE_VISIBLE GPasteStorageBackend *
g_paste_storage_backend_new (GPasteStorage   storage_kind,
                             GPasteSettings *settings)
{
    g_return_val_if_fail (G_PASTE_IS_SETTINGS (settings), NULL);

    const gchar *passphrase = NULL;

#ifdef G_PASTE_ENABLE_ENCRYPTION
    /* Asked for an encrypted kind alone: the encrypted constructors build
     * their plain kind through here, a storage worker among their callers,
     * and the main thread may be setting the process passphrase meanwhile. */
    if (g_paste_storage_is_encrypted (storage_kind))
        passphrase = g_paste_storage_backend_get_passphrase ();

#ifdef G_PASTE_ENABLE_LIBSECRET
    /* No passphrase set in this process yet (e.g. the in-process daemon in
     * gnome-shell never ran the prompt): fall back to the one remembered in
     * the keyring before giving up. apply_verified only keeps it when it
     * actually decrypts the history, so a stale entry can never be used (which
     * would overwrite the real data with an empty, wrongly-encrypted one). */
    if (!passphrase && g_paste_storage_is_encrypted (storage_kind) &&
        g_paste_storage_is_supported (storage_kind) &&
        g_paste_storage_keyring_apply_verified (storage_kind, settings))
        passphrase = g_paste_storage_backend_get_passphrase ();
#endif
#endif

    return _g_paste_storage_backend_new (storage_kind, settings, passphrase);
}

/**
 * g_paste_storage_backend_new_with_passphrase:
 * @storage_kind: the kind of storage we want to use to save and load history
 * @settings: a #GPasteSettings instance
 * @passphrase: (nullable): the passphrase to key an encrypted @storage_kind with
 *
 * Create a new instance of #GPasteStorageBackend keyed with exactly
 * @passphrase, deliberately without the process-wide / keyring fallback
 * g_paste_storage_backend_new() applies: a migration between two encrypted
 * flavors has to hold the source and the destination open under two different
 * keys at once, and the source must never end up opened with the destination's
 * one (which reads back empty and would pass for an emptied history). Ignored
 * for the plain kinds, which have nothing to key.
 *
 * Returns: a newly allocated #GPasteStorageBackend
 *          free it with g_object_unref
 */
G_PASTE_VISIBLE GPasteStorageBackend *
g_paste_storage_backend_new_with_passphrase (GPasteStorage   storage_kind,
                                             GPasteSettings *settings,
                                             const gchar    *passphrase)
{
    g_return_val_if_fail (G_PASTE_IS_SETTINGS (settings), NULL);

    return _g_paste_storage_backend_new (storage_kind, settings, passphrase);
}
