// SPDX-FileCopyrightText: 2010-2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com>
// SPDX-License-Identifier: BSD-2-Clause

#if !defined (__G_PASTE_GTK4_H_INSIDE__) && !defined (G_PASTE_COMPILATION)
#error "Only <gpaste-gtk4.h> can be included directly."
#endif

#pragma once

#include <gpaste.h>

#include <adwaita.h>
#include <gtk/gtk.h>

G_BEGIN_DECLS

typedef void (*GPasteGtkConfirmDialogCallback) (gboolean confirmed,
                                                gpointer user_data);

void     g_paste_gtk_util_confirm_dialog   (GtkWindow                     *parent,
                                            const gchar                   *heading,
                                            const gchar                   *body,
                                            const gchar                   *action,
                                            AdwResponseAppearance          appearance,
                                            GPasteGtkConfirmDialogCallback on_confirmation,
                                            gpointer                       user_data);

GdkTexture *g_paste_gtk_util_get_image_finish (GPasteClient *client,
                                               GAsyncResult *result,
                                               GError      **error);

void     g_paste_gtk_util_empty_history    (GtkWindow      *parent_window,
                                            GPasteClient   *client,
                                            GPasteSettings *settings,
                                            const gchar    *history);

void     g_paste_gtk_util_show_window      (GApplication *application);

void     g_paste_gtk_util_toast            (GtkWidget   *origin,
                                            const gchar *message);

AdwDialog *g_paste_gtk_util_form_dialog              (const gchar *heading,
                                                      const gchar *confirm_label,
                                                      GtkWidget   *content,
                                                      gint         width,
                                                      gint         height,
                                                      GtkWidget  **confirm);
void       g_paste_gtk_util_form_dialog_set_complete (AdwDialog   *dialog,
                                                      gboolean     complete);
gboolean   g_paste_gtk_util_form_dialog_hold         (AdwDialog   *dialog);
gboolean   g_paste_gtk_util_form_dialog_is_held      (AdwDialog   *dialog);
gboolean   g_paste_gtk_util_form_dialog_done         (AdwDialog   *dialog,
                                                      const gchar *failure);

/* Handed what the user confirmed, never empty, with @dialog held up until
 * g_paste_gtk_util_text_dialog_done () says how it went (see
 * g_paste_gtk_util_text_dialog ()). */
typedef void (*GPasteGtkTextDialogSubmit) (AdwDialog   *dialog,
                                           const gchar *text,
                                           gpointer     user_data);

gboolean g_paste_gtk_util_can_host_dialog  (GtkWindow *window);

void     g_paste_gtk_util_text_dialog      (GtkWindow                *parent,
                                            const gchar              *heading,
                                            const gchar              *confirm_label,
                                            const gchar              *text,
                                            GPasteGtkTextDialogSubmit submit,
                                            gpointer                  user_data,
                                            GDestroyNotify            destroy);
void     g_paste_gtk_util_text_dialog_done (AdwDialog   *dialog,
                                            const gchar *failure);

GtkWidget *g_paste_gtk_util_password_strength_row_new  (const gchar *title,
                                                        const gchar *unavailable);
void       g_paste_gtk_util_password_strength_row_rate (GtkWidget   *row,
                                                        GtkEditable *source);

void g_paste_gtk_util_set_row_title   (AdwPreferencesRow   *row,
                                       const gchar         *title);
void g_paste_gtk_util_set_group_text  (AdwPreferencesGroup *group,
                                       const gchar         *title,
                                       const gchar         *description);
void g_paste_gtk_util_set_status_text (AdwStatusPage       *page,
                                       const gchar         *title,
                                       const gchar         *description);

GtkWidget *g_paste_gtk_util_spin_row_new (gdouble min,
                                          gdouble max,
                                          gdouble step);

G_END_DECLS
