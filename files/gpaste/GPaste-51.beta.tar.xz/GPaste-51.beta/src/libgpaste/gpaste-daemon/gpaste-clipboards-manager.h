// SPDX-FileCopyrightText: 2010-2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com>
// SPDX-License-Identifier: BSD-2-Clause

#pragma once

#include <gpaste-daemon/gpaste-clipboard-provider.h>

G_BEGIN_DECLS

#define G_PASTE_TYPE_CLIPBOARDS_MANAGER (g_paste_clipboards_manager_get_type ())

G_PASTE_FINAL_TYPE (ClipboardsManager, clipboards_manager, CLIPBOARDS_MANAGER, GObject)

void     g_paste_clipboards_manager_add_clipboard   (GPasteClipboardsManager *self,
                                                     GPasteClipboardProvider *clipboard);
void     g_paste_clipboards_manager_sync_from_to    (GPasteClipboardsManager *self,
                                                     gboolean                 from_clipboard);
void     g_paste_clipboards_manager_activate        (GPasteClipboardsManager *self);
gboolean g_paste_clipboards_manager_select          (GPasteClipboardsManager *self,
                                                     GPasteItem              *item);
void     g_paste_clipboards_manager_store           (GPasteClipboardsManager *self);
void     g_paste_clipboards_manager_expire_password (GPasteClipboardsManager *self);
void     g_paste_clipboards_manager_rearm_password  (GPasteClipboardsManager *self,
                                                     GPasteItem              *item);

GPasteClipboardsManager *g_paste_clipboards_manager_new (GPasteHistory  *history,
                                                         GPasteSettings *settings);

G_END_DECLS
