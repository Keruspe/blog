// SPDX-FileCopyrightText: 2010-2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com>
// SPDX-License-Identifier: BSD-2-Clause

#if !defined (__G_PASTE_H_INSIDE__) && !defined (G_PASTE_COMPILATION)
#error "Only <gpaste.h> can be included directly."
#endif

#pragma once

#include <gpaste-3/gpaste-macros.h>
#include <gpaste-3/gpaste-storage.h>

G_BEGIN_DECLS

#define G_PASTE_TYPE_SETTINGS (g_paste_settings_get_type ())

G_PASTE_FINAL_TYPE (Settings, settings, SETTINGS, GObject)

gboolean     g_paste_settings_get_close_on_select            (GPasteSettings *self);
guint64      g_paste_settings_get_element_size               (GPasteSettings *self);
gboolean     g_paste_settings_get_empty_history_confirmation (GPasteSettings *self);
gboolean     g_paste_settings_get_experimental_meta_daemon   (GPasteSettings *self);
gboolean     g_paste_settings_get_growing_lines              (GPasteSettings *self);
const gchar *g_paste_settings_get_history_name               (GPasteSettings *self);
gboolean     g_paste_settings_get_images_preview             (GPasteSettings *self);
guint64      g_paste_settings_get_images_preview_size        (GPasteSettings *self);
gboolean     g_paste_settings_get_images_support             (GPasteSettings *self);
const gchar *g_paste_settings_get_launch_ui                  (GPasteSettings *self);
const gchar *g_paste_settings_get_make_password              (GPasteSettings *self);
guint64      g_paste_settings_get_max_history_size           (GPasteSettings *self);
guint64      g_paste_settings_get_max_memory_usage           (GPasteSettings *self);
guint64      g_paste_settings_get_max_text_item_size         (GPasteSettings *self);
guint64      g_paste_settings_get_min_text_item_size         (GPasteSettings *self);
guint64      g_paste_settings_get_password_timeout           (GPasteSettings *self);
const gchar *g_paste_settings_get_pop                        (GPasteSettings *self);
gboolean     g_paste_settings_get_primary_to_history         (GPasteSettings *self);
gboolean     g_paste_settings_get_rich_text_support          (GPasteSettings *self);
const gchar *g_paste_settings_get_show_history               (GPasteSettings *self);
GPasteStorage g_paste_settings_get_storage_backend           (GPasteSettings *self);
guint64      g_paste_settings_get_storage_backend_revision   (GPasteSettings *self);
const gchar *g_paste_settings_get_sync_clipboard_to_primary  (GPasteSettings *self);
const gchar *g_paste_settings_get_sync_primary_to_clipboard  (GPasteSettings *self);
gboolean     g_paste_settings_get_synchronize_clipboards     (GPasteSettings *self);
gboolean     g_paste_settings_get_track_changes              (GPasteSettings *self);
gboolean     g_paste_settings_get_track_extension_state      (GPasteSettings *self);
gboolean     g_paste_settings_get_trim_items                 (GPasteSettings *self);
const gchar *g_paste_settings_get_upload                     (GPasteSettings *self);

void g_paste_settings_set_close_on_select            (GPasteSettings *self,
                                                      gboolean        value);
void g_paste_settings_set_element_size               (GPasteSettings *self,
                                                      guint64         value);
void g_paste_settings_set_empty_history_confirmation (GPasteSettings *self,
                                                      gboolean        value);
void g_paste_settings_set_experimental_meta_daemon   (GPasteSettings *self,
                                                      gboolean        value);
void g_paste_settings_set_growing_lines              (GPasteSettings *self,
                                                      gboolean        value);
void g_paste_settings_set_history_name               (GPasteSettings *self,
                                                      const gchar    *value);
void g_paste_settings_set_images_preview             (GPasteSettings *self,
                                                      gboolean        value);
void g_paste_settings_set_images_preview_size        (GPasteSettings *self,
                                                      guint64         value);
void g_paste_settings_set_images_support             (GPasteSettings *self,
                                                      gboolean        value);
void g_paste_settings_set_launch_ui                  (GPasteSettings *self,
                                                      const gchar    *value);
void g_paste_settings_set_make_password              (GPasteSettings *self,
                                                      const gchar    *value);
void g_paste_settings_set_max_history_size           (GPasteSettings *self,
                                                      guint64         value);
void g_paste_settings_set_max_memory_usage           (GPasteSettings *self,
                                                      guint64         value);
void g_paste_settings_set_max_text_item_size         (GPasteSettings *self,
                                                      guint64         value);
void g_paste_settings_set_min_text_item_size         (GPasteSettings *self,
                                                      guint64         value);
void g_paste_settings_set_password_timeout           (GPasteSettings *self,
                                                      guint64         value);
void g_paste_settings_set_pop                        (GPasteSettings *self,
                                                      const gchar    *value);
void g_paste_settings_set_primary_to_history         (GPasteSettings *self,
                                                      gboolean        value);
void g_paste_settings_set_rich_text_support          (GPasteSettings *self,
                                                      gboolean        value);
void g_paste_settings_set_show_history               (GPasteSettings *self,
                                                      const gchar    *value);
void g_paste_settings_set_storage_backend            (GPasteSettings *self,
                                                      GPasteStorage   value);
void g_paste_settings_set_storage_backend_revision   (GPasteSettings *self,
                                                      guint64         value);
void g_paste_settings_set_sync_clipboard_to_primary  (GPasteSettings *self,
                                                      const gchar    *value);
void g_paste_settings_set_sync_primary_to_clipboard  (GPasteSettings *self,
                                                      const gchar    *value);
void g_paste_settings_set_synchronize_clipboards     (GPasteSettings *self,
                                                      gboolean        value);
void g_paste_settings_set_track_changes              (GPasteSettings *self,
                                                      gboolean        value);
void g_paste_settings_set_track_extension_state      (GPasteSettings *self,
                                                      gboolean        value);
void g_paste_settings_set_trim_items                 (GPasteSettings *self,
                                                      gboolean        value);
void g_paste_settings_set_upload                     (GPasteSettings *self,
                                                      const gchar    *value);

gboolean g_paste_settings_get_extension_enabled (GPasteSettings *self);
void     g_paste_settings_set_extension_enabled (GPasteSettings *self,
                                                 gboolean        value);

void g_paste_settings_reset (GPasteSettings *self,
                             const gchar    *key);
void g_paste_settings_sync (GPasteSettings *self);
void g_paste_settings_reload (GPasteSettings *self);
gboolean g_paste_settings_is_default (GPasteSettings *self,
                                      const gchar    *key);

GPasteSettings *g_paste_settings_new (void);

G_END_DECLS
