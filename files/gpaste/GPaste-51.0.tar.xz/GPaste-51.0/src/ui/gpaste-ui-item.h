// SPDX-FileCopyrightText: 2010-2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com>
// SPDX-License-Identifier: BSD-2-Clause

#pragma once

#include <gpaste-3/gpaste-client.h>
#include <gpaste-3/gpaste-settings.h>

#include <gtk/gtk.h>

G_BEGIN_DECLS

#define G_PASTE_TYPE_UI_ITEM (g_paste_ui_item_get_type ())

G_PASTE_FINAL_TYPE (UiItem, ui_item, UI_ITEM, GtkBox)

const gchar *g_paste_ui_item_get_uuid (GPasteUiItem *self);

gboolean  g_paste_ui_item_activate (GPasteUiItem *self);

void      g_paste_ui_item_set_index (GPasteUiItem *self,
                                     guint64       index);

void      g_paste_ui_item_set_uuid (GPasteUiItem *self,
                                    const gchar  *uuid);

void      g_paste_ui_item_popup_menu (GPasteUiItem *self);

GtkWidget *g_paste_ui_item_new (GPasteClient   *client,
                                GPasteSettings *settings,
                                GtkWindow      *rootwin,
                                guint64         index);

G_END_DECLS

