// SPDX-FileCopyrightText: 2010-2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com>
// SPDX-License-Identifier: BSD-2-Clause

#pragma once

#include <gpaste-3/gpaste-settings.h>

#include <gpaste-daemon/gpaste-password-item.h>

G_BEGIN_DECLS

#define G_PASTE_TYPE_HISTORY (g_paste_history_get_type ())

G_PASTE_FINAL_TYPE (History, history, HISTORY, GObject)

void                g_paste_history_add             (GPasteHistory *self,
                                                     GPasteItem    *item);
void                g_paste_history_remove          (GPasteHistory *self,
                                                     guint64        index);
gboolean            g_paste_history_remove_by_uuid  (GPasteHistory *self,
                                                     const gchar   *uuid);
GPasteItem         *g_paste_history_get             (GPasteHistory *self,
                                                     guint64        index);
GPasteItem         *g_paste_history_get_by_uuid     (GPasteHistory *self,
                                                     const gchar   *uuid);
GPasteItem         *g_paste_history_dup             (GPasteHistory *self,
                                                     guint64        index);
gboolean            g_paste_history_select          (GPasteHistory *self,
                                                     const gchar   *uuid);
gchar              *g_paste_history_replace         (GPasteHistory *self,
                                                     const gchar   *uuid,
                                                     const gchar   *contents);
gboolean            g_paste_history_strip_rich_text (GPasteHistory *self,
                                                     const gchar   *uuid,
                                                     gboolean      *found);
gboolean            g_paste_history_set_favourite   (GPasteHistory *self,
                                                     const gchar   *uuid,
                                                     gboolean       favourite);
gchar              *g_paste_history_make_password   (GPasteHistory *self,
                                                     const gchar   *uuid,
                                                     const gchar   *name,
                                                     guint          timeout);
GPastePasswordItem *g_paste_history_get_password    (GPasteHistory *self,
                                                     const gchar   *name);
gboolean            g_paste_history_delete_password (GPasteHistory *self,
                                                     const gchar   *name);
void         g_paste_history_empty       (GPasteHistory *self);
void         g_paste_history_flush       (GPasteHistory *self);
void         g_paste_history_resume      (GPasteHistory *self);
void         g_paste_history_reload_backend (GPasteHistory *self);
void     g_paste_history_save       (GPasteHistory *self,
                                     const gchar   *name);
void     g_paste_history_load       (GPasteHistory *self,
                                     const gchar   *name);
gboolean g_paste_history_is_unreadable (GPasteHistory *self);
void     g_paste_history_load_async (GPasteHistory *self,
                                     const gchar   *name);
void     g_paste_history_switch     (GPasteHistory *self,
                                     const gchar   *name);
gboolean g_paste_history_delete     (GPasteHistory *self,
                                     const gchar   *name,
                                     GError       **error);
const GPtrArray *g_paste_history_get_history (GPasteHistory *self);
guint64      g_paste_history_get_length  (GPasteHistory *self);
const gchar *g_paste_history_get_current (GPasteHistory *self);

GStrv g_paste_history_search (GPasteHistory *self,
                              const gchar   *pattern);

GPasteHistory *g_paste_history_new (GPasteSettings *settings);

GStrv    g_paste_history_list     (GPasteHistory *self,
                                   GError       **error);
guint64  g_paste_history_get_size (GPasteHistory *self,
                                   const gchar   *name);

G_END_DECLS
