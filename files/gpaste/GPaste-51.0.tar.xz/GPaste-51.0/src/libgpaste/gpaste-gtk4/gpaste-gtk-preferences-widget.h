// SPDX-FileCopyrightText: 2010-2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com>
// SPDX-License-Identifier: BSD-2-Clause

#if !defined (__G_PASTE_GTK4_H_INSIDE__) && !defined (G_PASTE_COMPILATION)
#error "Only <gpaste-gtk4.h> can be included directly."
#endif

#pragma once

#include <gpaste-gtk4/gpaste-gtk-macros.h>

G_BEGIN_DECLS

#define G_PASTE_TYPE_GTK_PREFERENCES_WIDGET (g_paste_gtk_preferences_widget_get_type ())

G_PASTE_GTK_FINAL_TYPE (PreferencesWidget, preferences_widget, PREFERENCES_WIDGET, AdwBin)

GtkWidget *g_paste_gtk_preferences_widget_new (void);

GPtrArray *g_paste_gtk_preferences_pages_list (void);

G_END_DECLS
