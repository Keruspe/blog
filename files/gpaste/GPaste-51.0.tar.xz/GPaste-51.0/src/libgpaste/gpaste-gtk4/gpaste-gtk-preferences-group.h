// SPDX-FileCopyrightText: 2010-2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com>
// SPDX-License-Identifier: BSD-2-Clause

#pragma once

#include <gpaste-gtk4/gpaste-gtk-macros.h>

G_BEGIN_DECLS

#define G_PASTE_TYPE_GTK_PREFERENCES_GROUP (g_paste_gtk_preferences_group_get_type ())

G_PASTE_GTK_FINAL_TYPE (PreferencesGroup, preferences_group, PREFERENCES_GROUP, AdwPreferencesGroup)

AdwSwitchRow *g_paste_gtk_preferences_group_add_boolean_setting  (GPasteGtkPreferencesGroup *self,
                                                                  const gchar               *label,
                                                                  const gchar               *key,
                                                                  GPasteSettings            *settings);
AdwSpinRow   *g_paste_gtk_preferences_group_add_range_setting    (GPasteGtkPreferencesGroup *self,
                                                                  const gchar               *label,
                                                                  const gchar               *key,
                                                                  gdouble                    min,
                                                                  gdouble                    max,
                                                                  gdouble                    step,
                                                                  GPasteSettings            *settings);
AdwEntryRow  *g_paste_gtk_preferences_group_add_text_setting     (GPasteGtkPreferencesGroup *self,
                                                                  const gchar               *label,
                                                                  const gchar               *key,
                                                                  GPasteSettings            *settings);
GtkWidget    *g_paste_gtk_preferences_group_add_shortcut_setting (GPasteGtkPreferencesGroup *self,
                                                                  const gchar               *label,
                                                                  const gchar               *key,
                                                                  GPasteSettings            *settings);

AdwButtonRow *g_paste_gtk_preferences_group_add_button (GPasteGtkPreferencesGroup *self,
                                                        const gchar               *label,
                                                        GCallback                  activated,
                                                        gpointer                   user_data);

GPasteGtkPreferencesGroup *g_paste_gtk_preferences_group_new (const gchar *title);

G_END_DECLS
