// SPDX-FileCopyrightText: 2010-2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com>
// SPDX-License-Identifier: BSD-2-Clause

#if !defined (__G_PASTE_H_INSIDE__) && !defined (G_PASTE_COMPILATION)
#error "Only <gpaste.h> can be included directly."
#endif

#pragma once

#include <glib-object.h>

G_BEGIN_DECLS

typedef enum {
    G_PASTE_ITEM_KIND_TEXT = 1,
    G_PASTE_ITEM_KIND_URIS,
    G_PASTE_ITEM_KIND_IMAGE,
    G_PASTE_ITEM_KIND_PASSWORD,
    G_PASTE_ITEM_KIND_COLOR,
    G_PASTE_ITEM_KIND_INVALID = 0
} GPasteItemKind;

#define G_PASTE_TYPE_ITEM_KIND (g_paste_item_kind_get_type ())
GType g_paste_item_kind_get_type (void);

const gchar   *g_paste_item_kind_to_string   (GPasteItemKind kind);
GPasteItemKind g_paste_item_kind_from_string (const gchar   *kind);

G_END_DECLS
