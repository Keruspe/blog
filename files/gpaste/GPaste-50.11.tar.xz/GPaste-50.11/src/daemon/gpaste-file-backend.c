// SPDX-FileCopyrightText: 2010-2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com>
// SPDX-License-Identifier: BSD-2-Clause

#include <gpaste/gpaste-util.h>

#include <gpaste-color-item.h>
#include <gpaste-file-backend.h>
#include <gpaste-image-item.h>
#include <gpaste-password-item.h>
#include <gpaste-uris-item.h>

#include <glib/gstdio.h>

#include <errno.h>
#include <fcntl.h>
#include <unistd.h>

G_PASTE_DEFINE_TYPE (FileBackend, file_backend, G_PASTE_TYPE_STORAGE_BACKEND)

/* Have what was written to @file on the disk before it is renamed over the
 * file it replaces: without it, a filesystem lacking ext4's rename heuristic --
 * XFS, ext4 mounted noauto_da_alloc -- may keep the rename and lose the data in
 * a crash right after a save, and the empty file left reads as an empty
 * history, which the next save makes for good. No test tells a synced file
 * from one that was not.
 *
 * Not left to the g_file_replace () the stream comes from: GIO syncs as it
 * closes only a file it replaced, which the temporary one, made afresh, never
 * is. Replacing the history file itself through it would sync, but have GIO's
 * own temporary file stand in for the one get_output_stream writes and
 * g_file_move () then puts in place. */
static gboolean
_g_paste_file_backend_sync (GFile   *file,
                            GError **error)
{
    g_autofree gchar *path = g_file_get_path (file);
    g_autofd gint fd = g_open (path, O_RDONLY | O_CLOEXEC, 0);

    if (fd >= 0 && !fsync (fd))
        return TRUE;

    gint saved_errno = errno;

    g_set_error (error, G_IO_ERROR, g_io_error_from_errno (saved_errno), "Could not sync %s: %s", path, g_strerror (saved_errno));

    return FALSE;
}

static gboolean
_g_paste_file_backend_write_image_metadata (GOutputStream         *stream,
                                            const GPasteImageItem *item,
                                            GError               **error)
{
    g_autofree gchar *date_str = g_date_time_format ((GDateTime *) g_paste_image_item_get_date (item), "%s");
    const gchar *checksum = g_paste_image_item_get_checksum (item);

    if (!g_output_stream_write_all (stream, "\" date=\"", 8, NULL, NULL /* cancellable */, error) ||
        !g_output_stream_write_all (stream, date_str, strlen (date_str), NULL, NULL /* cancellable */, error))
        return FALSE;

    /* The checksum (hex SHA256) needs no XML escaping */
    if (checksum &&
        (!g_output_stream_write_all (stream, "\" checksum=\"", 12, NULL, NULL /* cancellable */, error) ||
         !g_output_stream_write_all (stream, checksum, strlen (checksum), NULL, NULL /* cancellable */, error)))
        return FALSE;

    return TRUE;
}

static gboolean
_g_paste_file_backend_write_special_values (GOutputStream *stream,
                                            const GSList  *special_values,
                                            GError       **error)
{
    for (const GSList *val = special_values; val; val = val->next)
    {
        const GPasteBinaryData *value = val->data;
        GEnumValue *gev = g_enum_get_value (g_type_class_peek (G_PASTE_TYPE_SPECIAL_ATOM), g_paste_binary_data_get_mime (value));

        /* A representation we cannot name is one we could not read back either:
         * skip it rather than dereference NULL, the way the reader does when an
         * unknown mime comes the other way round. */
        if (!gev)
        {
            g_warning ("Unknown mime: %d", g_paste_binary_data_get_mime (value));
            continue;
        }

        const gchar *mime = gev->value_nick;
        g_autofree gchar *b64 = g_paste_binary_data_to_base64 (value);
        g_autofree gchar *text = g_paste_util_xml_encode (b64);

        if (!g_output_stream_write_all (stream, "    <value mime=\"", 17, NULL, NULL /* cancellable */, error) ||
            !g_output_stream_write_all (stream, mime, strlen (mime), NULL, NULL /* cancellable */, error) ||
            !g_output_stream_write_all (stream, "\"><![CDATA[", 11, NULL, NULL /* cancellable */, error) ||
            !g_output_stream_write_all (stream, text, strlen (text), NULL, NULL /* cancellable */, error) ||
            !g_output_stream_write_all (stream, "]]></value>\n", 12, NULL, NULL /* cancellable */, error))
        {
            return FALSE;
        }
    }

    return TRUE;
}

static void
g_paste_file_backend_write_history_file (const GPasteStorageBackend *self,
                                         const gchar                *history_file_path,
                                         const GList                *history)
{
    const GPasteSettings *settings = _G_PASTE_STORAGE_BACKEND_GET_CLASS (self)->get_settings (self);

    if (!g_paste_util_ensure_history_dir_exists (settings))
        return;

    g_autoptr (GFile) history_file = g_file_new_for_path (history_file_path);

    if (!g_paste_settings_get_save_history (settings))
    {
        g_autoptr (GError) error = NULL;
        if (!g_file_delete (history_file, NULL, &error) &&
            !g_error_matches (error, G_IO_ERROR, G_IO_ERROR_NOT_FOUND))
        {
            g_warning ("Failed to delete history file: %s", error->message);
        }
        return;
    }

    const GPasteFileBackend *real_self = _G_PASTE_FILE_BACKEND (self);

    g_autofree gchar *tmp_path = g_strconcat (history_file_path, ".tmp", NULL);
    g_autoptr (GFile) tmp_file = g_file_new_for_path (tmp_path);
    g_autoptr (GOutputStream) stream = _G_PASTE_FILE_BACKEND_GET_CLASS (real_self)->get_output_stream (real_self, tmp_file);

    if (!stream)
        return;

    gboolean success = TRUE;
    g_autoptr (GError) error = NULL;

    if (!g_output_stream_write_all (stream, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n", 39, NULL, NULL /* cancellable */, &error) ||
        !g_output_stream_write_all (stream, "<history version=\"2.0\">\n", 24, NULL, NULL /* cancellable */, &error))
    {
        g_warning ("Failed to write history header: %s", error->message);
        g_clear_error (&error);
        success = FALSE;
    }

    for (const GList *h = history; success && h; h = g_list_next (h))
    {
        const GPasteItem *item = h->data;
        const gchar *kind = g_paste_item_get_kind (item);
        const gchar *uuid = g_paste_item_get_uuid (item);

        if (g_paste_str_equal (kind, "Password"))
            continue;

        const GSList *special_values = g_paste_item_get_special_values (item);
        const gchar *value = g_paste_item_get_value (item);

        /* The document only holds UTF-8, and an image's value is its path: one
         * under a home directory whose name is not UTF-8 has no place in it.
         * The item is left out of the file rather than the save crashing on
         * it, the image staying in the history for as long as the daemon
         * runs, and its file, which no history then names, behind it after a
         * restart: nothing on this branch sweeps the images directory. Said
         * once a run: every save, which every copy makes, would otherwise say
         * it again, and what makes one path so makes them all. */
        if (!g_utf8_validate (value, -1, NULL))
        {
            static gint warned = 0;

            if (g_atomic_int_compare_and_exchange (&warned, 0, 1))
                g_warning ("Leaving out of the history file the items whose value is not UTF-8");
            continue;
        }

        g_autofree gchar *text = g_paste_util_xml_encode (value);

        if (!g_output_stream_write_all (stream, "  <item kind=\"", 14, NULL, NULL /* cancellable */, &error) ||
            !g_output_stream_write_all (stream, kind, strlen (kind), NULL, NULL /* cancellable */, &error) ||
            !g_output_stream_write_all (stream, "\" uuid=\"", 8, NULL, NULL /* cancellable */, &error) ||
            !g_output_stream_write_all (stream, uuid, strlen (uuid), NULL, NULL /* cancellable */, &error) ||
            (_G_PASTE_IS_IMAGE_ITEM (item) && !_g_paste_file_backend_write_image_metadata (stream, _G_PASTE_IMAGE_ITEM (item), &error)) ||
            !g_output_stream_write_all (stream, "\">\n    <value><![CDATA[", 23, NULL, NULL /* cancellable */, &error) ||
            !g_output_stream_write_all (stream, text, strlen (text), NULL, NULL /* cancellable */, &error) ||
            !g_output_stream_write_all (stream, "]]></value>\n", 12, NULL, NULL /* cancellable */, &error) ||
            (special_values && !_g_paste_file_backend_write_special_values (stream, special_values, &error)) ||
            !g_output_stream_write_all (stream, "  </item>\n", 10, NULL, NULL /* cancellable */, &error))
        {
            g_warning ("Failed to write an item to history: %s", error->message);
            g_clear_error (&error);
            success = FALSE;
        }
    }

    if (success &&
        !g_output_stream_write_all (stream, "</history>\n", 11, NULL, NULL /* cancellable */, &error))
    {
        g_warning ("Failed to write history footer: %s", error->message);
        g_clear_error (&error);
        success = FALSE;
    }

    if (success && !g_output_stream_close (stream, NULL /* cancellable */, &error))
    {
        g_warning ("Failed to close history temp file: %s", error->message);
        g_clear_error (&error);
        success = FALSE;
    }

    if (success && !_g_paste_file_backend_sync (tmp_file, &error))
    {
        g_warning ("Failed to sync history temp file: %s", error->message);
        g_clear_error (&error);
        success = FALSE;
    }

    if (success && !g_file_move (tmp_file, history_file, G_FILE_COPY_OVERWRITE, NULL, NULL, NULL, &error))
    {
        g_warning ("Failed to install history file: %s", error->message);
        g_clear_error (&error);
        success = FALSE;
    }

    if (!success)
    {
        if (!g_file_delete (tmp_file, NULL, &error) &&
            !g_error_matches (error, G_IO_ERROR, G_IO_ERROR_NOT_FOUND))
        {
            g_warning ("Failed to delete history temp file: %s", error->message);
        }
    }
}

/********************/
/* Begin XML Parser */
/********************/

typedef enum
{
    BEGIN,
    IN_HISTORY,
    IN_ITEM,
    IN_ITEM_WITH_TEXT,
    IN_VALUE,
    IN_VALUE_WITH_TEXT,
    END
} State;

typedef enum
{
    TEXT,
    IMAGE,
    URIS,
    PASSWORD,
    COLOR,
    /* No usable "kind" attribute (missing, or naming a kind this version does
     * not know). Reset per item, so one such item never makes the next one —
     * which may have no kind of its own — inherit its type. */
    UNKNOWN_TYPE
} Type;

typedef enum
{
    HISTORY_1_0,
    HISTORY_2_0,
    HISTORY_CURRENT = HISTORY_2_0,
    HISTORY_INVALID = -1
} HistoryVersion;

typedef struct
{
    const gchar      *history_file_path;
    GList            *history;
    gsize             mem_size;
    State             state;
    Type              type;
    guint64           current_size;
    guint64           max_size;
    gboolean          images_support;
    gchar            *uuid;
    gchar            *date;
    gchar            *checksum;
    gchar            *name;
    gchar            *text;
    GSList           *special_values;
    HistoryVersion    version;
    GPasteSpecialAtom mime;
} Data;

#define ASSERT_STATE_FULL(cond, x)                                                                    \
    if (!(cond))                                                                                      \
    {                                                                                                 \
        gint line_number, char_number;                                                                \
        g_markup_parse_context_get_position (context, &line_number, &char_number);                    \
        g_warning ("Expected state %" G_GINT32_FORMAT ", but got %" G_GINT32_FORMAT                   \
                   " in file “%s” at line %" G_GINT32_FORMAT ", column %" G_GINT32_FORMAT ".",        \
                   x, data->state, data->history_file_path, line_number, char_number);                \
        return;                                                                                       \
    }
#define ASSERT_STATE(x) ASSERT_STATE_FULL (data->state == (x), x)
#define SWITCH_STATE(x, y) \
    do {                   \
        ASSERT_STATE (x);  \
        data->state = y;   \
    } while (0)
/* Only a non-empty text run moves an element to its ..._WITH_TEXT state, so an
 * element that holds nothing (or only whitespace) is still in @empty when its
 * end tag arrives. Accept both: refusing the empty one would leave the state
 * machine stuck inside that element and silently drop every remaining item. */
#define SWITCH_STATE_OR_EMPTY(x, empty, y)                                        \
    do {                                                                          \
        ASSERT_STATE_FULL (data->state == (x) || data->state == (empty), x);      \
        data->state = y;                                                          \
    } while (0)

static gboolean
history_contains_uuid (const GList *history,
                       const gchar *uuid)
{
    for (; history; history = g_list_next (history))
    {
        const GPasteItem *item = history->data;

        if (g_paste_str_equal (g_paste_item_get_uuid (item), uuid))
            return TRUE;
    }

    return FALSE;
}

/* A SHA-256 in lowercase hex: what g_paste_image_item_get_checksum () answers
 * for an image, and the only checksum a document may name. */
static gboolean
is_image_checksum (const gchar *checksum)
{
    gsize length = 2 * (gsize) g_checksum_type_get_length (G_CHECKSUM_SHA256);

    return strspn (checksum, "0123456789abcdef") == length && !checksum[length];
}

static void
start_tag (GMarkupParseContext *context G_GNUC_UNUSED,
           const gchar         *element_name,
           const gchar        **attribute_names,
           const gchar        **attribute_values,
           gpointer             user_data,
           GError             **error G_GNUC_UNUSED)
{
    Data *data = user_data;

    if (g_paste_str_equal (element_name, "history"))
    {
        SWITCH_STATE (BEGIN, IN_HISTORY);
        for (const gchar **a = attribute_names, **v = attribute_values; *a && *v; ++a, ++v)
        {
            if (g_paste_str_equal (*a, "version"))
            {
                if (g_paste_str_equal (*v, "1.0"))
                    data->version = HISTORY_1_0;
                else if (g_paste_str_equal (*v, "2.0"))
                    data->version = HISTORY_2_0;
                else
                {
                    g_warning ("Unknown history version: %s", *v);
                    data->version = HISTORY_INVALID;
                }
            }
        }
    }
    else if (g_paste_str_equal (element_name, "item"))
    {
        SWITCH_STATE (IN_HISTORY, IN_ITEM);
        data->type = UNKNOWN_TYPE;
        g_clear_pointer (&data->uuid, g_free);
        g_clear_pointer (&data->date, g_free);
        g_clear_pointer (&data->checksum, g_free);
        g_clear_pointer (&data->name, g_free);
        g_clear_pointer (&data->text, g_free);
        g_clear_slist (&data->special_values, g_object_unref);
        for (const gchar **a = attribute_names, **v = attribute_values; *a && *v; ++a, ++v)
        {
            if (g_paste_str_equal (*a, "kind"))
            {
                if (g_paste_str_equal (*v, "Text"))
                    data->type = TEXT;
                else if (g_paste_str_equal (*v, "Image"))
                    data->type = IMAGE;
                else if (g_paste_str_equal (*v, "Uris"))
                    data->type = URIS;
                else if (g_paste_str_equal (*v, "Password"))
                    data->type = PASSWORD;
                else if (g_paste_str_equal (*v, "Color"))
                    data->type = COLOR;
                else
                    g_warning ("Unknown item kind: %s", *v);
            }
            else if (g_paste_str_equal (*a, "uuid"))
            {
                if (g_uuid_string_is_valid (*v) && !history_contains_uuid (data->history, *v))
                    data->uuid = g_strdup (*v);
            }
            /* An attribute that does not belong to this kind is skipped, not a
             * reason to abandon the item: returning here would also drop the
             * attributes that follow it (the uuid among them). */
            else if (g_paste_str_equal (*a, "date"))
            {
                if (data->type != IMAGE)
                {
                    g_warning ("Expected type %" G_GINT32_FORMAT ", but got %" G_GINT32_FORMAT, IMAGE, data->type);
                    continue;
                }
                data->date = g_strdup (*v);
            }
            else if (g_paste_str_equal (*a, "checksum"))
            {
                if (data->type != IMAGE)
                {
                    g_warning ("Expected type %" G_GINT32_FORMAT ", but got %" G_GINT32_FORMAT, IMAGE, data->type);
                    continue;
                }
                /* Only one the image could have computed: anything else would
                 * be written back as it is, unescaped (see the writer), and a
                 * quote in it then makes the whole file unreadable. Dropped,
                 * the image computes its own again. */
                if (!is_image_checksum (*v))
                {
                    g_warning ("Ignoring an invalid image checksum in file “%s”", data->history_file_path);
                    continue;
                }
                g_free (data->checksum);
                data->checksum = g_strdup (*v);
            }
            else if (g_paste_str_equal (*a, "name"))
            {
                if (data->type != PASSWORD)
                {
                    g_warning ("Expected type %" G_GINT32_FORMAT ", but got %" G_GINT32_FORMAT, PASSWORD, data->type);
                    continue;
                }
                data->name = g_strdup (*v);
            }
            else
                g_warning ("Unknown item attribute: %s", *a);
        }
    }
    else if (g_paste_str_equal (element_name, "value"))
    {
        SWITCH_STATE (IN_ITEM, IN_VALUE);
        data->mime = G_PASTE_SPECIAL_ATOM_INVALID;
        for (const gchar **a = attribute_names, **v = attribute_values; *a && *v; ++a, ++v)
        {
            if (g_paste_str_equal (*a, "mime"))
            {
                GEnumValue *gev = g_enum_get_value_by_nick (g_type_class_peek (G_PASTE_TYPE_SPECIAL_ATOM), *v);
                if (gev)
                    data->mime = gev->value;
                else
                    g_warning ("Unknown mime: %s", *v);
            }
        }
    }
    else
        g_warning ("Unknown element: %s", element_name);
}

static void
add_item (Data *data)
{
    GPasteItem *item = NULL;

    /* Every kind is built from the item's value, and every constructor rejects a
     * %NULL one with a critical: an <item> with no usable kind, or with no
     * <value> at all (absent, empty or whitespace-only), carries nothing we can
     * restore and is skipped — along with its special values, released below. */
    Type type = (data->text) ? data->type : UNKNOWN_TYPE;

    if (type == UNKNOWN_TYPE)
        g_warning ("Ignoring an item with no usable kind or value in file “%s”", data->history_file_path);

    switch (type)
    {
    case TEXT:
        item = g_paste_text_item_new (data->text);
        break;
    case URIS:
        item = g_paste_uris_item_new_from_str (data->text);
        break;
    case PASSWORD:
        item = g_paste_password_item_new (data->name, data->text);
        break;
    case COLOR:
        item = g_paste_color_item_new_from_str (data->text);
        break;
    case IMAGE:
        if (data->images_support && data->date)
        {
            g_autoptr (GDateTime) date_time = g_date_time_new_from_unix_local (g_ascii_strtoll (data->date,
                                                                                                NULL, /* end */
                                                                                                0)); /* base */
            item = g_paste_image_item_new_from_file (data->text, date_time, data->checksum);
        }
        else
        {
            g_autoptr (GFile) img_file = g_file_new_for_path (data->text);

            if (g_file_query_exists (img_file,
                                     NULL)) /* cancellable */
            {
                g_autoptr (GError) error = NULL;
                if (!g_file_delete (img_file, NULL, &error))
                    g_warning ("Failed to delete leftover image: %s", error->message);
            }
        }
        break;
    case UNKNOWN_TYPE:
        break;
    }

    if (item)
    {
        if (!data->uuid)
            data->uuid = g_uuid_string_random ();

        g_paste_item_set_uuid (item, data->uuid);
        data->history = g_list_append (data->history, item);
        ++data->current_size;
    }

    for (GSList *d = data->special_values; d; d = d->next)
    {
        GPasteBinaryData *v = d->data;

        if (item)
            g_paste_item_add_special_value (item, v);
        else
            g_object_unref (v);
    }

    if (item)
        data->mem_size += g_paste_item_get_size (item);

    g_clear_pointer (&data->special_values, g_slist_free);
}

static void
end_tag (GMarkupParseContext *context G_GNUC_UNUSED,
         const gchar         *element_name,
         gpointer             user_data,
         GError             **error G_GNUC_UNUSED)
{
    Data *data = user_data;

    if (g_paste_str_equal (element_name, "history"))
        SWITCH_STATE (IN_HISTORY, END);
    else if (g_paste_str_equal (element_name, "item"))
    {
        /* An unknown (or missing) version collects neither the item's value nor
         * its special values (see on_text), so there is nothing to restore. */
        if (data->version != HISTORY_INVALID && data->current_size < data->max_size)
            add_item (data);
        switch (data->version)
        {
        case HISTORY_1_0:
            SWITCH_STATE_OR_EMPTY (IN_ITEM_WITH_TEXT, IN_ITEM, IN_HISTORY);
            break;
        case HISTORY_2_0:
            SWITCH_STATE (IN_ITEM, IN_HISTORY);
            break;
        case HISTORY_INVALID:
            /* Leave the item all the same: staying inside it would make every
             * element that follows fail its assert — including the next <item>,
             * whose scratch reset would then be skipped, so the items of an
             * unknown-version history would bleed into each other. Which state
             * we are in depends on the (unknown) version, so accept both. */
            SWITCH_STATE_OR_EMPTY (IN_ITEM_WITH_TEXT, IN_ITEM, IN_HISTORY);
            break;
        }
    }
    else if (g_paste_str_equal (element_name, "value"))
        SWITCH_STATE_OR_EMPTY (IN_VALUE_WITH_TEXT, IN_VALUE, IN_ITEM);
    else
        g_warning ("Unknown element: %s", element_name);
}

static void
on_text (GMarkupParseContext *context G_GNUC_UNUSED,
         const gchar         *text,
         gsize                text_len,
         gpointer             user_data,
         GError             **error G_GNUC_UNUSED)
{
    Data *data = user_data;

    g_autofree gchar *txt = g_strndup (text, text_len);
    switch (data->state)
    {
    /* Text out of place is still the history's -- a password's among it, when
     * the file is damaged -- and the journal outlives the history it would be
     * copied from, with readers of its own: its length is all that is said of
     * it. */
    case IN_HISTORY:
    case IN_ITEM_WITH_TEXT:
    case IN_VALUE_WITH_TEXT:
        if (*g_strstrip (txt))
        {
            g_warning ("Unexpected text (%" G_GSIZE_FORMAT " bytes) in history file “%s”", text_len, data->history_file_path);
            return;
        }
        break;
    case IN_ITEM:
    {
        if (data->version == HISTORY_1_0)
        {
            data->text = g_paste_util_xml_decode (txt);
            if (*g_strstrip (txt))
                SWITCH_STATE (IN_ITEM, IN_ITEM_WITH_TEXT);
            else
                g_clear_pointer (&data->text, g_free);
        }
        else if (*g_strstrip (txt))
            g_warning ("Unexpected text in an item (%" G_GSIZE_FORMAT " bytes) in history file “%s”", text_len, data->history_file_path);
        break;
    }
    case IN_VALUE:
        if (data->version == HISTORY_2_0)
        {
            g_autofree gchar *value = g_paste_util_xml_decode (txt);

            /* GMarkup hands the runs either side of a CDATA section over apart
             * from it, so whitespace alone may be the indentation around the
             * value rather than the value: it stands only until a run that is
             * not whitespace comes. A plain value of whitespace alone -- blank
             * lines copied -- is written verbatim and kept, where a special
             * value is base64, which whitespace alone is none of. */
            if (!*g_strstrip (txt))
            {
                if (data->mime == G_PASTE_SPECIAL_ATOM_INVALID && value && *value && !data->text)
                    data->text = g_steal_pointer (&value);
            }
            else
            {
                SWITCH_STATE (IN_VALUE, IN_VALUE_WITH_TEXT);
                if (data->mime == G_PASTE_SPECIAL_ATOM_INVALID)
                {
                    g_clear_pointer (&data->text, g_free);
                    data->text = g_steal_pointer (&value);
                }
                else
                {
                    gsize raw_length;
                    guchar *raw = (guchar *) g_base64_decode (value, &raw_length);
                    GPasteBinaryData *sv = g_paste_binary_data_new (data->mime, g_bytes_new_take (raw, raw_length));
                    data->special_values = g_slist_prepend (data->special_values, sv);
                }
            }
        }
        else
            g_warning ("Unexpected value for history version != 2.0");
        break;
    default:
        g_warning ("Unexpected state: %" G_GINT32_FORMAT, data->state);
        break;
    }
}

/* What GMarkup found wrong, without its message: that quotes the document -- a
 * value not in UTF-8 whole -- and the journal outlives the history (see
 * on_text ()). Every error the parse reports is GMarkup's own, the callbacks
 * setting none. */
static const gchar *
markup_error_description (const GError *error)
{
    switch (error->code)
    {
    case G_MARKUP_ERROR_BAD_UTF8:
        return "text not in UTF-8";
    case G_MARKUP_ERROR_EMPTY:
        return "an empty document";
    default:
        return "markup that does not parse";
    }
}

static void on_error (GMarkupParseContext *context G_GNUC_UNUSED,
                      GError              *error,
                      gpointer             user_data)
{
    const Data *data = user_data;

    g_warning ("History file “%s” holding %s", data->history_file_path, markup_error_description (error));
}

/******************/
/* End XML Parser */
/******************/

static void
g_paste_file_backend_read_history_file (const GPasteStorageBackend *self,
                                        const gchar                *history_file_path,
                                        GList                     **history,
                                        gsize                      *size)
{
    const GPasteSettings *settings = _G_PASTE_STORAGE_BACKEND_GET_CLASS (self)->get_settings (self);
    g_autoptr (GFile) history_file = g_file_new_for_path (history_file_path);
    g_autofree gchar *text = NULL;

    if (g_file_query_exists (history_file,
                             NULL)) /* cancellable */
    {
        GMarkupParser parser = {
            start_tag,
            end_tag,
            on_text,
            NULL,
            on_error
        };
        Data data = {
            history_file_path,
            NULL,
            0,
            BEGIN,
            UNKNOWN_TYPE, /* set per item from its "kind" attribute */
            0,
            g_paste_settings_get_max_history_size (settings),
            g_paste_settings_get_images_support (settings),
            NULL, /* uuid */
            NULL, /* date */
            NULL, /* checksum */
            NULL, /* name */
            NULL, /* text */
            NULL, /* special_values */
            HISTORY_INVALID,
            G_PASTE_SPECIAL_ATOM_INVALID
        };
        g_autoptr (GMarkupParseContext) ctx = g_markup_parse_context_new (&parser,
                                                                          G_MARKUP_TREAT_CDATA_AS_TEXT,
                                                                          &data,
                                                                          NULL);
        gsize text_length;
        g_autoptr (GError) error = NULL;

        /* A FIFO named like a history would hold the read until a writer
         * came, which none ever does, freezing the daemon on it: what is not a
         * regular file is no history. */
        if (!g_file_test (history_file_path, G_FILE_TEST_IS_REGULAR))
        {
            g_warning ("Not reading history file “%s”, which is not a regular file", history_file_path);
            return;
        }

        if (!g_file_get_contents (history_file_path, &text, &text_length, &error))
        {
            g_warning ("Failed to read history file: %s", error->message);
            return;
        }

        /* No GError: on_error () reports each, and a second one set over the
         * first would have GLib log its message. */
        gboolean parsed = (g_markup_parse_context_parse (ctx, text, text_length, NULL) &&
                           g_markup_parse_context_end_parse (ctx, NULL));

        if (!parsed)
            g_warning ("Failed to parse history file “%s”", history_file_path);

        if (data.state != END)
            g_warning ("Unexpected state after parsing history: %" G_GINT32_FORMAT, data.state);

        *history = data.history;
        *size = data.mem_size;
        g_clear_pointer (&data.uuid, g_free);
        g_clear_pointer (&data.date, g_free);
        g_clear_pointer (&data.checksum, g_free);
        g_clear_pointer (&data.name, g_free);
        g_clear_pointer (&data.text, g_free);
        /* add_item() consumes these at every </item>; a document that ends inside
         * one (truncated file, failed parse) leaves the last item's behind. */
        g_clear_slist (&data.special_values, g_object_unref);

        /* Rewrite only to migrate a recognised older format that parsed cleanly.
         * A HISTORY_INVALID version means we never parsed a valid <history>
         * header (a corrupt file, or one written by a newer GPaste): leave it
         * untouched rather than overwrite it with a partial parse -- every item
         * of such a history is skipped, so what we would write back is empty. */
        if (parsed && data.version != HISTORY_CURRENT && data.version != HISTORY_INVALID)
            g_paste_file_backend_write_history_file (self, history_file_path, *history);
    }
    else
    {
        /* Create the empty file to be listed as an available history */
        if (g_paste_util_ensure_history_dir_exists (settings))
        {
            g_autoptr (GError) error = NULL;
            g_autoptr (GFileOutputStream) created = g_file_create (history_file, G_FILE_CREATE_NONE, NULL, &error);
            if (!created && !g_error_matches (error, G_IO_ERROR, G_IO_ERROR_EXISTS))
                g_warning ("Failed to create history file: %s", error->message);
        }
    }
}

static void
g_paste_file_backend_delete_history (const GPasteStorageBackend *self G_GNUC_UNUSED,
                                      const gchar                *name,
                                      GError                   **error)
{
    g_autoptr (GFile) history_file = g_paste_util_get_history_file (name, "xml");

    g_file_delete (history_file, NULL, error);
}

static GStrv
g_paste_file_backend_list_histories (const GPasteStorageBackend *self G_GNUC_UNUSED,
                                      GError                   **error)
{
    g_autoptr (GStrvBuilder) history_names = g_strv_builder_new ();
    g_autoptr (GFile) history_dir = g_paste_util_get_history_dir ();
    g_autoptr (GFileEnumerator) histories = g_file_enumerate_children (history_dir,
                                                                       G_FILE_ATTRIBUTE_STANDARD_DISPLAY_NAME "," G_FILE_ATTRIBUTE_STANDARD_TYPE,
                                                                       G_FILE_QUERY_INFO_NONE,
                                                                       NULL,
                                                                       error);
    if (error && *error)
    {
        if ((*error)->domain == G_IO_ERROR && (*error)->code == G_IO_ERROR_NOT_FOUND)
        {
            g_clear_error (error);
            return g_strv_builder_end (history_names);
        }
        return NULL;
    }

    GFileInfo *history;

    while ((history = g_file_enumerator_next_file (histories,
                                                   NULL,
                                                   error)))
    {
        g_autoptr (GFileInfo) h = history;

        if (error && *error)
            return NULL;

        const gchar *raw_name = g_file_info_get_display_name (h);

        /* Only a regular file is a history: see
         * g_paste_file_backend_read_history_file (). Its name, holding no "/",
         * is one g_paste_history_name_is_valid () takes. */
        if (g_file_info_get_file_type (h) == G_FILE_TYPE_REGULAR && g_str_has_suffix (raw_name, ".xml"))
        {
            g_autofree gchar *name = g_strdup (raw_name);

            name[strlen (name) - 4] = '\0';
            g_strv_builder_take (history_names, g_steal_pointer (&name));
        }
    }

    return g_strv_builder_end (history_names);
}

static const gchar *
g_paste_file_backend_get_extension (const GPasteStorageBackend *self G_GNUC_UNUSED)
{
    return "xml";
}

static GOutputStream *
g_paste_file_backend_get_output_stream (const GPasteFileBackend *self G_GNUC_UNUSED,
                                        GFile                   *output_file)
{
    g_autoptr (GError) error = NULL;
    GOutputStream *stream = G_OUTPUT_STREAM (g_file_replace (output_file,
                                                              NULL,
                                                              FALSE,
                                                              G_FILE_CREATE_REPLACE_DESTINATION,
                                                              NULL, /* cancellable */
                                                              &error));
    if (!stream)
        g_warning ("Failed to open history temp file for writing: %s", error->message);
    return stream;
}

static void
g_paste_file_backend_class_init (GPasteFileBackendClass *klass)
{
    GPasteStorageBackendClass *storage_class = G_PASTE_STORAGE_BACKEND_CLASS (klass);

    storage_class->read_history_file = g_paste_file_backend_read_history_file;
    storage_class->write_history_file = g_paste_file_backend_write_history_file;
    storage_class->get_extension = g_paste_file_backend_get_extension;
    storage_class->delete_history = g_paste_file_backend_delete_history;
    storage_class->list_histories = g_paste_file_backend_list_histories;

    klass->get_output_stream = g_paste_file_backend_get_output_stream;
}

static void
g_paste_file_backend_init (GPasteFileBackend *self G_GNUC_UNUSED)
{
}
