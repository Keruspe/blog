// SPDX-FileCopyrightText: 2010-2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com>
// SPDX-License-Identifier: BSD-2-Clause

import GObject from 'gi://GObject';
import St from 'gi://St';

import {GPasteDeleteButton} from './deleteButton.js';

export const GPasteDeleteItemPart = GObject.registerClass(
class GPasteDeleteItemPart extends St.Bin {
    constructor(client, uuid) {
        super();
        this._deleteButton = new GPasteDeleteButton(client, uuid);
        this.child = this._deleteButton;
    }

    setUuid(uuid) {
        this._deleteButton.setUuid(uuid);
    }
});
