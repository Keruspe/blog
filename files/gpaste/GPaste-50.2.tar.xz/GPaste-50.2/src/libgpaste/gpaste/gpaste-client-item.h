// SPDX-FileCopyrightText: 2010-2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com>
// SPDX-License-Identifier: BSD-2-Clause

#if !defined (__G_PASTE_H_INSIDE__) && !defined (G_PASTE_COMPILATION)
#error "Only <gpaste.h> can be included directly."
#endif

#pragma once

#include <gpaste/gpaste-macros.h>

G_BEGIN_DECLS

#define G_PASTE_TYPE_CLIENT_ITEM (g_paste_client_item_get_type ())

G_PASTE_FINAL_TYPE (ClientItem, client_item, CLIENT_ITEM, GObject)

const gchar *g_paste_client_item_get_uuid  (const GPasteClientItem *self);
const gchar *g_paste_client_item_get_value (const GPasteClientItem *self);

GPasteClientItem *g_paste_client_item_new (const gchar *uuid,
                                           const gchar *value);

G_END_DECLS
