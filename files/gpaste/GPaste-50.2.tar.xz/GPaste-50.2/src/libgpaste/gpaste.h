// SPDX-FileCopyrightText: 2010-2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com>
// SPDX-License-Identifier: BSD-2-Clause

#pragma once

#define __G_PASTE_H_INSIDE__

/* Misc. macros */
#include <gpaste/gpaste-macros.h>

/* GDBus utils */
#include <gpaste/gpaste-gdbus-defines.h>
#include <gpaste/gpaste-gdbus-macros.h>
#include <gpaste/gpaste-item-enums.h>
#include <gpaste/gpaste-update-enums.h>

/* GPasteSettings */
#include <gpaste/gpaste-gsettings-keys.h>
#include <gpaste/gpaste-settings.h>

/* GPasteClient */
#include <gpaste/gpaste-client.h>
#include <gpaste/gpaste-client-item.h>

/* GPasteUtil */
#include <gpaste/gpaste-util.h>

/* GPasteKeybindingProvider */
#include <gpaste/gpaste-keybinding-provider.h>

/* GPasteGnomeShellClient */
#include <gpaste/gpaste-gnome-shell-client.h>

/* GPasteScreensaverClient */
#include <gpaste/gpaste-screensaver-client.h>

#undef __G_PASTE_H_INSIDE__
