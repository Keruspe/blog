// SPDX-FileCopyrightText: 2010-2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com>
// SPDX-License-Identifier: BSD-2-Clause

#include <gpaste-3/gpaste-error.h>
#include <gpaste-3/gpaste-gdbus-defines.h>
#include <gpaste-3/gpaste-gsettings-keys.h>
#include <gpaste-3/gpaste-settings.h>
#include <gpaste-3/gpaste-util.h>

#include <getopt.h>
#include <stdio.h>

typedef struct
{
    GPasteClient *client;
    gint          argc;
    const gchar **args;
    gchar        *pipe_data;
    gboolean      help;
    gboolean      version;
    gboolean      favourites;
    gboolean      oneline;
    gboolean      raw;
    gboolean      reverse;
    gboolean      use_index;
    gboolean      zero;
    guint         timeout;
    gboolean      timeout_given;
    const gchar  *decoration;
    const gchar  *separator;
} Context;

/*
 * Utility functions
 */

static gboolean
parse_cmdline (int     *argc,
               char   **argv[],
               Context *ctx)
{
    struct option long_options[] = {
        { "decoration", required_argument, NULL,  'd'  },
        { "favourites", no_argument,       NULL,  'f'  },
        { "help",       no_argument,       NULL,  'h'  },
        { "oneline",    no_argument,       NULL,  'o'  },
        { "raw",        no_argument,       NULL,  'r'  },
        { "reverse",    no_argument,       NULL,  'e'  },
        { "separator",  required_argument, NULL,  's'  },
        { "timeout",    required_argument, NULL,  't'  },
        { "use-index",  no_argument,       NULL,  'i'  },
        { "version",    no_argument,       NULL,  'v'  },
        { "zero",       no_argument,       NULL,  'z'  },
        { NULL,         no_argument,       NULL,  '\0' }
    };
    gint64 c;

    while ((c = getopt_long (*argc, *argv, "d:fhores:t:ivz", long_options, NULL)) != -1)
    {
        switch (c)
        {
        case 'd':
            ctx->decoration = optarg;
            break;
        case 'f':
            ctx->favourites = TRUE;
            break;
        case 'h':
            ctx->help = TRUE;
            break;
        case 'o':
            ctx->oneline = TRUE;
            break;
        case 'r':
            ctx->raw = TRUE;
            break;
        case 'e':
            ctx->reverse = TRUE;
            break;
        case 's':
            ctx->separator = optarg;
            break;
        case 't':
        {
            gchar *end = NULL;
            guint64 timeout = g_ascii_strtoull (optarg, &end, 10);

            /* 0 is a timeout of its own -- a password that is never taken off
             * the clipboard -- so a malformed value has to be refused rather
             * than fall to it. Past the range is refused for the same reason:
             * the item caps what it is given, and a number silently becoming a
             * smaller one is a password expiring at a time nobody asked for. */
            if (!*optarg || (end && *end) || timeout > G_PASTE_PASSWORD_TIMEOUT_MAX)
            {
                ctx->help = TRUE;
                return FALSE;
            }

            ctx->timeout = (guint) timeout;
            ctx->timeout_given = TRUE;
            break;
        }
        case 'i':
            ctx->use_index = TRUE;
            break;
        case 'v':
            ctx->version = TRUE;
            break;
        case 'z':
            ctx->zero = TRUE;
            break;
        default:
            ctx->help = TRUE;
            return FALSE;
        }
    }

    *argc -= optind;
    *argv += optind;

    /* argv[0] is the verb and ctx->args the arguments after it. With no verb at
     * all (a plain "gpaste-client", or one only fed through a pipe) there is
     * nothing past it: stay on argv's own NULL terminator rather than stepping
     * over it, which ctx->args[0] would then read out of bounds. */
    ctx->argc = (*argc > 0) ? *argc - 1 : 0;
    ctx->args = (const gchar **) *argv + ((*argc > 0) ? 1 : 0);

    return TRUE;
}

static gchar *
extract_pipe_data (void)
{
    if (isatty (STDIN_FILENO))
        return NULL; /* We're not being piped */

    g_autoptr (GString) data = g_string_new (NULL);
    gint64 c;

    while ((c = fgetc (stdin)) != EOF)
        data = g_string_append_c (data, (guchar)c);
    g_string_append_c (data, '\0');

    return (*data->str) ? g_strdup (data->str) : NULL;
}

/* @text as it goes out: on a terminal, a control character an application put
 * on the clipboard -- an escape sequence retitling the window, clearing it or
 * writing the terminal's own clipboard -- is shown as U+FFFD rather than acted
 * on, line breaks and tabs aside: a line feed, a tab, and the carriage return
 * of a CRLF line ending, which takes the cursor nowhere the line feed after it
 * does not -- a lone one, writing over its line, is shown. Anywhere else it is
 * written as it is, a script reading the bytes the item holds.
 *
 * Whether stdout is a terminal is asked once, a listing printing many items,
 * and what lies between two such characters is written in one go. */
static void
print_text (const gchar *text)
{
    static gint terminal = -1;

    if (terminal < 0)
        terminal = isatty (STDOUT_FILENO);

    if (!terminal)
    {
        fputs (text, stdout);
        return;
    }

    const gchar *run = text;

    for (const gchar *c = text; *c; c = g_utf8_next_char (c))
    {
        gunichar u = g_utf8_get_char (c);

        if (u == '\n' || u == '\t' || (u == '\r' && c[1] == '\n') || !g_unichar_iscntrl (u))
            continue;

        fwrite (run, 1, (gsize) (c - run), stdout);
        fputs ("\xef\xbf\xbd", stdout);
        run = g_utf8_next_char (c);
    }

    fputs (run, stdout);
}

static void
print_history_line (gchar       *line,
                    guint        index,
                    const gchar *uuid,
                    Context     *ctx)
{
    if (!ctx->raw)
    {
        if (ctx->use_index)
            printf ("%d: ", index);
        else
            printf ("%s: ", uuid);
    }
    g_autofree gchar *oneline = (ctx->oneline) ? g_paste_util_one_line (line) : NULL;

    print_text ((oneline) ?: line);
    putchar ((ctx->zero) ? '\0' : '\n');
}

static gint
spawn (const gchar *app)
{
    g_autoptr (GError) error = NULL;

    if (!g_paste_util_spawn_sync (app, &error))
    {
        /* Translators: %s is the program GPaste tried to start, then the reason it could not. */
        g_critical (_("Couldn’t spawn %s: %s"), app, error->message);
        return EXIT_FAILURE;
    }

    return EXIT_SUCCESS;
}

static void show_help (void);

static void
show_version (void)
{
    printf ("%s\n", PACKAGE_STRING);
}

/*
 * GPaste commands
 */

static gint
g_paste_help (Context *ctx   G_GNUC_UNUSED,
              GError **error G_GNUC_UNUSED)
{
    show_help ();

    return EXIT_SUCCESS;
}

static gint
g_paste_version (Context *ctx   G_GNUC_UNUSED,
                 GError **error G_GNUC_UNUSED)
{
    show_version ();

    return EXIT_SUCCESS;
}

static gint
g_paste_flag_action (Context *ctx,
                     GError **error)
{
    if (ctx->help)
        return g_paste_help (ctx, error);
    if (ctx->version)
        return g_paste_version (ctx, error);
    return -1;
}

/* Whether a flag was given that, on a line with no verb, only the history
 * listing reads: g_paste_history () and print_history_line () read every one of
 * them, and the add that a verb-less line can also be reads none. A flag either
 * of those two comes to read belongs here, and in the client test's list and
 * the man page's DESCRIPTION with it (see dispatch_reads_stdin ()). */
static gboolean
listing_flags_given (const Context *ctx)
{
    return ctx->favourites || ctx->oneline || ctx->raw || ctx->reverse || ctx->use_index || ctx->zero;
}

static gint
g_paste_history (Context *ctx,
                 GError **error)
{
    /* The whole history even under --favourites, where GetFavourites would
     * answer the pinned items alone: what this prints beside each row is where
     * it sits in the history, which only a listing of the history knows. The
     * graphical front ends have no such number to print and do ask for the
     * short listing. */
    g_autolist (GPasteClientItem) history = g_paste_client_get_history_sync (ctx->client, error);

    if (*error)
        return EXIT_FAILURE;

    guint length = g_list_length (history);
    guint index = 0;

    for (const GList *i = (ctx->reverse ? g_list_last (history) : history); i; i = ctx->reverse ? i->prev : i->next)
    {
        GPasteClientItem *item = i->data;
        /* Where the item sits in the history, which is what --use-index takes
         * back: counted over every item, printed or not (a filtered listing
         * that renumbered its rows would name a different item on the way in),
         * and from the far end when the walk runs backwards. */
        guint position = (ctx->reverse) ? length - 1 - index : index;

        ++index;

        if (ctx->favourites && !g_paste_client_item_is_favourite (item))
            continue;

        g_autofree gchar *line = g_strdup (g_paste_client_item_get_value (item));
        print_history_line (line, position, g_paste_client_item_get_uuid (item), ctx);
    }

    return EXIT_SUCCESS;
}

/* Activating the UI app's own action, not a round trip through the daemon: the
 * daemon did nothing else with this than make the same call, and a client that
 * only wants the about dialog has no reason to need a daemon at all. */
static gint
g_paste_about (Context *ctx G_GNUC_UNUSED,
               GError **error)
{
    /* Synchronously: there is no main loop here to finish an asynchronous call
     * from, so the process would exit before anything reached the bus. */
    if (!g_paste_util_activate_ui_sync ("about", NULL, error))
        return EXIT_FAILURE;

    return EXIT_SUCCESS;
}

/* A daemon that honours the re-exec tears its D-Bus connection down before
 * replying, so @triggered is already TRUE for the expected missing reply; this
 * only covers an unsupported method by signalling the recorded daemon pid. */
static gboolean
reexec_fallback (GPasteClient *client,
                 gboolean      triggered,
                 GError      **error)
{
    /* Only an unsupported method warrants the legacy signal path, which
     * g_paste_util_reexecute_legacy_daemon () takes only for a daemon that
     * predates this interface. A daemon's refusal (including an expiry
     * deadline) must reach the caller unchanged, and so does the unsupported
     * method when the signal cannot be sent. */
    if (!triggered && error && g_error_matches (*error, G_DBUS_ERROR, G_DBUS_ERROR_UNKNOWN_METHOD) &&
        g_paste_util_reexecute_legacy_daemon (client, NULL))
    {
        g_clear_error (error);
        triggered = TRUE;
    }

    return triggered;
}

static gint
g_paste_daemon_reexec (Context *ctx,
                       GError **error)
{
    if (!reexec_fallback (ctx->client, g_paste_util_reexecute_daemon (ctx->client, error), error))
        return EXIT_FAILURE;

    printf ("%s\n", _("Successfully re-executed the daemon"));

    return EXIT_SUCCESS;
}

static gint
g_paste_migrate (Context *ctx,
                 GError **error)
{
    /* Through the daemon, and through the very same re-exec as above: the gate
     * is opened here (reset the revision, sync) so that its next start flushes,
     * re-runs the migration and reloads the chosen backend, rather than another
     * process racing the running daemon.
     *
     * Closed again only once the fallback has failed too, and not on the failure
     * the method call reports: the signal reexec_fallback () sends is that same
     * re-exec happening by another route, and a gate closed before it would hand
     * the successor nothing to migrate while this printed a success. */
    guint64 revision = g_paste_util_prepare_storage_migration ();

    if (!reexec_fallback (ctx->client, g_paste_util_reexecute_daemon (ctx->client, error), error))
    {
        g_paste_util_cancel_storage_migration (revision);
        return EXIT_FAILURE;
    }

    printf ("%s\n", _("Successfully triggered the storage migration"));

    return EXIT_SUCCESS;
}

static gint
g_paste_change_passphrase (Context *ctx,
                           GError **error)
{
    /* The daemon owns the prompts (it is the one that can show them, through its
     * own GPastePrompt backend), so this only asks it to. The passphrases are
     * never sent over the bus. */
    g_paste_client_change_passphrase_sync (ctx->client, error);

    if (*error)
        return EXIT_FAILURE;

    printf ("%s\n", _("Successfully triggered the passphrase change"));

    return EXIT_SUCCESS;
}

static gint
g_paste_daemon_version (Context *ctx,
                        GError **error)
{
    /* As in current_history (): the cached property is empty until the daemon
     * has answered for it, and again once it leaves the bus. */
    g_autofree gchar *v = g_paste_client_get_version (ctx->client);

    if (!v)
    {
        g_set_error_literal (error, G_PASTE_ERROR, G_PASTE_ERROR_NOT_FOUND, "Couldn't get the version of the daemon.");
        return EXIT_FAILURE;
    }

    printf ("%s\n", v);

    return EXIT_SUCCESS;
}

/* The history a command acts on when none was named on the command line. It
 * comes off the proxy's cached property, which is empty until the daemon has
 * answered for it and again once it leaves the bus -- and a %NULL name must not
 * travel on to a call that expects one, where it would be built as
 * g_variant_new ("(s)", NULL). */
static gchar *
current_history (Context *ctx,
                 GError **error)
{
    gchar *name = g_paste_client_get_history_name (ctx->client);

    if (!name)
        g_set_error_literal (error, G_PASTE_ERROR, G_PASTE_ERROR_NOT_FOUND, "Couldn't get the name of the current history.");

    return name;
}

static gint
g_paste_empty (Context *ctx,
               GError **error)
{
    g_autofree gchar *name = (ctx->argc) ? g_strdup (ctx->args[0]) : current_history (ctx, error);

    if (*error)
        return EXIT_FAILURE;

    g_paste_client_empty_history_sync (ctx->client, name, error);

    return (*error) ? EXIT_FAILURE : EXIT_SUCCESS;
}

static gint
g_paste_get_history (Context *ctx,
                     GError **error)
{
    g_autofree gchar *name = current_history (ctx, error);

    if (*error)
        return EXIT_FAILURE;

    printf ("%s\n", name);

    return EXIT_SUCCESS;
}

static gint
g_paste_history_size (Context *ctx,
                      GError **error)
{
    guint64 size = g_paste_client_get_history_size_sync (ctx->client, error);

    if (*error)
        return EXIT_FAILURE;

    printf ("%" G_GUINT64_FORMAT "\n", size);

    return EXIT_SUCCESS;
}

static gint
g_paste_list_histories (Context *ctx,
                        GError **error)
{
    g_autolist (GPasteClientHistory) histories = g_paste_client_list_histories_sync (ctx->client, error);

    if (*error)
        return EXIT_FAILURE;

    /* The names alone: this is what a script enumerating histories reads, and
     * the sizes the listing now carries have gpaste-client history-size and the
     * graphical panel for a home. */
    for (const GList *h = histories; h; h = h->next)
        printf ("%s\n", g_paste_client_history_get_name (h->data));

    return EXIT_SUCCESS;
}

static gint
g_paste_delete_history (Context *ctx,
                        GError **error)
{
    g_autofree gchar *name = (ctx->argc) ? g_strdup (ctx->args[0]) : current_history (ctx, error);

    if (*error)
        return EXIT_FAILURE;

    g_paste_client_delete_history_sync (ctx->client, name, error);

    return (*error) ? EXIT_FAILURE : EXIT_SUCCESS;
}

static gint
g_paste_preferences (Context *ctx   G_GNUC_UNUSED,
                     GError **error G_GNUC_UNUSED)
{
    return spawn ("Preferences");
}

static gint
g_paste_show_history (Context *ctx,
                      GError **error)
{
    g_paste_client_show_history_sync (ctx->client, error);

    return (*error) ? EXIT_FAILURE : EXIT_SUCCESS;
}

static gint
g_paste_start (Context *ctx,
               GError **error)
{
    g_paste_client_set_active_sync (ctx->client, TRUE, error);

    return (*error) ? EXIT_FAILURE : EXIT_SUCCESS;
}

static gint
g_paste_stop (Context *ctx,
              GError **error)
{
    g_paste_client_set_active_sync (ctx->client, FALSE, error);

    return (*error) ? EXIT_FAILURE : EXIT_SUCCESS;
}

static gint
g_paste_ui (Context *ctx   G_GNUC_UNUSED,
            GError **error G_GNUC_UNUSED)
{
    return spawn ("Ui");
}

static gint
g_paste_add (Context *ctx,
             GError **error)
{
    const gchar *data = (ctx->argc > 0) ? ctx->args[0] : ctx->pipe_data;

    if (!data)
        return -1;

    g_autofree gchar *uuid = g_paste_client_add_text_sync (ctx->client, data, error);

    return (*error) ? EXIT_FAILURE : EXIT_SUCCESS;
}

/* 0 is a timeout of its own -- a password that is never taken back off -- so
 * without --timeout, AddPassword is sent the one the settings carry. */
static guint
password_timeout (Context *ctx)
{
    if (ctx->timeout_given)
        return ctx->timeout;

    g_autoptr (GPasteSettings) settings = g_paste_settings_new ();

    return (guint) g_paste_settings_get_password_timeout (settings);
}

static gint
g_paste_add_password (Context *ctx,
                      GError **error)
{
    const gchar *data = (ctx->argc > 1) ? ctx->args[1] : ctx->pipe_data;

    if (!data)
        return EXIT_FAILURE;

    g_autofree gchar *uuid = g_paste_client_add_password_sync (ctx->client, ctx->args[0], data, password_timeout (ctx), error);

    return (*error) ? EXIT_FAILURE : EXIT_SUCCESS;
}

static gint
g_paste_backup_history (Context *ctx,
                        GError **error)
{
    guint64 index = 0;
    g_autofree gchar *name = (ctx->argc > 1) ? g_strdup (ctx->args[index++]) : current_history (ctx, error);

    if (*error)
        return EXIT_FAILURE;

    g_paste_client_backup_history_sync (ctx->client, name, ctx->args[index], error);

    return (*error) ? EXIT_FAILURE : EXIT_SUCCESS;
}

static gint
g_paste_delete (Context *ctx,
                GError **error)
{
    g_paste_client_delete_item_sync (ctx->client, ctx->args[0], error);

    return (*error) ? EXIT_FAILURE : EXIT_SUCCESS;
}

static gint
g_paste_favourite (Context *ctx,
                   GError **error)
{
    g_paste_client_set_favourite_sync (ctx->client, ctx->args[0], TRUE, error);

    return (*error) ? EXIT_FAILURE : EXIT_SUCCESS;
}

static gint
g_paste_unfavourite (Context *ctx,
                     GError **error)
{
    g_paste_client_set_favourite_sync (ctx->client, ctx->args[0], FALSE, error);

    return (*error) ? EXIT_FAILURE : EXIT_SUCCESS;
}

static gint
g_paste_delete_password (Context *ctx,
                         GError **error)
{
    g_paste_client_delete_password_sync (ctx->client, ctx->args[0], error);

    return (*error) ? EXIT_FAILURE : EXIT_SUCCESS;
}

static gint
g_paste_file (Context *ctx,
              GError **error)
{
    g_autofree gchar *uuid = g_paste_client_add_file_sync (ctx->client, ctx->args[0], error);

    return (*error) ? EXIT_FAILURE : EXIT_SUCCESS;
}

static gint
g_paste_get (Context *ctx,
             GError **error)
{
    g_autoptr (GPasteClientItem) item = g_paste_client_get_item_sync (ctx->client, ctx->args[0], error);

    if (*error)
        return EXIT_FAILURE;

    print_text (g_paste_client_item_get_value (item));

    return EXIT_SUCCESS;
}

static gint
g_paste_replace (Context *ctx,
                 GError **error)
{
    const gchar *data = (ctx->argc > 1) ? ctx->args[1] : ctx->pipe_data;

    if (!data)
        return EXIT_FAILURE;

    g_autofree gchar *uuid = g_paste_client_replace_sync (ctx->client, ctx->args[0], data, error);

    return (*error) ? EXIT_FAILURE : EXIT_SUCCESS;
}

static gint
g_paste_strip_rich_text (Context *ctx,
                         GError **error)
{
    g_paste_client_strip_rich_text_sync (ctx->client, ctx->args[0], error);

    return (*error) ? EXIT_FAILURE : EXIT_SUCCESS;
}

static gint
g_paste_search (Context *ctx,
                GError **error)
{
    g_autolist (GPasteClientItem) items = g_paste_client_search_sync (ctx->client, ctx->args[0], error);

    if (*error)
        return EXIT_FAILURE;

    /* The rank of the line among the ones printed, not a place in the history:
     * Search answers the matching items, and where each of them sits is what
     * only a listing of the history knows. Which is why this one does renumber
     * under --favourites where the history listing deliberately does not — it
     * is numbering its own output, not naming items. */
    guint index = 0;

    for (const GList *i = items; i; i = i->next)
    {
        GPasteClientItem *item = i->data;

        if (ctx->favourites && !g_paste_client_item_is_favourite (item))
            continue;

        g_autofree gchar *line = g_strdup (g_paste_client_item_get_value (item));
        print_history_line (line, index++, g_paste_client_item_get_uuid (item), ctx);
    }

    return EXIT_SUCCESS;
}

static gint
g_paste_select (Context *ctx,
                GError **error)
{
    g_paste_client_select_sync (ctx->client, ctx->args[0], error);

    return (*error) ? EXIT_FAILURE : EXIT_SUCCESS;
}

static gint
g_paste_switch_history (Context *ctx,
                        GError **error)
{
    g_paste_client_switch_history_sync (ctx->client, ctx->args[0], error);

    return (*error) ? EXIT_FAILURE : EXIT_SUCCESS;
}

static gint
g_paste_upload (Context *ctx,
                GError **error)
{
    g_autofree gchar *url = g_paste_client_upload_sync (ctx->client, ctx->args[0], error);

    if (*error)
        return EXIT_FAILURE;

    printf ("%s\n", url);

    return EXIT_SUCCESS;
}

/* What the keyboard shortcut does, and prints the url as upload does: see
 * UploadAndCopy in the D-Bus XML. */
static gint
g_paste_upload_and_copy (Context *ctx,
                         GError **error)
{
    g_autofree gchar *url = g_paste_client_upload_and_copy_sync (ctx->client, ctx->args[0], error);

    if (*error)
        return EXIT_FAILURE;

    printf ("%s\n", url);

    return EXIT_SUCCESS;
}

static gint
g_paste_make_password (Context *ctx,
                       GError **error)
{
    /* Without --timeout there is nothing to write: an item that is already a
     * password keeps the countdown it carries -- the settings' default would
     * cancel a running one -- and a text item becoming one takes that default
     * anyway, which is what the sentinel asks the daemon for. */
    guint timeout = (ctx->timeout_given) ? ctx->timeout : G_PASTE_PASSWORD_TIMEOUT_UNCHANGED;
    g_autofree gchar *uuid = g_paste_client_make_password_sync (ctx->client, ctx->args[0], ctx->args[1], timeout, error);

    return (*error) ? EXIT_FAILURE : EXIT_SUCCESS;
}

static gint
g_paste_merge (Context *ctx,
               GError **error)
{
    g_autofree gchar *uuid = g_paste_client_merge_sync (ctx->client, ctx->decoration, ctx->separator, ctx->args, error);

    return (*error) ? EXIT_FAILURE : EXIT_SUCCESS;
}

/*
 * Main
 */

/* Every verb GPaste answers to, in the order --help lists them. Carrying the
 * usage and the description here rather than in a second list is what stops a
 * verb from being added without them; tests/completions checks the shell
 * completions and the man page against it. */
typedef struct
{
    gint         argc;         /* argv count, verb included */
    const gchar *verb;         /* canonical name, NULL for the verb-less forms */
    const gchar *aliases;      /* space separated, or NULL */
    gint         extra_args;
    gboolean     needs_client;
    gboolean     reads_pipe;   /* takes its last argument from stdin when it is absent */
    gint         item_args;    /* leading item arguments, G_MAXINT for all */
    const gchar *args;         /* what --help shows after the verb */
    const gchar *doc;          /* untranslated */
    gint       (*handler) (Context *ctx,
                           GError **error);
} Command;

static const Command commands[] = {
        /* The verb-less forms, first: a flag with no verb at all, then a piped-in
         * item or, with nothing at all, the history. */
        { 0, NULL, NULL, G_MAXINT, FALSE, FALSE, 0,        NULL, NULL, g_paste_flag_action },
        { 0, NULL, NULL, 0,        TRUE,  TRUE,  0,        NULL, NULL, g_paste_add         },
        { 0, NULL, NULL, 0,        TRUE,  FALSE, 0,        NULL, NULL, g_paste_history     },

        { 1, "history",           "h",               0,        TRUE,  FALSE, 0,        NULL,                    N_ ("print the history with UUIDs"),                                                            g_paste_history },
        { 1, "history-size",      "hs",              0,        TRUE,  FALSE, 0,        NULL,                    N_ ("print the size of the current history"),                                                   g_paste_history_size },
        { 2, "search",            NULL,              0,        TRUE,  FALSE, 0,        "<pattern>",             N_ ("print the items of the history matching <pattern>"),                                       g_paste_search },
        { 1, "get-history",       "gh",              0,        TRUE,  FALSE, 0,        NULL,                    N_ ("get the name of the current history"),                                                     g_paste_get_history },
        { 2, "backup-history",    "bh",              1,        TRUE,  FALSE, 0,        "<name>",                N_ ("back up the current history"),                                                             g_paste_backup_history },
        { 2, "switch-history",    "sh",              0,        TRUE,  FALSE, 0,        "<name>",                N_ ("switch to another history"),                                                               g_paste_switch_history },
        { 1, "delete-history",    "dh",              1,        TRUE,  FALSE, 0,        "<name>",                N_ ("delete a history"),                                                                        g_paste_delete_history },
        { 1, "list-histories",    "lh",              0,        TRUE,  FALSE, 0,        NULL,                    N_ ("list available histories"),                                                                g_paste_list_histories },
        { 1, "add",               "a",               1,        TRUE,  TRUE,  0,        "<text>",                N_ ("set text to clipboard"),                                                                   g_paste_add },
        { 2, "add-password",      "ap",              1,        TRUE,  TRUE,  0,        "<name> <password>",     N_ ("add the <name> / <password> pair to the clipboard"),                                       g_paste_add_password },
        { 2, "get",               "g",               0,        TRUE,  FALSE, 1,        "<uuid>",                N_ ("get the item <uuid> from the history"),                                                    g_paste_get },
        { 2, "select",            "s set",           0,        TRUE,  FALSE, 1,        "<uuid>",                N_ ("set the item <uuid> from the history to the clipboard"),                                   g_paste_select },
        { 2, "replace",           NULL,              1,        TRUE,  TRUE,  1,        "<uuid> <contents>",     N_ ("replace the contents of the item <uuid> from the history with the provided one"),          g_paste_replace },
        { 2, "strip-rich-text",   "srt",             0,        TRUE,  FALSE, 1,        "<uuid>",                N_ ("drop the rich text flavours of the item <uuid>, keeping the plain text it shows"),          g_paste_strip_rich_text },
        { 4, "merge",             "m",               G_MAXINT, TRUE,  FALSE, G_MAXINT, "<uuid> … <uuid>",       N_ ("merge the items matching the UUIDs from the history and put the result in the clipboard"), g_paste_merge },
        { 3, "make-password",     "mp",              0,        TRUE,  FALSE, 1,        "<uuid> <name>",         N_ ("make the item <uuid> from the history a password named <name>, or update one that is"),    g_paste_make_password },
        { 2, "delete",            "d del rm remove", 0,        TRUE,  FALSE, 1,        "<uuid>",                N_ ("delete item <uuid> from the history"),                                                     g_paste_delete },
        { 2, "favourite",         "fav",             0,        TRUE,  FALSE, 1,        "<uuid>",                N_ ("pin item <uuid> so the history never drops it automatically"),                             g_paste_favourite },
        { 2, "unfavourite",       "unfav",           0,        TRUE,  FALSE, 1,        "<uuid>",                N_ ("unpin item <uuid>, letting the history drop it again"),                                    g_paste_unfavourite },
        { 2, "delete-password",   "dp",              0,        TRUE,  FALSE, 0,        "<name>",                N_ ("delete the password <name> from the history"),                                             g_paste_delete_password },
        { 2, "file",              "f",               0,        TRUE,  FALSE, 0,        "<path>",                N_ ("put the content of the file at <path> into the clipboard"),                                g_paste_file },
        { 1, "empty",             "e",               1,        TRUE,  FALSE, 0,        NULL,                    N_ ("empty the history"),                                                                       g_paste_empty },
        { 1, "start",             "d daemon",        0,        TRUE,  FALSE, 0,        NULL,                    N_ ("start tracking clipboard changes"),                                                        g_paste_start },
        { 1, "stop",              "q quit",          0,        TRUE,  FALSE, 0,        NULL,                    N_ ("stop tracking clipboard changes"),                                                         g_paste_stop },
        { 1, "daemon-reexec",     "dr",              0,        TRUE,  FALSE, 0,        NULL,                    N_ ("re-execute the daemon (after upgrading it, for instance)"),                                g_paste_daemon_reexec },
        { 1, "migrate",           NULL,              0,        TRUE,  FALSE, 0,        NULL,                    N_ ("migrate the history to a different storage backend"),                                      g_paste_migrate },
        { 1, "change-passphrase", NULL,              0,        TRUE,  FALSE, 0,        NULL,                    N_ ("change the passphrase of the encrypted history"),                                          g_paste_change_passphrase },
        { 1, "preferences",       "p settings",      0,        FALSE, FALSE, 0,        NULL,                    N_ ("launch the configuration tool"),                                                           g_paste_preferences },
        { 1, "ui",                NULL,              0,        FALSE, FALSE, 0,        NULL,                    N_ ("launch the graphical tool"),                                                               g_paste_ui },
        { 1, "show-history",      NULL,              0,        TRUE,  FALSE, 0,        NULL,                    N_ ("make the GNOME Shell extension display the history"),                                      g_paste_show_history },
        { 2, "upload",            "u",               0,        TRUE,  FALSE, 1,        "<uuid>",                N_ ("upload the item <uuid> to a pastebin service"),                                            g_paste_upload },
        { 2, "upload-and-copy",   "uc",              0,        TRUE,  FALSE, 1,        "<uuid>",                N_ ("upload the item <uuid> to a pastebin service, and copy its address"),                      g_paste_upload_and_copy },
        { 1, "version",           "v",               0,        FALSE, FALSE, 0,        NULL,                    N_ ("display the version"),                                                                     g_paste_version },
        { 1, "daemon-version",    "dv",              0,        TRUE,  FALSE, 0,        NULL,                    N_ ("display the daemon version"),                                                              g_paste_daemon_version },
        { 1, "help",              NULL,              0,        FALSE, FALSE, 0,        NULL,                    N_ ("display this help"),                                                                       g_paste_help },
        { 1, "about",             NULL,              0,        FALSE, FALSE, 0,        NULL,                    N_ ("display the about dialog"),                                                                g_paste_about },
};

/* Whether a command line takes its content from a pipe. Three verbs fall back
 * to it for a missing trailing argument, and the verb-less form is nothing but
 * a pipe -- they are the ones reading ctx->pipe_data, and the only reason to go
 * near stdin at all. Reading it for anything else would hang behind a pipe
 * nobody is going to write to or close, which is what a verb run from a script
 * with its stdin left open is.
 *
 * Which verbs those are is @reads_pipe on the row itself: a second list of them
 * here would be one more place to remember when a verb is added, and commands[]
 * is where a verb is described.
 *
 * The pipe stands in for an argument, so it is only wanted when that argument
 * is absent -- which is @command matching at its shortest, every one of these
 * taking the content last. */
static gboolean
command_reads_stdin (const Command *command,
                     gint           argc)
{
    return command->reads_pipe && argc == command->argc;
}

/* @verb is the canonical name or any of the aliases. */
static gboolean
command_matches (const Command *command,
                 const gchar   *verb)
{
    if (g_paste_str_equal (verb, command->verb))
        return TRUE;

    if (!command->aliases)
        return FALSE;

    for (const gchar *a = command->aliases; *a; )
    {
        const gchar *end = strchr (a, ' ');
        gsize len = (end) ? (gsize) (end - a) : strlen (a);

        if (!strncmp (verb, a, len) && !verb[len])
            return TRUE;

        a = (end) ? end + 1 : a + len;
    }

    return FALSE;
}

/* Whether @command is the row a command line of @argc arguments starting with
 * @verb dispatches to: the arity it takes, plus the verb when there is one.
 * Asked twice -- once before the dispatch, to know whether stdin is wanted, and
 * once by the dispatch itself -- and written once, so the two cannot answer
 * differently about the same command line. */
static gboolean
command_matches_line (const Command *command,
                      gint           argc,
                      const gchar   *verb)
{
    if (argc != command->argc && command->extra_args != G_MAXINT &&
        !(argc > command->argc && argc <= (command->argc + command->extra_args)))
        return FALSE;

    return !(argc > 0 && command->verb) || command_matches (command, verb);
}

static void
show_help (void)
{
    const char *progname = g_get_prgname ();

    printf (_("Usage:\n"));

    for (guint64 i = 0; i < G_N_ELEMENTS (commands); ++i)
    {
        const Command *c = &commands[i];

        if (!c->verb)
            continue;

        /* The history is what running with no verb at all does, so it is shown
         * the way it is actually reached. */
        if (g_paste_str_equal (c->verb, "history"))
            printf ("  %s [%s]: %s\n", progname, c->verb, _(c->doc));
        else if (c->args)
            printf ("  %s %s %s: %s\n", progname, c->verb, _(c->args), _(c->doc));
        else
            printf ("  %s %s: %s\n", progname, c->verb, _(c->doc));
    }

    /* Not a verb: the item comes in on stdin. */
    /* Translators: the metavariable standing for any command the user pipes into GPaste. */
    printf ("  %s | %s: %s\n", _("<command>"), progname, _("copy the output of <command> to the clipboard"));

    printf ("\n");
    printf (_("Convenience options:"));
    printf ("\n");
    /* Translators: help for --favourites */
    printf ("  --favourites: %s\n", _("only display the pinned items"));
    /* Translators: help for --timeout */
    printf ("  --timeout: %s\n", _("how long a password stays on the clipboard, in seconds; 0 for as long as anything else"));
    /* Translators: help for --use-index */
    printf ("  --use-index: %s\n", _("use the index of the item instead of its UUID"));

    printf ("\n");
    printf (_("Display options:"));
    printf ("\n");
    /* Translators: help for --oneline */
    printf ("  --oneline: %s\n", _("display each item on only one line"));
    /* Translators: help for --raw */
    printf ("  --raw: %s\n", _("display each item raw (without line numbers)"));
    /* Translators: help for --reverse */
    printf ("  --reverse: %s\n", _("display the items in reverse order"));
    /* Translators: help for --zero */
    printf ("  --zero: %s\n", _("use a NUL character instead of a new line between each item"));

    printf ("\n");
    printf (_("Merge options:"));
    printf ("\n");
    /* Translators: help for --decoration <string> */
    printf ("  --decoration <%s>: %s\n", _("string"), _("add the given decoration to the beginning and the end of each item before merging"));
    /* Translators: help for --separator <string> */
    printf ("  --separator <%s>: %s\n", _("string"), _("add the given separator between each item when merging"));
}

/* Whether this command line can reach a command that reads a pipe, tried with
 * the same match g_paste_dispatch () runs: the pipe has to be read before the
 * dispatch, since with no verb at all it is the presence of piped data that
 * decides between adding it and printing the history.
 *
 * The three handlers reading stdin themselves when their argument is missing
 * would behave the same -- the verb-less add already declines with nothing
 * piped, handing the line on to the history -- and would need neither this
 * pass nor @reads_pipe. It is kept on purpose: @reads_pipe makes which command
 * lines touch stdin a fact commands[] states, where every other property of a
 * verb lives (see AGENTS.md on single sources of truth), and a fact the client
 * test can check row by row without running a handler, a daemon or a pipe. A
 * handler reading on demand would make it something only running each verb can
 * tell. */
static gboolean
dispatch_reads_stdin (gint           argc,
                      const gchar   *verb,
                      const Context *ctx)
{
    /* A flag that is an action of its own answers with no verb at all, which is
     * the shape the verb-less add has too -- and its row comes first, so --help
     * and --version are answered before anything asks for a pipe. That order is
     * the half the loop below cannot express, matching rows rather than running
     * them. */
    if (ctx->help || ctx->version)
        return FALSE;

    /* A verb-less line carrying one of the listing's own flags is that listing,
     * answered without a look at stdin. A plain "gpaste-client" still reads it,
     * having nothing but the pipe to tell an add from a listing by. */
    if (argc == 0 && listing_flags_given (ctx))
        return FALSE;

    for (guint64 i = 0; i < G_N_ELEMENTS (commands); ++i)
    {
        const Command *c = &commands[i];

        if (command_matches_line (c, argc, verb) && command_reads_stdin (c, argc))
            return TRUE;
    }

    return FALSE;
}

/* Whether every string a command line carries -- its arguments, what is
 * piped in for one, merge's decoration and separator -- is UTF-8, as a D-Bus
 * string has to be. GLib would otherwise send "[Invalid UTF-8]" in its place,
 * and the daemon act on that: switch to a history of that name, or store a
 * password under it. A path is no exception: AddFile takes it as a string and
 * opens the file the string names, so one that is not UTF-8 cannot reach the
 * daemon at all, and converting it would name a file that is not there. */
static gboolean
check_utf8 (const Context *ctx,
            GError       **error)
{
    const gchar *options[] = { ctx->pipe_data, ctx->decoration, ctx->separator };
    gboolean valid = TRUE;

    for (gint i = 0; valid && i < ctx->argc; ++i)
        valid = g_utf8_validate (ctx->args[i], -1, NULL);
    for (guint i = 0; valid && i < G_N_ELEMENTS (options); ++i)
        valid = !options[i] || g_utf8_validate (options[i], -1, NULL);

    if (!valid)
        g_set_error_literal (error, G_PASTE_ERROR, G_PASTE_ERROR_INVALID_ARGUMENT, _("Cannot use arguments or input that are not valid UTF-8."));

    return valid;
}

/* The positions @command's leading item arguments name under --use-index,
 * every one of them checked before any is looked up.
 *
 * An index is a complete unsigned decimal number: g_ascii_strtoull () alone
 * would read "abc" as 0 and "1x" as 1, and act on items nobody named.
 * g_ascii_string_to_unsigned () refuses a sign or a space in front, but tells
 * a space by g_ascii_isspace (), which a vertical tab is not, while the
 * strtoull () beneath it skips one: the digit asked of the first character is
 * what keeps "\v-1" from reading as G_MAXUINT64. */
static GArray *
item_indexes (const Command *command,
              const Context *ctx,
              GError       **error)
{
    gint count = MIN (ctx->argc, command->item_args);
    g_autoptr (GArray) indexes = g_array_sized_new (FALSE, FALSE, sizeof (guint64), (guint) count);

    for (gint i = 0; i < count; ++i)
    {
        const gchar *arg = ctx->args[i];
        guint64 index = 0;

        if (!g_ascii_isdigit (*arg) || !g_ascii_string_to_unsigned (arg, 10, 0, G_MAXUINT64, &index, NULL))
        {
            g_set_error (error, G_PASTE_ERROR, G_PASTE_ERROR_INVALID_ARGUMENT, "Invalid item index: %s", arg);
            return NULL;
        }

        g_array_append_val (indexes, index);
    }

    return g_steal_pointer (&indexes);
}

/* The arguments a command runs with under --use-index: the leading ones
 * @indexes came from swapped for the uuids of the items at those positions,
 * and the others -- text, a pattern, a name, a path -- going through as they
 * are.
 *
 * Several indexes are all read off one listing of the history: looked up one
 * call at a time, a copy landing between two calls would shift every later
 * index by one, and a merge would take an item twice and skip another. A
 * single index cannot be caught that way, and its own lookup spares reading
 * the listing, which carries the text of every item. */
static GStrv
resolve_item_args (const Context *ctx,
                   GArray        *indexes,
                   GError       **error)
{
    g_autoptr (GStrvBuilder) builder = g_strv_builder_new ();

    if (indexes->len == 1)
    {
        g_autoptr (GPasteClientItem) item = g_paste_client_get_item_at_index_sync (ctx->client, g_array_index (indexes, guint64, 0), error);

        if (!item)
            return NULL;

        g_strv_builder_add (builder, g_paste_client_item_get_uuid (item));
    }
    else
    {
        g_autolist (GPasteClientItem) history = g_paste_client_get_history_sync (ctx->client, error);

        if (*error)
            return NULL;

        guint length = g_list_length (history);

        for (guint i = 0; i < indexes->len; ++i)
        {
            guint64 index = g_array_index (indexes, guint64, i);

            /* The error GetItemAtIndex answers past the end, so that one index
             * or several report it alike. */
            if (index >= length)
            {
                g_set_error (error, G_PASTE_ERROR, G_PASTE_ERROR_INVALID_INDEX, "No item at index %" G_GUINT64_FORMAT, index);
                return NULL;
            }

            g_strv_builder_add (builder, g_paste_client_item_get_uuid (g_list_nth_data (history, index)));
        }
    }

    for (gint i = (gint) indexes->len; i < ctx->argc; ++i)
        g_strv_builder_add (builder, ctx->args[i]);

    return g_strv_builder_end (builder);
}

static gint
g_paste_dispatch (gint         argc,
                  const gchar *verb,
                  Context     *ctx,
                  GError     **error)
{
    for (guint64 i = 0; i < G_N_ELEMENTS (commands); ++i)
    {
        const Command *c = &commands[i];

        if (command_matches_line (c, argc, verb))
        {
            g_autoptr (GArray) indexes = NULL;

            /* Only a command that talks to the daemon has its strings checked:
             * the launchers and the flag actions send nothing, and --help with
             * something stray after it still answers. */
            if (c->needs_client && !check_utf8 (ctx, error))
                return EXIT_FAILURE;

            if (ctx->use_index && c->item_args && ctx->argc)
            {
                indexes = item_indexes (c, ctx, error);
                if (!indexes)
                    return EXIT_FAILURE;
            }

            /* Building the client is what has D-Bus start the daemon, so it is
             * built for the commands that talk to it alone -- not for help,
             * version or a launcher -- and only once what they would send is
             * known to be well formed: refusing a malformed index or a string
             * that is not UTF-8 needs no daemon. */
            if (c->needs_client && !ctx->client)
            {
                ctx->client = g_paste_client_new_sync (error);
                if (!ctx->client)
                    return EXIT_FAILURE;
            }

            Context command_ctx = *ctx;
            g_auto (GStrv) resolved = NULL;

            if (indexes)
            {
                resolved = resolve_item_args (ctx, indexes, error);
                if (!resolved)
                    return EXIT_FAILURE;

                command_ctx.args = (const gchar **) resolved;
            }

            gint ret = c->handler (&command_ctx, error);
            if (ret >= 0)
                return ret;
        }
    }

    return -1;
}

gint
main (gint argc, gchar *argv[])
{
    G_PASTE_INIT_GETTEXT ();
    g_set_prgname (argv[0]);

    g_autoptr (GError) error = NULL;
    /* Every field starts empty, and says so once: a positional list has to be
     * recounted against the struct each time a member is added, and miscounting
     * it seeds a neighbouring flag instead — every field being a gboolean or a
     * pointer, nothing would say so. */
    Context ctx = { 0 };
    gint status = EXIT_SUCCESS;

    if (parse_cmdline (&argc, &argv, &ctx))
    {
        g_autofree gchar *pipe_data = NULL;

        /* Only where a pipe is what the command line is for: extract_pipe_data ()
         * reads stdin to its end, and an end is not something every caller is
         * going to provide (see command_reads_stdin ()). */
        if (dispatch_reads_stdin (argc, (argc > 0) ? argv[0] : NULL, &ctx))
            ctx.pipe_data = pipe_data = extract_pipe_data ();

        status = g_paste_dispatch (argc, (argc > 0) ? argv[0] : NULL, &ctx, &error);
        g_autoptr (GPasteClient) client = ctx.client;

        /* Nothing matched the command line at all: a verb we do not know, or one
         * we do with the wrong number of arguments after it. Say so the way a
         * bad option already does. Left alone, g_paste_dispatch ()'s "not mine"
         * sentinel travels out of main () as a status of its own -- 255 to a
         * shell, and not a word printed. */
        if (status < 0)
        {
            show_help ();
            status = EXIT_FAILURE;
        }

        if (error)
        {
            g_critical ("%s\n", error->message);
            status = EXIT_FAILURE;
        }
    }
    else
    {
        show_help ();
        status = EXIT_FAILURE;
    }

    return status;
}
