// SPDX-FileCopyrightText: 2010-2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com>
// SPDX-License-Identifier: BSD-2-Clause

#include <gpaste-daemon/gpaste-clipboards-manager.h>
#include <gpaste-daemon/gpaste-daemon-methods.h>
#include <gpaste-daemon/gpaste-daemon.h>
#include <gpaste-daemon/gpaste-history.h>
#include <gpaste-daemon/gpaste-keybinder.h>
#include <gpaste-daemon/gpaste-password-item.h>
#include <gpaste-daemon/gpaste-prompt.h>
#include <gpaste-daemon/gpaste-screensaver-client.h>
#include <gpaste-daemon/gpaste-storage-backend.h>
#include <gpaste-daemon/gpaste-storage-migration.h>
#include <gpaste-daemon/gpaste-text-item.h>
#include <gpaste-daemon/gpaste-global-shortcut-client.h>

#ifdef G_PASTE_ENABLE_GNOME_SHELL
#include <gpaste-daemon/gpaste-clipboard-meta.h>
#endif

#include <gio/gunixoutputstream.h>
#include <glib-unix.h>
#include <string.h>

struct _GPasteDaemon
{
    GPasteBusObject parent_instance;

    GPasteDaemon3           *skeleton;
    gboolean                 registered;
    guint                    startup_changed_id;

    GPasteHistory           *history;
    GPasteSettings          *settings;
    GPasteClipboardsManager *clipboards_manager;
    GPasteKeybinder         *keybinder;
    GPasteScreensaverClient *screensaver;

    GSignalGroup            *history_signals;
    GSignalGroup            *settings_signals;
    GSignalGroup            *screensaver_signals;

    /* Built by g_paste_daemon_new_meta (), for gnome-shell: see
     * g_paste_daemon_reexecute_after_expiry (). */
    gboolean                 in_process;

    /* The uploads out (UploadData), borrowed from their tasks: what leaving the
     * bus ends (g_paste_daemon_cancel_uploads ()). */
    GList                   *uploads;
};

G_PASTE_DEFINE_TYPE (Daemon, daemon, G_PASTE_TYPE_BUS_OBJECT)

enum
{
    REEXECUTE_SELF,
    CHANGE_PASSPHRASE,

    LAST_SIGNAL
};

static guint signals[LAST_SIGNAL] = { 0 };

/* The context the free-standing method handlers work on. Declared as a local so
 * it always mirrors the daemon's current state, and named the same way at every
 * call site so the handlers below read as one shape. */
#define G_PASTE_DAEMON_METHODS(self)    \
    {                                   \
        (self)->skeleton,               \
        (self)->history,                \
        (self)->settings,               \
        (self)->clipboards_manager      \
    }

/****************/
/* DBus Signals */
/****************/

/* The enums travel as their own values: the nicks are the storage backends'
 * spelling of an enum, and nothing on the wire has to share it. */
static void
g_paste_daemon_update (GPasteDaemon      *self,
                       GPasteUpdateAction action,
                       GPasteUpdateTarget target,
                       const gchar       *uuid,
                       guint64            position)
{
    g_paste_daemon3_emit_raw_update (self->skeleton, action, target, uuid, position);
}

/**
 * g_paste_daemon_show_history:
 * @self: (transfer none): the #GPasteDaemon
 * @error: return location for a #GError, or %NULL
 *
 * Emit the signal to show history
 *
 * This never fails: handing the signal to the exported interface is all it does,
 * and that reports nothing back. @error is left untouched, and is only still
 * here because callers pass one.
 */
G_PASTE_VISIBLE void
g_paste_daemon_show_history (GPasteDaemon *self,
                             GError      **error G_GNUC_UNUSED)
{
    g_return_if_fail (G_PASTE_IS_DAEMON (self));

    g_paste_daemon3_emit_raw_show_history (self->skeleton);
}

/**
 * g_paste_daemon_flush:
 * @self: (transfer none): the #GPasteDaemon
 *
 * Persist every pending history change and wait for it to hit the disk, then
 * stop recording. Meant for an exit/handover path (the daemon losing its name to
 * a takeover, or being told to stop): once this returns the on-disk history is up
 * to date, so a successor daemon can load it without losing the last changes.
 */
G_PASTE_VISIBLE void
g_paste_daemon_flush (GPasteDaemon *self)
{
    g_return_if_fail (G_PASTE_IS_DAEMON (self));

    g_paste_history_flush (self->history);
}

/**
 * g_paste_daemon_resume:
 * @self: (transfer none): the #GPasteDaemon
 *
 * Undo a previous g_paste_daemon_flush(): resume recording. Meant for a handover
 * that did not happen (e.g. a re-exec whose exec failed), so the daemon that is
 * still running keeps persisting the history.
 */
G_PASTE_VISIBLE void
g_paste_daemon_resume (GPasteDaemon *self)
{
    g_return_if_fail (G_PASTE_IS_DAEMON (self));

    g_paste_history_resume (self->history);
}

/**
 * g_paste_daemon_expire_password:
 * @self: (transfer none): the #GPasteDaemon
 *
 * Retire the passwords a countdown is running for from the history before a host
 * flushes it, and remove them from selections as soon as their pending reads
 * establish ownership.
 *
 * Meant for a daemon standing down inside a process that keeps going: dropping
 * the daemon takes its clipboards manager with it, and that manager's dispose
 * does exactly this -- but only once the last reference to it is actually gone,
 * which for the gnome-shell host is whenever the garbage collector gets round
 * to the wrapper. Until then mutter goes on serving the selection source we
 * published, and for a password that source holds its cleartext.
 *
 * A selection running no countdown has nothing to bring forward and is left as
 * it is: password-timeout defaults to 0, which is a password the user asked to
 * keep for as long as anything else, so on a stock install this takes nothing
 * off -- see g_paste_clipboards_manager_expire_password ().
 *
 * Deliberately not part of g_paste_daemon_flush(): that one is also how a live
 * daemon persists before re-reading its store (a passphrase change, an
 * on-demand migration), and yanking a password off the clipboard there would be
 * expiring it for something that is not an exit at all. A standalone daemon
 * needs neither, its selections dying with the process. Pending reads retain
 * the cleanup until they finish; re-exec awaits the manager's async variant
 * before replacing the process and losing those callbacks.
 */
G_PASTE_VISIBLE void
g_paste_daemon_expire_password (GPasteDaemon *self)
{
    g_return_if_fail (G_PASTE_IS_DAEMON (self));

    g_paste_clipboards_manager_expire_password (self->clipboards_manager);
}

/**
 * g_paste_daemon_reload_storage:
 * @self: (transfer none): the #GPasteDaemon
 *
 * Reload the history from its storage backend, rebuilding that backend from the
 * (possibly changed) "storage-backend" setting. Meant to be called after an
 * on-demand storage migration has rewritten the store on disk, so the live
 * daemon picks up the new backend without a full re-exec. Assumes the caller
 * flushed first (see g_paste_daemon_flush()); used by the gnome-shell host,
 * where the daemon cannot re-exec itself.
 */
G_PASTE_VISIBLE void
g_paste_daemon_reload_storage (GPasteDaemon *self)
{
    g_return_if_fail (G_PASTE_IS_DAEMON (self));

    g_paste_history_reload_backend (self->history);
}

/**
 * g_paste_daemon_extension_state_changed:
 * @self: (transfer none): the #GPasteDaemon
 * @state: whether the gnome-shell extension is there
 *
 * Same as the ReportExtensionState D-Bus method, for a host that runs the
 * daemon in its own process: the gnome-shell extension being disabled is also
 * what tears its daemon down, so the D-Bus call it would otherwise make is
 * dispatched — if at all — against a name it has already released. Applied
 * straight away here instead, so the "track-extension-state" policy is not lost
 * on the one path that has no daemon left to reach afterwards.
 */
G_PASTE_VISIBLE void
g_paste_daemon_extension_state_changed (GPasteDaemon *self,
                                        gboolean      state)
{
    g_return_if_fail (G_PASTE_IS_DAEMON (self));

    const GPasteDaemonMethods methods = G_PASTE_DAEMON_METHODS (self);

    g_paste_daemon_methods_extension_state_changed (&methods, state);
}

/* Connected swapped to notify::track-changes, so @settings is the emitter: the
 * new state is read back from it rather than carried by the signal. Tracking on
 * again, however it came about -- the preferences write the key themselves --
 * leaves no pause of the extension's for its return to undo. Cleared only when
 * set: this runs at every export too, and a write is a dconf round trip and a
 * change every process watching the schema hears, the same value or not. */
static void
g_paste_daemon_tracking (GPasteDaemon   *self,
                         GParamSpec     *pspec G_GNUC_UNUSED,
                         GPasteSettings *settings)
{
    gboolean tracking = g_paste_settings_get_track_changes (settings);

    g_paste_daemon3_set_active (self->skeleton, tracking);
    if (tracking && g_paste_settings_get_extension_paused (settings))
        g_paste_settings_set_extension_paused (settings, FALSE);
}

/********************/
/* Daemon controls  */
/********************/

/* The Reexecute invocation travels the whole way down here because it is not
 * answered on the way out: execl() replaces this process before it could, and
 * that missing reply is what a caller reads as the expected success
 * (g_paste_util_reexecute_daemon()). Answered only when there will be no exec.
 * NULL for a re-exec nobody asked for over the bus (g_paste_daemon_reexecute()).
 *
 * The daemon is held weakly: the task this rides in sits in the list of the
 * daemon's own clipboards manager, and a strong reference here would be the
 * daemon holding itself up until the reads it waits on resolve -- see AGENTS.md
 * on what an object tracks so that its own dispose() can end it. */
typedef struct
{
    GWeakRef               daemon;
    GDBusMethodInvocation *invocation;
    gint64                 deadline;
} ReexecuteData;

static void
reexecute_data_free (ReexecuteData *data)
{
    g_weak_ref_clear (&data->daemon);
    g_free (data);
}

G_DEFINE_AUTOPTR_CLEANUP_FUNC (ReexecuteData, reexecute_data_free)

static void
reexecute_stood_down (GDBusMethodInvocation *invocation)
{
    if (!invocation)
        return;

    g_dbus_method_invocation_return_error (invocation,
                                           G_PASTE_ERROR,
                                           G_PASTE_ERROR_FAILED,
                                           "The daemon stood down before it could re-execute.");
}

/* An exec waits for a storage worker rewriting the store to be done
 * (g_paste_storage_is_busy ()), which can take minutes: a request over the bus
 * is refused meanwhile, rather than answered for an exec that has not happened
 * and may never -- its later failures having no one left to tell. One without
 * an invocation (SIGUSR1) is the host's to carry out once the worker is done,
 * through g_paste_daemon_reexecute () again. Nothing execs in gnome-shell. */
static gboolean
g_paste_daemon_reexecute_refused (GPasteDaemon          *self,
                                  GDBusMethodInvocation *invocation)
{
    if (self->in_process || !invocation || !g_paste_storage_is_busy ())
        return FALSE;

    g_dbus_method_invocation_return_error_literal (invocation, G_IO_ERROR, G_IO_ERROR_BUSY,
                                                   "The history storage is being rewritten; re-execute once that is done");
    return TRUE;
}

static void g_paste_daemon_cancel_uploads (GPasteDaemon *self);

static void
g_paste_daemon_reexecute_now (GPasteDaemon          *self,
                              GDBusMethodInvocation *invocation)
{
    if (g_paste_daemon_reexecute_refused (self, invocation))
        return;

    g_paste_clipboards_manager_store (self->clipboards_manager);

    /* An exec replaces this process with one that has no idea of the commands
     * it left running, so their uploads end here -- for good, should the exec
     * fail and this daemon carry on. Nothing execs in gnome-shell, which keeps
     * them, and a host waiting on the store execs later, cancelling them then. */
    if (!self->in_process && !g_paste_storage_is_busy ())
        g_paste_daemon_cancel_uploads (self);

    gboolean accepted = FALSE;

    g_signal_emit (self,
                   signals[REEXECUTE_SELF],
                   0, /* detail */
                   &accepted);

    /* A standalone exec never returns on success. The in-process Shell host
     * accepts deferred migration explicitly; FALSE reports a host failure. */
    if (invocation)
    {
        if (accepted)
            g_paste_daemon3_complete_reexecute (self->skeleton, invocation);
        else
        {
            g_dbus_method_invocation_return_error (invocation, G_PASTE_ERROR, G_PASTE_ERROR_FAILED,
                                                   "The daemon host could not re-execute.");
        }
    }
}

static void
on_reexecute_passwords_expired (GObject      *source_object G_GNUC_UNUSED,
                                GAsyncResult *result,
                                gpointer      user_data)
{
    g_autoptr (ReexecuteData) data = user_data;

    g_autoptr (GPasteDaemon) self = g_weak_ref_get (&data->daemon);

    /* The task carries no source object (the manager's own list holds it), so
     * the manager comes from the daemon -- which can have been finalized or
     * disposed while the reads were still out, and then there is no re-exec
     * left to do. */
    if (!self || !self->clipboards_manager)
    {
        reexecute_stood_down (data->invocation);
        return;
    }

    g_autoptr (GError) error = NULL;

    if (!g_paste_clipboards_manager_expire_password_finish (self->clipboards_manager, result, &error))
    {
        if (g_error_matches (error, G_IO_ERROR, G_IO_ERROR_PENDING) && g_get_monotonic_time () < data->deadline)
        {
            g_paste_clipboards_manager_expire_password_async (self->clipboards_manager,
                                                              on_reexecute_passwords_expired,
                                                              g_steal_pointer (&data));
            return;
        }

        if (data->invocation)
        {
            g_dbus_method_invocation_return_error (data->invocation, G_PASTE_ERROR, G_PASTE_ERROR_FAILED,
                                                   "Could not expire passwords before restarting: %s", error->message);
        }
        else
            g_warning ("Could not expire passwords before restarting: %s", error->message);
        return;
    }

    g_paste_daemon_reexecute_now (self, data->invocation);
}

static void
g_paste_daemon_reexecute_after_expiry (GPasteDaemon          *self,
                                       GDBusMethodInvocation *invocation)
{
    if (!self->clipboards_manager)
    {
        reexecute_stood_down (invocation);
        return;
    }

    /* Nothing execs in gnome-shell: reexecute-self is an in-place storage
     * migration there, or nothing at all, and this very daemon goes on taking
     * passwords off. A countdown brought forward would take one off early for
     * no restart. */
    if (self->in_process)
    {
        g_paste_daemon_reexecute_now (self, invocation);
        return;
    }

    /* Before any countdown is brought forward for it. */
    if (g_paste_daemon_reexecute_refused (self, invocation))
        return;

    /* Storing preserves the selection across exec. Await classification and
     * expiry first, so the successor inherits no unmonitored password. */
    ReexecuteData *data = g_new0 (ReexecuteData, 1);

    g_weak_ref_init (&data->daemon, self);
    data->invocation = invocation;
    /* Retry a completion invalidated by a new copy for at most thirty seconds.
     * Each wait has its own sixty-second bound, keeping the entire request
     * below the client's two-minute allowance. */
    data->deadline = g_get_monotonic_time () + 30 * G_USEC_PER_SEC;
    g_paste_clipboards_manager_expire_password_async (self->clipboards_manager,
                                                      on_reexecute_passwords_expired,
                                                      data);
}

/**
 * g_paste_daemon_reexecute:
 * @self: (transfer none): the #GPasteDaemon
 *
 * Re-execute the daemon the way the Reexecute method does, for a request that
 * did not come over the bus -- SIGUSR1, which is also what gpaste-client falls
 * back on only when that method reports UnknownMethod. It has to go through
 * the same wait: an exec straight away hands the successor whatever password
 * the reads still being classified were about to take off, unmonitored.
 */
G_PASTE_VISIBLE void
g_paste_daemon_reexecute (GPasteDaemon *self)
{
    g_return_if_fail (G_PASTE_IS_DAEMON (self));

    g_paste_daemon_reexecute_after_expiry (self, NULL);
}

/* The prompts a passphrase change needs are the host's job (each has its own
 * GPastePrompt backend), so this only asks. The new passphrase never travels
 * over the bus: it is typed into the host's prompt.
 *
 * Refused outright when there is no passphrase to change, so a host never stops
 * recording and raises a dialog only to be told there was nothing to do -- and
 * for a store this build cannot open, whose re-key would be refused after the
 * host had flushed and reloaded around it. Refused with %G_IO_ERROR_BUSY while a
 * daemon this one took over from may still be writing the stores, which every
 * one of them a re-key rewrites (see g_paste_history_check_store_owned ()). */
static void
g_paste_daemon_change_passphrase (GPasteDaemon *self,
                                  GError      **error)
{
    GPasteStorage storage = g_paste_settings_get_storage_backend (self->settings);

    G_PASTE_DBUS_ASSERT (g_paste_storage_is_encrypted (storage),
                         G_PASTE_ERROR_NOT_ENCRYPTED,
                         "The history is not encrypted; there is no passphrase to change.");
    G_PASTE_DBUS_ASSERT (g_paste_prompt_storage_is_offered (storage),
                         G_PASTE_ERROR_FAILED,
                         "This build cannot open the history to change its passphrase.");

    if (!g_paste_storage_backend_try_lock ())
    {
        g_set_error_literal (error, G_IO_ERROR, G_IO_ERROR_BUSY, "Another GPaste daemon is still writing the history storage");
        return;
    }

    g_signal_emit (self,
                   signals[CHANGE_PASSPHRASE],
                   0, /* detail */
                   NULL);
}

/* How long the "upload-command" is given to answer. It is a command line the
 * user wrote, so nothing about it promises to exit: a curl with no timeout of
 * its own against an unreachable host, or an "nc host port" that never gets its
 * connection closed, waits for as long as the process lives -- and with it the
 * task, the child, and the pipes the daemon opened for it.
 *
 * Nothing secret waits with them: Upload takes a text item alone, a password
 * being refused before anything runs (g_paste_daemon_upload ()).
 *
 * Comfortably inside the ten minutes GPasteClient allows either upload call, so
 * what the caller is told is the deadline that ran out rather than a proxy
 * giving up on a daemon that never answered.
 *
 * Elapsed time and not silence, unlike the clipboard read guard: an upload
 * reports nothing until it is done, so there is no progress to measure. */
#define G_PASTE_DAEMON_UPLOAD_TIMEOUT (9 * 60)

/* The most the command's answer is read of: a url is one line, and a command
 * still writing past this is not answering one -- a "yes", a tool stuck in a
 * verbose loop -- which unbounded would grow the daemon until the deadline, or
 * until the system ran out of memory first. */
#define G_PASTE_DAEMON_UPLOAD_MAX_ANSWER 8192

/* What one upload has out: the item going in on the command's stdin, its answer
 * coming back on its stdout and its exit, all three at once -- a command writing
 * as it reads would otherwise fill one pipe while the other waits. Held as the
 * task's data, so its life is the task's; the deadline reaches it there, and
 * the last of the three to come back judges the upload. */
typedef struct
{
    GSubprocess  *upload;      /* the deadline has to be able to kill it */
    GCancellable *cancellable;
    guint         timeout_id;
    GBytes       *item;        /* the value going in, holding its item */
    guint         pending;     /* the write, the read and the exit still out */
    gboolean      timed_out;
    gboolean      overflowed;
    GError       *read_error;
    gsize         answered;
    gchar         answer[G_PASTE_DAEMON_UPLOAD_MAX_ANSWER + 1];
} UploadData;

static void
upload_data_free (UploadData *data)
{
    g_clear_handle_id (&data->timeout_id, g_source_remove);
    g_clear_object (&data->upload);
    g_clear_object (&data->cancellable);
    g_clear_pointer (&data->item, g_bytes_unref);
    g_clear_error (&data->read_error);
    g_free (data);
}

G_DEFINE_AUTOPTR_CLEANUP_FUNC (UploadData, upload_data_free)

static void
on_upload_timed_out (gpointer user_data)
{
    UploadData *data = user_data;

    data->timeout_id = 0;
    data->timed_out = TRUE;

    /* The cancel gives up the write and the read, and the kill is what ends the
     * exit's wait: the command is not trusted to stop on its own, its pipes
     * closing included. */
    g_cancellable_cancel (data->cancellable);
    g_subprocess_force_exit (data->upload);
}

/* Judged once all three are back, from how the command ended and what it
 * answered. */
static void
g_paste_daemon_upload_done (GTask *task)
{
    UploadData *data = g_task_get_task_data (task);

    if (--data->pending)
        return;

    GPasteDaemon *self = g_task_get_source_object (task);

    self->uploads = g_list_remove (self->uploads, data);

    /* Whatever the answer is, it has arrived, so there is nothing left for the
     * deadline to cut off. */
    g_clear_handle_id (&data->timeout_id, g_source_remove);

    /* What the command wrote before it was killed is not an answer, and "the
     * upload command failed" would read as one it gave. */
    if (data->timed_out)
    {
        g_task_return_new_error (task, G_PASTE_ERROR, G_PASTE_ERROR_FAILED,
                                 "The upload command did not answer within %d seconds.",
                                 G_PASTE_DAEMON_UPLOAD_TIMEOUT);
        return;
    }

    /* Given up on by the daemon going away (g_paste_daemon_cancel_uploads ()):
     * the kill that ended the command is not an answer it gave, and nobody is
     * left to put an address anywhere. */
    if (g_cancellable_is_cancelled (data->cancellable))
    {
        g_task_return_new_error (task, G_IO_ERROR, G_IO_ERROR_CANCELLED, "The upload was given up on, the daemon going away.");
        return;
    }

    if (data->overflowed)
    {
        g_task_return_new_error (task, G_PASTE_ERROR, G_PASTE_ERROR_FAILED,
                                 "The upload command answered more than %d bytes, which is no url.",
                                 G_PASTE_DAEMON_UPLOAD_MAX_ANSWER);
        return;
    }

    if (data->read_error)
    {
        g_task_return_error (task, g_steal_pointer (&data->read_error));
        return;
    }

    GSubprocess *upload = data->upload;

    /* Reading the output and seeing the command exit is all the three above
     * answer for: a command that exited non-zero got that far too, and what it
     * wrote on the way out is a diagnostic rather than an address.
     *
     * How it ended and not what it wrote: the item's text went in on that
     * command's standard input, and a tool that hands its input back when it
     * fails -- a misconfigured "cat", a curl given an error page that quotes the
     * request body -- would put what the user copied in an error that travels to
     * the caller over the bus and into the journal behind it. What the command
     * wrote is the user's to look at by running their own command line. */
    if (!g_subprocess_get_successful (upload))
    {
        if (g_subprocess_get_if_signaled (upload))
        {
            g_task_return_new_error (task, G_PASTE_ERROR, G_PASTE_ERROR_FAILED,
                                     "The upload command was killed by signal %d.",
                                     g_subprocess_get_term_sig (upload));
            return;
        }

        g_task_return_new_error (task, G_PASTE_ERROR, G_PASTE_ERROR_FAILED,
                                 "The upload command exited with status %d.",
                                 g_subprocess_get_exit_status (upload));
        return;
    }

    /* Reported without quoting it, for the reason the exit above is: a command
     * that hands its own input back answers something that is not a url, and
     * that something is the item. */
    if (!g_utf8_validate (data->answer, (gssize) data->answered, NULL))
    {
        g_task_return_new_error (task, G_PASTE_ERROR, G_PASTE_ERROR_FAILED,
                                 "The upload command answered something that is not a url.");
        return;
    }

    /* The command answers the url on stdout, with the newline it ended the line
     * with; anything else means it did not upload. */
    g_autofree gchar *url = g_strstrip (g_strndup (data->answer, data->answered));

    if (!*url)
    {
        g_task_return_new_error (task, G_PASTE_ERROR, G_PASTE_ERROR_FAILED, "The pastebin service answered no url.");
        return;
    }

    /* "upload-command" is a command line the user wrote, so a tool that is
     * misconfigured, out of date or simply not a pastebin client at all answers
     * with its usage, or with the body of an HTTP error, on the very stream the
     * url was meant to come back on. Unchecked, that lands on the clipboard and
     * in the history as though it were an address. Being a valid uri does not
     * tell the two apart -- a scheme and a colon is the whole of what that
     * takes, so "Usage:", "curl:" and "Error: 429 Too Many Requests" all pass
     * -- so the scheme has to be one a browser can open, not merely present.
     *
     * Nor does g_uri_is_valid () refuse what may follow a url: a line break, a
     * space, an escape sequence. Whoever answers the command -- the pastebin,
     * for the default one -- would then have whatever it put after the address
     * pasted as the link, a second line run by the terminal it lands in, so a
     * url is one run of visible characters. */
    const gchar *scheme = g_uri_peek_scheme (url);
    gboolean visible = TRUE;

    for (const gchar *c = url; visible && *c; c = g_utf8_next_char (c))
    {
        gunichar u = g_utf8_get_char (c);

        visible = !g_unichar_isspace (u) && !g_unichar_iscntrl (u) && g_unichar_type (u) != G_UNICODE_FORMAT;
    }

    if (!visible || !g_uri_is_valid (url, G_URI_FLAGS_NONE, NULL) ||
        (!g_paste_str_equal (scheme, "http") && !g_paste_str_equal (scheme, "https")))
    {
        g_task_return_new_error (task, G_PASTE_ERROR, G_PASTE_ERROR_FAILED,
                                 "The upload command answered something that is not a url.");
        return;
    }

    g_task_return_pointer (task, g_steal_pointer (&url), g_free);
}

/* The item in, then the end of it. A command that answers before reading all
 * of it -- one that only needs the start, or a pipeline that stops reading --
 * leaves the write a broken pipe, which says it stopped reading and nothing
 * about the upload: how it exited and what it answered say that. */
static void
on_upload_written (GObject      *source_object,
                   GAsyncResult *res,
                   gpointer      user_data)
{
    GOutputStream *stdin_pipe = G_OUTPUT_STREAM (source_object);
    g_autoptr (GTask) task = user_data;

    g_output_stream_write_all_finish (stdin_pipe, res, NULL, NULL);
    g_output_stream_close (stdin_pipe, NULL, NULL);
    g_paste_daemon_upload_done (task);
}

static void
on_upload_read (GObject      *source_object,
                GAsyncResult *res,
                gpointer      user_data)
{
    g_autoptr (GTask) task = user_data;
    UploadData *data = g_task_get_task_data (task);
    g_autoptr (GError) error = NULL;

    if (!g_input_stream_read_all_finish (G_INPUT_STREAM (source_object), res, &data->answered, &error) &&
        !g_error_matches (error, G_IO_ERROR, G_IO_ERROR_CANCELLED))
        data->read_error = g_steal_pointer (&error);

    /* A full buffer is a command still writing, and one whose answer can no
     * longer be read is one with nothing left to say: either way it is killed,
     * which is what ends the wait for its exit. */
    data->overflowed = (data->answered > G_PASTE_DAEMON_UPLOAD_MAX_ANSWER);
    if (data->overflowed || data->read_error)
        g_subprocess_force_exit (data->upload);

    g_paste_daemon_upload_done (task);
}

/* Waited for with no cancellable: the deadline's kill is what ends it, so the
 * command is never left running with nothing waiting for it. */
static void
on_upload_exited (GObject      *source_object,
                  GAsyncResult *res,
                  gpointer      user_data)
{
    g_autoptr (GTask) task = user_data;

    g_subprocess_wait_finish (G_SUBPROCESS (source_object), res, NULL);
    g_paste_daemon_upload_done (task);
}

/* Each upload out given up on and its command killed, which brings all three of
 * its parts back at once: what answers it then is the cancellation. */
static void
g_paste_daemon_cancel_uploads (GPasteDaemon *self)
{
    for (const GList *u = self->uploads; u; u = u->next)
    {
        UploadData *data = u->data;

        g_cancellable_cancel (data->cancellable);
        g_subprocess_force_exit (data->upload);
    }
}

/**
 * g_paste_daemon_upload:
 * @self: (transfer none): the #GPasteDaemon
 * @uuid: the uuid of the item to upload, or "" (or %NULL) for the current one
 * @callback: (nullable): a #GAsyncReadyCallback to call once the upload is done
 * @user_data: (nullable): the data to pass to @callback
 *
 * Upload an item to a pastebin service.
 *
 * The tool doing the uploading is the "upload-command" setting: a command line
 * that takes the item on stdin and answers its url on stdout.
 *
 * The upload is what this waits for, not merely the spawning of the tool that
 * performs it: the url only exists once it has finished, and an upload that
 * failed is what @callback is told about. What to do with the url is the
 * caller's business -- nothing is added to the history here.
 */
G_PASTE_VISIBLE void
g_paste_daemon_upload (GPasteDaemon       *self,
                       const gchar        *uuid,
                       GAsyncReadyCallback callback,
                       gpointer            user_data)
{
    g_return_if_fail (G_PASTE_IS_DAEMON (self));

    g_autoptr (GTask) task = g_task_new (self, NULL, callback, user_data);

    g_task_set_source_tag (task, g_paste_daemon_upload);

    /* No uuid means the current item, which is what the keyboard shortcut
     * uploads. It travels as an empty string rather than as nothing, a D-Bus
     * string never being absent. */
    GPasteItem *item = (uuid && *uuid) ? g_paste_history_get_by_uuid (self->history, uuid) : g_paste_history_get (self->history, 0);

    if (!item)
    {
        g_task_return_new_error (task, G_PASTE_ERROR, G_PASTE_ERROR_NOT_FOUND, "Provided uuid doesn't match any item.");
        return;
    }

    /* A pastebin takes text, and every other kind's value is something else
     * than what the user picked: an image's is the checksum naming its file, a
     * password's the placeholder standing for it. */
    if (!G_PASTE_IS_TEXT_ITEM (item))
    {
        g_task_return_new_error (task, G_PASTE_ERROR, G_PASTE_ERROR_WRONG_ITEM_KIND, "Only a text item can be uploaded.");
        return;
    }

    const gchar *command = g_paste_settings_get_upload_command (self->settings);

    if (!command || !*command)
    {
        g_task_return_new_error (task, G_PASTE_ERROR, G_PASTE_ERROR_INVALID_ARGUMENT,
                                 "No upload command is configured; see the \"upload-command\" setting.");
        return;
    }

    /* Parsed the way a shell would, so the setting can carry arguments
     * ("pastebinit -b …"), but handed to the kernel as an argv rather than to a
     * shell: a clipboard item reaching a shell as anything but stdin is not a
     * risk worth taking for the pipes and globs nobody needs here. */
    g_autoptr (GError) error = NULL;
    g_auto (GStrv) argv = NULL;

    if (!g_shell_parse_argv (command, NULL, &argv, &error))
    {
        g_task_return_new_error (task, G_PASTE_ERROR, G_PASTE_ERROR_INVALID_ARGUMENT,
                                 "Could not parse the upload command \"%s\": %s", command, error->message);
        return;
    }

    GSubprocess *upload = g_subprocess_newv ((const gchar * const *) argv,
                                             G_SUBPROCESS_FLAGS_STDIN_PIPE|G_SUBPROCESS_FLAGS_STDOUT_PIPE,
                                             &error);

    if (!upload)
    {
        g_task_return_new_error (task, G_PASTE_ERROR, G_PASTE_ERROR_FAILED, "Failed to spawn \"%s\": %s", command, error->message);
        return;
    }

    g_autoptr (UploadData) data = g_new0 (UploadData, 1);

    data->upload = upload;
    data->cancellable = g_cancellable_new ();
    /* The item's own string, which never changes once in the history, held
     * through a reference on the item rather than copied: the history may drop
     * the item while the command still reads it. */
    const gchar *value = g_paste_item_get_value (item);

    data->item = g_bytes_new_with_free_func (value, strlen (value), g_object_unref, g_object_ref (item));
    data->pending = 3;
    data->timeout_id = g_timeout_add_seconds_once (G_PASTE_DAEMON_UPLOAD_TIMEOUT,
                                                   on_upload_timed_out,
                                                   data);
    g_source_set_name_by_id (data->timeout_id, "[GPaste] upload command deadline");

    gsize length;
    gconstpointer bytes = g_bytes_get_data (data->item, &length);
    GCancellable *cancellable = data->cancellable;
    gchar *answer = data->answer;

    /* The task holds the daemon, as any GIO call holds the object it was
     * started on, where what a daemon's teardown has to end would otherwise hold
     * it weakly: callers read the daemon off the result, and the teardown every
     * host runs -- leaving the bus, which dispose does too -- is reachable with
     * that reference held. It ends the upload there, through
     * g_paste_daemon_cancel_uploads (), so the reference goes one main loop turn
     * later; a host doing neither waits out the deadline at most. */
    self->uploads = g_list_prepend (self->uploads, data);
    g_task_set_task_data (task, g_steal_pointer (&data), (GDestroyNotify) upload_data_free);

    GOutputStream *input = g_subprocess_get_stdin_pipe (upload);

    /* Written to without blocking, as g_subprocess_communicate () does: a write
     * to a blocking pipe runs right here, on the main loop -- gnome-shell's, for
     * the in-shell daemon -- until the command has read all but the last
     * pipe-full of the item, and forever when it never does, the deadline and
     * the answer's bound waiting on that very loop. */
    g_unix_set_fd_nonblocking (g_unix_output_stream_get_fd (G_UNIX_OUTPUT_STREAM (input)), TRUE, NULL);
    g_output_stream_write_all_async (input, bytes, length, G_PRIORITY_DEFAULT,
                                     cancellable, on_upload_written, g_object_ref (task));
    g_input_stream_read_all_async (g_subprocess_get_stdout_pipe (upload), answer, G_PASTE_DAEMON_UPLOAD_MAX_ANSWER + 1, G_PRIORITY_DEFAULT,
                                   cancellable, on_upload_read, g_object_ref (task));
    g_subprocess_wait_async (upload, NULL, on_upload_exited, g_steal_pointer (&task));
}

/**
 * g_paste_daemon_upload_finish:
 * @self: (transfer none): the #GPasteDaemon
 * @result: the #GAsyncResult handed to the callback
 * @error: return location for a #GError, or %NULL
 *
 * Finish an upload started with g_paste_daemon_upload().
 *
 * Errors are in %G_PASTE_ERROR (%G_PASTE_ERROR_NOT_FOUND for a uuid matching
 * nothing, %G_PASTE_ERROR_WRONG_ITEM_KIND for an item that is not a text,
 * %G_PASTE_ERROR_INVALID_ARGUMENT for an "upload-command" that is
 * empty or does not parse, %G_PASTE_ERROR_FAILED when the tool could not be run
 * or answered something that is not a url), %G_IO_ERROR_CANCELLED for an upload
 * the daemon left the bus with still out, or whatever running it reported.
 *
 * Returns: (transfer full) (nullable): the url the item was uploaded to
 */
G_PASTE_VISIBLE gchar *
g_paste_daemon_upload_finish (GPasteDaemon *self,
                              GAsyncResult *result,
                              GError      **error)
{
    g_return_val_if_fail (G_PASTE_IS_DAEMON (self), NULL);
    g_return_val_if_fail (g_task_is_valid (result, self), NULL);

    return g_task_propagate_pointer (G_TASK (result), error);
}

/****************/
/* Keybindings  */
/****************/

/* Whether a shortcut may change the history's items, as every D-Bus method
 * changing one asks (g_paste_daemon_methods_check_owned ()): while the store is
 * handed over the change would be recorded nowhere, and the reload ending the
 * handover would undo it. */
static gboolean
keybinding_may_change (GPasteHistory *history)
{
    g_autoptr (GError) error = NULL;

    if (g_paste_history_sync (history, g_paste_history_get_current (history), &error))
        return TRUE;

    g_message ("Keyboard shortcut ignored: %s", error->message);
    return FALSE;
}

/* Takes the daemon, not just the history: the countdown the new password calls
 * for is armed on the clipboards, which the history has no reach into. */
static void
keybinding_make_password (GPasteKeybinding *self G_GNUC_UNUSED,
                          gpointer          data)
{
    GPasteDaemon *daemon = data;
    GPasteHistory *history = daemon->history;
    GPasteItem *first = g_paste_history_get (history, 0);

    /* A text item alone: a password is one already, and a shortcut carries
     * neither a name nor a timeout, so there is nothing it could change about
     * one. */
    if (!first || !G_PASTE_IS_TEXT_ITEM (first) || !keybinding_may_change (history))
        return;

    /* No timeout of its own to hand over, so the item takes the one the settings
     * carry -- which is what %G_PASTE_PASSWORD_TIMEOUT_UNCHANGED asks for. */
    g_autofree gchar *uuid = g_paste_history_make_password (history, g_paste_item_get_uuid (first), NULL,
                                                            G_PASTE_PASSWORD_TIMEOUT_UNCHANGED);
    /* As in g_paste_daemon_methods_make_password(): the selection carries the
     * value the password was just made from, and the history publishes nothing,
     * so the countdown the timeout calls for is ours to ask for. */
    GPasteItem *password = g_paste_history_get_by_uuid (history, uuid);

    if (password)
        g_paste_clipboards_manager_rearm_password (daemon->clipboards_manager, password);
}

static void
keybinding_pop (GPasteKeybinding *self G_GNUC_UNUSED,
                gpointer          data)
{
    if (keybinding_may_change (data))
        g_paste_history_remove (data, 0);
}

static void
keybinding_show_history (GPasteKeybinding *self G_GNUC_UNUSED,
                         gpointer          data)
{
    g_autoptr (GError) error = NULL;

    g_paste_daemon_show_history (data, &error);
    if (error)
        g_warning ("Failed to show history: %s", error->message);
}

static void
keybinding_sync_clipboard_to_primary (GPasteKeybinding *self G_GNUC_UNUSED,
                                      gpointer          data)
{
    g_paste_clipboards_manager_sync_from_to (data, TRUE);
}

static void
keybinding_sync_primary_to_clipboard (GPasteKeybinding *self G_GNUC_UNUSED,
                                      gpointer          data)
{
    g_paste_clipboards_manager_sync_from_to (data, FALSE);
}

static void
keybinding_launch_ui (GPasteKeybinding *self G_GNUC_UNUSED,
                      gpointer          data G_GNUC_UNUSED)
{
    g_paste_util_spawn ("Ui");
}

static void
on_keybinding_upload_done (GObject      *source_object,
                           GAsyncResult *res,
                           gpointer      user_data G_GNUC_UNUSED)
{
    GPasteDaemon *self = G_PASTE_DAEMON (source_object);
    g_autoptr (GError) error = NULL;
    g_autofree gchar *url = g_paste_daemon_upload_finish (self, res, &error);

    if (g_error_matches (error, G_IO_ERROR, G_IO_ERROR_CANCELLED))
        return;

    if (!url)
    {
        g_warning ("Upload failed: %s", error->message);
        return;
    }

    /* A shortcut has nobody to hand a url back to: putting it where the user
     * can paste it is the whole of what pressing the shortcut does. */
    const GPasteDaemonMethods methods = G_PASTE_DAEMON_METHODS (self);

    g_paste_daemon_methods_copy_uploaded (&methods, url);
}

static void
keybinding_upload (GPasteKeybinding *self G_GNUC_UNUSED,
                   gpointer          data)
{
    g_paste_daemon_upload (data, NULL, on_keybinding_upload_done, NULL);
}

static void
g_paste_daemon_activate_default_keybindings (GPasteDaemon *self)
{
    GPasteKeybinder *keybinder = self->keybinder;
    GPasteHistory *history = self->history;
    GPasteClipboardsManager *clipboards_manager = self->clipboards_manager;
    /* What to run for each shortcut, and what to run it on. Everything the user
     * ever sees -- the description the shortcut UIs show, the short label the
     * portal lists it under -- comes from the shared table instead, so a
     * shortcut added there and forgotten here warns rather than silently doing
     * nothing. */
    const struct
    {
        const gchar           *key;
        GPasteKeybindingGetter getter;
        GPasteKeybindingFunc   callback;
        gpointer               user_data;
    } handlers[] = {
        { G_PASTE_MAKE_PASSWORD_SETTING,             g_paste_settings_get_make_password,             keybinding_make_password,             self               },
        { G_PASTE_POP_SETTING,                       g_paste_settings_get_pop,                       keybinding_pop,                       history            },
        { G_PASTE_SHOW_HISTORY_SETTING,              g_paste_settings_get_show_history,              keybinding_show_history,              self               },
        { G_PASTE_SYNC_CLIPBOARD_TO_PRIMARY_SETTING, g_paste_settings_get_sync_clipboard_to_primary, keybinding_sync_clipboard_to_primary, clipboards_manager },
        { G_PASTE_SYNC_PRIMARY_TO_CLIPBOARD_SETTING, g_paste_settings_get_sync_primary_to_clipboard, keybinding_sync_primary_to_clipboard, clipboards_manager },
        { G_PASTE_LAUNCH_UI_SETTING,                 g_paste_settings_get_launch_ui,                 keybinding_launch_ui,                 NULL               },
        { G_PASTE_UPLOAD_SETTING,                    g_paste_settings_get_upload,                    keybinding_upload,                    self               },
    };

    gsize n_shortcuts = 0;
    const GPasteKeybindingInfo *shortcuts = g_paste_keybindings (&n_shortcuts);

    for (gsize i = 0; i < n_shortcuts; ++i)
    {
        const GPasteKeybindingInfo *shortcut = &shortcuts[i];
        gsize h;

        for (h = 0; h < G_N_ELEMENTS (handlers); ++h)
        {
            if (g_paste_str_equal (handlers[h].key, shortcut->key))
                break;
        }

        if (h == G_N_ELEMENTS (handlers))
        {
            g_warning ("Nothing to run for the \"%s\" keyboard shortcut", shortcut->key);
            continue;
        }

        g_paste_keybinder_add_keybinding (keybinder,
                                          g_paste_keybinding_new (shortcut->key,
                                                                  _(shortcut->portal_label),
                                                                  handlers[h].getter,
                                                                  handlers[h].callback,
                                                                  handlers[h].user_data));
    }

    g_paste_keybinder_activate_all (keybinder);
}

/****************/
/* DBus Methods */
/****************/

/* One handler per method on the generated skeleton, connected swapped so @self
 * comes first. Each one runs the method and answers the invocation: the error it
 * set, or the reply its matching completion builds. Returning %TRUE says the
 * method was handled, which is what stops the skeleton from replying itself.
 *
 * They come in three shapes, by whether the method answers anything and
 * whether it can fail. PARAMS is what the interface adds after the invocation
 * and ARGS the matching arguments to forward; both are parenthesized so the
 * preprocessor takes each as one macro argument, and ARGLIST supplies the comma
 * joining them -- disappearing when the list is empty.
 *
 * A handler's signature is not checked against the vfunc it is connected to, so
 * concentrating them here is also what keeps that hazard in three places rather
 * than thirty-three: compare these against struct _GPasteDaemon3Iface by hand
 * when a method changes. */
#define ARGLIST(...) , ##__VA_ARGS__

#define G_PASTE_DAEMON_ANSWER(complete_call)                                            \
    do {                                                                                \
        if (error)                                                                      \
            g_dbus_method_invocation_take_error (invocation, g_steal_pointer (&error)); \
        else                                                                            \
            complete_call;                                                              \
        return TRUE;                                                                    \
    } while (FALSE)

#define G_PASTE_DAEMON_HANDLER_HEAD(name, PARAMS)                                     \
    static gboolean                                                                   \
    g_paste_daemon_handle_##name (GPasteDaemon          *self,                        \
                                  GDBusMethodInvocation *invocation ARGLIST PARAMS)

/* Answers nothing, may fail. */
#define G_PASTE_DAEMON_HANDLER_ERR(name, PARAMS, ARGS)                                        \
    G_PASTE_DAEMON_HANDLER_HEAD (name, PARAMS)                                                \
    {                                                                                         \
        const GPasteDaemonMethods methods = G_PASTE_DAEMON_METHODS (self);                    \
        g_autoptr (GError) error = NULL;                                                      \
                                                                                              \
        g_paste_daemon_methods_##name (&methods ARGLIST ARGS, &error);                        \
                                                                                              \
        G_PASTE_DAEMON_ANSWER (g_paste_daemon3_complete_##name (self->skeleton, invocation)); \
    }

/* Answers something, cannot fail. */
#define G_PASTE_DAEMON_HANDLER_RET(name, PARAMS, ARGS)                                           \
    G_PASTE_DAEMON_HANDLER_HEAD (name, PARAMS)                                                   \
    {                                                                                            \
        const GPasteDaemonMethods methods = G_PASTE_DAEMON_METHODS (self);                       \
                                                                                                 \
        g_paste_daemon3_complete_##name (self->skeleton,                                         \
                                         invocation,                                             \
                                         g_paste_daemon_methods_##name (&methods ARGLIST ARGS)); \
                                                                                                 \
        return TRUE;                                                                             \
    }

/* Answers something, may fail: @decl declares what the method hands back and
 * @value is what the completion sends. */
#define G_PASTE_DAEMON_HANDLER_RET_ERR(name, decl, value, PARAMS, ARGS)                              \
    G_PASTE_DAEMON_HANDLER_HEAD (name, PARAMS)                                                       \
    {                                                                                                \
        const GPasteDaemonMethods methods = G_PASTE_DAEMON_METHODS (self);                           \
        g_autoptr (GError) error = NULL;                                                             \
        decl = g_paste_daemon_methods_##name (&methods ARGLIST ARGS, &error);                        \
                                                                                                     \
        G_PASTE_DAEMON_ANSWER (g_paste_daemon3_complete_##name (self->skeleton, invocation, value)); \
    }

G_PASTE_DAEMON_HANDLER_RET_ERR (add_file,
                                g_autofree gchar *uuid, uuid,
                                (const gchar *path), (path))

G_PASTE_DAEMON_HANDLER_RET_ERR (add_text,
                                g_autofree gchar *uuid, uuid,
                                (const gchar *text), (text))

G_PASTE_DAEMON_HANDLER_RET_ERR (add_password,
                                g_autofree gchar *uuid, uuid,
                                (const gchar *name, const gchar *password, guint timeout), (name, password, timeout))

G_PASTE_DAEMON_HANDLER_ERR (backup_history, (const gchar *history, const gchar *backup), (history, backup))

static gboolean
g_paste_daemon_handle_change_passphrase (GPasteDaemon          *self,
                                         GDBusMethodInvocation *invocation)
{
    g_autoptr (GError) error = NULL;

    g_paste_daemon_change_passphrase (self, &error);

    G_PASTE_DAEMON_ANSWER (g_paste_daemon3_complete_change_passphrase (self->skeleton, invocation));
}

G_PASTE_DAEMON_HANDLER_ERR (delete_item, (const gchar *uuid), (uuid))

G_PASTE_DAEMON_HANDLER_ERR (delete_history, (const gchar *name), (name))

G_PASTE_DAEMON_HANDLER_ERR (delete_password, (const gchar *name), (name))

static void
on_history_emptied (GObject      *source_object G_GNUC_UNUSED,
                    GAsyncResult *result,
                    gpointer      user_data)
{
    GDBusMethodInvocation *invocation = user_data;
    GError *error = NULL;

    if (g_paste_daemon_methods_empty_history_finish (result, &error))
        g_dbus_method_invocation_return_value (invocation, NULL);
    else
        g_dbus_method_invocation_take_error (invocation, error);
}

/* Answered once the history is empty: another history is written on a worker
 * thread (g_paste_daemon_methods_empty_history_async ()). */
static gboolean
g_paste_daemon_handle_empty_history (GPasteDaemon          *self,
                                     GDBusMethodInvocation *invocation,
                                     const gchar           *name)
{
    const GPasteDaemonMethods methods = G_PASTE_DAEMON_METHODS (self);

    g_paste_daemon_methods_empty_history_async (&methods, name, on_history_emptied, invocation);

    return TRUE;
}

G_PASTE_DAEMON_HANDLER_RET (get_favourites, (), ())

G_PASTE_DAEMON_HANDLER_RET (get_history, (), ())

G_PASTE_DAEMON_HANDLER_RET (get_history_size, (), ())

G_PASTE_DAEMON_HANDLER_RET_ERR (get_image,
                                GVariant *image, image,
                                (const gchar *uuid), (uuid))

G_PASTE_DAEMON_HANDLER_RET_ERR (get_item,
                                GVariant *item, item,
                                (const gchar *uuid), (uuid))

G_PASTE_DAEMON_HANDLER_RET_ERR (get_item_at_index,
                                GVariant *item, item,
                                (guint64 index), (index))

G_PASTE_DAEMON_HANDLER_RET_ERR (get_items,
                                GVariant *items, items,
                                (const gchar * const *uuids), (uuids))

G_PASTE_DAEMON_HANDLER_RET_ERR (get_password_timeout,
                                guint timeout, timeout,
                                (const gchar *uuid), (uuid))

G_PASTE_DAEMON_HANDLER_RET_ERR (get_uris,
                                g_auto (GStrv) uris, (const gchar * const *) uris,
                                (const gchar *uuid), (uuid))

G_PASTE_DAEMON_HANDLER_RET_ERR (list_histories,
                                GVariant *histories, histories,
                                (), ())

G_PASTE_DAEMON_HANDLER_RET_ERR (make_password,
                                g_autofree gchar *new_uuid, new_uuid,
                                (const gchar *uuid, const gchar *name, guint timeout), (uuid, name, timeout))

G_PASTE_DAEMON_HANDLER_RET_ERR (merge,
                                g_autofree gchar *uuid, uuid,
                                (const gchar *decoration, const gchar *separator, const gchar * const *uuids), (decoration, separator, uuids))

static gboolean
g_paste_daemon_handle_report_extension_state (GPasteDaemon          *self,
                                              GDBusMethodInvocation *invocation,
                                              gboolean               active)
{
    const GPasteDaemonMethods methods = G_PASTE_DAEMON_METHODS (self);

    g_paste_daemon_methods_extension_state_changed (&methods, active);
    g_paste_daemon3_complete_report_extension_state (self->skeleton, invocation);

    return TRUE;
}

static gboolean
g_paste_daemon_handle_reexecute (GPasteDaemon          *self,
                                 GDBusMethodInvocation *invocation)
{
    /* Handed the invocation rather than completing it here: the reply is the one
     * this daemon is not meant to send (see on_reexecute_passwords_expired()). */
    g_paste_daemon_reexecute_after_expiry (self, invocation);

    return TRUE;
}

G_PASTE_DAEMON_HANDLER_RET_ERR (replace,
                                g_autofree gchar *new_uuid, new_uuid,
                                (const gchar *uuid, const gchar *contents), (uuid, contents))

G_PASTE_DAEMON_HANDLER_RET_ERR (search,
                                GVariant *results, results,
                                (const gchar *query), (query))

G_PASTE_DAEMON_HANDLER_ERR (select, (const gchar *uuid), (uuid))

G_PASTE_DAEMON_HANDLER_ERR (set_active, (gboolean active), (active))

G_PASTE_DAEMON_HANDLER_ERR (set_favourite, (const gchar *uuid, gboolean favourite), (uuid, favourite))

static gboolean
g_paste_daemon_handle_show_history (GPasteDaemon          *self,
                                    GDBusMethodInvocation *invocation)
{
    g_autoptr (GError) error = NULL;

    g_paste_daemon_show_history (self, &error);

    G_PASTE_DAEMON_ANSWER (g_paste_daemon3_complete_show_history (self->skeleton, invocation));
}

G_PASTE_DAEMON_HANDLER_ERR (strip_rich_text, (const gchar *uuid), (uuid))

G_PASTE_DAEMON_HANDLER_ERR (switch_history, (const gchar *name), (name))

/* The methods that cannot answer from their handler, Upload and UploadAndCopy:
 * the url exists only once the upload command has finished, so the invocation
 * is carried along and answered from the callback -- the url, and for
 * UploadAndCopy the address kept as the shortcut keeps it first. */
static void
g_paste_daemon_answer_upload (GPasteDaemon          *self,
                              GAsyncResult          *res,
                              GDBusMethodInvocation *invocation,
                              gboolean               copy)
{
    g_autoptr (GError) error = NULL;
    g_autofree gchar *url = g_paste_daemon_upload_finish (self, res, &error);

    if (!url)
    {
        g_dbus_method_invocation_take_error (invocation, g_steal_pointer (&error));
        return;
    }

    if (!copy)
    {
        g_paste_daemon3_complete_upload (self->skeleton, invocation, url);
        return;
    }

    const GPasteDaemonMethods methods = G_PASTE_DAEMON_METHODS (self);

    g_paste_daemon_methods_copy_uploaded (&methods, url);
    g_paste_daemon3_complete_upload_and_copy (self->skeleton, invocation, url);
}

static void
on_upload_done (GObject      *source_object,
                GAsyncResult *res,
                gpointer      user_data)
{
    g_paste_daemon_answer_upload (G_PASTE_DAEMON (source_object), res, user_data, FALSE);
}

static gboolean
g_paste_daemon_handle_upload (GPasteDaemon          *self,
                              GDBusMethodInvocation *invocation,
                              const gchar           *uuid)
{
    g_paste_daemon_upload (self, uuid, on_upload_done, invocation);

    return TRUE;
}

static void
on_upload_and_copy_done (GObject      *source_object,
                         GAsyncResult *res,
                         gpointer      user_data)
{
    g_paste_daemon_answer_upload (G_PASTE_DAEMON (source_object), res, user_data, TRUE);
}

static gboolean
g_paste_daemon_handle_upload_and_copy (GPasteDaemon          *self,
                                       GDBusMethodInvocation *invocation,
                                       const gchar           *uuid)
{
    g_paste_daemon_upload (self, uuid, on_upload_and_copy_done, invocation);

    return TRUE;
}

#undef ARGLIST

/* Every method the interface declares, wired in one place so a method added to
 * the XML without a handler here shows up as a missing symbol rather than a
 * silent "not implemented" on the bus. Swapped, so @self leads. */
static void
g_paste_daemon_connect_handlers (GPasteDaemon *self)
{
    static const struct
    {
        const gchar *signal_name;
        GCallback    handler;
    } handlers[] = {
        { "handle-add-file",                    G_CALLBACK (g_paste_daemon_handle_add_file)                    },
        { "handle-add-password",                G_CALLBACK (g_paste_daemon_handle_add_password)                },
        { "handle-add-text",                    G_CALLBACK (g_paste_daemon_handle_add_text)                    },
        { "handle-backup-history",              G_CALLBACK (g_paste_daemon_handle_backup_history)              },
        { "handle-change-passphrase",           G_CALLBACK (g_paste_daemon_handle_change_passphrase)           },
        { "handle-delete-history",              G_CALLBACK (g_paste_daemon_handle_delete_history)              },
        { "handle-delete-item",                 G_CALLBACK (g_paste_daemon_handle_delete_item)                 },
        { "handle-delete-password",             G_CALLBACK (g_paste_daemon_handle_delete_password)             },
        { "handle-empty-history",               G_CALLBACK (g_paste_daemon_handle_empty_history)               },
        { "handle-get-favourites",              G_CALLBACK (g_paste_daemon_handle_get_favourites)              },
        { "handle-get-history",                 G_CALLBACK (g_paste_daemon_handle_get_history)                 },
        { "handle-get-history-size",            G_CALLBACK (g_paste_daemon_handle_get_history_size)            },
        { "handle-get-image",                   G_CALLBACK (g_paste_daemon_handle_get_image)                   },
        { "handle-get-item",                    G_CALLBACK (g_paste_daemon_handle_get_item)                    },
        { "handle-get-item-at-index",           G_CALLBACK (g_paste_daemon_handle_get_item_at_index)           },
        { "handle-get-items",                   G_CALLBACK (g_paste_daemon_handle_get_items)                   },
        { "handle-get-password-timeout",        G_CALLBACK (g_paste_daemon_handle_get_password_timeout)        },
        { "handle-get-uris",                    G_CALLBACK (g_paste_daemon_handle_get_uris)                    },
        { "handle-list-histories",              G_CALLBACK (g_paste_daemon_handle_list_histories)              },
        { "handle-make-password",               G_CALLBACK (g_paste_daemon_handle_make_password)               },
        { "handle-merge",                       G_CALLBACK (g_paste_daemon_handle_merge)                       },
        { "handle-reexecute",                   G_CALLBACK (g_paste_daemon_handle_reexecute)                   },
        { "handle-replace",                     G_CALLBACK (g_paste_daemon_handle_replace)                     },
        { "handle-report-extension-state",      G_CALLBACK (g_paste_daemon_handle_report_extension_state)      },
        { "handle-search",                      G_CALLBACK (g_paste_daemon_handle_search)                      },
        { "handle-select",                      G_CALLBACK (g_paste_daemon_handle_select)                      },
        { "handle-set-active",                  G_CALLBACK (g_paste_daemon_handle_set_active)                  },
        { "handle-set-favourite",               G_CALLBACK (g_paste_daemon_handle_set_favourite)               },
        { "handle-show-history",                G_CALLBACK (g_paste_daemon_handle_show_history)                },
        { "handle-strip-rich-text",             G_CALLBACK (g_paste_daemon_handle_strip_rich_text)             },
        { "handle-switch-history",              G_CALLBACK (g_paste_daemon_handle_switch_history)              },
        { "handle-upload",                      G_CALLBACK (g_paste_daemon_handle_upload)                      },
        { "handle-upload-and-copy",             G_CALLBACK (g_paste_daemon_handle_upload_and_copy)             },
    };

    for (guint64 i = 0; i < G_N_ELEMENTS (handlers); ++i)
        g_signal_connect_swapped (self->skeleton, handlers[i].signal_name, handlers[i].handler, self);
}

/* Drop the export (and the signal wiring that goes with it), so the object path
 * is free again for a successor daemon built on the same, still-alive
 * connection — which is exactly what the gnome-shell host does on re-enable.
 * dispose () runs it too; @registered makes it a no-op once it has run. */
static void
g_paste_daemon_unregister_on_connection (GPasteBusObject *self)
{
    GPasteDaemon *daemon = G_PASTE_DAEMON (self);

    /* A daemon off the bus is one going away: an upload finishing later would
     * put its address on a clipboard the user has since moved on from. */
    g_paste_daemon_cancel_uploads (daemon);

    if (!daemon->registered)
        return;

    /* The startup update tells this export's clients to read everything again:
     * with the export gone, it has nobody left to tell. */
    g_clear_handle_id (&daemon->startup_changed_id, g_source_remove);
    g_dbus_interface_skeleton_unexport (G_DBUS_INTERFACE_SKELETON (daemon->skeleton));

    g_signal_group_set_target (daemon->settings_signals, NULL);
    g_signal_group_set_target (daemon->history_signals, NULL);
    g_signal_group_set_target (daemon->screensaver_signals, NULL);

    daemon->registered = FALSE;
}

static void
g_paste_daemon_on_history_update (GPasteDaemon      *self,
                                  GPasteUpdateAction action,
                                  GPasteUpdateTarget target,
                                  const gchar       *uuid,
                                  guint64            position,
                                  gpointer           user_data G_GNUC_UNUSED)
{
    g_paste_daemon_update (self, action, target, uuid, position);
}

/* Which history is in use is state, so it is a property: the skeleton turns the
 * assignment into the PropertiesChanged a client listens for. */
static void
g_paste_daemon_on_history_switch (GPasteDaemon *self,
                                  const gchar  *name,
                                  gpointer      user_data G_GNUC_UNUSED)
{
    g_paste_daemon3_set_history (self->skeleton, name);
}

static void
g_paste_daemon_on_screensaver_active_changed (GPasteDaemon            *self,
                                              GParamSpec              *pspec G_GNUC_UNUSED,
                                              GPasteScreensaverClient *screensaver)
{
    if (!self->registered)
        return;

    gboolean active = g_paste_screensaver_client_is_active (screensaver);

    /* Blank the selection on both transitions: nothing of the history sits in
     * the clipboard while the screen is locked, and unlocking puts the head
     * item back over that blank unless it is a password. An empty text item is
     * always accepted, hence the unchecked return value here (unlike the one
     * below). */
    {
        g_autoptr (GPasteItem) item = g_paste_text_item_new ("");

        g_paste_clipboards_manager_select (self->clipboards_manager, item);
    }

    if (!active)
    {
        g_autoptr (GPasteItem) item = g_paste_history_dup (self->history, 0);

        /* As in g_paste_clipboard_provider_ensure_not_empty (): nobody asked to
         * put a password back, so the blank stays. */
        if (item && !G_PASTE_IS_PASSWORD_ITEM (item))
        {
            if (!g_paste_clipboards_manager_select (self->clipboards_manager, item))
                g_paste_history_remove (self->history, 0);
        }
    }
}

static void
_g_paste_daemon_changed (gpointer data)
{
    GPasteDaemon *self = G_PASTE_DAEMON (data);

    g_paste_daemon_update (self, G_PASTE_UPDATE_ACTION_REPLACE, G_PASTE_UPDATE_TARGET_ALL, "", 0);
}

/* One-shot startup nudge. Unregistering cancels it, and it holds the daemon
 * weakly for the reason g_paste_weak_ref_new () gives: dispose () is what
 * unregisters. */
static gboolean
_g_paste_daemon_changed_once (gpointer data)
{
    g_autoptr (GPasteDaemon) self = g_weak_ref_get (data);

    if (!self)
        return G_SOURCE_REMOVE;

    self->startup_changed_id = 0;
    _g_paste_daemon_changed (self);

    return G_SOURCE_REMOVE;
}

static void
g_paste_daemon_dispose (GObject *object)
{
    GPasteDaemon *self = G_PASTE_DAEMON (object);

    g_paste_daemon_unregister_on_connection (G_PASTE_BUS_OBJECT (self));

    g_clear_object (&self->skeleton);
    g_clear_object (&self->history_signals);
    g_clear_object (&self->settings_signals);
    g_clear_object (&self->screensaver_signals);
    g_clear_object (&self->history);
    g_clear_object (&self->settings);
    /* Disposed rather than only let go of: a read in flight holds the manager
     * (update_data_new ()), which until its last read lands would go on
     * reading every owner change off the providers -- synchronizing them, and
     * putting this history's head back on a released selection beside the
     * daemon that took over. Its dispose leaves such a read what it needs to
     * take a password off when it answers. */
    if (self->clipboards_manager)
        g_object_run_dispose (G_OBJECT (self->clipboards_manager));
    g_clear_object (&self->clipboards_manager);
    g_clear_object (&self->keybinder);
    g_clear_object (&self->screensaver);

    G_OBJECT_CLASS (g_paste_daemon_parent_class)->dispose (object);
}

static gboolean
g_paste_daemon_register_on_connection (GPasteBusObject *self,
                                       GDBusConnection *connection,
                                       GError         **error)
{
    GPasteDaemon *daemon = G_PASTE_DAEMON (self);

    if (!g_dbus_interface_skeleton_export (G_DBUS_INTERFACE_SKELETON (daemon->skeleton),
                                           connection,
                                           G_PASTE_DAEMON_OBJECT_PATH,
                                           error))
    {
        return FALSE;
    }

    g_signal_group_set_target (daemon->settings_signals, daemon->settings);
    g_signal_group_set_target (daemon->history_signals, daemon->history);
    /* Taken off with the others on unregistering, so put back for an export
     * that is not the first; %NULL until the client is ready, which sets it. */
    g_signal_group_set_target (daemon->screensaver_signals, daemon->screensaver);

    /* Seed "Active" from the setting: set_target does not emit notify, so the
     * handler above only ever runs on a later change, and the property would
     * read FALSE until the user toggled tracking. Here rather than in init() so
     * it is the state as of the moment the interface goes on the bus. */
    g_paste_daemon_tracking (daemon, NULL, daemon->settings);

    /* And "History" likewise, for the same reason one level down: the property
     * is written from the "switch" signal, which loading the history at startup
     * does not emit -- only a later change of history does. Unseeded it would
     * read "", and a client that sized or emptied "the current history" would
     * name a history called "" instead. The setting is where the daemon's own
     * history took its name from (g_paste_history_load_async (history, NULL)). */
    g_paste_daemon3_set_history (daemon->skeleton, g_paste_settings_get_history_name (daemon->settings));

    /* And "Version", though it never changes, for a reason of its own: a
     * client already running when this daemon took the name asked for every
     * property before the export and got nothing, so it learns them only from
     * the PropertiesChanged a set announces -- which the skeleton sends only
     * for one made while exported. Set in init () instead, the window would
     * never know which version a daemon it watched start is
     * (g_paste_ui_window_update_version_toast ()). No test checks it on a
     * whole daemon; the UI suite's stand-in sets it here too. */
    g_paste_daemon3_set_version (daemon->skeleton, VERSION);

    daemon->registered = TRUE;

    daemon->startup_changed_id = g_timeout_add_seconds_full (G_PRIORITY_DEFAULT, 1,
                                                             _g_paste_daemon_changed_once,
                                                             g_paste_weak_ref_new (self),
                                                             g_paste_weak_ref_free);
    g_source_set_name_by_id (daemon->startup_changed_id, "[GPaste] Startup - changed");

    return TRUE;
}

static void
g_paste_daemon_class_init (GPasteDaemonClass *klass)
{
    G_OBJECT_CLASS (klass)->dispose = g_paste_daemon_dispose;
    G_PASTE_BUS_OBJECT_CLASS (klass)->register_on_connection = g_paste_daemon_register_on_connection;
    G_PASTE_BUS_OBJECT_CLASS (klass)->unregister_on_connection = g_paste_daemon_unregister_on_connection;

    /**
     * GPasteDaemon::reexecute-self:
     * @gpaste_daemon: the object on which the signal was emitted
     *
     * The "reexecute-self" signal is emitted when the daemon is about
     * to reexecute itself into a new freshly spawned daemon.
     *
     * Returns: TRUE if the host accepted an in-process restart; FALSE on failure.
     */
    signals[REEXECUTE_SELF] = g_signal_new ("reexecute-self",
                                            G_PASTE_TYPE_DAEMON,
                                            G_SIGNAL_RUN_LAST,
                                            0, /* class offset */
                                            NULL, /* accumulator */
                                            NULL, /* accumulator data */
                                            NULL,
                                            G_TYPE_BOOLEAN,
                                            0);

    /**
     * GPasteDaemon::change-passphrase:
     * @gpaste_daemon: the object on which the signal was emitted
     *
     * The "change-passphrase" signal is emitted when the passphrase of the
     * encrypted history should be changed. Like "reexecute-self", the work
     * belongs to whoever hosts the daemon, which is also who supplies the
     * #GPastePrompt the prompts are put to the user through.
     */
    signals[CHANGE_PASSPHRASE] = g_signal_new ("change-passphrase",
                                               G_PASTE_TYPE_DAEMON,
                                               G_SIGNAL_RUN_LAST,
                                               0, /* class offset */
                                               NULL, /* accumulator */
                                               NULL, /* accumulator data */
                                               g_cclosure_marshal_VOID__VOID,
                                               G_TYPE_NONE,
                                               0);
}

static void
on_screensaver_client_ready (GObject      *source_object G_GNUC_UNUSED,
                             GAsyncResult *res,
                             gpointer      user_data)
{
    g_autoptr (GPasteDaemon) self = g_weak_ref_get (user_data);
    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteScreensaverClient) screensaver = g_paste_screensaver_client_new_finish (res, &error);

    g_paste_weak_ref_free (user_data);

    if (!self)
        return;

    if (error)
    {
        g_warning ("Couldn't watch screensaver state: %s", error->message);
        return;
    }

    self->screensaver = g_steal_pointer (&screensaver);
    g_signal_group_set_target (self->screensaver_signals, self->screensaver);
}

static void
on_portal_client_ready (GObject      *source_object G_GNUC_UNUSED,
                        GAsyncResult *res,
                        gpointer      user_data)
{
    g_autoptr (GPasteDaemon) self = g_weak_ref_get (user_data);
    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteGlobalShortcutClient) portal_client = g_paste_global_shortcut_client_new_finish (res, &error);

    g_paste_weak_ref_free (user_data);

    /* A session opened for a daemon gone meanwhile would grab its shortcuts
     * for nobody: dropped with the client, as the screensaver's is. */
    if (!self)
        return;

    if (error)
    {
        g_warning ("Couldn't connect to the GlobalShortcuts portal, keyboard shortcuts won't work: %s", error->message);
        return;
    }

    self->keybinder = g_paste_keybinder_new (self->settings, portal_client);
    g_paste_daemon_activate_default_keybindings (self);
}

static void
g_paste_daemon_init (GPasteDaemon *self)
{
    /* The skeleton owns the marshalling and the property store; the daemon owns
     * the skeleton. Its properties are all seeded once the interface is
     * exported (g_paste_daemon_register_on_connection ()). */
    self->skeleton = G_PASTE_DAEMON3 (g_paste_daemon3_skeleton_new ());

    g_paste_daemon_connect_handlers (self);

    /* The settings, history, clipboards manager and providers are wired up in
     * g_paste_daemon_new () from the caller-provided GPasteSettings. */

    self->history_signals = g_signal_group_new (G_PASTE_TYPE_HISTORY);
    g_signal_group_connect_swapped (self->history_signals,
                                    "update",
                                    G_CALLBACK (g_paste_daemon_on_history_update),
                                    self);
    g_signal_group_connect_swapped (self->history_signals,
                                    "switch",
                                    G_CALLBACK (g_paste_daemon_on_history_switch),
                                    self);

    self->settings_signals = g_signal_group_new (G_PASTE_TYPE_SETTINGS);
    g_signal_group_connect_swapped (self->settings_signals,
                                    "notify::" G_PASTE_TRACK_CHANGES_SETTING,
                                    G_CALLBACK (g_paste_daemon_tracking),
                                    self);

    self->screensaver_signals = g_signal_group_new (G_PASTE_TYPE_SCREENSAVER_CLIENT);
    g_signal_group_connect_swapped (self->screensaver_signals,
                                    "notify::active",
                                    G_CALLBACK (g_paste_daemon_on_screensaver_active_changed),
                                    self);

    /* Held weakly, as anything a dispose () has to end is (AGENTS.md):
     * gnome-shell disposes a daemon it lets go of (g_object_run_dispose () in
     * daemon.js), which clears the reference, and a client arriving after that
     * has no daemon to serve. */
    g_paste_screensaver_client_new (on_screensaver_client_ready, g_paste_weak_ref_new (self));
    g_paste_global_shortcut_client_new (on_portal_client_ready, g_paste_weak_ref_new (self));
}

/**
 * g_paste_daemon_new:
 * @settings: (transfer none): the #GPasteSettings shared by the whole daemon
 * @clipboard: (transfer none): the clipboard selection provider
 * @primary: (transfer none): the primary selection provider
 *
 * Create a new instance of #GPasteDaemon, handing the (backend-specific)
 * clipboard providers to the clipboards manager. The caller picks the backend
 * by choosing which #GPasteClipboardProvider implementations it builds, and
 * owns the single @settings instance threaded through the daemon (history,
 * clipboards manager and providers all share it).
 *
 * Returns: a newly allocated #GPasteDaemon
 *          free it with g_object_unref
 */
G_PASTE_VISIBLE GPasteDaemon *
g_paste_daemon_new (GPasteSettings          *settings,
                    GPasteClipboardProvider *clipboard,
                    GPasteClipboardProvider *primary)
{
    g_return_val_if_fail (G_PASTE_IS_SETTINGS (settings), NULL);
    g_return_val_if_fail (G_PASTE_IS_CLIPBOARD_PROVIDER (clipboard), NULL);
    g_return_val_if_fail (G_PASTE_IS_CLIPBOARD_PROVIDER (primary), NULL);

    GPasteDaemon *self = G_PASTE_DAEMON (g_object_new (G_PASTE_TYPE_DAEMON, NULL));

    /* "extension-paused" never written is a GPaste that had no such key having
     * run the tracking last -- one that resumed it on every return of the
     * extension. The tracking it left off under track-extension-state is
     * carried over as the extension's pause, once: the key is written either
     * way, so that a pause of the user's own made from here on is never taken
     * for one (g_paste_daemon_methods_extension_state_changed ()). */
    if (g_paste_settings_is_default (settings, G_PASTE_EXTENSION_PAUSED_SETTING))
        g_paste_settings_set_extension_paused (settings, g_paste_settings_get_track_extension_state (settings) && !g_paste_settings_get_track_changes (settings));

    self->settings = g_object_ref (settings);
    GPasteHistory *history = self->history = g_paste_history_new (settings);
    GPasteClipboardsManager *clipboards_manager = self->clipboards_manager = g_paste_clipboards_manager_new (history, settings);

    g_paste_clipboards_manager_add_clipboard (clipboards_manager, clipboard);
    g_paste_clipboards_manager_add_clipboard (clipboards_manager, primary);
    g_paste_clipboards_manager_activate (clipboards_manager);

    g_paste_history_load_async (history, NULL);

    return self;
}

#ifdef G_PASTE_ENABLE_GNOME_SHELL
/**
 * g_paste_daemon_new_meta:
 * @settings: a #GPasteSettings instance
 * @selection: the mutter MetaSelection (typed as #GObject to keep this API
 *             free of a libmutter dependency)
 *
 * Create a new instance of #GPasteDaemon driving the mutter clipboard backend,
 * for use from inside gnome-shell. The same @selection backs both the clipboard
 * and the primary provider.
 *
 * Returns: a newly allocated #GPasteDaemon
 *          free it with g_object_unref
 */
G_PASTE_VISIBLE GPasteDaemon *
g_paste_daemon_new_meta (GPasteSettings *settings,
                         GObject        *selection)
{
    g_return_val_if_fail (G_PASTE_IS_SETTINGS (settings), NULL);
    g_return_val_if_fail (META_IS_SELECTION (selection), NULL);

    MetaSelection *meta_selection = META_SELECTION (selection);
    g_autoptr (GPasteClipboardProvider) clipboard = g_paste_clipboard_meta_new_clipboard (meta_selection, settings);
    g_autoptr (GPasteClipboardProvider) primary = g_paste_clipboard_meta_new_primary (meta_selection, settings);

    GPasteDaemon *self = g_paste_daemon_new (settings, clipboard, primary);

    self->in_process = TRUE;

    return self;
}
#endif
