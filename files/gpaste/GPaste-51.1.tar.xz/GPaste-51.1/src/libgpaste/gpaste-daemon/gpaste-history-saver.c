// SPDX-FileCopyrightText: 2010-2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com>
// SPDX-License-Identifier: BSD-2-Clause

#include <gpaste-daemon/gpaste-history-saver.h>

#include <gio/gio.h>

typedef struct _GPasteHistorySaverWrite    GPasteHistorySaverWrite;
typedef struct _GPasteHistorySaverLoadData GPasteHistorySaverLoadData;

static void g_paste_history_saver_load_data_free (gpointer data);

/* Owns the asynchronous persistence of a history: it writes snapshots handed to
 * it (coalescing concurrent requests) and loads histories in the background,
 * handing the result back through a callback. It never touches the live history
 * list, so it shares no locking with the model.
 *
 * All of its state is only ever touched on the main thread: g_paste_history_saver_record
 * / _load run there, and the GTask completion callbacks fire on the thread-default
 * context they were created on. A load that has to wait for writes to land (see
 * g_paste_history_saver_start_load ()) is started by the completion of one, so
 * it completes on the context that write was recorded from rather than on the
 * one its caller had: a caller pushing a context of its own around a load while
 * writes are out would iterate that context in vain. Every caller runs on the
 * default one. A write's GTask takes the @owner GObject as its source, so it
 * stays alive until the write has landed. A load's takes none: a load can wait on
 * the storage lock for as long as another process holds it, and what gives that
 * wait up is the owner's dispose (), through g_paste_history_saver_detach (),
 * which a reference held for the wait would keep from ever running. Each task
 * also holds its own ref on the saver (released in its done callback), so an
 * owner that swaps its saver out mid-flight (g_paste_history_reload_backend)
 * cannot free one whose completion callback has not fired yet. */
struct _GPasteHistorySaver
{
    GObject parent_instance;

    GPasteStorageBackend          *backend;
    gpointer                       owner; /* not ref'd: owns us, outlives us */
    GPasteHistorySaverLoadedFunc   loaded;
    GPasteHistorySaverDivergedFunc diverged;

    /* The write a worker has out, borrowed from its task (which frees it only
     * once write_done () has run), or %NULL. */
    GPasteHistorySaverWrite       *writing;
    /* Pending writes (GPasteHistorySaverWrite*), applied in order. With a
     * non-incremental backend each entry is a full rewrite, so the queue is
     * coalesced down to the latest snapshot of each history. */
    GQueue                         pending;

    /* Handshake for g_paste_history_saver_drain(): the worker thread clears
     * @worker_running and signals @drain_cond when it finishes its write, so a
     * synchronous drain on the main thread can wait for it without spinning the
     * main loop (which is what would otherwise dispatch the write-done callback). */
    GMutex                         drain_mutex;
    GCond                          drain_cond;
    gboolean                       worker_running;

    gboolean                       load_in_progress;
    guint64                        load_generation;
    /* A load waiting for writes to land before it reads, or %NULL. */
    GPasteHistorySaverLoadData    *pending_load;
    /* The read the load in flight is doing. The generation says whether anyone
     * still wants that read's result; this is what stops the read itself, which
     * is the lock wait and then a whole history off disk. */
    GCancellable                  *load_cancellable;

    /* Set by g_paste_history_saver_detach(): the owner has replaced us or is
     * going away, so an in-flight load (which keeps us alive through the task's
     * own reference) must not hand its result back to it. */
    gboolean                       detached;
    /* Set while the owner has handed the store over (g_paste_history_flush ()):
     * the load it left pending behind a write stays pending, rather than take
     * the storage lock its host has just released -- or read a store a
     * migration is rewriting. A load asked for afterwards is one somebody
     * wants, and lifts it. */
    gboolean                       loads_held;
};

G_PASTE_DEFINE_TYPE (HistorySaver, history_saver, G_TYPE_OBJECT)

/****************/
/* Write path   */
/****************/

struct _GPasteHistorySaverWrite
{
    GPasteHistorySaver   *saver; /* not ref'd: the task's own ref keeps it alive */
    GPasteStorageBackend *backend;
    GPasteHistorySaveOp   op;
    gchar                *name;
    GPasteItem           *item; /* ref'd, or NULL */
    gchar                *uuid; /* or NULL */
    GList                *history;
};

static void
g_paste_history_saver_write_free (gpointer data)
{
    g_autofree GPasteHistorySaverWrite *d = data;
    g_clear_object (&d->backend);
    g_clear_pointer (&d->name, g_free);
    g_clear_object (&d->item);
    g_clear_pointer (&d->uuid, g_free);
    g_clear_list (&d->history, g_object_unref);
}

G_DEFINE_AUTOPTR_CLEANUP_FUNC (GPasteHistorySaverWrite, g_paste_history_saver_write_free)

static void
g_paste_history_saver_do_write (const GPasteHistorySaverWrite *data)
{
    switch (data->op)
    {
    case G_PASTE_HISTORY_SAVE_ADD:
        g_paste_storage_backend_add_item (data->backend, data->name, data->item, data->history);
        break;
    case G_PASTE_HISTORY_SAVE_REMOVE:
        g_paste_storage_backend_remove_item (data->backend, data->name, data->uuid, data->history);
        break;
    case G_PASTE_HISTORY_SAVE_REPLACE:
        g_paste_storage_backend_replace_item (data->backend, data->name, data->uuid, data->item, data->history);
        break;
    case G_PASTE_HISTORY_SAVE_CLEAR:
        g_paste_storage_backend_clear_history (data->backend, data->name, data->history);
        break;
    case G_PASTE_HISTORY_SAVE_FULL:
    default:
        g_paste_storage_backend_write_history (data->backend, data->name, data->history);
        break;
    }
}

static void
g_paste_history_saver_write_task (GTask        *task,
                                  gpointer      source_object G_GNUC_UNUSED,
                                  gpointer      task_data,
                                  GCancellable *cancellable G_GNUC_UNUSED)
{
    const GPasteHistorySaverWrite *data = task_data;
    GPasteHistorySaver *self = data->saver;

    g_paste_history_saver_do_write (data);

    /* Let a concurrent g_paste_history_saver_drain() know this write is done. */
    g_mutex_lock (&self->drain_mutex);
    self->worker_running = FALSE;
    g_cond_signal (&self->drain_cond);
    g_mutex_unlock (&self->drain_mutex);

    g_task_return_boolean (task, TRUE);
}

static void g_paste_history_saver_write_done (GObject *source_object, GAsyncResult *result, gpointer user_data);
static void g_paste_history_saver_start_load (GPasteHistorySaver *self);

static void
g_paste_history_saver_start_write (GPasteHistorySaver *self)
{
    if (self->writing || g_queue_is_empty (&self->pending))
        return;

    /* Set before launching so a drain that runs before the worker starts still
     * sees the write as in flight and waits for it. */
    g_mutex_lock (&self->drain_mutex);
    self->worker_running = TRUE;
    g_mutex_unlock (&self->drain_mutex);

    g_autoptr (GPasteHistorySaverWrite) data = g_queue_pop_head (&self->pending);

    self->writing = data;

    /* Hold our own ref for the duration of the task: the owner keeps us alive
     * only as long as it still owns us, but g_paste_history_reload_backend()
     * swaps its saver out mid-flight, so rely on this ref (released in
     * write_done) rather than the owner to survive until the callback fires. */
    g_autoptr (GTask) task = g_task_new (self->owner, NULL, g_paste_history_saver_write_done, g_object_ref (self));
    g_task_set_static_name (task, "gpaste-history-write");
    g_task_set_task_data (task, g_steal_pointer (&data), g_paste_history_saver_write_free);
    g_task_run_in_thread (task, g_paste_history_saver_write_task);
}

/* Whether a full write of @name is queued, which brings its store level with
 * the history whatever failed before it. */
static gboolean
g_paste_history_saver_full_write_queued (GPasteHistorySaver *self,
                                         const gchar        *name)
{
    for (const GList *link = self->pending.head; link; link = link->next)
    {
        const GPasteHistorySaverWrite *pending = link->data;

        if (pending->op == G_PASTE_HISTORY_SAVE_FULL && g_paste_str_equal (pending->name, name))
            return TRUE;
    }

    return FALSE;
}

static void
g_paste_history_saver_write_done (GObject      *source_object G_GNUC_UNUSED,
                                  GAsyncResult *result        G_GNUC_UNUSED,
                                  gpointer      user_data)
{
    g_autoptr (GPasteHistorySaver) self = user_data; /* the ref taken in start_write */
    /* A write that failed left the store behind, which nothing would write
     * again before the next add carrying the history. A full one failing is
     * asked for again by the next change, not here, where a store refusing
     * every write would have it retried in a loop. */
    g_autofree gchar *diverged = (self->writing->op != G_PASTE_HISTORY_SAVE_FULL && !self->detached &&
                                  !g_paste_history_saver_full_write_queued (self, self->writing->name) &&
                                  g_paste_storage_backend_has_diverged (self->backend, self->writing->name))
        ? g_strdup (self->writing->name)
        : NULL;

    self->writing = NULL;

    if (diverged)
        self->diverged (self->owner, diverged);

    /* More changes may have queued up while we were writing: drain the next. */
    g_paste_history_saver_start_write (self);
    g_paste_history_saver_start_load (self);
}

/**
 * g_paste_history_saver_record:
 * @self: a #GPasteHistorySaver
 * @op: the kind of change to persist
 * @name: the history name to write to
 * @item: (nullable): the item involved (for %G_PASTE_HISTORY_SAVE_ADD / _REPLACE)
 * @uuid: (nullable): the uuid involved (for %G_PASTE_HISTORY_SAVE_REMOVE / _REPLACE)
 * @history: (transfer full) (nullable) (element-type GPasteItem): a snapshot of
 *           the items, used as-is by a non-incremental backend and to reconcile
 *           an incremental add; %NULL for the operations that never consume it
 *
 * Persist a change to @name in the background. An incremental backend applies
 * the queued changes in order; for a non-incremental one (which rewrites the
 * whole snapshot anyway) successive records for the same history coalesce into
 * its latest snapshot, so only the most recent state ever reaches its store.
 */
G_PASTE_VISIBLE void
g_paste_history_saver_record (GPasteHistorySaver *self,
                              GPasteHistorySaveOp op,
                              const gchar        *name,
                              GPasteItem         *item,
                              const gchar        *uuid,
                              GList              *history)
{
    g_return_if_fail (G_PASTE_IS_HISTORY_SAVER (self));

    /* A non-incremental backend ignores the granular hint and rewrites the whole
     * snapshot, so collapse this history's pending writes into a single full
     * one. Only this history's: one just switched away from may still have its
     * last snapshot waiting for its turn, and
     * nothing else would ever write it. */
    if (!g_paste_storage_backend_is_incremental (self->backend))
    {
        for (GList *link = self->pending.head; link;)
        {
            GList *next = link->next;
            GPasteHistorySaverWrite *pending = link->data;

            if (g_paste_str_equal (pending->name, name))
            {
                g_autoptr (GPasteHistorySaverWrite) dropped = pending;

                g_queue_delete_link (&self->pending, link);
            }

            link = next;
        }

        op = G_PASTE_HISTORY_SAVE_FULL;
        item = NULL;
        uuid = NULL;
    }

    g_autoptr (GPasteHistorySaverWrite) data = g_new0 (GPasteHistorySaverWrite, 1);
    data->saver = self;
    data->backend = g_object_ref (self->backend);
    data->op = op;
    data->name = g_strdup (name);
    data->item = item ? g_object_ref ((GPasteItem *) item) : NULL;
    data->uuid = g_strdup (uuid);
    data->history = history;

    g_queue_push_tail (&self->pending, g_steal_pointer (&data));

    g_paste_history_saver_start_write (self);
}

/* Wait for the in-flight worker write (if any) to finish. We cannot spin the
 * main loop here (that is where the write-done callback would run), so the
 * worker signals us directly when its write completes.
 *
 * Deliberately *not* clearing @writing: the drained task's completion callback
 * is still queued on the main context and will clear it (and pick up anything
 * recorded meanwhile). Clearing it here would let a record() made after a
 * resumed handover start a second worker while that callback then starts a
 * third — two threads rewriting the same history at once. */
static void
g_paste_history_saver_wait_worker (GPasteHistorySaver *self)
{
    g_mutex_lock (&self->drain_mutex);
    while (self->worker_running)
        g_cond_wait (&self->drain_cond, &self->drain_mutex);
    g_mutex_unlock (&self->drain_mutex);
}

/**
 * g_paste_history_saver_drain:
 * @self: a #GPasteHistorySaver
 *
 * Synchronously flush every queued write to disk and wait for any in-flight one
 * to finish. Meant to be called on the main thread from an exit path (the daemon
 * losing its name to a takeover, or being told to stop), so no clipboard change
 * is lost before the successor loads the history. Records made afterwards would
 * queue again, so the caller must stop recording (see g_paste_history_flush()).
 */
G_PASTE_VISIBLE void
g_paste_history_saver_drain (GPasteHistorySaver *self)
{
    g_return_if_fail (G_PASTE_IS_HISTORY_SAVER (self));

    g_paste_history_saver_wait_worker (self);

    /* Apply whatever is still queued synchronously, in order. */
    while (!g_queue_is_empty (&self->pending))
    {
        g_autoptr (GPasteHistorySaverWrite) data = g_queue_pop_head (&self->pending);

        g_paste_history_saver_do_write (data);
    }
}

/**
 * g_paste_history_saver_drain_history:
 * @self: a #GPasteHistorySaver
 * @name: the history whose writes have to land
 *
 * Synchronously finish the writes recorded for @name: wait for the one in
 * flight if it is @name's, and apply @name's queued ones, in order. Meant for
 * the main thread, before something reads, rewrites or unlinks @name's store
 * outside the saver. The writes of every other history carry on in the
 * background: they reach other stores, so making the caller wait for them
 * would only hold the main thread, and records made afterwards queue as ever.
 *
 * On the SQLite flavours, applying @name's operations here takes the one
 * cached connection, which the history in use's next operation opens back --
 * an Argon2id derivation each way on an encrypted store. They are seldom
 * still queued by then: a load waits for the whole queue on such a backend
 * (g_paste_history_saver_holds_writes_for ()) and nothing is recorded while it
 * runs, so the history left has landed before the one switched to is read or
 * written. Only one emptied while it loads, its load given up, and left at
 * once leaves operations of its own behind a write of the next; paying the
 * derivations then is kept over moving the drain to the worker.
 */
G_PASTE_VISIBLE void
g_paste_history_saver_drain_history (GPasteHistorySaver *self,
                                     const gchar        *name)
{
    g_return_if_fail (G_PASTE_IS_HISTORY_SAVER (self));

    if (self->writing && g_paste_str_equal (self->writing->name, name))
        g_paste_history_saver_wait_worker (self);

    for (GList *link = self->pending.head; link;)
    {
        GList *next = link->next;
        GPasteHistorySaverWrite *pending = link->data;

        if (g_paste_str_equal (pending->name, name))
        {
            g_autoptr (GPasteHistorySaverWrite) data = pending;

            g_queue_delete_link (&self->pending, link);
            g_paste_history_saver_do_write (data);
        }

        link = next;
    }
}

/* How many of @history the store answers for once it holds it, which is what
 * its count_history () counts: a plain flavour keeps none of its passwords, as
 * its writes leave them out, and a count takes no image while images-support
 * is off and, past the favourites, at most max-history-size items -- the
 * SQLite flavours' cap taking in the images it then leaves out, the file
 * flavours' not. */
static guint64
g_paste_history_saver_count_stored (GPasteHistorySaver *self,
                                    const GList        *history)
{
    GPasteSettings *settings = g_paste_storage_backend_get_settings (self->backend);
    gboolean encrypted = g_paste_storage_backend_is_encrypted (self->backend);
    gboolean images = g_paste_settings_get_images_support (settings);
    gboolean capped_images = g_paste_storage_backend_is_incremental (self->backend);
    guint64 max = g_paste_settings_get_max_history_size (settings);
    guint64 capped = 0;
    guint64 count = 0;

    for (const GList *h = history; h; h = h->next)
    {
        GPasteItemKind kind = g_paste_item_get_kind (h->data);
        gboolean favourite = g_paste_item_is_favourite (h->data);
        gboolean image = kind == G_PASTE_ITEM_KIND_IMAGE;

        if (!encrypted && kind == G_PASTE_ITEM_KIND_PASSWORD)
            continue;
        if (!favourite && (capped_images || images || !image) && capped++ >= max)
            continue;
        if (!images && image)
            continue;

        ++count;
    }

    return count;
}

/**
 * g_paste_history_saver_count_pending:
 * @self: a #GPasteHistorySaver
 * @name: a history name
 * @count: (out): how many items @name holds once its writes have landed
 *
 * How many items the store of @name is about to hold, when the latest write
 * recorded for it says: a snapshot of the whole history, which every write of a
 * non-incremental backend is, or an emptying. An incremental backend's other
 * operations carry no count of their own, and neither does a history nothing
 * is recorded for: its store then answers for it.
 *
 * Returns: whether @count was set
 */
G_PASTE_VISIBLE gboolean
g_paste_history_saver_count_pending (GPasteHistorySaver *self,
                                     const gchar        *name,
                                     guint64            *count)
{
    g_return_val_if_fail (G_PASTE_IS_HISTORY_SAVER (self), FALSE);
    g_return_val_if_fail (count, FALSE);

    const GPasteHistorySaverWrite *latest = NULL;

    for (const GList *link = self->pending.tail; link && !latest; link = link->prev)
    {
        const GPasteHistorySaverWrite *pending = link->data;

        if (g_paste_str_equal (pending->name, name))
            latest = pending;
    }

    if (!latest && self->writing && g_paste_str_equal (self->writing->name, name))
        latest = self->writing;

    if (!latest)
        return FALSE;

    switch (latest->op)
    {
    case G_PASTE_HISTORY_SAVE_FULL:
        *count = g_paste_history_saver_count_stored (self, latest->history);
        return TRUE;
    case G_PASTE_HISTORY_SAVE_CLEAR:
        *count = 0;
        return TRUE;
    case G_PASTE_HISTORY_SAVE_ADD:
        /* What rides along with an add, when anything does, is the whole
         * history it reconciles the store down to, never empty. */
        if (!latest->history)
            return FALSE;
        *count = g_paste_history_saver_count_stored (self, latest->history);
        return TRUE;
    case G_PASTE_HISTORY_SAVE_REMOVE:
    case G_PASTE_HISTORY_SAVE_REPLACE:
    default:
        return FALSE;
    }
}

/**
 * g_paste_history_saver_detach:
 * @self: a #GPasteHistorySaver
 *
 * Stop handing results back to the owner, and give up the load in flight. An
 * in-flight load keeps the saver alive through its own reference, so a saver that
 * has been replaced (see g_paste_history_reload_backend()) would otherwise still
 * install its stale, old-backend history over the one the new saver just loaded,
 * and one whose owner is going away would hand its result to an owner that is
 * gone: an owner detaches its saver before dropping it either way.
 */
G_PASTE_VISIBLE void
g_paste_history_saver_detach (GPasteHistorySaver *self)
{
    g_return_if_fail (G_PASTE_IS_HISTORY_SAVER (self));

    self->detached = TRUE;
    g_clear_pointer (&self->pending_load, g_paste_history_saver_load_data_free);

    /* The result was going to be dropped either way; this is the read producing
     * it, which the new saver is not waiting for and the old owner cannot use. */
    g_cancellable_cancel (self->load_cancellable);
}

/****************/
/* Load path    */
/****************/

struct _GPasteHistorySaverLoadData
{
    GPasteStorageBackend *backend;
    gchar                *name;
    guint64               generation;
    gboolean              save_after;
};

static void
g_paste_history_saver_load_data_free (gpointer data)
{
    g_autofree GPasteHistorySaverLoadData *d = data;
    g_clear_object (&d->backend);
    g_clear_pointer (&d->name, g_free);
}

G_DEFINE_AUTOPTR_CLEANUP_FUNC (GPasteHistorySaverLoadData, g_paste_history_saver_load_data_free)

typedef struct
{
    GList   *history;
    gsize    size;
    /* %FALSE when the history is on disk but could not be read back (a failed
     * decryption, parse or I/O error), so the owner can refuse to persist over
     * data it never managed to load. */
    gboolean readable;
} GPasteHistorySaverLoadResult;

static void
g_paste_history_saver_load_result_free (GPasteHistorySaverLoadResult *result)
{
    g_autofree GPasteHistorySaverLoadResult *r = result;
    g_clear_list (&r->history, g_object_unref);
}

G_DEFINE_AUTOPTR_CLEANUP_FUNC (GPasteHistorySaverLoadResult, g_paste_history_saver_load_result_free)

static void
g_paste_history_saver_load_task (GTask        *task,
                                 gpointer      source_object G_GNUC_UNUSED,
                                 gpointer      task_data,
                                 GCancellable *cancellable)
{
    const GPasteHistorySaverLoadData *data = task_data;
    GPasteHistorySaverLoadResult *result = g_new0 (GPasteHistorySaverLoadResult, 1);

    /* First file access of the process: block until any previous daemon has
     * finished flushing and released the lock, so we never load a stale history.
     * The wait is the longest thing a load does and the cancellable is what ends
     * it, an owner that has moved on having nothing to wait for. */
    gboolean locked = g_paste_storage_backend_lock (cancellable);

    /* Nobody is waiting for what a read would produce: the owner that asked has
     * moved on, and the generation check drops the result. @readable stays
     * %FALSE, a read that never happened not being one that succeeded.
     *
     * And where the wait above is what was given up on, no lock is held either:
     * reading then would open -- and, on the sqlite backend, create and
     * migrate -- a store the previous daemon may still be flushing, which is the
     * whole of what the lock is for. A load that found the lock already taken is
     * past that, it being installed process-wide. */
    if (!locked || g_cancellable_is_cancelled (cancellable))
    {
        g_task_return_pointer (task, result, (GDestroyNotify) g_paste_history_saver_load_result_free);

        return;
    }

    result->readable = g_paste_storage_backend_read_history (data->backend, data->name, cancellable,
                                                             &result->history, &result->size);
    g_task_return_pointer (task, result, (GDestroyNotify) g_paste_history_saver_load_result_free);
}

static void
g_paste_history_saver_load_done (GObject      *source_object G_GNUC_UNUSED,
                                 GAsyncResult *result,
                                 gpointer      user_data)
{
    g_autoptr (GPasteHistorySaver) self = user_data; /* the ref taken in _load */
    const GPasteHistorySaverLoadData *data = g_task_get_task_data (G_TASK (result));

    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteHistorySaverLoadResult) load_result = g_task_propagate_pointer (G_TASK (result), &error);

    /* The owner replaced us (g_paste_history_reload_backend): this result comes
     * from the backend it just moved away from, so installing it would clobber
     * the freshly loaded one. */
    if (self->detached)
        return;

    /* A newer load superseded this one: leave load_in_progress set (the newer
     * load will clear it) and drop this stale result, so is_loading() does not
     * briefly report FALSE and let a save race the still-running load. */
    if (data->generation != self->load_generation)
        return;

    self->load_in_progress = FALSE;

    if (!load_result)
    {
        if (error)
            g_warning ("Failed to load history: %s", error->message);
        return;
    }

    self->loaded (self->owner, g_steal_pointer (&load_result->history), load_result->size,
                  data->save_after, load_result->readable);
}

/* Whether writes still out have to land before @name is read. */
static gboolean
g_paste_history_saver_holds_writes_for (GPasteHistorySaver *self,
                                        const gchar        *name)
{
    /* An incremental backend applies each operation to the store it has open,
     * which on the SQLite flavours is a single cached connection: a read of
     * another history in between takes it from under the queued operations,
     * and on an encrypted store every reopening derives its key again, an
     * Argon2id pass each. Its reads wait for the whole queue. A store
     * rewritten whole is a file per history, so those wait only for the writes
     * of the history they read. */
    if (g_paste_storage_backend_is_incremental (self->backend))
        return self->writing || !g_queue_is_empty (&self->pending);

    if (self->writing && g_paste_str_equal (self->writing->name, name))
        return TRUE;

    for (const GList *link = self->pending.head; link; link = link->next)
    {
        const GPasteHistorySaverWrite *pending = link->data;

        if (g_paste_str_equal (pending->name, name))
            return TRUE;
    }

    return FALSE;
}

/* A history is read only once the writes recorded for it have landed: one
 * switched away from and straight back to would otherwise be read without its
 * last changes, installed without them and saved over them by the switch's own
 * full write. The load waits on the main thread, where nothing blocks on it, and
 * write_done () tries it again. */
static void
g_paste_history_saver_start_load (GPasteHistorySaver *self)
{
    if (!self->pending_load || self->loads_held || g_paste_history_saver_holds_writes_for (self, self->pending_load->name))
        return;

    g_autoptr (GPasteHistorySaverLoadData) data = g_steal_pointer (&self->pending_load);

    /* Hold our own ref for the task (see start_write): reload_backend may drop
     * the owner's ref to us while this load is still in flight. None on the
     * owner, though (see the top of this file). */
    g_autoptr (GTask) task = g_task_new (NULL, self->load_cancellable, g_paste_history_saver_load_done, g_object_ref (self));
    /* The result is what says whether the read completed (@readable), and the
     * generation and @detached are what say whether anyone still wants it, so
     * GTask must not turn a cancelled load into an error of its own on top. */
    g_task_set_check_cancellable (task, FALSE);
    g_task_set_static_name (task, "gpaste-history-load");
    g_task_set_task_data (task, g_steal_pointer (&data), g_paste_history_saver_load_data_free);
    g_task_run_in_thread (task, g_paste_history_saver_load_task);
}

/**
 * g_paste_history_saver_load:
 * @self: a #GPasteHistorySaver
 * @name: the history name to read
 * @save_after: whether the loaded history should be persisted back once installed
 *
 * Read @name in the background. When it completes (and has not been superseded
 * by a later load) the result is handed to the #GPasteHistorySaverLoadedFunc.
 */
/* Make @name's read the load wanted, superseding the one out: see
 * g_paste_history_saver_load (). */
static void
g_paste_history_saver_set_load (GPasteHistorySaver *self,
                                const gchar        *name,
                                gboolean            save_after)
{
    self->load_in_progress = TRUE;
    self->load_generation++;

    g_autoptr (GPasteHistorySaverLoadData) data = g_new (GPasteHistorySaverLoadData, 1);
    data->backend = g_object_ref (self->backend);
    data->name = g_strdup (name);
    data->generation = self->load_generation;
    /* save_after exists so a snapshot-rewriting backend persists its read-time
     * normalization (format upgrade, uuid dedup, truncation). An incremental
     * backend normalizes its storage on open instead, so writing the whole
     * history back after a load would be pure churn: drop the request. */
    data->save_after = save_after && !g_paste_storage_backend_is_incremental (self->backend);

    /* Whatever the load before it was reading, nobody is waiting for it: the
     * generation check below drops its result, and this is what stops the read
     * that was producing it. */
    g_paste_clear_cancellable (&self->load_cancellable);
    self->load_cancellable = g_cancellable_new ();

    g_clear_pointer (&self->pending_load, g_paste_history_saver_load_data_free);
    self->pending_load = g_steal_pointer (&data);
}

G_PASTE_VISIBLE void
g_paste_history_saver_load (GPasteHistorySaver *self,
                            const gchar        *name,
                            gboolean            save_after)
{
    g_return_if_fail (G_PASTE_IS_HISTORY_SAVER (self));

    g_paste_history_saver_set_load (self, name, save_after);
    self->loads_held = FALSE;
    g_paste_history_saver_start_load (self);
}

/**
 * g_paste_history_saver_load_when_released:
 * @self: a #GPasteHistorySaver
 * @name: the history name to read
 * @save_after: whether the loaded history should be persisted back once installed
 *
 * As g_paste_history_saver_load (), superseding the load out, but leaving loads
 * held as they are: while they are (g_paste_history_saver_hold_loads ()), the
 * read waits for the hold to be lifted.
 */
G_PASTE_VISIBLE void
g_paste_history_saver_load_when_released (GPasteHistorySaver *self,
                                          const gchar        *name,
                                          gboolean            save_after)
{
    g_return_if_fail (G_PASTE_IS_HISTORY_SAVER (self));

    g_paste_history_saver_set_load (self, name, save_after);
    g_paste_history_saver_start_load (self);
}

/**
 * g_paste_history_saver_abandon_load:
 * @self: a #GPasteHistorySaver
 *
 * Drop the load currently in flight, if any: its result is discarded instead of
 * being installed, is_loading() reports %FALSE right away, and the read itself
 * is given up on -- at the lock wait, or between the rows it is still building.
 * Meant for a caller that just invalidated what is being read (see
 * g_paste_history_delete()), so the load cannot resurrect it afterwards.
 */
G_PASTE_VISIBLE void
g_paste_history_saver_abandon_load (GPasteHistorySaver *self)
{
    g_return_if_fail (G_PASTE_IS_HISTORY_SAVER (self));

    /* The same mechanism a superseding load relies on: bumping the generation
     * makes load_done() drop the stale result, and the cancel stops the read
     * that would have produced it. Unlike that case there is no newer load to
     * clear @load_in_progress, so clear it here. */
    self->load_generation++;
    self->load_in_progress = FALSE;
    g_clear_pointer (&self->pending_load, g_paste_history_saver_load_data_free);
    g_cancellable_cancel (self->load_cancellable);
}

/**
 * g_paste_history_saver_hold_loads:
 * @self: a #GPasteHistorySaver
 * @held: whether to hold the loads
 *
 * Keep the load left pending while @held, and start it once it no longer
 * is: see @loads_held.
 */
G_PASTE_VISIBLE void
g_paste_history_saver_hold_loads (GPasteHistorySaver *self,
                                  gboolean            held)
{
    g_return_if_fail (G_PASTE_IS_HISTORY_SAVER (self));

    self->loads_held = held;
    g_paste_history_saver_start_load (self);
}

/**
 * g_paste_history_saver_is_loading:
 * @self: a #GPasteHistorySaver
 *
 * Returns: whether a load is currently in progress
 */
G_PASTE_VISIBLE gboolean
g_paste_history_saver_is_loading (GPasteHistorySaver *self)
{
    g_return_val_if_fail (G_PASTE_IS_HISTORY_SAVER (self), FALSE);

    return self->load_in_progress;
}

/****************/
/* GObject glue */
/****************/

static void
g_paste_history_saver_dispose (GObject *object)
{
    GPasteHistorySaver *self = G_PASTE_HISTORY_SAVER (object);

    g_queue_clear_full (&self->pending, g_paste_history_saver_write_free);
    g_clear_pointer (&self->pending_load, g_paste_history_saver_load_data_free);
    g_clear_object (&self->backend);

    /* A load in flight holds a ref on us through its task, so dispose () runs
     * only once it has reported: there is nothing left to cancel here. */
    g_clear_object (&self->load_cancellable);

    G_OBJECT_CLASS (g_paste_history_saver_parent_class)->dispose (object);
}

static void
g_paste_history_saver_finalize (GObject *object)
{
    GPasteHistorySaver *self = G_PASTE_HISTORY_SAVER (object);

    g_mutex_clear (&self->drain_mutex);
    g_cond_clear (&self->drain_cond);

    G_OBJECT_CLASS (g_paste_history_saver_parent_class)->finalize (object);
}

static void
g_paste_history_saver_class_init (GPasteHistorySaverClass *klass)
{
    G_OBJECT_CLASS (klass)->dispose = g_paste_history_saver_dispose;
    G_OBJECT_CLASS (klass)->finalize = g_paste_history_saver_finalize;
}

static void
g_paste_history_saver_init (GPasteHistorySaver *self)
{
    g_queue_init (&self->pending);
    g_mutex_init (&self->drain_mutex);
    g_cond_init (&self->drain_cond);
}

/**
 * g_paste_history_saver_new:
 * @backend: the #GPasteStorageBackend to read and write through
 * @owner: the GObject driving this saver, which detaches it before dropping
 *         it; the source of every write, which keeps it (and therefore this
 *         saver, which it owns) alive until the write lands, and passed back
 *         to @loaded and @diverged
 * @loaded: (scope notified): invoked when an async load completes
 * @diverged: (scope notified): invoked when a write left its store behind
 *
 * Create a new instance of #GPasteHistorySaver
 *
 * Returns: a newly allocated #GPasteHistorySaver
 *          free it with g_object_unref
 */
G_PASTE_VISIBLE GPasteHistorySaver *
g_paste_history_saver_new (GPasteStorageBackend          *backend,
                           gpointer                       owner,
                           GPasteHistorySaverLoadedFunc   loaded,
                           GPasteHistorySaverDivergedFunc diverged)
{
    g_return_val_if_fail (G_PASTE_IS_STORAGE_BACKEND (backend), NULL);
    g_return_val_if_fail (G_IS_OBJECT (owner), NULL);
    g_return_val_if_fail (loaded, NULL);
    g_return_val_if_fail (diverged, NULL);

    GPasteHistorySaver *self = g_object_new (G_PASTE_TYPE_HISTORY_SAVER, NULL);

    self->backend = g_object_ref (backend);
    self->owner = owner;
    self->loaded = loaded;
    self->diverged = diverged;

    return self;
}
