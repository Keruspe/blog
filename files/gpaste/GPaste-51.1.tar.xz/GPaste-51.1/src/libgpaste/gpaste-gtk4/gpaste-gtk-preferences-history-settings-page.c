// SPDX-FileCopyrightText: 2010-2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com>
// SPDX-License-Identifier: BSD-2-Clause

#include <gpaste-gtk4/gpaste-gtk-preferences-pages.h>
#include <gpaste-gtk4/gpaste-gtk-preferences-group.h>

typedef struct
{
    AdwButtonRow *row;
    guint64       revision;
} StorageMigration;

static void
storage_migration_free (StorageMigration *migration)
{
    g_object_unref (migration->row);
    g_free (migration);
}

G_DEFINE_AUTOPTR_CLEANUP_FUNC (StorageMigration, storage_migration_free)

static void
storage_migration_complete (StorageMigration *migration,
                            GError           *error)
{
    gtk_widget_set_sensitive (GTK_WIDGET (migration->row), TRUE);

    if (!error)
        return;

    GtkRoot *root = gtk_widget_get_root (GTK_WIDGET (migration->row));

    /* The dialog needs a window to go on, and the preferences can be closed
     * while the daemon is still answering -- which is exactly when a migration
     * that failed has nowhere to report itself. The journal is the only record
     * left then, so the failure is warned about rather than dropped
     * (/ui/migration/refused_without_window). Where there is a window the dialog
     * is the report, and no warning goes out for something the user was shown. */
    if (!root)
    {
        g_warning ("Could not change the storage backend: %s", error->message);
        return;
    }

    AdwAlertDialog *dialog = ADW_ALERT_DIALOG (adw_alert_dialog_new (_("Could Not Change Storage Backend"), error->message));

    adw_alert_dialog_add_response (dialog, "close", _("Close"));
    adw_dialog_present (ADW_DIALOG (dialog), GTK_WIDGET (root));
}

static void
on_storage_migration_done (GObject      *source,
                           GAsyncResult *result,
                           gpointer      user_data)
{
    g_autoptr (StorageMigration) migration = user_data;
    g_autoptr (GError) error = NULL;

    g_paste_client_reexecute_finish (G_PASTE_CLIENT (source), result, &error);
    if (error)
        g_paste_util_cancel_storage_migration (migration->revision);
    storage_migration_complete (migration, error);
}

static void
on_storage_migration_client_ready (GObject      *source G_GNUC_UNUSED,
                                   GAsyncResult *result,
                                   gpointer      user_data)
{
    g_autoptr (StorageMigration) migration = user_data;
    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_finish (result, &error);

    if (!client)
    {
        storage_migration_complete (migration, error);
        return;
    }

    migration->revision = g_paste_util_prepare_storage_migration ();
    g_paste_client_reexecute (client, NULL, on_storage_migration_done, g_steal_pointer (&migration));
}

static void
on_storage_migration_activated (AdwButtonRow *row,
                                gpointer      user_data G_GNUC_UNUSED)
{
    StorageMigration *migration = g_new0 (StorageMigration, 1);

    migration->row = g_object_ref (row);
    gtk_widget_set_sensitive (GTK_WIDGET (row), FALSE);
    g_paste_client_new (on_storage_migration_client_ready, migration);
}

static void
on_change_passphrase_activated (AdwButtonRow *row G_GNUC_UNUSED,
                                gpointer      user_data G_GNUC_UNUSED)
{
    g_autoptr (GError) error = NULL;
    g_autoptr (GPasteClient) client = g_paste_client_new_sync (&error);

    if (!client)
    {
        g_warning ("Could not connect to the daemon to change the passphrase: %s", error->message);
        return;
    }

    /* The daemon owns the prompts (it holds the current passphrase, and knows
     * how to raise them in its host), so ask it rather than doing any of it
     * here; the passphrases never travel over the bus. */
    g_paste_client_change_passphrase_sync (client, &error);

    if (error)
        g_warning ("Could not change the passphrase: %s", error->message);
}

static void
update_passphrase_sensitivity (GPasteSettings *settings,
                               GParamSpec     *pspec G_GNUC_UNUSED,
                               gpointer        user_data)
{
    gtk_widget_set_sensitive (GTK_WIDGET (user_data),
                              g_paste_storage_is_encrypted (g_paste_settings_get_storage_backend (settings)));
}

/**
 * g_paste_gtk_preferences_history_settings_page_new:
 * @settings: a #GPasteSettings instance
 *
 * Build the preferences page
 *
 * Returns: (transfer full): a newly allocated #AdwPreferencesPage
 */
AdwPreferencesPage *
g_paste_gtk_preferences_history_settings_page_new (GPasteSettings *settings)
{
    g_return_val_if_fail (G_PASTE_IS_SETTINGS (settings), NULL);

    AdwPreferencesPage *self = ADW_PREFERENCES_PAGE (g_object_new (ADW_TYPE_PREFERENCES_PAGE,
                                                                   "name", "history-settings",
                                                                   "title", _("History Settings"),
                                                                   "icon-name", "preferences-other",
                                                                   NULL));

    GPasteGtkPreferencesGroup *group = g_paste_gtk_preferences_group_new (_("Resource Limits"));
    g_paste_gtk_preferences_group_add_range_setting (group,
                                                     _("Max History Size"),
                                                     G_PASTE_MAX_HISTORY_SIZE_SETTING,
                                                     5, 65535, 5,
                                                     settings);
    g_paste_gtk_preferences_group_add_range_setting (group,
                                                     _("Max Memory Usage (MB)"),
                                                     G_PASTE_MAX_MEMORY_USAGE_SETTING,
                                                     5, 16383, 5,
                                                     settings);
    adw_preferences_page_add (self, ADW_PREFERENCES_GROUP (group));

    group = g_paste_gtk_preferences_group_new (_("Text Limits"));
    g_paste_gtk_preferences_group_add_range_setting (group,
                                                     _("Min Text Item Length"),
                                                     G_PASTE_MIN_TEXT_ITEM_SIZE_SETTING,
                                                     1, 65535, 1,
                                                     settings);
    g_paste_gtk_preferences_group_add_range_setting (group,
                                                     _("Max Text Item Length"),
                                                     G_PASTE_MAX_TEXT_ITEM_SIZE_SETTING,
                                                     1, 2147483647, 1,
                                                     settings);
    adw_preferences_page_add (self, ADW_PREFERENCES_GROUP (group));

    group = g_paste_gtk_preferences_group_new (_("Display Settings"));
    g_paste_gtk_preferences_group_add_range_setting (group,
                                                     _("Max Element Size When Displaying"),
                                                     G_PASTE_ELEMENT_SIZE_SETTING,
                                                     0, 511, 5,
                                                     settings);
    adw_preferences_page_add (self, ADW_PREFERENCES_GROUP (group));

    group = g_paste_gtk_preferences_group_new (_("Storage"));
    adw_preferences_group_set_description (ADW_PREFERENCES_GROUP (group),
                                           _("Choose how the history is stored on disk (plain or encrypted)."));
    g_paste_gtk_preferences_group_add_button (group,
                                              _("Change Storage Backend…"),
                                              G_CALLBACK (on_storage_migration_activated),
                                              NULL);

    /* Only an encrypted history has a passphrase to change, so the row stays
     * visible (it is how the feature is discovered) but insensitive otherwise.
     * Bound to the setting rather than read once: the button above can change
     * the backend from this very window. */
    AdwButtonRow *passphrase = g_paste_gtk_preferences_group_add_button (group,
                                                                          _("Change Passphrase…"),
                                                                          G_CALLBACK (on_change_passphrase_activated),
                                                                          NULL);

    update_passphrase_sensitivity (settings, NULL, passphrase);
    g_signal_connect_object (settings, "notify::" G_PASTE_STORAGE_BACKEND_SETTING,
                             G_CALLBACK (update_passphrase_sensitivity), passphrase, 0);

    adw_preferences_page_add (self, ADW_PREFERENCES_GROUP (group));

    return self;
}
