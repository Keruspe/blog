Name:           germinal
Version:        31
Release:        1%{?dist}
Summary:        Minimalist VTE-based terminal emulator

License:        GPL-3.0-or-later
URL:            https://github.com/Keruspe/Germinal
Source0:        https://www.imagination-land.org/files/%{name}/%{name}-%{version}.tar.xz

BuildRequires:  meson >= 1.1
BuildRequires:  gcc
BuildRequires:  gettext
BuildRequires:  systemd-rpm-macros
BuildRequires:  pkgconfig(glib-2.0) >= 2.76
BuildRequires:  pkgconfig(gio-2.0) >= 2.76
BuildRequires:  pkgconfig(gtk4) >= 4.10
BuildRequires:  pkgconfig(vte-2.91-gtk4) >= 0.78.0
BuildRequires:  pkgconfig(libadwaita-1) >= 1.6
BuildRequires:  pkgconfig(pango)
BuildRequires:  pkgconfig(libpcre2-8)
BuildRequires:  pkgconfig(dbus-1)
BuildRequires:  pkgconfig(systemd)
BuildRequires:  pkgconfig(gsettings-desktop-schemas) >= 3.28.1

Requires:       gsettings-desktop-schemas
Recommends:     tmux

%description
Germinal is a minimalist terminal emulator based on VTE. It relies on
tmux for tabs and pane management, and uses GSettings for configuration.

%prep
%autosetup

%build
%meson
%meson_build

%check
%meson_test

%install
%meson_install
%find_lang Germinal

%files -f Germinal.lang
%license COPYING
%doc README.md
%{_bindir}/germinal
%{_datadir}/applications/org.gnome.Germinal.desktop
%{_datadir}/glib-2.0/schemas/org.gnome.Germinal.gschema.xml
%{_datadir}/metainfo/org.gnome.Germinal.metainfo.xml
%{_datadir}/dbus-1/services/org.gnome.Germinal.service
%{_userunitdir}/org.gnome.Germinal.service

%changelog
* Sun Jun 07 2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com> - 31-1
- New About dialog, reachable from Preferences
- preferences/settings/about commands and desktop actions open the matching dialog
- Fix foreground/background colours with an empty palette

* Sat Jun 06 2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com> - 30-1
- Ctrl + left-click now opens the URL under the cursor

* Sat May 23 2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com> - 29-1
- Built-in Preferences dialog with per-setting reset buttons
- Palette editor with 16-colour Dracula theme support
- Default colour theme switched to Dracula

* Fri May 22 2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com> - 28-1
- In-buffer text search (Ctrl+F)
- Trackpad zoom support (Ctrl+scroll)
- Fix keyboard shortcut controller precedence

* Wed May 21 2026 Marc-Antoine Perennou <Marc-Antoine@Perennou.com> - 27-1
- Port to GTK4 and libadwaita
